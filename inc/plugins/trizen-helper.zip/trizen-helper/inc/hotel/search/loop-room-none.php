

<div class="empty-room-item">
    <?php esc_html_e( 'No room available', 'trizen-helper' ); ?>
</div>