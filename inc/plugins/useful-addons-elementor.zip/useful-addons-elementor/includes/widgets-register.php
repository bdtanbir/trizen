<?php
function UA_elementor_add_elements() {

    $is_component_active = UA_elementor_activated_modules();

    // load elements
    if( $is_component_active['advice'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/advice/advice.php';
    }
    if( $is_component_active['corona-live-map'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/corona-live-map/corona-live-map.php';
    }
	if( $is_component_active['icon-list'] ) {
		require_once UA_ELEMENTOR_PATH.'includes/Elements/icon-list/icon-list.php';
	}
	if( $is_component_active['hero-banner'] ) {
		require_once UA_ELEMENTOR_PATH.'includes/Elements/hero-banner/hero-banner.php';
	}
    if( $is_component_active['icon-box'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/icon-box/icon-box.php';
    }
    if( $is_component_active['button'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/button/button.php';
    }
    if( $is_component_active['counter'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/counter/counter.php';
    }
    if( $is_component_active['progressbar'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/progressbar/progressbar.php';
    }
    if( $is_component_active['tabs'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/tabs/tabs.php';
    }
    if( $is_component_active['post-grid'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/post-grid/post-grid.php';
    }
    if( $is_component_active['testimonial'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/testimonial/testimonial.php';
    }
    if( $is_component_active['divider'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/divider/divider.php';
    }
    if( $is_component_active['search-form'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/search-form/search-form.php';
    }
    if(class_exists('TravelHelper')) {
        if( $is_component_active['search-hotel'] ) {
            require_once UA_ELEMENTOR_PATH.'includes/Elements/search-hotel/search-hotel.php';
        }
        if( $is_component_active['hotel-slider'] ) {
            require_once UA_ELEMENTOR_PATH.'includes/Elements/hotel-slider/hotel-slider.php';
        }
    }
    if( $is_component_active['course-grid'] && function_exists('tutor') ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/course-grid/course-grid.php';
    }
    if( $is_component_active['social-media'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/social-media/social-media.php';
    }
    if( $is_component_active['team'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/team/team.php';
    }
    if( $is_component_active['pricing']) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/pricing/pricing.php';
    }
    if( $is_component_active['portfolio'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/portfolio/portfolio.php';
    }
    if( $is_component_active['pie-chart'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/pie-chart/pie-chart.php';
    }
    if( $is_component_active['page-list'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/page-list/page-list.php';
    }
    if( $is_component_active['hero-slider'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/hero-slider/hero-slider.php';
    }
    if( $is_component_active['breadcrumbs'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/breadcrumbs/breadcrumbs.php';
    }
    if( $is_component_active['category-box'] && class_exists('woocommerce') ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/category-box/category-box.php';
    }
    if( $is_component_active['flip-card'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/flip-card/flip-card.php';
    }
    if( $is_component_active['course-category'] && function_exists('tutor') ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/course-category/course-category.php';
    }
    if( $is_component_active['edd-slider'] && class_exists('Easy_Digital_Downloads') ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/edd-slider/edd-slider.php';
    }
    if( $is_component_active['edd-gallery-slider'] && class_exists('Easy_Digital_Downloads') ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/edd-gallery-slider/edd-gallery-slider.php';
    }
    if( $is_component_active['edd-product-filter'] && class_exists('Easy_Digital_Downloads') ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/edd-product-filter/edd-product-filter.php';
    }
    if( $is_component_active['course-filter'] && function_exists('tutor') ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/course-filter/course-filter.php';
    }
    if( $is_component_active['login_register'] ) {
        require_once UA_ELEMENTOR_PATH.'includes/Elements/login_register/login_register.php';
    }
}
add_action('elementor/widgets/widgets_registered','UA_elementor_add_elements');