<?php


/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function UA_team_sidebar_init() {
if(function_exists( 'wp_minzel_theme_setup' )) {
    /*! Team WIDGET
	------------------------------------------------->*/
    register_sidebar( array (
        'name'          => esc_html__( 'Team Sidebar', 'useful-addons-elementor' ),
        'id'            => 'team-sidebar',
        'description'   => esc_html__( 'Sidebar On Team Detail.', 'useful-addons-elementor' ),
        'before_widget' => '<div id="%1$s" class="team-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget__title">',
        'after_title'   => '</h3>',
    ) );
}

}
add_action( 'widgets_init', 'UA_team_sidebar_init' );