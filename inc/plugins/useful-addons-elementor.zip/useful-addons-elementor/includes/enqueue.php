<?php

/*
	UA Enqueue Assets
*/
function UA_enqueue_assets() {
    $is_component_active = UA_elementor_activated_modules();
    // stylesheet
    wp_enqueue_style(
        'mukta-fonts',
        '//fonts.googleapis.com/css2?family=Mukta:wght@200;300;400;500;600;700;800&display=swap'
    );
    wp_enqueue_style(
        'lib-bootstrap-css',
        UA_ELEMENTOR_URL.'assets/frontend/css/bootstrap/css/index.min.css'
    );
    wp_enqueue_style(
        'lib-lineawesome-css',
        '//maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css'
    );
    wp_enqueue_style(
        'lib-owl-carousel-min-css',
        UA_ELEMENTOR_URL.'assets/frontend/owl-carousel/owl.carousel.min.css'
    );
    wp_enqueue_style(
        'lib-tooltipster-bundle-css',
        UA_ELEMENTOR_URL.'assets/frontend/tooltip/tooltipster.bundle.css'
    );
    wp_enqueue_style(
        'lib-swiper-min',
        UA_ELEMENTOR_URL.'assets/frontend/swiper/swiper.min.css',
	    null,
	    UA_ELEMENTOR_VERSION
    );
	wp_enqueue_style(
		'isotope-css',
		UA_ELEMENTOR_URL . 'assets/frontend/isotope/isotope.css',
		null,
		UA_ELEMENTOR_VERSION
	);
	wp_register_style(
		'ts-select.css',
		UA_ELEMENTOR_URL . 'assets/css/ts-select.css',
		null,
		UA_ELEMENTOR_VERSION
	);
	wp_enqueue_style(
		'ion-rangeslider-css',
		UA_ELEMENTOR_URL . 'assets/css/ion.rangeslider.css',
		null,
		UA_ELEMENTOR_VERSION
	);
	wp_enqueue_style(
		'ion-rangeSlider-skinHTML5-css',
		UA_ELEMENTOR_URL . 'assets/css/ion.rangeSlider.skinHTML5.css',
		null,
		UA_ELEMENTOR_VERSION
	);
	wp_enqueue_style(
		'lib-animated-headline',
		UA_ELEMENTOR_URL . 'assets/css/animated-headline.css',
		null,
		UA_ELEMENTOR_VERSION
	);
    wp_enqueue_style(
        'theme-main-css',
        UA_ELEMENTOR_URL.'assets/css/main.css',
        '',
        time()
    );

    // Script
    wp_enqueue_script(
        'lib-popper-min-js',
        UA_ELEMENTOR_URL.'assets/frontend/css/bootstrap/js/popper.min.js',
        array('jquery'),
        '1.0.0',
	    true
    );
    wp_enqueue_script(
        'lib-bootstrap-min-js',
        UA_ELEMENTOR_URL.'assets/frontend/css/bootstrap/js/index.min.js',
        array('jquery'),
        '1.0.0',
	    true
    );
    if($is_component_active['pie-chart']) {
        wp_enqueue_script(
            'pie-chart-js',
            UA_ELEMENTOR_URL . 'assets/frontend/chart/chart.js',
            array('jquery'),
            '1.0.0',
	        true
        );
    }
    wp_enqueue_script(
        'lib-owl-carousel-js',
        UA_ELEMENTOR_URL.'assets/frontend/owl-carousel/owl.carousel.min.js',
        array('jquery'),
        '1.0.0'
    );
    wp_enqueue_script(
        'lib-tooltipster-bundle-min',
        UA_ELEMENTOR_URL.'assets/frontend/tooltip/tooltipster.bundle.min.js',
        array('jquery'),
        '1.0.0',
	    true
    );
    wp_enqueue_script(
        'lib-swiper-min',
        UA_ELEMENTOR_URL.'assets/frontend/swiper/swiper.min.js',
        array('jquery'),
        '1.0.0',
	    true
    );
    wp_enqueue_script(
        'html5lightbox-js',
        UA_ELEMENTOR_URL.'assets/frontend/html5lightbox/html5lightbox.js',
        array('jquery'),
        '1.0.0',
	    true
    );
    if($is_component_active['counter']) {
        wp_enqueue_script(
            'waypoints-min-js',
            UA_ELEMENTOR_URL . 'assets/frontend/counter/waypoints.js',
            array('jquery'),
            '1.0.0',
	        true
        );
        wp_enqueue_script(
            'jquery-counter-min-js',
            UA_ELEMENTOR_URL . 'assets/frontend/counter/jquery.counter.min.js',
            array('jquery'),
            '1.0.0',
	        true
        );
    }
    wp_enqueue_script(
        'jquery-isotope-min-js',
        UA_ELEMENTOR_URL . 'assets/frontend/isotope/isotope-3.0.6.min.js',
        array('jquery'),
        '1.0.0'
    );
    wp_register_script(
        'ts-select.js',
        UA_ELEMENTOR_URL.'assets/js/ts-select.js',
        '',
        UA_ELEMENTOR_VERSION,
	    true
    );
    wp_enqueue_script(
        'ion-rangeslider-js',
        UA_ELEMENTOR_URL.'assets/js/ion.rangeslider.js',
        ['jquery'],
        '1.0.0',
	    true
    );
    wp_enqueue_script(
        'lib-animated-headline',
        UA_ELEMENTOR_URL.'assets/js/animated-headline.js',
        ['jquery'],
        '1.0.0',
	    true
    );
    wp_enqueue_script(
        'UA-Elementor-js',
        UA_ELEMENTOR_URL.'assets/js/UA-elementor.js',
        '',
        UA_ELEMENTOR_VERSION,
	    true
    );

    if(function_exists('edd_get_ajax_url')) {
	    $ajax_url = edd_get_ajax_url();
    } else {
    	$ajax_url = admin_url( 'admin-ajax.php' );
    }
	wp_localize_script(
		'UA-Elementor-js',
		'ua_main_ajax',
		array(
			'ajaxurl' => $ajax_url,
			'nonce'   => wp_create_nonce('UA_Elementor_js'),
		)
	);

    if(class_exists('TravelHelper')) {
        wp_localize_script( 'jquery', 'ts_params', [
            'theme_url' => get_template_directory_uri(),
            'site_url' => site_url(),
            'ajax_url' => admin_url('admin-ajax.php'),
            'ts_search_nonce' => wp_create_nonce("ts_search_security"),
            'booking_currency_precision' => get_woocommerce_currency_symbol(),
            'thousand_separator' => '.',
            'decimal_separator' => ',',
            'currency_symbol' => get_woocommerce_currency_symbol(),
            'currency_position' => 'left',
            'free_text' => __('Free', 'useful-addons-elementor'),
            'date_format' => getDateFormatJs(),
            'time_format' => '12h',
            '_s' => wp_create_nonce('ts_frontend_security'),
        ]);
    }
}
add_action('wp_enqueue_scripts', 'UA_enqueue_assets');


// register editor stylesheet
function enqueue_editor_styles() {
    wp_enqueue_style(
        'editor_style',
        UA_ELEMENTOR_URL . 'assets/css/editor.css',
        false,
        UA_ELEMENTOR_VERSION
    );
}
add_action('elementor/editor/before_enqueue_scripts', 'enqueue_editor_styles');






