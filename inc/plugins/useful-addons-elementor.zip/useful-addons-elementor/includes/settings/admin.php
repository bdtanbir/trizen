<?php
/**
 * Admin Settings Page
 */

if( ! defined( 'ABSPATH' ) ) exit(); // Exit if accessed directly

class UA_admin_menu_setting_class {

	/**
	 * Contains Default Component keys
	 * @var array
	 * @since 2.3.0
	 */
	public $UA_elementor_default_keys = [ 'advice', 'corona-live-map', 'hero-banner', 'icon-list', 'icon-box', 'button', 'counter', 'progressbar', 'particle', 'tabs', 'post-grid', 'testimonial','divider','search-form', 'search-hotel', 'hotel-slider', 'course-grid', 'course-filter', 'login_register', 'team', 'social-media', 'pricing', 'portfolio', 'pie-chart', 'page-list', 'hero-slider', 'breadcrumbs', 'category-box', 'flip-card', 'course-category', 'edd-slider', 'edd-gallery-slider', 'edd-product-filter'];

	/**
	 * Will Contain All Components Default Values
	 * @var array
	 * @since 2.3.0
	 */
	private $UA_elementor_default_settings;

	/**
	 * Will Contain User End Settings Value
	 * @var array
	 * @since 2.3.0
	 */
	private $UA_elementor_settings;

	/**
	 * Will Contains Settings Values Fetched From DB
	 * @var array
	 * @since 2.3.0
	 */
	private $UA_elementor_get_settings;

	/**
	 * Initializing all default hooks and functions
	 * @param
	 * @return void
	 * @since 1.1.2
	 */
	public function __construct() {

		add_action( 'admin_menu', array( $this, 'create_UA_elementor_admin_menu' ), 5 );

		add_action( 'admin_enqueue_scripts', array( $this, 'UA_enqueue_admin_scripts' ) );

		add_action( 'wp_ajax_save_settings_with_ajax', array( $this, 'UA_save_settings_with_ajax' ) );

	}

	/**
	 * UA Create an admin menu.
	 */
	public function create_UA_elementor_admin_menu() {

		add_menu_page(
			'UsefulAddons',
			'UsefulAddons',
			'manage_options',
			'ua_settings',
			array( $this, 'UA_elementor_admin_settings_page' ),
			UA_ELEMENTOR_URL . '/assets/admin/images/UA-logo-icon.png',
			5
		);

	}

    /*
     * Enqueue UA Admin Scripts Files
     * */
	public function UA_enqueue_admin_scripts(){
		wp_register_style(
			'UA-fontawesome-min-css',
			'//pro.fontawesome.com/releases/v5.10.0/css/all.css',
			false,
			UA_ELEMENTOR_VERSION
		);
		wp_register_style(
			'UA-animate-css',
			UA_ELEMENTOR_URL . 'assets/css/animate.css',
			false,
			UA_ELEMENTOR_VERSION
		);
		wp_register_style(
			'UA-admin-settings-css',
			UA_ELEMENTOR_URL.( 'assets/admin/css/admin.css' ),
			false,
			UA_ELEMENTOR_VERSION
		);
		wp_register_style(
			'sweetalert2-min-css',
			UA_ELEMENTOR_URL.( 'assets/admin/vendor/sweetalert2/css/sweetalert2.min.css' )
		);
		wp_register_style(
			'UA-global-css-admin',
			UA_ELEMENTOR_URL . 'assets/css/admin-global.css'
		);


		wp_register_script(
			'UA-admin-settings-js',
			UA_ELEMENTOR_URL.( 'assets/admin/js/admin.js' ),
			array('jquery'),
			UA_ELEMENTOR_VERSION,
			true
		);

		wp_register_script(
			'sweetalert2-core-js',
			UA_ELEMENTOR_URL.( 'assets/admin/vendor/sweetalert2/js/core.js' ),
			array('jquery'),
			'1.0',
			true
		);
		wp_register_script(
			'sweetalert2-min-js',
			UA_ELEMENTOR_URL.( 'assets/admin/vendor/sweetalert2/js/sweetalert2.min.js' ),
			array('jquery', 'sweetalert2-core-js'),
			'1.0',
			true
		);



		wp_enqueue_style( 'UA-fontawesome-min-css' );
		wp_enqueue_style( 'sweetalert2-min-css' );
		wp_enqueue_style( 'UA-global-css-admin' );
		wp_enqueue_style( 'UA-admin-settings-css' );
		wp_enqueue_script( 'UA-admin-settings-js' );
		wp_enqueue_script( 'sweetalert2-core-js' );
		wp_enqueue_script( 'sweetalert2-min-js' );
	}

	/**
	 * UA Create settings page.
	 */
	public function UA_elementor_admin_settings_page() {

		$UA_js_info = array(
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
		);
		wp_localize_script( 'UA-admin-settings-js', 'js_UA_lite_settings', $UA_js_info );

		/**
		 * This section will handle the "UA_elementor_save_settings" array. If any new settings options is added
		 * then it will matches with the older array and then if it founds anything new then it will update the entire array.
		 */
		$this->UA_elementor_default_settings = array_fill_keys( $this->UA_elementor_default_keys, true );
		$this->UA_elementor_get_settings     = get_option( 'UA_elementor_save_settings', $this->UA_elementor_default_settings );
		$UA_elementor_new_settings           = array_diff_key( $this->UA_elementor_default_settings, $this->UA_elementor_get_settings );

		if( ! empty( $UA_elementor_new_settings ) ) {
			$UA_elementor_updated_settings = array_merge( $this->UA_elementor_get_settings, $UA_elementor_new_settings );
			update_option( 'UA_elementor_save_settings', $UA_elementor_updated_settings );
		}
		$this->UA_elementor_get_settings = get_option( 'UA_elementor_save_settings', $this->UA_elementor_default_settings );
        ?>
        <div class="UA-settings-wrap">
            <form action="" method="POST" id="ua_admin_settings_form" name="ua_admin_settings_form">
                <div class="UA-header-bar">
                    <div class="UA-header-left">
                        <div class="UA-admin-logo-inline">
                            <img src="<?php echo UA_ELEMENTOR_URL . '/assets/admin/images/UA-logo.png'; ?>" alt="<?php esc_attr_e('Useful Addons For Elementor', 'useful-addons-elementor'); ?>">
                        </div>
                        <h2 class="title">
				            <?php esc_html_e('Useful Addons Settings', 'useful-addons-elementor'); ?>
                        </h2>
                    </div>
                    <div class="UA-header-right">
                        <button type="submit" class="button UA-btn js-UA-settings-save">
                            <i class="fas fa-save"></i> <?php esc_html_e('Save settings', 'useful-addons-elementor'); ?>
                        </button>
                    </div>
                </div>
                <div class="UA-settings-tabs">
                    <div class="col-lg-4">
                        <ul class="UA-tabs">
                            <li class="UA-tab-list">
                                <a href="#dashboard" class="active">
                                    <i class="fas fa-cogs"></i>
                                    <span><?php esc_html_e('Dashboard', 'useful-addons-elementor'); ?></span>
                                </a>
                            </li>
                            <li class="UA-tab-list">
                                <a href="#elements">
                                    <i class="fas fa-cubes"></i>
                                    <span><?php esc_html_e('Elements', 'useful-addons-elementor'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-8">
			            <?php
                            include_once UA_ELEMENTOR_PATH . 'includes/settings/settings-general.php';
                            include_once UA_ELEMENTOR_PATH . 'includes/settings/settings-elements.php';
			            ?>
                    </div>
                </div>
            </form>
        </div>
        <?php
	}

	/**
	 * Saving data with ajax request
	 * @param
	 * @return  array
	 * @since 1.1.2
	 */
	public function UA_save_settings_with_ajax() {

		if( isset( $_POST['fields'] ) ) {
			parse_str( $_POST['fields'], $settings );
		} else {
			return;
		}

		$this->UA_elementor_settings = [];

		foreach( $this->UA_elementor_default_keys as $key ){
			if( isset( $settings[ $key ] ) ) {
				$this->UA_elementor_settings[ $key ] = 1;
			} else {
				$this->UA_elementor_settings[ $key ] = 0;
			}
		}
		update_option( 'UA_elementor_save_settings', $this->UA_elementor_settings );
		return true;
		die();

	}

}

new UA_admin_menu_setting_class();