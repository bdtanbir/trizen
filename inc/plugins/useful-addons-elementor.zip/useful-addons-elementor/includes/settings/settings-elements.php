

<div id="elements" class="UA-settings-tab UA-elements-list">
    <div class="row">
        <div class="col-full">
            <h2 class="UA-admin-section-header-title">
                <span class="left">
                    <i class="fas fa-cubes"></i> <?php esc_html_e('Elements', 'useful-addons-elementor'); ?>
                </span>
            </h2>
            <div class="elements-global-control-wrap">
                <h4>
                    <?php esc_html_e('Global Controls', 'useful-addons-elementor') ?>
                </h4>
                <p>
                    <?php esc_html_e('Use the Buttons to Activate or Deactivate all the Elements of Useful Addons at once.', 'useful-addons-elementor') ?>
                </p>

                <div class="UA-btn-group">
                    <button type="button" class="UA-btn UA-global-control-enable">
                        <?php esc_html_e('Enable All', 'useful-addons-elementor'); ?>
                    </button>
                    <button type="button" class="UA-btn UA-global-control-disable">
                        <?php esc_html_e('Disable All', 'useful-addons-elementor'); ?>
                    </button>
                </div>
            </div>

            <h4>
                <?php esc_html_e('Content Elements', 'useful-addons-elementor'); ?>
            </h4>
            <div class="UA-checkbox-container">
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Creative Button', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="button" name="button" <?php checked( 1, $this->UA_elementor_get_settings['button'], true ); ?>>
                    <label for="button"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Team Member', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="team" name="team" <?php checked( 1, $this->UA_elementor_get_settings['team'], true ); ?>>
                    <label for="team"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Social Media', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="social-media" name="social-media" <?php checked( 1, $this->UA_elementor_get_settings['social-media'], true ); ?>>
                    <label for="social-media"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Advice', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="advice" name="advice" <?php checked( 1, $this->UA_elementor_get_settings['advice'], true ); ?>>
                    <label for="advice"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Icon List', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="icon-list" name="icon-list" <?php checked( 1, $this->UA_elementor_get_settings['icon-list'], true ); ?>>
                    <label for="icon-list"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Icon Box', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="icon-box" name="icon-box" <?php checked( 1, $this->UA_elementor_get_settings['icon-box'], true ); ?>>
                    <label for="icon-box"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Hero Banner', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="hero-banner" name="hero-banner" <?php checked( 1, $this->UA_elementor_get_settings['hero-banner'], true ); ?>>
                    <label for="hero-banner"></label>
                </div>
                <?php
                    if( class_exists('woocommerce' ) ) {
                        ?>
                        <div class="UA-checkbox">
                            <div class="UA-elements-info">
                                <p class="UA-title">
                                    <?php esc_html_e('Category Box', 'useful-addons-elementor'); ?>
                                </p>
                            </div>
                            <input type="checkbox" id="category-box" name="category-box" <?php checked(1, $this->UA_elementor_get_settings['category-box'], true); ?>>
                            <label for="category-box"></label>
                        </div>
                        <?php
                    } if(function_exists('tutor')) {
                ?>
                    <div class="UA-checkbox">
                        <div class="UA-elements-info">
                            <p class="UA-title">
                                <?php esc_html_e('Course Category', 'useful-addons-elementor'); ?>
                            </p>
                        </div>
                        <input type="checkbox" id="course-category" name="course-category" <?php checked(1, $this->UA_elementor_get_settings['course-category'], true); ?>>
                        <label for="course-category"></label>
                    </div>
                <?php } ?>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Flip Card', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="flip-card" name="flip-card" <?php checked(1, $this->UA_elementor_get_settings['flip-card'], true); ?>>
                    <label for="flip-card"></label>
                </div>
            </div>

            <h4>
                <?php esc_html_e('Dynamic Content Elements', 'useful-addons-elementor'); ?>
            </h4>
            <div class="UA-checkbox-container">
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
				            <?php esc_html_e('Testimonial Slider', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="testimonial" name="testimonial" <?php checked( 1, $this->UA_elementor_get_settings['testimonial'], true ); ?>>
                    <label for="testimonial"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
				            <?php esc_html_e('Corona Live Map', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="corona-live-map" name="corona-live-map" <?php checked( 1, $this->UA_elementor_get_settings['corona-live-map'], true ); ?>>
                    <label for="corona-live-map"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
				            <?php esc_html_e('Hero Slider', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="hero-slider" name="hero-slider" <?php checked( 1, $this->UA_elementor_get_settings['hero-slider'], true ); ?>>
                    <label for="hero-slider"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
				            <?php esc_html_e('Breadcrumb', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="breadcrumbs" name="breadcrumbs" <?php checked( 1, $this->UA_elementor_get_settings['breadcrumbs'], true ); ?>>
                    <label for="breadcrumbs"></label>
                </div>
                <?php if ( class_exists('Easy_Digital_Downloads') ) {
                ?>
                    <div class="UA-checkbox">
                        <div class="UA-elements-info">
                            <p class="UA-title">
                                <?php esc_html_e('EDD Slider', 'useful-addons-elementor'); ?>
                            </p>
                        </div>
                        <input type="checkbox" id="edd-slider" name="edd-slider" <?php checked( 1, $this->UA_elementor_get_settings['edd-slider'], true ); ?>>
                        <label for="edd-slider"></label>
                    </div>
                    <div class="UA-checkbox">
                        <div class="UA-elements-info">
                            <p class="UA-title">
                                <?php esc_html_e('EDD Gallery Slider', 'useful-addons-elementor'); ?>
                            </p>
                        </div>
                        <input type="checkbox" id="edd-gallery-slider" name="edd-gallery-slider" <?php checked( 1, $this->UA_elementor_get_settings['edd-gallery-slider'], true ); ?>>
                        <label for="edd-gallery-slider"></label>
                    </div>
                    <div class="UA-checkbox">
                        <div class="UA-elements-info">
                            <p class="UA-title">
				                <?php esc_html_e('EDD Product Gallery', 'useful-addons-elementor'); ?>
                            </p>
                        </div>
                        <input type="checkbox" id="edd-product-filter" name="edd-product-filter" <?php checked( 1, $this->UA_elementor_get_settings['edd-product-filter'], true ); ?>>
                        <label for="edd-product-filter"></label>
                    </div>
                <?php } ?>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
				            <?php esc_html_e('Particle', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="particle" name="particle" <?php checked( 1, $this->UA_elementor_get_settings['particle'], true ); ?>>
                    <label for="particle"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
				            <?php esc_html_e('Search Form', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="search-form" name="search-form" <?php checked( 1, $this->UA_elementor_get_settings['search-form'], true ); ?>>
                    <label for="search-form"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
				            <?php esc_html_e('Search Hotel', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="search-hotel" name="search-hotel" <?php checked( 1, $this->UA_elementor_get_settings['search-hotel'], true ); ?>>
                    <label for="search-hotel"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
				            <?php esc_html_e('Hotel Slider', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="hotel-slider" name="hotel-slider" <?php checked( 1, $this->UA_elementor_get_settings['hotel-slider'], true ); ?>>
                    <label for="hotel-slider"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
				            <?php esc_html_e('Advanced Tabs', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="tabs" name="tabs" <?php checked( 1, $this->UA_elementor_get_settings['tabs'], true ); ?>>
                    <label for="tabs"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Post Grid', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="post-grid" name="post-grid" <?php checked( 1, $this->UA_elementor_get_settings['post-grid'], true ); ?>>
                    <label for="post-grid"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Page List', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="page-list" name="page-list" <?php checked( 1, $this->UA_elementor_get_settings['page-list'], true ); ?>>
                    <label for="page-list"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Filterable Gallery', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="portfolio" name="portfolio" <?php checked( 1, $this->UA_elementor_get_settings['portfolio'], true ); ?>>
                    <label for="portfolio"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Dynamic Chart', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="pie-chart" name="pie-chart" <?php checked( 1, $this->UA_elementor_get_settings['pie-chart'], true ); ?>>
                    <label for="pie-chart"></label>
                </div>
                <?php if(function_exists('tutor')) { ?>
                    <div class="UA-checkbox">
                        <div class="UA-elements-info">
                            <p class="UA-title">
                                <?php esc_html_e('Course Grid', 'useful-addons-elementor'); ?>
                            </p>
                        </div>
                        <input type="checkbox" id="course-grid" name="course-grid" <?php checked( 1, $this->UA_elementor_get_settings['course-grid'], true ); ?>>
                        <label for="course-grid"></label>
                    </div>
                    <div class="UA-checkbox">
                        <div class="UA-elements-info">
                            <p class="UA-title">
								<?php esc_html_e('Course Filter', 'useful-addons-elementor'); ?>
                            </p>
                        </div>
                        <input type="checkbox" id="course-filter" name="course-filter" <?php checked( 1, $this->UA_elementor_get_settings['course-filter'], true ); ?>>
                        <label for="course-filter"></label>
                    </div>
                <?php } ?>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Login_Register', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="login_register" name="login_register" <?php checked( 1, $this->UA_elementor_get_settings['login_register'], true ); ?>>
                    <label for="login_register"></label>
                </div>
            </div>

            <h4>
                <?php esc_html_e('Creative Elements', 'useful-addons-elementor'); ?>
            </h4>
            <div class="UA-checkbox-container">
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Counter', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="counter" name="counter" <?php checked( 1, $this->UA_elementor_get_settings['counter'], true ); ?>>
                    <label for="counter"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Progress Bar', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="progressbar" name="progressbar" <?php checked( 1, $this->UA_elementor_get_settings['progressbar'], true ); ?>>
                    <label for="progressbar"></label>
                </div>
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Divider', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="divider" name="divider" <?php checked( 1, $this->UA_elementor_get_settings['divider'], true ); ?>>
                    <label for="divider"></label>
                </div>
            </div>

            <h4>
                <?php esc_html_e('Marketing Elements', 'useful-addons-elementor'); ?>
            </h4>
            <div class="UA-checkbox-container">
                <div class="UA-checkbox">
                    <div class="UA-elements-info">
                        <p class="UA-title">
							<?php esc_html_e('Pricing Table', 'useful-addons-elementor'); ?>
                        </p>
                    </div>
                    <input type="checkbox" id="pricing" name="pricing" <?php checked( 1, $this->UA_elementor_get_settings['pricing'], true ); ?>>
                    <label for="pricing"></label>
                </div>
            </div>

            <div class="UA-save-btn-wrap">
                <button type="submit" class="button UA-btn js-UA-settings-save">
                    <i class="fas fa-save"></i> <?php esc_html_e('Save settings', 'useful-addons-elementor'); ?>
                </button>
            </div>
        </div>
    </div>
</div>