<div id="dashboard" class="UA-settings-tab active">
    <div class="row UA-admin-general-wrapper">
        <div class="UA-admin-general-inner">
            <div class="UA-admin-block-wrapper">

                <h2 class="UA-admin-section-header-title">
                    <span class="left">
                        <i class="fas fa-cogs"></i> <?php _e('Dashboard', 'useful-addons-elementor'); ?>
                    </span>
                </h2>
                <div class="UA-admin-dashboard-card">
                    <img src="<?php echo UA_ELEMENTOR_URL . '/assets/admin/images/UA-dashboard-banner.jpg'; ?>" alt="useful-addons-for-elementor">
                </div>

            </div><!--admin block-wrapper end-->
        </div>
    </div><!--Row end-->
</div>