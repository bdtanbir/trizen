<?php
namespace Elementor;
// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}


class ua_advice extends Widget_Base {
	public function get_name() {
		return 'UA_advice';
	}

	public function get_title() {
		return esc_html__( 'Advice', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-table-of-contents ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Advice content */
	private function get_advice_content() {
		$this->start_controls_section( 'advice_content_setting',
			[
				'label' => __( 'Advice Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'advice_icon',
			[
				'label'   => __( 'Icon', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$this->add_control( 'advice_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Default title', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
			]
		);

		/* Repeater */
		$repeater = new Repeater();
		$repeater->add_control( 'advice_list_icon',
			[
				'label'   => __( 'Icon', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$repeater->add_control( 'advice_list_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Default title', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
			]
		);
		$repeater->add_control( 'advice_list_desc',
			[
				'label'       => __( 'Description', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => __( 'Default description', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'advice_lists',
			[
				'label'   => __( 'Lists', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
						'advice_list_icon'  => __( 'fas fa-star', 'useful-addons-elementor' ),
						'advice_list_title' => __( 'Do Not Share Eating', 'useful-addons-elementor' ),
						'advice_list_desc'  => __( 'Libero Perspiciatis Sequi Delectus, Maxime, Voluptatum Minima Nam Amet Ultrices', 'useful-addons-elementor' ),
					],
					[
						'advice_list_icon'  => __( 'fas fa-star', 'useful-addons-elementor' ),
						'advice_list_title' => __( 'Don’t Touch Your Face Or Nose', 'useful-addons-elementor' ),
						'advice_list_desc'  => __( 'Libero Perspiciatis Sequi Delectus, Maxime, Voluptatum Minima Nam Amet Ultrices', 'useful-addons-elementor' ),
					],
					[
						'advice_list_icon'  => __( 'fas fa-star', 'useful-addons-elementor' ),
						'advice_list_title' => __( 'Avoid Contact Sick People', 'useful-addons-elementor' ),
						'advice_list_desc'  => __( 'Libero Perspiciatis Sequi Delectus, Maxime, Voluptatum Minima Nam Amet Ultrices', 'useful-addons-elementor' ),
					],
					[
						'advice_list_icon'  => __( 'fas fa-star', 'useful-addons-elementor' ),
						'advice_list_title' => __( 'Avoid Crowded Places', 'useful-addons-elementor' ),
						'advice_list_desc'  => __( 'Libero Perspiciatis Sequi Delectus, Maxime, Voluptatum Minima Nam Amet Ultrices', 'useful-addons-elementor' ),
					]
				],
				'title_field' => '{{{ advice_list_title }}}',
			]
		);
		$this->end_controls_section();
    }
	/* UA Advice Main Icon Style */
	private function get_advice_main_icon_style() {
		$this->start_controls_section( 'advice_main_icon_style',
			[
				'label' => __( 'Main Icon', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'advice_main_icon_svg_clr',
			[
				'label'     => __( 'SVG Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon svg' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'advice_main_icon_svg_size',
			[
				'label'      => __( 'SVG Icon Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon svg' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'advice_main_icon_clr',
			[
				'label'     => __( 'Normal Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'advice_main_icon_size',
			[
				'label'      => __( 'Normal Icon Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'advice_main_icon_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#DD493D',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'advice_main_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_main_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_main_icon_lheight',
			[
				'label'      => __( 'Line Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'advice_main_icon_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon',
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'advice_main_icon_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon',
			]
		);
		$this->add_responsive_control( 'advice_main_icon_radius',
			[
				'label'      => __( 'Border Radius', 'plugin-domain' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '50',
					'right'  => '50',
					'bottom' => '50',
					'left'   => '50',
					'unit'   => '%',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_main_icon_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_main_icon_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-main-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Advice Main Title Style */
	private function get_advice_main_title_style() {
		$this->start_controls_section( 'advice_main_title_style',
			[
				'label' => __( 'Main Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'advice_main_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0A1B4F',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-header-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'advice_main_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-header-title',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'advice_main_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-header-title',
			]
		);
		$this->add_responsive_control( 'advice_main_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-header-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_main_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header .ua-advice-box-header-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Advice Inner Box Head Style */
	private function get_advice_inner_box_head_style() {
		$this->start_controls_section( 'advice_inner_box_head_style',
			[
				'label' => __( 'Inner Box Header', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'advice_inner_box_head_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'advice_inner_box_head_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '0',
							'right'    => '0',
							'bottom'   => '1',
							'left'     => '0',
							'isLinked' => false,
						],
					],
					'color' => [
						'default' => 'rgba(127, 136, 151, 0.1)',
					],
				],
				'selector'  => '{{WRAPPER}} .ua-advice-box .ua-advice-box-header',
			]
		);
		$this->add_responsive_control( 'advice_inner_box_head_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '85',
					'right'  => '30',
					'bottom' => '33',
					'left'   => '30',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_inner_box_head_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-header' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Advice Inner Box Foot Style */
	private function get_advice_inner_box_foot_style() {
		$this->start_controls_section( 'advice_inner_box_foot_style',
			[
				'label' => __( 'Inner Box Footer', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'advice_inner_box_foot_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'advice_inner_box_foot_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-items',
			]
		);
		$this->add_control( 'advice_inner_box_foot_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_inner_box_foot_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '40',
					'right'  => '40',
					'bottom' => '20',
					'left'   => '40',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_inner_box_foot_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Advice List Icon Style */
	private function get_advice_list_icon_style() {
		$this->start_controls_section( 'advice_list_icon_style',
			[
				'label' => __( 'List Icon', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'advice_list_icon_svg_size',
			[
				'label'      => __( 'SVG Icon Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon svg' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'advice_list_icon_size',
			[
				'label'      => __( 'Normal Icon Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 35,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'advice_list_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'advice_list_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'advice_list_icon_lheight',
			[
				'label'      => __( 'Line Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon, .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon i' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/* start tab */
		$this->start_controls_tabs( 'advice_list_icon_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'advice_list_icon_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'advice_list_icon_svg_clr',
			[
				'label'     => __( 'SVG Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#DD493D',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon svg' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'advice_list_icon_clr',
			[
				'label'     => __( 'Normal Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#DD493D',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'advice_list_icon_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(221, 73, 61, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'advice_list_icon_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon',
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'advice_list_icon_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon',
			]
		);
		$this->add_control( 'advice_list_icon_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '50',
					'right'  => '50',
					'bottom' => '50',
					'left'   => '50',
					'unit'   => '%',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_list_icon_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_list_icon_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '16',
                    'bottom' => '0',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'advice_list_icon_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'advice_list_icon_svg_hv_clr',
			[
				'label'     => __( 'SVG Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li:hover .ua-advice-box-items-icon svg' => 'fill: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'advice_list_icon_hv_clr',
			[
				'label'     => __( 'Normal Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li:hover .ua-advice-box-items-icon i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'advice_list_icon_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#DD493D',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li:hover .ua-advice-box-items-icon' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'advice_list_icon_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-items li:hover .ua-advice-box-items-icon',
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'advice_list_icon_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-items li:hover .ua-advice-box-items-icon',
			]
		);
		$this->add_control( 'advice_list_icon_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li:hover .ua-advice-box-items-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_list_icon_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li:hover .ua-advice-box-items-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_list_icon_hv_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li:hover .ua-advice-box-items-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* end tab */
		$this->end_controls_section();
	}
	/* UA Advice List Title Style */
	private function get_advice_list_title_style() {
		$this->start_controls_section( 'advice_list_title_style',
			[
				'label' => __( 'List Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'advice_list_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0A1B4F',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-content h3' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'advice_list_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-content h3',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'advice_list_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-content h3',
			]
		);
		$this->add_responsive_control( 'advice_list_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'default'    => [
                    'top'    => '0',
                    'right'  => '0',
                    'bottom' => '8',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-content h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_list_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-content h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Advice List Description Style */
	private function get_advice_list_desc_style() {
		$this->start_controls_section( 'advice_list_desc_style',
			[
				'label' => __( 'List Description', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'advice_list_desc_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-content p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'advice_list_desc_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-content p',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'advice_list_desc_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-content p',
			]
		);
		$this->add_responsive_control( 'advice_list_desc_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_list_desc_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li .ua-advice-box-items-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Advice List Box Style */
	private function get_advice_list_box_style() {
		$this->start_controls_section( 'advice_list_box_style',
			[
				'label' => __( 'List Box', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'advice_list_box_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'advice_list_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box .ua-advice-box-items li',
			]
		);
		$this->add_responsive_control( 'advice_list_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_list_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '0',
                    'bottom' => '24',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked'  => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box .ua-advice-box-items li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Advice Box Style */
	private function get_advice_box_style() {
		$this->start_controls_section( 'advice_box_style',
			[
				'label' => __( 'Box', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'advice_box_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-advice-box' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'advice_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box',
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'advice_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-advice-box',
			]
		);
		$this->add_control( 'advice_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'default'    => [
                    'top'     => '8',
                    'right'   => '8',
                    'bottom'  => '8',
                    'left'    => '8',
                    'unit'    => 'px',
                    'isLinked' => true
                ],
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'advice_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-advice-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls() {
		$this->get_advice_content();
		$this->get_advice_main_icon_style();
		$this->get_advice_main_title_style();
		$this->get_advice_inner_box_head_style();
		$this->get_advice_inner_box_foot_style();
		$this->get_advice_list_icon_style();
		$this->get_advice_list_title_style();
		$this->get_advice_list_desc_style();
		$this->get_advice_list_box_style();
		$this->get_advice_box_style();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();
		$advice_lists     = $this->get_settings_for_display( 'advice_lists' );
		?>
        <div class="ua-advice-box do-not-box">
	        <?php if(!empty($settings['advice_title']) || !empty($settings['advice_icon'])) { ?>
	            <div class="ua-advice-box-header">
		            <?php if(!empty($settings['advice_icon'])) { ?>
	                <div class="ua-advice-box-main-icon">
		                <?php Icons_Manager::render_icon( $settings['advice_icon'], [ 'aria-hidden' => 'true' ] ); ?>
	                </div>
					<?php }
					if(!empty($settings['advice_title'])) { ?>
	                <h3 class="ua-advice-box-header-title text-uppercase">
	                    <?php echo esc_html($settings['advice_title']); ?>
	                </h3>
					<?php } ?>
	            </div>
			<?php } ?>
            <ul class="ua-advice-box-items">

	            <?php
	            foreach ( $advice_lists as $index => $item ) { ?>
                <li class="d-flex align-items-center">
	                <?php if(!empty($item['advice_list_icon'])) { ?>
	                    <div class="ua-advice-box-items-icon flex-shrink-0">
	                        <?php Icons_Manager::render_icon( $item['advice_list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
	                    </div>
		            <?php }
		            if(!empty($item['advice_list_title']) || !empty($item['advice_list_desc'])) { ?>
	                    <div class="ua-advice-box-items-content">
		                    <?php if(!empty($item['advice_list_title'])) { ?>
	                        <h3 class="widget-title">
		                        <?php echo esc_html($item['advice_list_title']); ?>
	                        </h3>
				            <?php }
				             if(!empty($item['advice_list_desc'])) { ?>
	                        <p>
	                            <?php echo $item['advice_list_desc']; ?>
	                        </p>
				             <?php } ?>
	                    </div>
		            <?php } ?>
                </li>
                  <?php } ?>

            </ul>
        </div>
		<?php
	}

	protected function _content_template() {}
}

Plugin::instance()->widgets_manager->register_widget_type( new ua_advice() );