<?php
//namespace Elementor;
namespace UsefulAddons\Includes\Elements\Breadcrumbs;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Plugin;
use Elementor\Widget_Base;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

class ua_breadcrumbs extends Widget_Base {
    public function get_name() {
        return 'ua_breadcrumbs';
    }

    public function get_title() {
        return esc_html__( 'Breadcrumb', 'useful-addons-elementor' );
    }

    public function get_icon() {
        return 'eicon-form-vertical ua-addons-icon';
    }

    public function get_categories() {
        return [ 'useful-addons-elementor-category' ];
    }

    /* UA Get Breadcrumb Spacing Style */
    private function get_breadcrumbs_style() {
        $this->start_controls_section( 'ua_breadcrumbs_content',
            [
                'label' => __( 'Breadcrumbs', 'useful-addons-elementor' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('ua_breadcrumbs_style',
			[
				'label'   => __( 'Styles', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style_1',
				'options' => [
					'style_1'  => __( 'Style 1', 'useful-addons-elementor' ),
					'style_2'  => __( 'Style 2', 'useful-addons-elementor' ),
				],
			]
		);
        $this->add_responsive_control('ua_breadcrumbs_spc',
            [
                'label'        => __( 'Space Between The Title And Breadcrumbs', 'useful-addons-elementor' ),
                'type'         => Controls_Manager::SLIDER,
                'size_units'   => [ 'px', '%' ],
                'range'        => [
                    'px'       => [
                        'min'  => 0,
                        'max'  => 500,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'   => [
                    'unit'  => 'px',
                    'size'  => 155,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content' => 'padding-bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'ua_breadcrumbs_style' => 'style_1'
                ],
            ]
        );
	    $this->add_control( 'ua_breadcrumb_show_shape',
		    [
			    'label'        => __( 'Show Shape', 'useful-addons-elementor' ),
			    'type'         => Controls_Manager::SWITCHER,
			    'label_on'     => __( 'Show', 'useful-addons-elementor' ),
			    'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
			    'return_value' => 'yes',
			    'default'      => 'no',
                'condition'    => [
                    'ua_breadcrumbs_style' => 'style_1'
                ]
		    ]
	    );
        $this->end_controls_section();
    }
    /* UA Get title style */
    private function get_title_style() {
        $this->start_controls_section( 'ua_breadcrumb_title_style',
            [
                'label' => __( 'Title', 'useful-addons-elementor' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_breadcrumbs_style' => 'style_1'
                ],
            ]
        );
        $this->add_control('ua_breadcrumb_title_clr',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__title' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'ua_breadcrumb_title_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__title',
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'      => 'ua_breadcrumb_title_typography',
                'label'     => __( 'Typography', 'useful-addons-elementor' ),
                'selector'  => '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__title',
            ]
        );
        $this->add_responsive_control('ua_breadcrumb_title_pd',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('ua_breadcrumb_title_mg',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    /* UA Get Breadcrumb Link Style */
    private function get_breadcrumb_link_style() {
        $this->start_controls_section( 'ua_breadcrumb_links_style',
            [
                'label' => __( 'Breadcrumb', 'useful-addons-elementor' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_breadcrumbs_style' => 'style_1'
                ],
            ]
        );
        $this->add_control('ua_breadcrumb_links_clr',
            [
                'label'     => __( 'Link Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#233d63',
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list li a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('ua_breadcrumb_links_hv_clr',
            [
                'label'     => __( 'Link Hover Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#F66B5D',
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list li a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('ua_breadcrumb_nrml_clr',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#677286',
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list li' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name'     => 'ua_breadcrumb_bg',
                'label'    => __( 'Background', 'useful-addons-elementor' ),
                'types'    => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list',
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'ua_breadcrumb_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list',
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'ua_breadcrumb_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list',
            ]
        );
        $this->add_responsive_control('ua_breadcrumb_radius',
            [
                'label'        => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'         => Controls_Manager::DIMENSIONS,
                'size_units'   => [ 'px', '%', 'em' ],
                'default'      => [
                    'top'      => '30',
                    'right'    => '30',
                    'bottom'   => '30',
                    'left'     => '30',
                    'unit'     => 'px',
                    'isLinked' => true
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
	    $this->add_group_control( Group_Control_Typography::get_type(),
		    [
			    'name'     => 'ua_breadcrumb_typography',
			    'label'    => __( 'Typography', 'useful-addons-elementor' ),
			    'selector' => '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list li',
		    ]
	    );
        $this->add_responsive_control('ua_breadcrumb_pd',
            [
                'label'        => __( 'Padding', 'useful-addons-elementor' ),
                'type'         => Controls_Manager::DIMENSIONS,
                'size_units'   => [ 'px', '%', 'em' ],
                'default'      => [
                    'top'      => '10',
                    'right'    => '32',
                    'bottom'   => '10',
                    'left'     => '32',
                    'unit'     => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('ua_breadcrumb_mg',
            [
                'label'        => __( 'Margin', 'useful-addons-elementor' ),
                'type'         => Controls_Manager::DIMENSIONS,
                'size_units'   => [ 'px', '%', 'em' ],
                'default'      => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '-22',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // shape
	    $this->add_control( 'ua_breadcrumb_shape_hd',
		    [
			    'label'     => __( 'Shape', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::HEADING,
			    'separator' => 'before',
                'condition' => [
                    'ua_breadcrumb_show_shape' => 'yes'
                ]
		    ]
	    );
	    $this->add_control( 'ua_breadcrumb_shape_bg',
		    [
			    'label'     => __( 'Background', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#ffffff',
			    'selectors' => [
				    '{{WRAPPER}} .ua-breadcrumb-area .ua-breadcrumb-content .ua-breadcrumb__list.show:after' => 'background: {{VALUE}}',
			    ],
		    ]
	    );
        $this->end_controls_section();
    }


    /* UA Breadcrumb style 2 */
    private function get_breadcrumb2_title_style() {
        $this->start_controls_section( 'ua_breadcrumb2_title_style',
            [
                'label'     => __( 'Title', 'useful-addons-elementor' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_breadcrumbs_style' => 'style_2'
                ],
            ]
        );
        $this->add_control('ua_breadcrumb2_title_clr',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#0D233E',
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-style2 .ua-breadcrumb-content .ua-breadcrumb__title' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Typography::get_type(),
			[
				'name'     => 'ua_breadcrumb2_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-breadcrumb-style2 .ua-breadcrumb-content .ua-breadcrumb__title',
			]
		);
        $this->add_responsive_control('ua_breadcrumb2_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-breadcrumb-style2 .ua-breadcrumb-content .ua-breadcrumb__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
    private function get_breadcrumb2_breadcrumb_style() {
        $this->start_controls_section( 'ua_breadcrumb2_breadcrumb_style',
            [
                'label'     => __( 'Breadcrumb', 'useful-addons-elementor' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_breadcrumbs_style' => 'style_2'
                ],
            ]
        );
        $this->add_control('ua_breadcrumb2_breadcrumb_link_clr',
            [
                'label'     => __( 'Link Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-style2 .ua-breadcrumb-content .ua-breadcrumb__list li' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ua-breadcrumb-style2 .ua-breadcrumb-content .ua-breadcrumb__list li a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('ua_breadcrumb2_breadcrumb_link_clr_hv',
            [
                'label'     => __( 'Link Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#287dfa',
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-style2 .ua-breadcrumb-content .ua-breadcrumb__list li a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('ua_breadcrumb2_breadcrumb_bg',
            [
                'label'     => __( 'Breadcrumb BG', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(0,0,0,.3)',
                'selectors' => [
                    '{{WRAPPER}} .ua-breadcrumb-style2 .ua-breadcrumb-content .ua-breadcrumb__list' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control('ua_breadcrumb2_breadcrumb_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'     => [
                    'top'      => '5',
                    'right'    => '5',
                    'bottom'   => '5',
                    'left'     => '5',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-breadcrumb-style2 .ua-breadcrumb-content .ua-breadcrumb__list' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('ua_breadcrumb2_breadcrumb_padding',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'     => [
                    'top'      => '10',
                    'right'    => '20',
                    'bottom'   => '10',
                    'left'     => '20',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-breadcrumb-style2 .ua-breadcrumb-content .ua-breadcrumb__list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('ua_breadcrumb2_breadcrumb_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-breadcrumb-style2 .ua-breadcrumb-content .ua-breadcrumb__list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }

    protected function _register_controls() {
        /* UA Get Breadcrumb Spacing Style */
        $this->get_breadcrumbs_style();
        /* UA Get title style */
        $this->get_title_style();
        /* UA Get Breadcrumb Link Style */
        $this->get_breadcrumb_link_style();

        $this->get_breadcrumb2_title_style();
        $this->get_breadcrumb2_breadcrumb_style();
    }


    protected function render( ) {
        $settings = $this->get_settings_for_display();

        if($settings['ua_breadcrumb_show_shape'] == 'yes') {
            $shape = 'show';
        } else {
	        $shape = ' ';
        }

        if($settings['ua_breadcrumbs_style'] == 'style_2') {
            $breadcrumb_style2 = ' ua-breadcrumb-style2';
        } else {
            $breadcrumb_style2 = '';
        }
        ?>
        <section class="ua-breadcrumb-area<?php echo esc_attr( $breadcrumb_style2 ); ?>">
            <div class="ua-breadcrumb-content text-center">
                <?php if(!empty(get_the_title())) { ?>
                    <h2 class="ua-breadcrumb__title"><?php the_title(); ?></h2>
                <?php } ?>
                <ul class="ua-breadcrumb__list <?php echo esc_attr_e($shape); ?>">
                    <?php OEE_Breadcrumbs::breadcrumb(); ?>
                </ul>
            </div>
        </section>


        <?php
    }

    protected function _content_template() {}
}

Plugin::instance()->widgets_manager->register_widget_type( new ua_breadcrumbs() );