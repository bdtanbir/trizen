<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class ua_course_filter extends Widget_Base {
	public function get_name() {
		return 'ua_course_filter';
	}

	public function get_title() {
		return esc_html__( 'Course Filter', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-filter ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Course Filter */
	private function get_course_filter_query_setting() {
		$this->start_controls_section( 'course_filter_query_setting',
			[
				'label' => __( 'Query', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'course_filter_query_itemperpage',
			[
				'label'   => __( 'Item Per Page', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 20,
				'step'    => 1,
				'default' => 6,
			]
		);
		$this->add_control( 'course_filter_query_orderby',
			[
				'label'             => __( 'Order By', 'useful-addons-elementor' ),
				'type'              => Controls_Manager::SELECT,
				'default'           => 'date',
				'options'           => [
					'ID'            => 'Post ID',
					'author'        => 'Post Author',
					'title'         => 'Title',
					'date'          => 'Date',
					'modified'      => 'Last Modified Date',
					'parent'        => 'Parent Id',
					'rand'          => 'Random',
					'comment_count' => 'Comment Count',
					'menu_order'    => 'Menu Order',
				],
			]
		);
		$this->add_control( 'course_filter_query_order',
			[
				'label'    => __('Order', 'useful-addons-elementor'),
				'type'     => Controls_Manager::SELECT,
				'options'  => [
					'asc'  => 'Ascending',
					'desc' => 'Descending',
				],
				'default'  => 'desc',
			]
		);
        $this->add_control('course_filter_course_by_ids',
            [
                'label'       => __( 'Course By IDs', 'useful-addons-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'placeholder' => __( 'course ids here for example: 1, 2, 3', 'useful-addons-elementor' ),
            ]
        );
		$this->end_controls_section();
	}
	private function get_course_filter_layout_setting() {
		$this->start_controls_section( 'course_filter_layout_setting',
			[
				'label' => __( 'Layout', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'course_filter_show_image',
			[
				'label'        => __( 'Show Image', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_badge',
			[
				'label'        => __( 'Show Badge', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_level',
			[
				'label'        => __( 'Show Level', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_wishlist',
			[
				'label'        => __( 'Show Wishlist Button', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_title',
			[
				'label'        => __( 'Show Title', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_author',
			[
				'label'        => __( 'Show Author', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_rating',
			[
				'label'        => __( 'Show Rating', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_classes',
			[
				'label'        => __( 'Show Classes', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_classes_icon',
			[
				'label'        => __( 'Show Classes Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
                    'course_filter_show_classes' => 'yes'
                ]
			]
		);
		$this->add_control( 'course_filter_classes_icon',
			[
				'label'   => __( 'Icon', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'la la-play-circle',
					'library' => 'solid',
				],
                'condition' => [
                    'course_filter_show_classes_icon' => 'yes',
                    'course_filter_show_classes'      => 'yes',
                ]
			]
		);
		$this->add_control( 'course_filter_show_duration',
			[
				'label'        => __( 'Show Course Duration', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_duration_icon',
			[
				'label'        => __( 'Show Duration Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'course_filter_show_duration' => 'yes'
				]
			]
		);
		$this->add_control( 'course_filter_duration_icon',
			[
				'label'   => __( 'Icon', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'la la-clock',
					'library' => 'solid',
				],
				'condition' => [
					'course_filter_show_duration_icon' => 'yes',
					'course_filter_show_duration'      => 'yes',
				]
			]
		);
		$this->add_control( 'course_filter_show_price',
			[
				'label'        => __( 'Show Price', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_addtocart',
			[
				'label'        => __( 'Show Add To Cart Button', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_show_hover_card',
			[
				'label'        => __( 'Show Hover Card', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_hover_card() {
		$this->start_controls_section( 'course_filter_hover_card_layout',
			[
				'label'     => __( 'Hover Card Layout', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'course_filter_show_hover_card' => 'yes'
				]
			]
		);
		$this->add_control( 'course_filter_pp_show_author',
			[
				'label'        => __('Show Author', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_pp_show_title',
			[
				'label'        => __('Show Title', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_pp_show_badge',
			[
				'label'        => __('Show Title', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_pp_show_category',
			[
				'label'        => __('Show Category', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_pp_show_excerpt',
			[
				'label'        => __('Show Excerpt', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_pp_show_materials',
			[
				'label'        => __('Show Materials', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_pp_show_classes',
			[
				'label'        => __('Show Classes', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_pp_show_duration',
			[
				'label'        => __('Show Duration', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_pp_show_course_preview_btn',
			[
				'label'        => __('Show Course Preview Button', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_pp_show_price',
			[
				'label'        => __('Show Price', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_filter_pp_show_addtocart',
			[
				'label'        => __('Show Add To Cart Button', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_nav_style() {
		$this->start_controls_section( 'course_filter_nav_style',
			[
				'label'     => __( 'Navigation', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_filter_nav_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter-nav li',
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'course_filter_nav_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'course_filter_nav_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_filter_nav_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter-nav li' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_filter_nav_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(81, 190, 120, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter-nav li' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_nav_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter-nav li',
			]
		);
		$this->add_responsive_control( 'course_filter_nav_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '5',
                    'right'  => '5',
                    'bottom' => '5',
                    'left'   => '5',
                    'unit'   => 'px',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter-nav li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_filter_nav_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter-nav li',
			]
		);
		$this->add_responsive_control( 'course_filter_nav_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '17',
					'bottom' => '0',
					'left'   => '17',
					'unit'   => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter-nav li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_nav_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '3',
					'bottom' => '0',
					'left'   => '3',
					'unit'   => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter-nav li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'course_filter_nav_av',
			[
				'label' => __( 'Active', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_filter_nav_clr_av',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter-nav li.active' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_filter_nav_bg_av',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter-nav li.active' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_nav_border_av',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter-nav li.active',
			]
		);
		$this->add_responsive_control( 'course_filter_nav_radius_av',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter-nav li.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_filter_nav_shadow_av',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter-nav li.active',
			]
		);
		$this->add_responsive_control( 'course_filter_nav_pd_av',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter-nav li.active' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_nav_mg_av',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter-nav li.active' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
        $this->add_control('course_filter_nav_wrap_hd',
            [
                'label'     => __( 'Nav\'s Wrapper Margin', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_responsive_control( 'course_filter_nav_wrap_mg',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'    => '0',
                    'right'  => '0',
                    'bottom' => '50',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-course-filter-nav' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();
	}
	private function get_course_filter_img_style() {
		$this->start_controls_section( 'course_filter_img_style',
			[
				'label' => __( 'Image', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_filter_show_image' => 'yes'
				]
			]
		);
		$this->add_responsive_control( 'course_filter_img_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-image a img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_img_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-image a img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_img_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '0',
					'left'     => '0',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-image a img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_img_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-image a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_badge_style() {
		$this->start_controls_section( 'course_filter_badge_style',
			[
				'label' => __( 'Badge', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_filter_show_badge' => 'yes'
				]
			]
		);
		$this->add_control( 'course_filter_badge_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-badge .ua-course-badge-label' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_filter_badge_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-badge .ua-course-badge-label, .ua-course-filter .ua-course-card-badge .ua-course-badge-label:after' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_filter_badge_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-badge .ua-course-badge-label',
			]
		);
		$this->add_responsive_control( 'course_filter_badge_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '4',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-badge .ua-course-badge-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_badge_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '10',
					'bottom'   => '4',
					'left'     => '12',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-badge .ua-course-badge-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_badge_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_level_style() {
		$this->start_controls_section( 'course_filter_level_style',
			[
				'label' => __( 'Level', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_filter_show_level' => 'yes'
				]
			]
		);
		$this->add_control( 'course_filter_level_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'color: {{VALUE}}',
					'{{WRAPPER}} .tooltipster-content .ua-course-filter .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_filter_level_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(81, 190, 120, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_filter_level_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label .ua-course-card-label-text',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_level_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label .ua-course-card-label-text',
			]
		);
		$this->add_responsive_control( 'course_filter_level_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '30',
					'right'    => '30',
					'bottom'   => '30',
					'left'     => '30',
					'unit'     => 'px',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_filter_level_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label .ua-course-card-label-text',
			]
		);
		$this->add_responsive_control( 'course_filter_level_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '1',
					'right'    => '12',
					'bottom'   => '1',
					'left'     => '12',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_level_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_wishlist_style() {
		$this->start_controls_section( 'course_filter_wishlist_style',
			[
				'label'     => __( 'Wishlist', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_filter_show_wishlist' => 'yes'
				]
			]
		);
		$this->add_responsive_control( 'course_filter_wishlist_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_wishlist_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'course_filter_wishlist_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'course_filter_wishlist_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_filter_wishlist_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_filter_wishlist_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_wishlist_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a',
			]
		);
		$this->add_control( 'course_filter_wishlist_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_filter_wishlist_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a',
			]
		);
		$this->add_responsive_control( 'course_filter_wishlist_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_wishlist_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'course_filter_wishlist_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_filter_wishlist_clr_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a:hover, .ua-course-filter .ua-course-card-collection-icon.has-wish-listed span:before' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_filter_wishlist_bg_hv',
			[
				'label'     => __( 'background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a:hover, .ua-course-filter .ua-course-card-collection-icon.has-wish-listed span:before' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_wishlist_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a:hover, .ua-course-filter .ua-course-card-collection-icon.has-wish-listed',
			]
		);
		$this->add_control( 'course_filter_wishlist_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a:hover, .ua-course-filter .ua-course-card-collection-icon.has-wish-listed' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_filter_wishlist_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a:hover, .ua-course-filter .ua-course-card-collection-icon.has-wish-listed',
			]
		);
		$this->add_responsive_control( 'course_filter_wishlist_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a:hover, .ua-course-filter .ua-course-card-collection-icon.has-wish-listed' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_wishlist_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-label a:hover, .ua-course-filter .ua-course-card-collection-icon.has-wish-listed' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->end_controls_section();
	}
	private function get_course_filter_title_style() {
		$this->start_controls_section( 'course_filter_title_style',
			[
				'label'     => __( 'Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_filter_show_title' => 'yes'
				]
			]
		);
		$this->add_control( 'course_filter_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-title a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_filter_title_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-title a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-title',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_filter_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-title',
			]
		);
		$this->add_responsive_control( 'course_filter_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '10',
					'right'    => '0',
					'bottom'   => '9',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_author_style() {
		$this->start_controls_section( 'course_filter_author_style',
			[
				'label'     => __( 'Author', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_filter_show_author' => 'yes'
				]
			]
		);
		$this->add_control( 'course_filter_author_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-author a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_filter_author_color_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-author a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_filter_author_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-author a',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_author_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-author a',
			]
		);
		$this->add_control( 'course_filter_author_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-author a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_author_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-author a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_author_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-author a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_rating_style() {
		$this->start_controls_section( 'course_filter_rating_style',
			[
				'label'     => __( 'Ratings', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_filter_show_rating' => 'yes'
				]
			]
		);
		$this->add_control( 'course_filter_rating_icon_clr',
			[
				'label'     => __( 'Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#F68A03',
				'selectors' => [
					'{{WRAPPER}} .ua-course-star-rating-wrap .tutor-star-rating-group i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_filter_rating_txt_clr',
			[
				'label'     => __( 'Text Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#4b5981',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-rating-wrap .ua-course-star-rating-wrap .tutor-rating-count' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_rating_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-star-rating-wrap' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_rating_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-star-rating-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_classes_style() {
		$this->start_controls_section( 'course_filter_classes_style',
			[
				'label'     => __( 'Classes', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_filter_show_classes' => 'yes'
				]
			]
		);
		$this->add_control( 'course_filter_classes_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-duration .classes' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_filter_classes_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-duration .classes',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_classes_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '0',
							'right'    => '1',
							'bottom'   => '0',
							'left'     => '0',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'rgba(127, 136, 151, 0.2)',
					],
				],
				'selector' => '{{WRAPPER}} .ua-course-card-duration .classes',
			]
		);
		$this->add_responsive_control( 'course_filter_classes_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '15',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-duration .classes' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_classes_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-duration .classes' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_duration_style() {
		$this->start_controls_section( 'course_filter_duration_style',
			[
				'label'     => __( 'Duration', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_filter_show_duration' => 'yes'
				]
			]
		);
		$this->add_control( 'course_filter_duration_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-duration .duration' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_filter_duration_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-duration .duration',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_duration_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-duration .duration',
			]
		);
		$this->add_responsive_control( 'course_filter_duration_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '15',
					'unit'   => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-duration .duration' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_duration_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-duration .duration' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_price_style() {
		$this->start_controls_section( 'course_filter_price_style',
			[
				'label'     => __( 'Price', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_filter_show_price' => 'yes'
				]
			]
		);
		$this->add_control( 'course_filter_price_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_filter_price_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_filter_price_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_price_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price',
			]
		);
		$this->add_control( 'course_filter_price_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_filter_price_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price',
			]
		);
		$this->add_control( 'course_filter_price_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'course_filter_price_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_filter_card_style() {
		$this->start_controls_section( 'course_filter_card_style',
			[
				'label'     => __( 'Card', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'course_filter_card_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'course_filter_card_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_filter_card_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-course-filter .ua-course-card-image:after' => 'border-bottom: 12px solid {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'            => 'course_filter_card_border',
				'label'           => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'rgba(127, 136, 151, 0.2)',
					],
				],
				'selector'        => '{{WRAPPER}} .ua-course-filter',
			]
		);
		$this->add_control( 'course_filter_card_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '4',
					'right'  => '4',
					'bottom' => '4',
					'left'   => '4',
					'unit'   => 'px',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_gird_card_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter',
			]
		);
		$this->add_responsive_control( 'course_filter_card_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_card_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '30',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false
				],
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'course_filter_card_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_filter_card_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-course-filter:hover' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-course-filter:hover .ua-course-card-image:after' => 'border-bottom: 12px solid {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_filter_card_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-filter:hover',
			]
		);
		$this->add_control( 'course_filter_card_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_gird_card_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
				'selector' => '{{WRAPPER}} .ua-course-filter:hover',
			]
		);
		$this->add_responsive_control( 'course_filter_card_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_filter_card_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-filter:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->end_controls_section();
	}



	protected function _register_controls() {
        $this->get_course_filter_query_setting();
        $this->get_course_filter_layout_setting();
        $this->get_course_filter_nav_style();
        $this->get_course_filter_img_style();
        $this->get_course_filter_badge_style();
        $this->get_course_filter_level_style();
        $this->get_course_filter_wishlist_style();
        $this->get_course_filter_title_style();
        $this->get_course_filter_author_style();
        $this->get_course_filter_rating_style();
        $this->get_course_filter_classes_style();
        $this->get_course_filter_duration_style();
        $this->get_course_filter_price_style();
        $this->get_course_filter_card_style();

        /* Course Hover Card */
        $this->get_course_filter_hover_card();
	}


	protected function render( ) {
		$settings   = $this->get_settings_for_display();
        $course_ids = explode(',', $settings['course_filter_course_by_ids']);


        if(!empty($settings['course_filter_course_by_ids'])) {
            $default = [
                'posts_per_page' => $settings['course_filter_query_itemperpage'],
                'post_type'      => 'courses',
                'orderby'        => $settings['course_filter_query_orderby'],
                'order'          => $settings['course_filter_query_order'],
                'post__in'       => $course_ids,
            ];
        } else {
            $default = [
                'posts_per_page' => $settings['course_filter_query_itemperpage'],
                'post_type'      => 'courses',
                'orderby'        => $settings['course_filter_query_orderby'],
                'order'          => $settings['course_filter_query_order'],
            ];
        }

		/**
		 * Setup the post arguments.
		 */
		// Post Query
        global $post;
		$post_query = new \WP_Query( $default );

		if($post_query->have_posts()) {
		?>
            <section class="ua-course-filter-wrap">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ua-course-filter-bar text-center">
	                        <?php
	                        if(!empty( get_terms("course-category"))) {


                                $args = array(
                                    'orderby' => 'name',
                                    'order'   => 'ASC',
                                    'parent'  => 0,
                                    'hide_empty' => 0,
                                    'taxonomy' => 'course-category'
                                );
                                $terms = get_categories($args);
		                        $count = count( $terms );

		                        echo '<ul class="ua-course-filter-nav nav-tabs d-flex align-items-center justify-content-center flex-wrap">';
		                        echo '<li data-filter="*" class="active">' . esc_html__('All', 'useful-addons-elementor') . '</li>';
		                        if ( $count > 0 ) {
			                        foreach ( $terms as $term ) {
				                        $termname = strtolower( $term->name );
				                        $termname = str_replace( ' ', '-', $termname );
				                        echo '
                                        <li data-filter=".' . esc_attr($termname) . '">
                                            ' . esc_html($term->name) . '
                                        </li>';
			                        }
		                        }
		                        echo "</ul>";
	                        }
	                        ?>
                        </div><!-- ua-course-filter -->
                    </div><!-- col-lg-12 -->
                </div><!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ua-course-filter-list">

	                        <?php if ( $post_query ) :
	                        while ( $post_query->have_posts() ) : $post_query->the_post();

	                        $terms = get_the_terms( $post->ID, 'course-category' );
	                        if ( $terms && ! is_wp_error( $terms ) ) :
		                        $links = array();
		                        foreach ( $terms as $term ) {
			                        $links[] = $term->name;
		                        }
		                        $links = str_replace(' ', '-', $links);
		                        $tax   = join( " ", $links );
	                        else :
		                        $tax = '';
	                        endif;

								global $post, $authordata;
								$tutor_course_img = get_tutor_course_thumbnail_src();

								if ( is_user_logged_in() ) {
									$whishlist_class = 'tutor-course-wishlist-btn';
								} else {
									$whishlist_class = 'cart-required-login';
								}
								$course_id     = get_the_ID();
								$is_wishlisted = tutor_utils()->is_wishlisted( $course_id );
								$has_wish_list = '';
								if ( $is_wishlisted ) {
									$has_wish_list = 'has-wish-listed';
								}

								$total_lessons     = tutor_utils()->get_lesson_count_by_course();
								$course_duration   = get_tutor_course_duration_context();

								$course_materials  = tutor_course_material_includes();
								$course_categories = get_tutor_course_categories();


								$badge_title = get_post_meta( get_the_ID(), 'aduca_course_badge_title', true );

								if($settings['course_filter_show_hover_card'] === 'yes') {
								    $hovercard = '#ua_course_filter_card_tooltip_'.esc_attr($course_id).'';
								} else {
								    $hovercard = ' ';
								}
	                        ?>
                                <div class="ua-course-filter-items col-lg-4 col-md-6 all <?php echo strtolower($tax); ?>">
                                    <div class="card-preview ua-course-filter transition-all-3s ua-card-preview tooltipstered" data-tooltip-content="<?php echo esc_attr($hovercard); ?>">
										<?php if(!empty($tutor_course_img) || !empty($badge_title)) { ?>
                                            <div class="ua-course-card-image position-relative">
												<?php
												if ( ! empty( $tutor_course_img ) && $settings['course_filter_show_image'] === 'yes' ) { ?>
                                                    <a href="<?php the_permalink(); ?>" class="ua-course-card-img d-block relative">
                                                        <img src="<?php echo esc_url( $tutor_course_img ); ?>" alt="<?php esc_attr_e('Course', 'useful-addons-elementor'); ?>" width="358" height="239" />
                                                    </a>
												<?php }
												if(!empty($badge_title) && $settings['course_filter_show_badge']=== 'yes') { ?>
                                                    <div class="ua-course-card-badge position-absolute">
                                                        <span class="ua-course-badge-label relative d-inline-block">
                                                            <?php echo esc_html($badge_title); ?>
                                                        </span>
                                                    </div>
												<?php } ?>
                                            </div>
										<?php } ?>
                                        <div class="ua-course-card-content">
                                            <p class="ua-course-card-label d-flex align-items-center justify-content-between">
												<?php if(get_tutor_course_level() && $settings['course_filter_show_level'] === 'yes') { ?>
                                                    <span class="ua-course-card-label-text d-inline-block">
                                                        <?php echo get_tutor_course_level(); ?>
                                                    </span>
												<?php }
												if($settings['course_filter_show_wishlist'] === 'yes') {
													echo '
                                                    <a href="javascript:;" class="ua-course-card-collection-icon d-inline-block ' . esc_attr($whishlist_class) . ' ' . esc_attr($has_wish_list) . '" data-course-id="' . esc_attr($course_id) . '">
                                                        <span class="la la-heart"></span>
                                                    </a>';
												}
												?>
                                            </p>
											<?php if(get_the_title() && $settings['course_filter_show_title']  === 'yes') { ?>
                                                <h3 class="ua-course-card-title">
                                                    <a class="transition-all-3s" href="<?php the_permalink(); ?>">
														<?php the_title(); ?>
                                                    </a>
                                                </h3>
											<?php } if($settings['course_filter_show_author'] === 'yes' ) { ?>
                                                <p class="ua-course-card-author">
                                                    <a class="transition-all-3s" href="<?php echo tutor_utils()->profile_url($authordata->ID); ?>">
                                                        <?php echo get_the_author(); ?>
                                                    </a>
                                                </p>
                                            <?php } if($settings['course_filter_show_rating'] === 'yes') { ?>
                                                <div class="ua-course-rating-wrap d-flex mt-2 mb-3">
                                                    <div class="ua-course-star-rating-wrap">
                                                        <?php
                                                        $course_rating = tutor_utils()->get_course_rating();
                                                        tutor_utils()->star_rating_generator($course_rating->rating_avg);
                                                        ?>
                                                        <span class="tutor-rating-count">
                                                            <?php
                                                            if ($course_rating->rating_avg > 0) {
                                                                echo apply_filters('tutor_course_rating_average', $course_rating->rating_avg);
                                                                echo '<span class="star__count">' . esc_html__('(','useful-addons-elementor') . apply_filters('tutor_course_rating_count', $course_rating->rating_count) . esc_html__(')', 'useful-addons-elementor') . '</span>';
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                            <div class="ua-course-card-action">
                                                <ul class="ua-course-card-duration d-flex align-items-center">
                                                    <?php if($settings['course_filter_show_classes'] === 'yes') { ?>
                                                        <li class="classes">
                                                            <span class="ua-course-meta-date">
                                                                <?php if($settings['course_filter_show_classes_icon'] === 'yes') {
																	Icons_Manager::render_icon( $settings['course_filter_classes_icon'], [ 'aria-hidden' => 'true' ] );
                                                                } echo esc_html($total_lessons) . esc_html__(' Classes', 'useful-addons-elementor'); ?>
                                                            </span>
                                                        </li>
                                                    <?php } if($settings['course_filter_show_duration'] === 'yes') { ?>
                                                        <li class="duration text-right">
                                                            <?php if(!empty($course_duration)) { ?>
                                                                <span class="ua-course-meta-date">
                                                                    <?php if($settings['course_filter_show_duration_icon'] === 'yes') {
                                                                        Icons_Manager::render_icon( $settings['course_filter_duration_icon'], [ 'aria-hidden' => 'true' ] );
                                                                    } echo esc_html($course_duration); ?>
                                                                </span>
                                                            <?php } ?>
                                                        </li>
                                                    <?php } ?>
                                                </ul>
                                            </div>
                                            <div class="ua-course-card-price-wrap d-flex justify-content-between align-items-center">
												<?php
                                                if($settings['course_filter_show_price'] === 'yes') {
                                                    $is_purchasable = tutor_utils()->is_course_purchasable();
                                                    $price          = apply_filters('get_tutor_course_price', null, get_the_ID());
                                                    if ($is_purchasable && $price){
                                                        echo '<div class="ua-course-card-price">' . $price . '</div>';
                                                    } else {
                                                        ?>
                                                        <div class="ua-course-card-price free">
                                                            <?php esc_html_e('Free', 'useful-addons-elementor'); ?>
                                                        </div>
                                                        <?php
                                                    }
                                                }

                                                if($settings['course_filter_show_addtocart'] === 'yes') {
													$enroll_btn = '<a class="edd-add-to-cart" href="' . get_the_permalink() . '">' . __( 'Get Enrolled', 'useful-addons-elementor' ) . '</a>';
													if ( tutor_utils()->is_course_purchasable() ) {
														$enroll_btn = tutor_course_loop_add_to_cart( false );
														$enroll_btn = '<div class="price"> ' . $enroll_btn . ' </div>';
													}
													echo ''.$enroll_btn;
												}
												?>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="ua_course_tooltip_templates d-none">
                                        <div id="ua_course_filter_card_tooltip_<?php echo esc_attr($course_id) ?>">
                                            <div class="ua-course-filter ua-course-filter">
                                                <div class="ua-course-card-content">
                                                    <?php if($settings['course_filter_pp_show_author'] === 'yes') { ?>
                                                    <p class="ua-course-card-author">
														<?php esc_html_e('By', 'useful-addons-elementor'); ?> <a class="transition-all-3s" href="<?php echo tutor_utils()->profile_url($authordata->ID); ?>">
															<?php echo get_the_author(); ?>
                                                        </a>
                                                    </p>
													<?php } if(get_the_title() && $settings['course_filter_pp_show_title'] === 'yes') { ?>
                                                        <h3 class="ua-course-card-title">
                                                            <a class="transition-all-3s" href="<?php the_permalink(); ?>">
																<?php the_title(); ?>
                                                            </a>
                                                        </h3>
													<?php } ?>
                                                    <p class="ua-course-card-label">
														<?php if(!empty($badge_title) && $settings['course_filter_pp_show_badge'] === 'yes') { ?>
                                                            <span class="ua-course-card-label-text mr-1">
                                                                <?php echo esc_html($badge_title); ?>
                                                            </span>
														<?php } if(is_array($course_categories) && count($course_categories) && $settings['course_filter_pp_show_category'] === 'yes') { ?>
                                                            <span class="mr-1">
                                                                <?php esc_html_e('in', 'useful-addons-elementor'); ?>
                                                            </span>
															<?php
															foreach ($course_categories as $course_category){
																$category_name = $course_category->name;
																$category_link = get_term_link($course_category->term_id);
																echo "<a href=" . esc_url($category_link) . " class='mr-1'>" . esc_html($category_name) . "</a> <span class='cat-bar'>" . esc_html__('|', 'useful-addons-elementor') . " </span> ";
															}
															?>
														<?php } ?>
                                                    </p>
                                                    <div class="ua-course-rating-wrap d-flex mt-2 mb-3">
                                                        <?php if($settings['course_filter_pp_show_category'] === 'yes') { ?>
                                                            <div class="ua-course-star-rating-wrap">
                                                                <?php
                                                                $course_rating = tutor_utils()->get_course_rating();
                                                                tutor_utils()->star_rating_generator($course_rating->rating_avg);
                                                                ?>
                                                                <span class="tutor-rating-count">
                                                                    <?php
                                                                    if ($course_rating->rating_avg > 0) {
                                                                        echo apply_filters('tutor_course_rating_average', $course_rating->rating_avg);
                                                                        echo '<span class="star__count">' . esc_html__('(', 'useful-addons-elementor') . apply_filters('tutor_course_rating_count', $course_rating->rating_count) . esc_html__(')', 'useful-addons-elementor') . '</span>';
                                                                    }
                                                                    ?>
                                                                </span>
                                                            </div>
                                                        <?php } ?>
                                                    </div><!-- end rating-wrap -->
													<?php if(get_the_excerpt() && $settings['course_filter_pp_show_excerpt'] === 'yes') { ?>
                                                        <div class="ua-course-card-para mb-3">
                                                            <p class="font-size-14 line-height-24">
																<?php
																    echo wp_trim_words(get_the_excerpt(), '21', ' ');
																?>
                                                            </p>
                                                        </div>
													<?php }
													if(!empty($course_materials) && is_array($course_materials) && count($course_materials) && $settings['course_filter_pp_show_materials'] === 'yes') { ?>
                                                        <ul class="ua-course-list-items mb-3 font-size-14">
															<?php foreach ($course_materials as $course_material) {
																echo '<li>'.$course_material.'</li>';
															} ?>
                                                        </ul>
													<?php } ?>
                                                    <div class="ua-course-card-action">
                                                        <ul class="ua-course-card-duration d-flex justify-content-between align-items-center">
                                                            <?php if($settings['course_filter_pp_show_classes'] === 'yes') {  ?>
                                                                <li class="classes">
                                                                    <span class="ua-course-meta-date">
                                                                        <i class="la la-play-circle"></i> <?php echo esc_html($total_lessons) . esc_html__(' Classes', 'useful-addons-elementor'); ?>
                                                                    </span>
                                                                </li>
                                                            <?php } if($settings['course_filter_pp_show_duration'] === 'yes') { ?>
                                                                <li class="duration">
                                                                    <?php if(!empty($course_duration)) { ?>
                                                                        <span class="ua-course-meta-date">
                                                                            <i class="la la-clock-o"></i> <?php echo esc_html($course_duration); ?>
                                                                        </span>
                                                                    <?php } ?>
                                                                </li>
                                                            <?php } ?>
                                                        </ul>
                                                    </div><!-- end card-action -->
                                                    <?php if($settings['course_filter_pp_show_course_preview_btn'] === 'yes') { ?>
                                                        <div class="ua-course-btn-box w-100 text-center mb-3">
                                                            <a href="<?php the_permalink(); ?>" class="theme-btn d-block">
                                                                <?php esc_html_e('Preview this course', 'useful-addons-elementor'); ?>
                                                            </a>
                                                        </div>
                                                    <?php } ?>
                                                    <div class="ua-course-card-price-wrap d-flex justify-content-between align-items-center">
														<?php
                                                        if($settings['course_filter_pp_show_price'] === 'yes') {
                                                            $is_purchasable = tutor_utils()->is_course_purchasable();
                                                            $price          = apply_filters('get_tutor_course_price', null, get_the_ID());
                                                            if ($is_purchasable && $price){
                                                                echo '<div class="ua-course-card-price">' . $price . '</div>';
                                                            } else {
                                                                ?>
                                                                <div class="ua-course-card-price free">
                                                                    <?php esc_html_e('Free', 'useful-addons-elementor'); ?>
                                                                </div>
                                                                <?php
                                                            }
                                                        }
                                                        if($settings['course_filter_pp_show_addtocart'] === 'yes') {
															$enroll_btn = '<div  class="tutor-loop-cart-btn-wrap"><a href="' . get_the_permalink() . '">' . esc_html__( 'Get Enrolled', 'useful-addons-elementor' ) . '</a></div>';
															if ( tutor_utils()->is_course_purchasable() ) {
																$enroll_btn = tutor_course_loop_add_to_cart( false );
																$enroll_btn = '<div class="price"> ' . $enroll_btn . ' </div>';
															}
															echo ''.$enroll_btn;
														}
														?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
	                        <?php endwhile; else: ?>
	                        <?php endif;
	                        wp_reset_query();
	                        ?>

                        </div>
                    </div>
                </div>
            </section>


            <script>
                var $container = jQuery('.ua-course-filter-list');
                $container.isotope({
                    filter: '*',
                    animationOptions: {
                        duration: 750,
                        easing: 'linear',
                        queue: false
                    }
                });

                jQuery('.ua-course-filter-nav li').click(function () {
                    jQuery('.ua-course-filter-nav li').removeClass('active');
                    jQuery(this).addClass('active');

                    var selector = jQuery(this).attr('data-filter');
                    $container.isotope({
                        filter: selector,
                        animationOptions: {
                            duration: 750,
                            easing: 'linear',
                            queue: false
                        }
                    });
                    return false;
                });
            </script>
        <?php
        }

	}

	protected function _content_template() { }
}

Plugin::instance()->widgets_manager->register_widget_type( new ua_course_filter() );