<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_hero_banner extends Widget_Base {
	public function get_name() {
		return 'UA_hero_banner';
	}

	public function get_title() {
		return esc_html__( 'Hero Banner', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-banner ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Hero Banner content setting */
	private function hero_banner_controls() {
		$this->start_controls_section( 'hero_banner_content_setting',
			[
				'label' => __( 'Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control( 'hero_banner_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( 'Default Title', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'hero_banner_description',
			[
				'label'       => __( 'Description', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'Default description', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'hero_banner_show_buttons',
			[
				'label'        => __( 'Show Buttons', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'hero_banner_button_options',
			[
				'label'   => __( 'Button Style', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dual_button',
				'options' => [
					'dual_button'   => __( 'Dual Button', 'useful-addons-elementor' ),
					'single_button' => __( 'Single Button', 'useful-addons-elementor' ),
				],
                'condition' => [
                    'hero_banner_show_buttons' => 'yes'
                ]
			]
		);
		/* first button */
		$this->add_control( 'hero_banner_first_button',
			[
				'label'       => __( 'First Button', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'View All Products', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your button text here', 'useful-addons-elementor' ),
                'condition'   => [
                    'hero_banner_show_buttons' => 'yes',
                    'hero_banner_button_options' => ['dual_button', 'single_button']
                ]
			]
		);
		$this->add_control( 'hero_banner_first_btn_link',
			[
				'label'         => __( 'First Button Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( '#', 'useful-addons-elementor' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition'   => [
					'hero_banner_show_buttons' => 'yes',
					'hero_banner_button_options' => ['dual_button', 'single_button']
				]
			]
		);
		$this->add_control( 'hero_banner_second_button',
			[
				'label'       => __( 'Second Button', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Browse Themes', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your button text here', 'useful-addons-elementor' ),
                'condition'   => [
                    'hero_banner_show_buttons'   => 'yes',
                    'hero_banner_button_options' => 'dual_button'
                ]
			]
		);
		$this->add_control( 'hero_banner_second_button_link',
			[
				'label'         => __( 'Second Button Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( '#', 'useful-addons-elementor' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition'   => [
					'hero_banner_show_buttons'   => 'yes',
					'hero_banner_button_options' => 'dual_button'
				]
			]
		);
		$this->add_control( 'hero_banner_show_bubble',
			[
				'label'        => __( 'Bubble Shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'hero_banner_show_bg_shape',
			[
				'label'        => __( 'Background Shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();
	}
	/* UA Hero Banner Title Style */
	private function hero_banner_title_style() {
		$this->start_controls_section( 'hero_banner_title_style',
			[
				'label' => __( 'Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'hero_banner_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-hero-content .td__title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'hero_banner_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .td__title',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'hero_banner_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .td__title',
			]
		);
		$this->add_responsive_control( 'hero_banner_title_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '0',
                    'bottom' => '1',
                    'left'   => '0',
                    'unit'   => 'rem',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .td__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .td__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
    }
	/* UA Hero Banner Description Style */
	private function hero_banner_desc_style() {
		$this->start_controls_section( 'hero_banner_desc_style',
			[
				'label' => __( 'Description', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'hero_banner_desc_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-hero-content .td__desc' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'hero_banner_desc_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .td__desc',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'hero_banner_desc_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .td__desc',
			]
		);
		$this->add_responsive_control( 'hero_banner_desc_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .td__desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_desc_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .td__desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Hero Banner Button 1 Style */
	private function hero_banner_btn1_style() {
		$this->start_controls_section( 'hero_banner_btn1_style',
			[
				'label'     => __( 'First Button', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'hero_banner_show_buttons'  => 'yes',
                    'hero_banner_button_options' => ['dual_button', 'single_button']
                ]
			]
		);

		/* Start Tab */
		$this->start_controls_tabs( 'hero_banner_btn1_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'hero_banner_btn1_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'hero_banner_btn1_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-1' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'hero_banner_btn1_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-1',
			]
		);
		$this->add_responsive_control( 'hero_banner_btn1_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em','rem' ],
				'default'    => [
                    'top'    => '.25',
                    'right'  => '.25',
                    'bottom' => '.25',
                    'left'   => '.25',
                    'unit'   => 'rem',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'hero_banner_btn1_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-1',
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'hero_banner_btn1_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-1',
			]
		);
		$this->add_responsive_control( 'hero_banner_btn1_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'    => '10',
                    'right'  => '18',
                    'bottom' => '10',
                    'left'   => '18',
                    'unit'   => 'px',
                    'isLinked'=> false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_btn1_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '10',
                    'bottom' => '0',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked'=> false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'hero_banner_btn1_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'hero_banner_btn1_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-1:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'hero_banner_btn1_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-1:hover',
			]
		);
		$this->add_responsive_control( 'hero_banner_btn1_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em','rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-1:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'hero_banner_btn1_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-1:hover',
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'hero_banner_btn1_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-1:hover',
			]
		);
		$this->add_responsive_control( 'hero_banner_btn1_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-1:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_btn1_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-1:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'hero_banner_btn1_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control( 'hero_banner_btn1_width',
			[
				'label'       => __( 'Width', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', '%' ,'em', 'rem' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-1' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_btn1_height',
			[
				'label'       => __( 'Height', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', '%' ,'em', 'rem' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-1' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'hero_banner_btn1_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-1',
			]
		);

		$this->end_controls_section();
	}
	/* UA Hero Banner Button 2 Style */
	private function hero_banner_btn2_style() {
		$this->start_controls_section( 'hero_banner_btn2_style',
			[
				'label'     => __( 'Second Button', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'hero_banner_show_buttons' => 'yes',
                    'hero_banner_button_options' => 'dual_button'
                ]
			]
		);

		/* Start Tab */
		$this->start_controls_tabs( 'hero_banner_btn2_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'hero_banner_btn2_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'hero_banner_btn2_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-2' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'hero_banner_btn2_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-2',
			]
		);
		$this->add_responsive_control( 'hero_banner_btn2_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em','rem' ],
				'default'    => [
					'top'    => '.25',
					'right'  => '.25',
					'bottom' => '.25',
					'left'   => '.25',
					'unit'   => 'rem',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-2' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'hero_banner_btn2_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-2',
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'hero_banner_btn2_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-2',
			]
		);
		$this->add_responsive_control( 'hero_banner_btn2_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
					'top'    => '10',
					'right'  => '18',
					'bottom' => '10',
					'left'   => '18',
					'unit'   => 'px',
					'isLinked'=> false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_btn2_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'hero_banner_btn2_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'hero_banner_btn2_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-2:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'hero_banner_btn2_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-2:hover',
			]
		);
		$this->add_responsive_control( 'hero_banner_btn2_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em','rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-2:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'hero_banner_btn2_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-2:hover',
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'hero_banner_btn2_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-2:hover',
			]
		);
		$this->add_responsive_control( 'hero_banner_btn2_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-2:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_btn2_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-2:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'hero_banner_btn2_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control( 'hero_banner_btn2_width',
			[
				'label'       => __( 'Width', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', '%' ,'em', 'rem' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-2' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_btn2_height',
			[
				'label'       => __( 'Height', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::SLIDER,
				'size_units'  => [ 'px', '%' ,'em', 'rem' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hero-content .btn-box .btn-2' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'hero_banner_btn2_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hero-content .btn-box .btn-2',
			]
		);

		$this->end_controls_section();
	}
	/* UA Hero Banner Background Shape Style */
	private function hero_banner_bg_shape_style() {
		$this->start_controls_section( 'hero_banner_bg_shape_style',
			[
				'label'     => __( 'Background Shape', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
                    'hero_banner_show_bg_shape' => 'yes'
				]
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'hero_banner_bg_shape_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .ua-hero-banner-wrapper .ua-hero-inner',
			]
		);
		$this->add_responsive_control( 'hero_banner_bg_shape_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em', 'vw' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 130,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hero-banner-wrapper .ua-hero-inner' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_bg_shape_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em', 'vw' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 124,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hero-banner-wrapper .ua-hero-inner' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_bg_shape_rotate',
			[
				'label'      => __( 'Rotate', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em', 'deg' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 360,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'deg',
					'size' => 352,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hero-banner-wrapper .ua-hero-inner' => 'transform: rotate({{SIZE}}{{UNIT}});',
				],
			]
		);
		$this->add_control( 'hero_banner_bg_shape_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '0',
                    'bottom' => '0',
                    'left'   => '32',
                    'unit'   => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-banner-wrapper .ua-hero-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'hero_banner_bg_shape_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em','vh' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-banner-wrapper .ua-hero-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Hero Banner Content Box Style */
	private function hero_banner_content_box() {
		$this->start_controls_section( 'hero_banner_content_box_style',
			[
				'label'     => __( 'Content Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'hero_banner_content_box_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .ua-hero-banner-wrapper',
			]
		);
		$this->add_responsive_control( 'hero_banner_content_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '215',
                    'right'  => '0',
                    'bottom' => '290',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hero-banner-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls() {
		$this->hero_banner_controls();
		$this->hero_banner_title_style();
		$this->hero_banner_desc_style();
		$this->hero_banner_btn1_style();
		$this->hero_banner_btn2_style();
		$this->hero_banner_bg_shape_style();
		$this->hero_banner_content_box();

	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();

		$btn1_target   = $settings['hero_banner_first_btn_link']['is_external'] ? ' target="_blank"' : '';
		$btn1_nofollow = $settings['hero_banner_first_btn_link']['nofollow'] ? ' rel="nofollow"' : '';

		$btn2_target   = $settings['hero_banner_second_button_link']['is_external'] ? ' target="_blank"' : '';
		$btn2_nofollow = $settings['hero_banner_second_button_link']['nofollow'] ? ' rel="nofollow"' : '';

		?>

		<section class="ua-hero-banner-wrapper overflow-hidden text-center">
            <?php if($settings['hero_banner_show_bg_shape'] === 'yes') { ?>
			    <div class="ua-hero-inner bg-gradient"></div>
            <?php
            }
                if($settings['hero_banner_show_bubble'] === 'yes') {
            ?>
			<span class="bubble bubble-one"></span>
			<span class="bubble bubble-two"></span>
			<span class="bubble bubble-three"></span>
			<span class="bubble bubble-four"></span>
			<span class="bubble bubble-five"></span>
			<span class="bubble bubble-six"></span>
			<span class="bubble bubble-seven"></span>
			<span class="bubble bubble-eight">
		        <img src="<?php echo UA_ELEMENTOR_ASSETS.'images/icon-shape.png' ?>" alt="<?php esc_attr_e('Shape', 'useful-addons-elementor'); ?>">
		    </span>
			<span class="bubble bubble-nine">
		        <img src="<?php echo UA_ELEMENTOR_ASSETS.'images/icon-shape2.png' ?>" alt="<?php esc_attr_e('Shape', 'useful-addons-elementor'); ?>">
		    </span>
            <?php } ?>
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="ua-hero-content">
							<div class="td-heading">
                                <?php if(!empty($settings['hero_banner_title'])) { ?>
                                    <h2 class="td__title pb-3">
                                        <?php echo $settings['hero_banner_title']; ?>
                                    </h2>
                                <?php } if(!empty($settings['hero_banner_description'])) { ?>
                                    <p class="td__desc">
                                        <?php echo $settings['hero_banner_description']; ?>
                                    </p>
                                <?php } ?>
							</div><!-- td-heading -->
                            <?php
                            if($settings['hero_banner_show_buttons'] === 'yes') {
                                if($settings['hero_banner_button_options'] === 'dual_button' || $settings['hero_banner_button_options'] === 'single_button') { ?>
                                    <div class="btn-box">
                                        <?php if($settings['hero_banner_button_options'] === 'dual_button') {
                                            if(!empty($settings['hero_banner_first_button'])) {
                                            ?>
                                                <a href="<?php echo esc_url($settings['hero_banner_first_btn_link']['url']); ?>" <?php echo esc_attr($btn1_target) .' '. esc_attr($btn1_nofollow) ?> class="btn-1 btn td-btn transition-all-3s">
                                                    <?php echo esc_html($settings['hero_banner_first_button']); ?>
                                                </a>
                                            <?php } if(!empty($settings['hero_banner_second_button'])) { ?>
                                                <a href="<?php echo esc_url($settings['hero_banner_second_button_link']['url']); ?>" <?php echo esc_attr($btn2_target) .' '. esc_attr($btn2_nofollow) ?>  class="btn-2 btn td-btn transition-all-3s td-btn-light">
                                                    <?php echo esc_html($settings['hero_banner_second_button']); ?>
                                                </a>
                                            <?php
                                                }
                                            } else {
                                            if(!empty($settings['hero_banner_first_button'])) {
                                            ?>
                                            <a href="<?php echo esc_url($settings['hero_banner_first_btn_link']['url']); ?>" <?php echo esc_attr($btn1_target) .' '. esc_attr($btn1_nofollow) ?>  class="btn-1 btn td-btn transition-all-3s mr-2">
                                                <?php echo esc_html($settings['hero_banner_first_button']); ?>
                                            </a>
                                        <?php
                                            }
                                        } ?>
                                    </div><!-- btn-box -->
                                <?php
                                }
                            }
                            ?>
						</div>
					</div><!-- col-lg-12 -->
				</div><!-- row -->
			</div><!-- container -->
            <?php if($settings['hero_banner_show_bg_shape'] === 'yes') { ?>
			    <svg class="svg-bg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" id="b163acb8-d7e3-44ae-95e8-546cddd31e63" data-name="Layer 1" viewBox="0 0 1077.87 813.02" style="height: 1000px;"><defs><linearGradient id="198f78e2-ec49-403a-9acf-506373c5226e-16" x1="975.77" y1="484.92" x2="975.77" y2="87.89" gradientTransform="translate(-77.03)" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="gray" stop-opacity="0.25"></stop><stop offset="0.54" stop-color="gray" stop-opacity="0.12"></stop><stop offset="1" stop-color="gray" stop-opacity="0.1"></stop></linearGradient><linearGradient id="6e777f18-a157-4954-9b1f-a7cbf36b1989-16" x1="649.11" y1="832.85" x2="649.11" y2="382.11" gradientTransform="matrix(1, 0, 0, 1, 0, 0)" xlink:href="#198f78e2-ec49-403a-9acf-506373c5226e"></linearGradient></defs><path d="M724.89,154.84c-46.25,39.26-106.24,36.72-158.81,16.29S465.22,114.34,414,88.49c-42.94-21.67-88-35.9-133.61-42.23-65.28-9.06-138.18,2-183.66,65.44-50.65,70.68-46.76,198.16,8,263,27.87,33,64.36,49.2,96.18,75S262.2,518.26,259.49,568c-2.51,46-31.68,81.37-61.87,103.54-23.33,17.13-52.06,35.84-54.87,71.33-2.72,34.33,21.44,61.24,44.51,76.54,75.26,49.91,168,49.43,243-1.26C457,800.06,481.56,776,509.61,761.92c73.65-37,154.81.24,232.8,13.87,66,11.53,133.69,5.55,198-17.48,38.62-13.83,77.39-35,104.52-74.36,19.57-28.4,31.76-64.35,43.2-99.85q18.3-56.77,35.19-114.36c6.75-23.05,13.4-46.54,15.15-71.19,3.16-44.68-10.16-88.85-28.3-126.55C1067.1,182.47,994.56,119.52,916,103.53S754.33,118.77,693.4,187.11" transform="translate(-61.06 -43.49)" fill="#510fa8" opacity="0.1"></path></svg>
            <?php } ?>
		</section>

		<?php

	}

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_hero_banner() );