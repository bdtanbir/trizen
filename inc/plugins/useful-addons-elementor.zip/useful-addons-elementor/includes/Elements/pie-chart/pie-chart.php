<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_pie_chart extends Widget_Base {
	public function get_name() {
		return 'UA_pie_chart';
	}

	public function get_title() {
		return esc_html__( 'PieChart', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-time-line ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA PieChart Query Content Controls */
	private function get_query_piechart( ){
		$this->start_controls_section( 'UA_pie_chart_query_setting',
			[
				'label' => __( 'Chart Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'UA_pie_chart_types',
			[
				'label'   => __( 'Chart Types', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'line',
				'options' => [
					'line'     => __( 'Line', 'useful-addons-elementor' ),
					'doughnut' => __( 'Pie', 'useful-addons-elementor' ),
				],
			]
		);

        // Line Chart
        $this->add_control( 'UA_pie_chart_labels',
            [
                'label'       => __( 'Labels', 'useful-addons-elementor' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 5,
                'default'     => __( "Jan, Feb, Mar, Apr, May, Jun", "useful-addons-elementor" ),
                'placeholder' => __( 'Type chart labels here', 'useful-addons-elementor' ),
                'description' => __("Insert the labels with <strong><b>,</b></strong>. For example: <strong>one, two, three</strong>"),
                'condition'   => [
                    'UA_pie_chart_types' => 'line'
                ]
            ]
        );
        $this->add_control( 'UA_pie_chart_tooltip_alignment',
            [
                'label'   => __( 'Tooltip Alignment', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'bottom',
                'options' => [
                    'top'     => __( 'Top', 'useful-addons-elementor' ),
                    'right'   => __( 'Right', 'useful-addons-elementor' ),
                    'bottom'  => __( 'Bottom', 'useful-addons-elementor' ),
                    'left'    => __( 'Left', 'useful-addons-elementor' ),
                ],
                'condition' => [
                    'UA_pie_chart_types' => 'line'
                ]
            ]
        );
        $this->add_control( 'UA_pie_chart_legend_position',
            [
                'label'   => __( 'Legend Position', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'bottom',
                'options' => [
                    'none'    => __( 'None', 'useful-addons-elementor' ),
                    'top'     => __( 'Top', 'useful-addons-elementor' ),
                    'right'   => __( 'Right', 'useful-addons-elementor' ),
                    'bottom'  => __( 'Bottom', 'useful-addons-elementor' ),
                    'left'    => __( 'Left', 'useful-addons-elementor' ),
                ],
            ]
        );
        $this->add_control( 'UA_pie_chart_repeaters',
            [
                'label'     => __( 'Datasets', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::REPEATER,
                'condition' => [
                    'UA_pie_chart_types' => 'line'
                ],
                'fields' => [
                    [
                        'name'        => 'UA_pie_chart_label_title',
                        'label'       => __( 'Label', 'useful-addons-elementor' ),
                        'type'        => Controls_Manager::TEXT,
                        'default'     => __( 'One', 'useful-addons-elementor' ),
                        'placeholder' => __( 'Type label text here', 'useful-addons-elementor' ),
                    ],
                    [
                        'name'        => 'UA_pie_chart_datas',
                        'label'       => __( 'Data', 'useful-addons-elementor' ),
                        'type'        => Controls_Manager::TEXTAREA,
                        'rows'        => 5,
                        'default'     => __( "10, 25, 13, 22, 32, 25", "useful-addons-elementor" ),
                        'placeholder' => __( 'Type chart datas here', 'useful-addons-elementor' ),
                        'description' => __("Insert the data with <strong><big>,</big></strong>. For example: <strong>20, 30, 40, 50</strong>"),
                    ],
                    [
                        'name' => 'end_div_hr',
                        'type' => Controls_Manager::DIVIDER,
                    ],
                    [
                        'name'    => 'UA_pie_chart_background',
                        'label'   => __( 'Background', 'useful-addons-elementor' ),
                        'type'    => Controls_Manager::COLOR,
                        'default' => 'rgba(64,33,186,.2)',
                    ],
                    [
                        'name'    => 'UA_pie_chart_border_clr',
                        'label'   => __( 'Border Color', 'useful-addons-elementor' ),
                        'type'    => Controls_Manager::COLOR,
                        'default' => '#4021ba',
                    ],
                    [
                        'name'    => 'UA_pie_chart_pntborder_clr',
                        'label'   => __( 'PointBorder Color', 'useful-addons-elementor' ),
                        'type'    => Controls_Manager::COLOR,
                        'default' => '#4021ba',
                    ]
                ],
                'default' => [
                    [
                        'UA_pie_chart_label_title'   => 'One',
                        'UA_pie_chart_datas'         => '10, 25, 13, 22, 32, 25',
                        'UA_pie_chart_background'    => 'rgba(64,33,186,0)',
                        'UA_pie_chart_border_clr'    => '#4021ba',
                        'UA_pie_chart_pntborder_clr' => '#4021ba',
                    ],
                    [
                        'UA_pie_chart_label_title'   => 'Two',
                        'UA_pie_chart_datas'         => '5, 12, 25, 18, 15, 34',
                        'UA_pie_chart_background'    => 'rgba(255,126,0,0)',
                        'UA_pie_chart_border_clr'    => '#F66B5D',
                        'UA_pie_chart_pntborder_clr' => '#F66B5D',
                    ]
                ],
                'title_field' => '{{{ UA_pie_chart_label_title }}}',
            ]
        );

		/* Doughnut Chart */
		$this->add_control('ua_doughnut_datasets_items',
            [
                'label'        => __('Datasets', 'useful-addons-elementor'),
                'type'         => Controls_Manager::REPEATER,
                'condition'    => [
                    'UA_pie_chart_types' => 'doughnut'
                ],
                'fields'       => [
                    [
                        'name'          => 'ua_doughnut_label',
                        'label'         => __('Label', 'useful-addons-elementor'),
                        'type'          => Controls_Manager::TEXT,
                        'default'       => __('One', 'useful-addons-elementor'),
                    ],
                    [
                        'name'          => 'ua_doughnut_datas',
                        'label'         => __('Data', 'useful-addons-elementor'),
                        'type'          => Controls_Manager::TEXT,
                        'default'       => __('20', 'useful-addons-elementor'),
                    ],
                    [
                        'name'    => 'ua_doughnut_chart_bg',
                        'label'   => __( 'Background', 'useful-addons-elementor' ),
                        'type'    => Controls_Manager::COLOR,
                        'default' => 'rgb(240, 234, 198)'
                    ],
                    [
                        'name'    => 'ua_doughnut_chart_hv_bg',
                        'label'   => __( 'Hover Background', 'useful-addons-elementor' ),
                        'type'    => Controls_Manager::COLOR,
                        'default' => '#d1dae9'
                    ]
                ],
                'default'      => [
                    [
                        'ua_doughnut_label'       => __('One', 'useful-addons-elementor'),
                        'ua_doughnut_datas'       => __('20', 'useful-addons-elementor'),
                        'ua_doughnut_chart_bg'    => '#d1dae9',
                        'ua_doughnut_chart_hv_bg' => '#d1dae9',
                    ],
                    [
                        'ua_doughnut_label'       => __('Two', 'useful-addons-elementor'),
                        'ua_doughnut_datas'       => __('20', 'useful-addons-elementor'),
                        'ua_doughnut_chart_bg'    => '#f2d2d3',
                        'ua_doughnut_chart_hv_bg' => '#f2d2d3',
                    ],
                    [
                        'ua_doughnut_label'       => __('Three', 'useful-addons-elementor'),
                        'ua_doughnut_datas'       => __('60', 'useful-addons-elementor'),
                        'ua_doughnut_chart_bg'    => '#f0eac6',
                        'ua_doughnut_chart_hv_bg' => '#f0eac6',
                    ]
                ],
                'title_field'  => '{{{ ua_doughnut_label }}}'
            ]
        );
		$this->end_controls_section();
	}
	/* UA PieChart Line Style Controls */
	private function get_style_piechart_line( ){
		$this->start_controls_section( 'UA_pie_chart_line_styles',
			[
				'label'     => __( 'Chart Line', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'UA_pie_chart_types' => 'line'
                ]
			]
		);
		$this->add_control( 'UA_pie_chart_line_width',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 1,
						'max'  => 20,
						'step' => 1,
					],
				],
				'default'  => [
					'size' => 2,
				],
			]
		);
		$this->add_control( 'UA_pie_chart_line_pntsize',
			[
				'label'      => __( 'Pointer Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 1,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'size' => 4,
				],
			]
		);
		$this->add_control( 'UA_pie_chart_line_pntbg',
			[
				'label'   => __( 'Pointer Background', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '#ffffff',
			]
		);
		$this->add_control( 'UA_pie_chart_default_clr',
			[
				'label'   => __( 'Default Chart Color', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '#3b3e79',
			]
		);
		$this->add_control( 'UA_pie_chart_default_font_size',
			[
				'label'      => __( 'Default Chart Font Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 1,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'size' => 15,
				],
			]
		);
		$this->add_control( 'UA_pie_chart_default_font_family',
			[
				'label'   => __( 'Default Chart Font Family', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::FONT,
				'default' => "Barlow",
			]
		);
		$this->add_control( 'UA_pie_chart_default_fontweight',
			[
				'label'   => __( 'Default Chart FontWeight', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '500',
				'options' => [
					'100'  => __( 'Thin', 'useful-addons-elementor' ),
					'200'  => __( 'Extra Light', 'useful-addons-elementor' ),
					'300'  => __( 'Light', 'useful-addons-elementor' ),
					'400'  => __( 'Regular', 'useful-addons-elementor' ),
					'500'  => __( 'medium', 'useful-addons-elementor' ),
					'600'  => __( 'Semi Bold', 'useful-addons-elementor' ),
					'700'  => __( 'Bold', 'useful-addons-elementor' ),
					'800'  => __( 'Extra Bold', 'useful-addons-elementor' ),
					'900'  => __( 'Black', 'useful-addons-elementor' ),
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA PieChart Tooltip style controls */
	private function get_style_piechart_tooltip( ){
		$this->start_controls_section( 'UA_pie_chart_tooltip_styles',
			[
				'label'     => __( 'Tooltip', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'UA_pie_chart_types' => 'line'
                ]
			]
		);
		$this->add_control( 'UA_pie_chart_tooltip_title_clr',
			[
				'label'   => __( 'Title Color', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '#ffffff',
			]
		);
		$this->add_control( 'UA_pie_chart_tooltip_body_clr',
			[
				'label'   => __( 'BodyFont Color', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '#ffffff',
			]
		);
		$this->add_control( 'UA_pie_chart_tooltip_body_bg',
			[
				'label'   => __( 'Body Background', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '#212121',
			]
		);
		$this->add_control( 'UA_pie_chart_tooltip_caret_show',
			[
				'label'        => __( 'Show Caret', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'UA_pie_chart_tooltip_caret_size',
			[
				'label'  => __( 'Caret Size', 'useful-addons-elementor' ),
				'type'   => Controls_Manager::SLIDER,
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'default'  => [
					'size' => 5,
				],
				'condition' => [
					'UA_pie_chart_tooltip_caret_show' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'UA_pie_chart_tooltip_xpadding',
			[
				'label'  => __( 'xPadding', 'useful-addons-elementor' ),
				'type'   => Controls_Manager::SLIDER,
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default' => [
					'size' => 15,
				],
			]
		);
		$this->add_responsive_control( 'UA_pie_chart_tooltip_ypadding',
			[
				'label'  => __( 'yPadding', 'useful-addons-elementor' ),
				'type'   => Controls_Manager::SLIDER,
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default' => [
					'size' => 15,
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA PieChart Legend style controls */
	private function get_style_piechart_legend( ){
		$this->start_controls_section( 'UA_pie_chart_legend_styles',
			[
				'label'     => __( 'Legend', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'UA_pie_chart_types' => 'line'
                ]
			]
		);
		$this->add_control( 'UA_pie_chart_legend_size',
			[
				'label'      => __( 'Font Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'size' => 14,
				],
			]
		);
		$this->add_control( 'UA_pie_chart_legend_font_weight',
			[
				'label'   => __( 'Font Weight', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'bold',
				'options' => [
					'thin'        => __( 'Thin', 'useful-addons-elementor' ),
					'extra-light' => __( 'Extra Light', 'useful-addons-elementor' ),
					'light'       => __( 'Light', 'useful-addons-elementor' ),
					'regular'     => __( 'Regular', 'useful-addons-elementor' ),
					'medium'      => __( 'Medium', 'useful-addons-elementor' ),
					'semi-bold'   => __( 'Semi Bold', 'useful-addons-elementor' ),
					'bold'        => __( 'Bold', 'useful-addons-elementor' ),
					'extra-bold'  => __( 'Extra Bold', 'useful-addons-elementor' ),
					'black'       => __( 'Black', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control( 'UA_pie_chart_legend_font_clr',
			[
				'label'   => __( 'Font Color', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '#233d63',
			]
		);
		$this->add_control( 'UA_pie_chart_legend_box_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
				],
				'default'  => [
					'size' => 50,
				],
			]
		);
		$this->add_responsive_control( 'UA_pie_chart_legend_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
				],
				'default'  => [
					'size' => 25,
				],
			]
		);
		$this->add_control( 'UA_pie_chart_legend_font_family',
			[
				'label'   => __( 'Font Family', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::FONT,
				'default' => "Barlow",
			]
		);
		$this->end_controls_section();
	}
	/* UA PieChart Guidline style Controls */
	private function get_style_piechart_guidline( ){
		$this->start_controls_section( 'UA_pie_chart_guidline_styles',
			[
				'label'     => __( 'GuidLine', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'UA_pie_chart_types' => 'line'
                ]
			]
		);
		$this->add_control( 'UA_pie_chart_guidline_xguidline_clr',
			[
				'label'   => __( 'xGuidLine Color', '' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '#eeeeee',
			]
		);
		$this->add_control( 'UA_pie_chart_guidline_yguidline_clr',
			[
				'label'   => __( 'yGuidLine Color', '' ),
				'type'    => Controls_Manager::COLOR,
				'default' => '#eeeeee',
			]
		);
		$this->add_control( 'UA_pie_chart_ticks_size',
			[
				'label'  => __( 'Ticks Size', 'useful-addons-elementor' ),
				'type'   => Controls_Manager::SLIDER,
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'size' => 14,
				],
			]
		);
		$this->add_control( 'UA_pie_chart_elements_hd',
			[
				'label'     => __( 'Elements', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'UA_pie_chart_elements_tension',
			[
				'label'  => __( 'Tension', 'useful-addons-elementor' ),
				'type'   => Controls_Manager::SLIDER,
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 0.1,
					],
				],
				'default'  => [
					'size' => 0.4,
				],
			]
		);
		$this->add_control( 'UA_pie_chart_elements_bwidth',
			[
				'label'  => __( 'Border Width', 'useful-addons-elementor' ),
				'type'   => Controls_Manager::SLIDER,
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'default'  => [
					'size' => 1,
				],
			]
		);
		$this->end_controls_section();
	}
	
	/* UA Doughnut Chart Styles */
    private function get_style_doughnut_chart() {
        $this->start_controls_section('ua_doughnut_chart_style',
            [
                'label'     => __('Pie Chart Default Styles', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'UA_pie_chart_types' => 'doughnut'
                ]
            ]
        );
        $this->add_control('doughnut_chart_border_width',
            [
                'label'      => __( 'Border Width', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px'],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'  => [
                    'size' => 3,
                ],
            ]
        );
        $this->add_control('doughnut_chart_d_size',
            [
                'label'      => __( 'Default Font-size', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px'],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default'  => [
                    'size' => 14,
                ],
            ]
        );
        $this->add_control('doughnut_chart_d_clr',
            [
                'label'   => __( 'Default Font Color', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::COLOR,
                'default' => "#222232",
            ]
        );
        $this->add_control('doughnut_chart_d_font_family',
            [
                'label'     => __( 'Default Font Family', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::FONT,
                'default'   => "Barlow",
            ]
        );
        $this->add_control('doughnut_chart_d_font_weight',
            [
                'label'   => __( 'Default Font Weight', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '700',
                'options' => [
                    '100'  => __( '100', 'useful-addons-elementor' ),
                    '200'  => __( '200', 'useful-addons-elementor' ),
                    '300'  => __( '300', 'useful-addons-elementor' ),
                    '400'  => __( '400', 'useful-addons-elementor' ),
                    '500'  => __( '500', 'useful-addons-elementor' ),
                    '600'  => __( '600', 'useful-addons-elementor' ),
                    '700'  => __( '700', 'useful-addons-elementor' ),
                    '800'  => __( '800', 'useful-addons-elementor' ),
                    '900'  => __( '900', 'useful-addons-elementor' ),
                ],
            ]
        );
        $this->end_controls_section();
    }
    /* UA Doughnut Chart Tooltip Styles */
    private function get_style_doughnut_tooltip() {
        $this->start_controls_section('doughnut_chart_tooltip_style',
            [
                'label'     => __('Tooltip', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'UA_pie_chart_types' => 'doughnut'
                ]
            ]
        );
        $this->add_control('doughnut_chart_tooltip_title_size',
            [
                'label'      => __( 'Title Size', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'  => [
                    'px' => [
                        'min'  => 1,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'  => [
                    'size' => 56,
                ],
            ]
        );
        $this->add_control('doughnut_chart_tooltip_title_clr',
            [
                'label'   => __( 'Title Color', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::COLOR,
                'default' => '#222232'
            ]
        );
        $this->add_control('doughnut_chart_tooltip_bodyfont_clr',
            [
                'label'   => __( 'BodyFont Color', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::COLOR,
                'default' => '#222232'
            ]
        );
        $this->add_control('doughnut_chart_tooltip_bodyfont_weight',
            [
                'label'   => __( 'BodyFont Weight', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '500',
                'options' => [
                    '100'  => __( '100', 'useful-addons-elementor' ),
                    '200'  => __( '200', 'useful-addons-elementor' ),
                    '300'  => __( '300', 'useful-addons-elementor' ),
                    '400'  => __( '400', 'useful-addons-elementor' ),
                    '500'  => __( '500', 'useful-addons-elementor' ),
                    '700'  => __( '700', 'useful-addons-elementor' ),
                    '800'  => __( '800', 'useful-addons-elementor' ),
                    '900'  => __( '900', 'useful-addons-elementor' ),
                ],
            ]
        );
        $this->add_control('doughnut_chart_tooltip_body_bg',
            [
                'label'   => __( 'Body Background', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::COLOR,
                'default' => '#ffffff'
            ]
        );
        $this->add_control('doughnut_chart_tooltip_font_family',
            [
                'label'   => __( 'Font Family', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::FONT,
                'default' => "Barlow",
            ]
        );
        $this->add_control('doughnut_chart_tooltip_radius',
            [
                'label'      => __( 'Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'  => [
                    'size' => 5
                ]
            ]
        );
        $this->add_responsive_control('doughnut_chart_tooltip_xpd',
            [
                'label'      => __( 'Xpadding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'  => [
                    'size' => 20
                ]
            ]
        );
        $this->add_responsive_control('doughnut_chart_tooltip_ypd',
            [
                'label'      => __( 'Ypadding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'  => [
                    'size' => 20
                ]
            ]
        );
        $this->add_control('doughnut_chart_tooltip_bsize',
            [
                'label'      => __( 'Border Size', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'  => [
                    'size' => 3
                ]
            ]
        );
        $this->add_control('doughnut_chart_tooltip_bclr',
            [
                'label'   => __( 'Border Color', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::COLOR,
                'default' => 'rgba(0, 0, 0, .9)'
            ]
        );
        // Tooltip Caret
        $this->add_control('doughnut_chart_tooltip_caret_hd',
            [
                'label'     => __( 'Caret', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control('doughnut_chart_tooltip_caret_size',
            [
                'label'      => __( 'Size', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'  => [
                    'size' => 0
                ]
            ]
        );
        $this->end_controls_section();
    }
    /* UA Doughnut Chart Legend Styles */
    private function get_style_doughnut_legend() {
        $this->start_controls_section('doughnut_chart_legend_style',
            [
                'label'     => __('Legend', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'UA_pie_chart_types' => 'doughnut'
                ]
            ]
        );
        $this->add_control('doughnut_chart_legend_fontsize',
            [
                'label'      => __( 'Font Size', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'  => [
                    'size' => 13,
                ],
            ]
        );
        $this->add_control('doughnut_chart_legend_font_family',
            [
                'label'   => __( 'Font Family', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::FONT,
                'default' => "Barlow",
            ]
        );
        $this->add_control('doughnut_chart_legend_fontweight',
            [
                'label'   => __( 'Font Weight', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '700',
                'options' => [
                    '100'  => __( '100', 'useful-addons-elementor' ),
                    '200'  => __( '200', 'useful-addons-elementor' ),
                    '300'  => __( '300', 'useful-addons-elementor' ),
                    '400'  => __( '400', 'useful-addons-elementor' ),
                    '500'  => __( '500', 'useful-addons-elementor' ),
                    '600'  => __( '600', 'useful-addons-elementor' ),
                    '700'  => __( '700', 'useful-addons-elementor' ),
                    '800'  => __( '800', 'useful-addons-elementor' ),
                    '900'  => __( '900', 'useful-addons-elementor' ),
                ],
            ]
        );
        $this->add_control('doughnut_chart_legend_fontclr',
            [
                'label'   => __( 'Font Color', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::COLOR,
                'default' => '#7c7c82'
            ]
        );
        $this->add_control('doughnut_chart_legend_boxwidth',
            [
                'label'      => __( 'Box Width', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 500,
                        'step' => 1,
                    ],
                ],
                'default'  => [
                    'size' => 50,
                ],
            ]
        );
        $this->add_responsive_control('doughnut_chart_legend_pd',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default'  => [
                    'size' => 13,
                ],
            ]
        );
        $this->end_controls_section();
    }

	protected function _register_controls() {
	    $this->get_query_piechart();
	    $this->get_style_piechart_line();
	    $this->get_style_piechart_tooltip();
	    $this->get_style_piechart_legend();
	    $this->get_style_piechart_guidline();
	    $this->get_style_doughnut_chart();
	    $this->get_style_doughnut_tooltip();
	    $this->get_style_doughnut_legend();
	}
	protected function render( ) {
		$settings                = $this->get_settings_for_display();
		$piechart_line_lists     = $this->get_settings_for_display( 'UA_pie_chart_repeaters' );
		$ua_doughnut_chart_items = $this->get_settings_for_display( 'ua_doughnut_datasets_items' );

    ?>
        <div class="line_charts">
            <?php
            if ( $settings['UA_pie_chart_types'] == 'line' ) {
                ?>
                <canvas id="result-chart" height="240"></canvas>
                <?php
            }
                if ( $settings['UA_pie_chart_types'] == 'doughnut' ) {
            ?>
                <canvas id="doughnutChart" ></canvas>
            <?php } ?>
        </div>
        <script>
            /*==== result-chart =====*/
            <?php if ( $settings['UA_pie_chart_types'] == 'line' ) { ?>
                var ctx = document.getElementById('result-chart');
                Chart.defaults.global.defaultFontFamily = '<?php echo esc_attr($settings['UA_pie_chart_default_font_family']); ?>';
                Chart.defaults.global.defaultFontSize = <?php echo esc_attr($settings['UA_pie_chart_default_font_size']['size']); ?>;
                Chart.defaults.global.defaultFontStyle = '<?php echo esc_attr($settings['UA_pie_chart_default_fontweight']); ?>';
                Chart.defaults.global.defaultFontColor = '<?php echo esc_attr($settings['UA_pie_chart_default_clr']); ?>';
                var chart_type = '<?php echo esc_attr($settings['UA_pie_chart_types']); ?>';
                var chart = new Chart(ctx, {
                    // The type of chart we want to create
                    type: chart_type,
                    // The data for our dataset
                    data: {
                        labels: [
                            <?php
                            $UA_pie_chart_labels_setting = $settings['UA_pie_chart_labels'];
                            $UA_pie_chart_labels_loops = explode(",", $UA_pie_chart_labels_setting);
                            foreach ($UA_pie_chart_labels_loops as $UA_pie_chart_labels_loop) {
                                echo "'" . $UA_pie_chart_labels_loop . "',";
                            }
                            ?>
                        ],
                        datasets: [
                            <?php
                            foreach ( $piechart_line_lists as $index => $piechart_line_list ) {
                            $UA_pie_chart_datas_list = $piechart_line_list['UA_pie_chart_datas'];
                            $UA_pie_chart_datas_list_counts = explode(",", $UA_pie_chart_datas_list);
                            ?>
                            {
                                label: "<?php echo esc_attr($piechart_line_list['UA_pie_chart_label_title']); ?>",
                                type: chart_type,
                                data: [
                                    <?php
                                    foreach ($UA_pie_chart_datas_list_counts as $UA_pie_chart_datas_list_count) {
                                        echo $UA_pie_chart_datas_list_count . ',';
                                    }
                                    ?>
                                ],
                                backgroundColor: '<?php echo esc_attr($piechart_line_list['UA_pie_chart_background']); ?>',
                                borderColor: '<?php echo esc_attr($piechart_line_list['UA_pie_chart_border_clr']); ?>',
                                pointBackgroundColor: '<?php echo esc_attr($settings['UA_pie_chart_line_pntbg']); ?>',
                                pointBorderColor: '<?php echo esc_attr($piechart_line_list['UA_pie_chart_pntborder_clr']); ?>',
                                borderWidth: <?php echo esc_attr($settings['UA_pie_chart_line_width']['size']); ?>,
                                pointRadius: <?php echo esc_attr($settings['UA_pie_chart_line_pntsize']['size']); ?>
                            },
                            <?php } ?>
                        ]
                    },
                    // Configuration options go here
                    options: {
                        tooltips: {
                            yAlign: '<?php echo $settings['UA_pie_chart_tooltip_alignment']; ?>',
                            custom: function (tooltip) {
                                if (!tooltip) return;
                                // disable displaying the color box;
                                tooltip.displayColors = false;
                            },
                            titleFontColor: '<?php echo esc_attr($settings['UA_pie_chart_tooltip_title_clr']); ?>',
                            bodyFontColor: '<?php echo esc_attr($settings['UA_pie_chart_tooltip_body_clr']); ?>',
                            backgroundColor: '<?php echo esc_attr($settings['UA_pie_chart_tooltip_body_bg']); ?>',
                            caretSize: <?php if($settings['UA_pie_chart_tooltip_caret_show'] == 'yes') {
                                echo esc_attr($settings['UA_pie_chart_tooltip_caret_size']['size']);
                            } else { ?> 0 <?php } ?>,
                            xPadding: <?php echo esc_attr($settings['UA_pie_chart_tooltip_xpadding']['size']); ?>,
                            yPadding: <?php echo esc_attr($settings['UA_pie_chart_tooltip_ypadding']['size']); ?>,
                            borderWidth: 3,
                            borderColor: "blue"
                        },
                        legend: {
                            display: true,
                            position: '<?php echo esc_attr($settings['UA_pie_chart_legend_position']); ?>',
                            tooltips: {
                                displayColors: true,
                            },
                            labels: {
                                fontSize: <?php echo esc_attr($settings['UA_pie_chart_legend_size']['size']); ?>,
                                fontStyle: '<?php echo esc_attr($settings['UA_pie_chart_legend_font_weight']); ?>',
                                fontColor: '<?php echo esc_attr($settings['UA_pie_chart_legend_font_clr']); ?>',
                                boxWidth: <?php echo esc_attr($settings['UA_pie_chart_legend_box_width']['size']); ?>,
                                padding: <?php echo esc_attr($settings['UA_pie_chart_legend_box_padding']['size']); ?>,
                                defaultFontStyle: '<?php echo esc_attr($settings['UA_pie_chart_legend_font_weight']); ?>',
                                fontFamily: '<?php echo esc_attr($settings['UA_pie_chart_legend_font_family']); ?>',
                                usePointStyle: true,
                            }
                        },

                        scales: {
                            xAxes: [{
                                display: true,
                                gridLines: {
                                    color: '<?php echo esc_attr($settings['UA_pie_chart_guidline_xguidline_clr']); ?>',
                                }
                            }],
                            yAxes: [{
                                display: true,
                                gridLines: {
                                    color: '<?php echo esc_attr($settings['UA_pie_chart_guidline_yguidline_clr']); ?>',
                                },
                                ticks: {
                                    fontSize: <?php echo esc_attr($settings['UA_pie_chart_ticks_size']['size']); ?>,
                                }
                            }]

                        },
                        elements: {
                            line: {
                                tension: <?php echo esc_attr($settings['UA_pie_chart_elements_tension']['size']); ?>,
                                borderWidth: <?php echo esc_attr($settings['UA_pie_chart_elements_bwidth']['size']); ?>,
                            }
                        }
                    }
                });
            <?php }

                if( $settings['UA_pie_chart_types'] == 'doughnut') {
            ?>
            //doughnut chart
            var ctx = document.getElementById( "doughnutChart" );
            <?php if (!empty($settings['doughnut_chart_d_font_family'])) { ?>
                Chart.defaults.global.defaultFontFamily = '<?php echo esc_attr($settings['doughnut_chart_d_font_family']); ?>';
            <?php
            }

            if (!empty( $settings['doughnut_chart_d_size'] ) ) { ?>
                Chart.defaults.global.defaultFontSize = <?php echo esc_attr($settings['doughnut_chart_d_size']['size']); ?>;
            <?php } ?>
                Chart.defaults.global.defaultFontStyle = '<?php echo esc_attr($settings['doughnut_chart_d_font_weight']); ?>';

            <?php
            if (!empty($settings['doughnut_chart_d_clr'])) { ?>
                Chart.defaults.global.defaultFontColor = '<?php echo esc_attr($settings['doughnut_chart_d_clr']); ?>';
            <?php  } ?>
            // ctx.height = 100;
            var myChart = new Chart( ctx, {
                type: 'doughnut',
                data: {
                    datasets: [ {
                        data: [
                            <?php
                                foreach ( $ua_doughnut_chart_items as $index => $ua_doughnut_chart_item ) {
                                    $ua_doughnut_datas = $ua_doughnut_chart_item['ua_doughnut_datas'];
                                    $ua_doughnut_datas_expld = explode(",", $ua_doughnut_datas);
                                    foreach ($ua_doughnut_datas_expld as $ua_doughnut_data_expld) {
                                        echo $ua_doughnut_data_expld.', ';
                                    }
                                }
                            ?>
                        ],
                        backgroundColor: [
                            <?php
                            foreach ( $ua_doughnut_chart_items as $ua_doughnut_chart_item ) {
                                $ua_doughnut_bgs = $ua_doughnut_chart_item['ua_doughnut_chart_bg'];
                                $ua_doughnut_bgs_expld = explode(",", $ua_doughnut_bgs);
                                foreach ($ua_doughnut_bgs_expld as $ua_doughnut_bg_expld) {
                                    echo '"'.$ua_doughnut_bg_expld.'", ';
                                }
                            }
                            ?>
                        ],
                        hoverBackgroundColor: [
                            <?php
                            foreach ( $ua_doughnut_chart_items as $ua_doughnut_chart_item ) {
                                $ua_doughnut_hv_bgs = $ua_doughnut_chart_item['ua_doughnut_chart_hv_bg'];
                                $ua_doughnut_hv_bgs_expld = explode(",", $ua_doughnut_hv_bgs);
                                foreach ($ua_doughnut_hv_bgs_expld as $ua_doughnut_hv_bg_expld) {
                                    echo '"'.$ua_doughnut_hv_bg_expld.'", ';
                                }
                            }
                            ?>
                        ],
                        borderWidth: <?php echo esc_attr($settings['doughnut_chart_border_width']['size']); ?>
                    } ],
                    labels: [
                        <?php
                        foreach ( $ua_doughnut_chart_items as $index => $ua_doughnut_chart_item ) {
                            $ua_doughnut_datas       = $ua_doughnut_chart_item['ua_doughnut_label'];
                            $ua_doughnut_datas_expld = explode(",", $ua_doughnut_datas);
                            foreach ($ua_doughnut_datas_expld as $ua_doughnut_data_expld) {
                                echo '"'.$ua_doughnut_data_expld.'", ';
                            }
                        }
                        ?>
                    ]
                },
                options: {
                    responsive: true,
                    tooltips: {
                        yAlign: '<?php echo $settings['UA_pie_chart_tooltip_alignment']; ?>',
                        custom: function(tooltip) {
                            if (!tooltip) return;
                            // disable displaying the color box;
                            tooltip.displayColors = false;
                        },
                        mode: 'index',
                        titleFontSize: <?php echo esc_attr($settings['doughnut_chart_tooltip_title_size']['size']); ?>,
                        titleFontColor: '<?php echo esc_attr($settings['doughnut_chart_tooltip_title_clr']); ?>',
                        bodyFontColor: '<?php echo esc_attr($settings['doughnut_chart_tooltip_bodyfont_clr']); ?>',
                        bodyFontStyle: '<?php echo esc_attr($settings['doughnut_chart_tooltip_bodyfont_weight']); ?>',
                        backgroundColor: '<?php echo esc_attr($settings['doughnut_chart_tooltip_body_bg']); ?>',
                        titleFontFamily: '<?php echo esc_attr($settings['doughnut_chart_tooltip_font_family']); ?>',
                        bodyFontFamily: '<?php echo esc_attr($settings['doughnut_chart_tooltip_font_family']); ?>',
                        cornerRadius: <?php echo esc_attr($settings['doughnut_chart_tooltip_radius']['size']); ?>,
                        caretSize: <?php echo esc_attr($settings['doughnut_chart_tooltip_caret_size']['size']); ?>,
                        xPadding: <?php echo esc_attr($settings['doughnut_chart_tooltip_xpd']['size']); ?>,
                        yPadding: <?php echo esc_attr($settings['doughnut_chart_tooltip_ypd']['size']); ?>,
                        borderWidth: <?php echo esc_attr($settings['doughnut_chart_tooltip_bsize']['size']); ?>,
                        borderColor:  "<?php echo esc_attr($settings['doughnut_chart_tooltip_bclr']); ?>"
                    },
                    legend: {
                        display: true,
                        position: '<?php echo esc_attr($settings['UA_pie_chart_legend_position']); ?>',
                        labels: {
                            fontSize: <?php echo esc_attr($settings['doughnut_chart_legend_fontsize']['size']) ?>,
                            fontStyle: '<?php echo esc_attr($settings['doughnut_chart_legend_fontweight']); ?>',
                            fontColor: '<?php echo esc_attr($settings['doughnut_chart_legend_fontclr']); ?>',
                            boxWidth: <?php echo esc_attr($settings['doughnut_chart_legend_boxwidth']['size']); ?>,
                            padding: <?php echo esc_attr($settings['doughnut_chart_legend_pd']['size']); ?>,
                            bodyFontStyle: '<?php echo esc_attr($settings['doughnut_chart_legend_fontweight']); ?>',
                            fontFamily: '<?php echo esc_attr($settings['doughnut_chart_legend_font_family']); ?>',
                            usePointStyle: true
                        }
                    }
                }
            } );

            <?php  } ?>
        </script>

	<?php }

	protected function _content_template() {}
}
Plugin::instance()->widgets_manager->register_widget_type( new UA_pie_chart() );


