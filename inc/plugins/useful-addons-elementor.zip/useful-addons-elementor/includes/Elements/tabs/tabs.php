<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_tabs extends Widget_Base {

    /**
     * Get all elementor page templates
     * @param null $type
     * @return array
     */
	function UA_get_page_templates($type = null) {
		$template_args = [
			'post_type'      => 'elementor_library',
			'posts_per_page' => -1,
		];

		if ($type) {
			$template_args['tax_query'] = [
				[
					'taxonomy' => 'elementor_library_type',
					'field'    => 'slug',
					'terms'    => $type,
				],
			];
		}

		$page_templates = get_posts($template_args);
		$options        = array();

		if ( !empty( $page_templates ) && !is_wp_error( $page_templates )) {
			foreach ( $page_templates as $post ) {
				$options[$post->ID] = $post->post_title;
			}
		}
		return $options;
	}


	public function get_name() {
		return 'UA_tabs';
	}

	public function get_title() {
		return esc_html__( 'Tabs', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-tabs ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Tabs Content Setting */
	private function get_content_tabs_content_setting( ){
		$this->start_controls_section( 'UA_tabs_content',
			[
				'label' => __( 'Tabs', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'UA_tabs_different_style',
			[
				'label'   => __( 'Tabs Style', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style_1',
				'options' => [
					'style_1' => __( 'Style 1', 'useful-addons-elementor' ),
					'style_2' => __( 'Style 2', 'useful-addons-elementor' ),
					'style_3' => __( 'Style 3', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control( 'tabs_st2_nav_shape_show',
			[
				'label'        => __( 'Show Tabs nav shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'UA_tabs_different_style' => 'style_2',
				],
			]
		);
		// Tab style 1
		$this->add_responsive_control( 'UA_tabs_alignment',
			[
				'label'   => __('Navs Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0' => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => '1',
				'condition' => [
					'UA_tabs_different_style' => 'style_1',
				],
			]
		);
		$this->add_control( 'UA_tabs_shape', [
			'label'        => __( 'Show Nav\'s Shape', 'useful-addons-elementor' ),
			'type'         => Controls_Manager::SWITCHER,
			'label_on'     => __( 'Show', 'useful-addons-elementor' ),
			'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
			'return_value' => 'yes',
			'default'      => 'yes',
			'condition'    => [
				'UA_tabs_different_style' => 'style_1',
			],
		] );
		// Tab style 1 repeater
		$repeater1 = new Repeater();
		$repeater1->add_control('UA_tabs_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Tab title', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
				'label_block' => true,
			]
		);
		$repeater1->add_control('UA_tabs_description',
			[
				'label'       => __( 'Description', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 15,
				'default'     => __( 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
			]
		);
		$repeater1->add_control('UA_tabs_image_alignments',
			[
				'label'   => __( 'Image Position', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'left'  => __( 'Left', 'useful-addons-elementor' ),
					'right' => __( 'Right', 'useful-addons-elementor' ),
				],
			]
		);
		$repeater1->add_control('UA_tabs_image',
			[
				'label'   => __( 'Choose Image', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater1->add_control('UA_tabs_button_tx',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Get Started', 'useful-addons-elementor' ),
				'placeholder' => __( 'e.g button text', 'useful-addons-elementor' ),
			]
		);
		$repeater1->add_control('UA_tabs_button_url',
			[
				'label'         => __( 'Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);
		$repeater1->add_control('UA_tabs_button_icon_dependency',
			[
				'label'        => __( 'Show Button Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater1->add_control( 'UA_tabs_button_icon',
			[
				'label'            => __( 'Button Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'UA_tabs_button_icon_dependency' => 'yes',
				],
			]
		);
		$repeater1->add_control('UA_tabs_button_icon_position',
			[
				'label'     => __( 'Icon Position', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'default',
				'options'   => [
					'default' => __( 'Default', 'useful-addons-elementor' ),
					'top'     => __( 'Top', 'useful-addons-elementor' ),
					'right'   => __( 'Right', 'useful-addons-elementor' ),
					'bottom'  => __( 'Bottom', 'useful-addons-elementor' ),
					'left'    => __( 'Left', 'useful-addons-elementor' ),
				],
				'condition' => [
					'UA_tabs_button_icon_dependency' => 'yes',
				],
			]
		);
		$this->add_control( 'UA_tabs', [
			'label'       => __( 'Tabs Items', 'elementor' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => $repeater1->get_controls(),
			'condition'   => [
				'UA_tabs_different_style' => 'style_1',
			],
			'default'     => [
				[
					'UA_tabs_title'            => __( 'Expert Team', 'useful-addons-elementor' ),
					'UA_tabs_description'      => __( 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet', 'useful-addons-elementor' ),
					'UA_tabs_image_alignments' => 'left',
				],
				[
					'UA_tabs_title'            => __( 'Best Finance Brand', 'useful-addons-elementor' ),
					'UA_tabs_description'      => __( 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet', 'elementor' ),
					'UA_tabs_image_alignments' => 'right',
				],
				[
					'UA_tabs_title'            => __( 'Best Leadership Ideas', 'useful-addons-elementor' ),
					'UA_tabs_description'      => __( 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet', 'elementor' ),
					'UA_tabs_image_alignments' => 'left',
				],
			],
			'title_field' => '{{{ UA_tabs_title }}}',
		] );

		// Tab Style 2 repeater
		$this->add_control( 'UA_tabs_st2', [
			'label'       => __( 'Tabs Items', 'elementor' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => [
				[
					'name'        => 'UA_tabs_st2_title',
					'label'       => __( 'Tab Title', 'useful-addons-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Tab title', 'useful-addons-elementor' ),
					'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
					'label_block' => true,
				],
				[
					'name'        => 'UA_tabs_st2_description',
					'label'       => __( 'Tab Description', 'useful-addons-elementor' ),
					'type'        => Controls_Manager::TEXTAREA,
					'rows'        => 5,
					'default'     => __( 'The argument in favor of using filler text goes some thing like this', 'useful-addons-elementor' ),
					'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
				],
				[
					'name'        => 'UA_get_page_template',
					'label'       => __('Choose Template', 'useful-addons-elementor'),
					'label_block' => true,
					'type'        => Controls_Manager::SELECT2,
					'options'     => $this->UA_get_page_templates(),
				],
			],
			'condition' => [
				'UA_tabs_different_style' => 'style_2',
			],
			'default'     => [
				[
					'UA_tabs_st2_title'            => __( 'Tab 1', 'useful-addons-elementor' ),
					'UA_tabs_st2_description'      => __( 'Description 1', 'useful-addons-elementor' ),
				],
				[
					'UA_tabs_st2_title'            => __( 'Tab 2', 'useful-addons-elementor' ),
					'UA_tabs_st2_description'      => __( 'Description 2', 'elementor' ),
				],
			],
			'title_field' => '{{{ UA_tabs_st2_title }}}',
		] );

		/* Tab style 3 repeater */
		$this->add_control( 'tab_st3_lists', [
			'label'       => __( 'Tab Items', 'elementor' ),
			'type'        => Controls_Manager::REPEATER,
			'fields'      => [
				[
					'name'        => 'tabs_st3_title',
					'label'       => __( 'Tab Title', 'useful-addons-elementor' ),
					'type'        => Controls_Manager::TEXT,
					'default'     => __( 'Tab title', 'useful-addons-elementor' ),
					'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
					'label_block' => true,
				],
                [
                    'name'         => 'tabs_st3_icon_show',
                    'label'        => __( 'Show Icon', 'useful-addons-elementor' ),
                    'type'         => Controls_Manager::SWITCHER,
                    'label_on'     => __( 'Show', 'useful-addons-elementor' ),
                    'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
                    'return_value' => 'yes',
                    'default'      => 'yes',
                ],
				[
					'name'             => 'tabs_st3_icon',
					'label'            => __( 'Tab Icon', 'useful-addons-elementor' ),
					'type'             => Controls_Manager::ICONS,
					'fa4compatibility' => 'icon',
					'label_block'      => true,
					'default'          => [
						'value'   => 'la la-shopping-cart',
						'library' => 'solid',
					],
					'recommended'  => [
						'fa-solid' => [
							'angle-right',
							'angle-left',
							'arrow-alt-circle-down',
							'arrow-alt-circle-up',
							'arrow-alt-circle-left',
							'arrow-alt-circle-right',
							'arrow-circle-down',
							'arrow-circle-up',
							'arrow-circle-left',
							'arrow-circle-right',
							'arrow-down',
							'arrow-up',
							'arrow-left',
							'arrow-right',
							'arrows-alt',
							'arrows-alt-h',
							'arrows-alt-v',
							'cart-arrow-down',
							'compress-arrows-alt',
							'expand-rows-alt',
							'location-arrow',
							'long-arrow-alt-down',
							'long-arrow-alt-up',
							'long-arrow-alt-left',
							'long-arrow-alt-right',
						],
					],
                    'condition'    => [
                        'tabs_st3_icon_show' => 'yes'
                    ]
				],
				[
					'name'        => 'tabs_st3_get_page_template',
					'label'       => __('Choose Template', 'useful-addons-elementor'),
					'label_block' => true,
					'type'        => Controls_Manager::SELECT2,
					'options'     => $this->UA_get_page_templates(),
				],
			],
			'condition'   => [
				'UA_tabs_different_style' => 'style_3',
			],
			'default'     => [
				[
					'tabs_st3_title'            => __( 'Tab 1', 'useful-addons-elementor' ),
					'tabs_st3_icon'             => __( 'la la-user', 'useful-addons-elementor' ),
				],
				[
					'tabs_st3_title'            => __( 'Tab 2', 'useful-addons-elementor' ),
					'tabs_st3_icon'             => __( 'la la-user', 'useful-addons-elementor' ),
				],
			],
			'title_field' => '{{{ tabs_st3_title }}}',
		] );

		$this->end_controls_section();
	}
	/* UA Tabs Style Settings */
	private function get_style_tabs_style_settings( ){
		$this->start_controls_section( 'UA_tabs_style',
			[
				'label'     => __( 'Tabs Nav', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'UA_tabs_different_style' => 'style_1',
				]
			]
		);
		$this->add_control( 'UA_tabs_active_clr',
			[
				'label'     => __( 'Active Tabs Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a.active, {{WRAPPER}} .tab-content-shared .nav-tabs li.active a, {{WRAPPER}} .tab-content-shared .nav-tabs li.active a:hover, {{WRAPPER}} .tab-content-shared .nav-tabs li a.active:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_tabs_active_bg',
			[
				'label'     => __( 'Active Tabs Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li.active a, {{WRAPPER}} .tab-content-shared .nav-tabs li a.active:hover, {{WRAPPER}} .tab-content-shared .nav-tabs li a.active:hover, {{WRAPPER}} .tab-content-shared .nav-tabs li a.active' => 'background: {{VALUE}};border-color: {{VALUE}}',
				],
			]
		);

		// start tab
		$this->start_controls_tabs( 'UA_tabs_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_tabs_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_tabs_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_tabs_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_tabs_normal_border',
				'label'    => esc_html__( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .nav-tabs li a',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#233d63',
					],
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '4',
					'right'     => '4',
					'bottom'    => '4',
					'left'      => '4',
					'unit'      => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_tabs_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .nav-tabs li a',
			]
		);
		$this->add_responsive_control( 'UA_tabs_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '15',
					'right'     => '30',
					'bottom'    => '15',
					'left'      => '30',
					'unit'      => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '10',
					'right'     => '5',
					'bottom'    => '0',
					'left'      => '0',
					'unit'      => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'UA_tabs_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_tabs_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_tabs_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_tabs_hover_border',
				'label'    => esc_html__( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .nav-tabs li a:hover',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#f66b5d',
					],
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a:hover, {{WRAPPER}} .tab-content-shared .nav-tabs li.active a, {{WRAPPER}} .tab-content-shared .nav-tabs li a.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_tabs_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .nav-tabs li a:hover, {{WRAPPER}} .tab-content-shared .nav-tabs li.active a, {{WRAPPER}} .tab-content-shared .nav-tabs li a.active',
			]
		);
		$this->add_responsive_control( 'UA_tabs_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a:hover, {{WRAPPER}} .tab-content-shared .nav-tabs li.active a, {{WRAPPER}} .tab-content-shared .nav-tabs li a.active' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a:hover, {{WRAPPER}} .tab-content-shared .nav-tabs li.active a, {{WRAPPER}} .tab-content-shared .nav-tabs li a.active' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_tabs_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .nav-tabs li a',
			]
		);
		$this->add_responsive_control( 'UA_tabs_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'more_options',
			[
				'label'     => __( 'Tab\'s Shape', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'UA_tabs_shape' => 'yes',
				],
			]
		);
		$this->add_control( 'UA_tabs_shape_normal_bg',
			[
				'label'     => __( 'shape Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a.active:after, {{WRAPPER}} .tab-content-shared .nav-tabs li.active a:after' => 'border-top-color: {{VALUE}}',
				],
				'condition' => [
					'UA_tabs_shape' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_shape_size',
			[
				'label'      => __( 'Shape\' Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a:after' => 'border-width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_tabs_shape' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_shape_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .nav-tabs li a:after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_tabs_shape' => 'yes',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Tabs Image Style Setting */
	private function get_style_tabs_img_style( ){
		$this->start_controls_section( 'UA_tabs_image_style',
			[
				'label'     => __( 'Image', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'UA_tabs_different_style' => 'style_1',
				]
			]
		);
		$this->add_responsive_control( 'UA_tabs_image_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_image_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_tabs_image_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .tab-content .tab-img',
			]
		);
		$this->add_responsive_control( 'UA_tabs_image_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '4',
					'right'     => '0',
					'bottom'    => '0',
					'left'      => '4',
					'unit'      => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_image_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Tabs Description Style Setting */
	private function get_style_tabs_desc_style( ){
		$this->start_controls_section( 'UA_tabs_desc_style',
			[
				'label'     => __( 'Description', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'UA_tabs_different_style' => 'style_1',
				]
			]
		);
		$this->add_control( 'UA_tabs_desc_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#677286',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .tab__desc' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_tabs_desc_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .tab__desc',
			]
		);
		$this->add_responsive_control( 'UA_tabs_desc_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .tab__desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_desc_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '0',
					'right'     => '0',
					'bottom'    => '40',
					'left'      => '0',
					'unit'      => 'px',
					'isLinked'  => false,
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .tab__desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Tabs Button Style Setting */
	private function get_style_tabs_btn_style( ){
		$this->start_controls_section( 'UA_tabs_button_style',
			[
				'label'     => __( 'Button', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'UA_tabs_different_style' => 'style_1',
				]
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'UA_tabs_button_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_tabs_button_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_tabs_button_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_tabs_button_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '4',
					'right'     => '4',
					'bottom'    => '4',
					'left'      => '4',
					'unit'      => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_tabs_button_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button',
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '13',
					'right'     => '40',
					'bottom'    => '13',
					'left'      => '25',
					'unit'      => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'UA_tabs_button_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_tabs_button_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_tabs_button_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_tabs_button_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover',
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_tabs_button_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button',
			]
		);
		$this->add_control( 'buttons_icon_title',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default .fa__arrow' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default .fa__arrow' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_icon_size',
			[
				'label'      => __( 'Font size', 'my-element' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default .fa__arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_tabs_button_icon_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_tabs_button_icon_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_tabs_button_icon_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default .fa__arrow' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_tabs_button_icon_normal_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default .fa__arrow',
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_icon_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default .fa__arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_icon_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default .fa__arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_icon_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'UA_tabs_button_icon_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_tabs_button_icon_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default:hover .fa__arrow' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_tabs_button_icon_hover_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default:hover .fa__arrow',
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_icon_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default:hover .fa__arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_icon_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default:hover .fa__arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_button_icon_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.top:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.right:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.bottom:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.left:hover .fa__arrow, {{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box .theme-button.default:hover .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* UA Tabs Box Style Setting */
	private function get_style_tabs_box_style( ){
		$this->start_controls_section( 'UA_tabs_box_style',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'UA_tabs_different_style' => 'style_1',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_tabs_box_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .tab-content-shared .tab-content',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_tabs_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .tab-content',
			]
		);
		$this->add_responsive_control( 'UA_tabs_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '4',
					'left'     => '4',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_tabs_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .tab-content-shared .tab-content',
			]
		);
		$this->add_responsive_control( 'UA_tabs_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_box_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '40',
					'right'     => '0',
					'bottom'    => '0',
					'left'      => '0',
					'unit'      => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .tab-content-shared .tab-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		/* Content box */
		$this->add_control('ua_tab_cntbox_hd',
			[
				'label'     => __( 'Content Box', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control( 'UA_tabs_cntbox_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '43',
					'right'    => '30',
					'bottom'   => '0',
					'left'     => '10',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_tabs_cntbox_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .tab-content-shared .tab-content .tab-desc-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Tab Style 2 Style setting */
	private function get_style_tab_st2_style( ){
		$this->start_controls_section( 'UA_tabs_st2_nav_style',
			[
				'label'     => __( 'Tabs Nav', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'UA_tabs_different_style' => 'style_2',
				]
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'UA_tabs_st2_nav_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_tabs_st2_nav_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'tabs_st2_nav_normal_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'tabs_st2_nav_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'tabs_st2_nav_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right '   => '4',
					'bottom'   => '4',
					'left'     => '4',
					'unit'     => 'px',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'tabs_st2_nav_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'tabs_st2_nav_normal_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#233d63',
					],
				],
				'selector' => '{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a',
			]
		);
		$this->add_responsive_control( 'tabs_st2_nav_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '25',
					'right'    => '30',
					'bottom'   => '25',
					'left'     => '30',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'tabs_st2_nav_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '10',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'UA_tabs_st2_nav_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'tabs_st2_nav_hover_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:hover ,{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a.active, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li.active a, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:hover span, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a.active span, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li.active a span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'tabs_st2_nav_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:hover, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a.active, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li.active a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'tabs_st2_nav_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#F66B5D',
					],
				],
				'selectors'  => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:hover, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a.active, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li.active a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'tabs_st2_nav_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:hover, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li.active a, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a.active',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'tabs_st2_nav_hover_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#F66B5D',
					],
				],
				'selector' => '{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:hover, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li.active a, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a.active',
			]
		);
		$this->add_responsive_control( 'tabs_st2_nav_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:hover, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a.active, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li.active a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'tabs_st2_nav_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:hover, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a.active, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li.active a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_UA_tabs_st2_nav_tabs',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		// nav title
		$this->add_control( 'UA_tabs_st2_nav_title_hd',
			[
				'label'     => __( 'Nav Title', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'tabs_st2_nav_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a',
			]
		);
		// nav subtitle
		$this->add_control( 'UA_tabs_st2_nav_stitle_hd',
			[
				'label'     => __( 'Nav SubTitle', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'tabs_st2_nav_stitle_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a span',
			]
		);
		$this->add_responsive_control( 'tabs_st2_nav_stitle_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '6',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// nav shape
		$this->add_control( 'UA_tabs_st2_nav_shape_hd',
			[
				'label'     => __( 'Nav Shape', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'tabs_st2_nav_shape_show' => 'yes',
				],
			]
		);
		$this->add_control( 'tabs_st2_nav_shape_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li.active a:after, {{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a.active:after' => 'border-top-color: {{VALUE}}',
				],
				'condition' => [
					'tabs_st2_nav_shape_show' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'tabs_st2_nav_shape_size',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:after' => 'border-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'tabs_st2_nav_shape_rotate',
			[
				'label'  => __( 'Rotate', 'useful-addons-elementor' ),
				'type'   => Controls_Manager::SLIDER,
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 360,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:after' => 'transform: rotate({{SIZE}}deg);',
				],
			]
		);
		$this->add_responsive_control( 'tabs_st2_nav_shape_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .howitworks-area2 .hiw-content .tab-content-shared .nav-tabs li a:after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	/* UA Tab Style 3 Styles Controls */
	private function get_style_tab_st3_nav( ) {
		$this->start_controls_section( 'tab_st3_nav_style',
			[
				'label'     => __( 'Nav', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'UA_tabs_different_style' => 'style_3'
                ]
			]
		);
		$this->add_responsive_control( 'tab_st3_nav_spc_between',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 12
				],
				'selectors' => [
					'{{WRAPPER}} .ua-tab-st3-section-tab ul li' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'tab_st3_nav_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 300,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-tab-st3-section-tab ul li a'             => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'tab_st3_nav_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 300,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-tab-st3-section-tab ul li a'             => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'tab_st3_nav_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-tab-st3-section-tab ul li a, {{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link',
			]
		);

        $this->add_responsive_control( 'tab_st3_nav_wrap_margin',
            [
                'label'      => __( 'Wrapper Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		/* Start Tab */
		$this->start_controls_tabs( 'tab_st3_nav_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'tab_st3_nav_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'tab_st3_nav_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-tab-st3-section-tab ul li a'             => 'color: {{VALUE}}',
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'tab_st3_nav_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-tab-st3-section-tab ul li a'             => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'tab_st3_nav_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-tab-st3-section-tab ul li a, {{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link',
			]
		);
		$this->add_control( 'tab_st3_nav_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '8',
                    'right'  => '8',
                    'bottom' => '8',
                    'left'   => '8',
                    'unit'   => 'px',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-tab-st3-section-tab ul li a'             => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'tab_st3_nav_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-tab-st3-section-tab ul li a, {{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link',
				'fields_options' => [
					'box_shadow_type' => [
						'default' =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
			]
		);
		$this->add_responsive_control( 'tab_st3_nav_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '15',
					'right'  => '30',
					'bottom' => '15',
					'left'   => '30',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-tab-st3-section-tab ul li a'             => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'tab_st3_nav_icon_heading',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'tab_st3_nav_icon_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link i, .ua-tab-st3-section-tab ul li a i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'tab_st3_nav_icon_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '0',
                    'bottom' => '4',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link i, .ua-tab-st3-section-tab ul li a i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'tab_st3_nav_act_tab',
			[
				'label' => __( 'Active', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'tab_st3_nav_act_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link.active, .ua-tab-st3-section-tab ul li a.active' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'tab_st3_nav_act_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link.active, .ua-tab-st3-section-tab ul li a.active' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'tab_st3_nav_act_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link.active, .ua-tab-st3-section-tab ul li a.active',
			]
		);
		$this->add_control( 'tab_st3_nav_act_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link.active, .ua-tab-st3-section-tab ul li a.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'tab_st3_nav_act_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link.active, .ua-tab-st3-section-tab ul li a.active',
			]
		);
		$this->add_responsive_control( 'tab_st3_nav_act_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link.active, .ua-tab-st3-section-tab ul li a.active' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'tab_st3_nav_icon_act_heading',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'tab_st3_nav_icon_act_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link.active i, .ua-tab-st3-section-tab ul li a.active i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'tab_st3_nav_icon_act_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-tab-st3-section-tab .nav-tabs .nav-link.active i, .ua-tab-st3-section-tab ul li a.active i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->end_controls_section();
	}

	protected function _register_controls() {
		$this->get_content_tabs_content_setting();
		$this->get_style_tabs_style_settings();
		$this->get_style_tabs_desc_style();
		$this->get_style_tabs_img_style();
		$this->get_style_tabs_btn_style();
		$this->get_style_tabs_box_style();
		$this->get_style_tab_st2_style();
		$this->get_style_tab_st3_nav();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();
		$tabs     = $this->get_settings_for_display( 'UA_tabs' );
		$tabs_st2 = $this->get_settings_for_display( 'UA_tabs_st2' );
		$tabs_st3_lists = $this->get_settings_for_display( 'tab_st3_lists' );

		$this->add_inline_editing_attributes( 'UA_tabs_description', 'none' );

		if($settings['UA_tabs_shape'] == 'yes') {
			$tabs_shape_show = '';
		} else {
			$tabs_shape_show = 'hide_tabs_shape';
		}

		if ( $settings['UA_tabs_alignment'] == 0) {
			$tabs_nav_position = 'text-left justify-content-left';
		} elseif( $settings['UA_tabs_alignment'] == 1 ) {
			$tabs_nav_position = 'text-center justify-content-center';
		} elseif ( $settings['UA_tabs_alignment'] == 2 ) {
			$tabs_nav_position = 'text-right justify-content-end';
		} else {
			$tabs_nav_position = 'text-center justify-content-center';
		}

		?>
		<?php if($settings['UA_tabs_different_style'] == 'style_1') { ?>
            <div class="tab-content-shared">
                <!-- Nav tabs  class="active" -->
                <ul class="nav nav-tabs <?php echo esc_attr($tabs_nav_position); ?>" role="tablist">
					<?php
					foreach ( $tabs as $index => $item ) {
						$tab_count = $index + 1;
						if($tab_count == 1) {
							$tab_first_active_class = ' in active';
						} else {
							$tab_first_active_class = '';
						}

						$target = $item['UA_tabs_button_url']['is_external'] ? ' target="_blank"' : '';
						$nofollow = $item['UA_tabs_button_url']['nofollow'] ? ' rel="nofollow"' : '';
						?>
                        <li role="presentation" class=" <?php echo esc_attr($tabs_shape_show); ?>">
                            <a class="<?php echo esc_attr( $tab_first_active_class); ?> UA_tabs_title" role="tab" data-toggle="tab" href="#tab<?php echo esc_attr($tab_count); ?>" >
								<?php echo esc_html($item['UA_tabs_title']); ?>
                            </a>
                        </li>
					<?php } ?>
                </ul>
                <!-- Tab panes in active -->
                <div class="tab-content clearfix">
					<?php
					foreach ( $tabs as $index => $item ) {
						$tab_count = $index + 1;
						if($tab_count == 1) {
							$tab_first_active_class = ' in active';
						} else {
							$tab_first_active_class = '';
						}
						$tab_description_setting_key = $this->get_repeater_setting_key( 'UA_tabs_description', 'UA_tabs', $index );

                        $target = $item['UA_tabs_button_url']['is_external'] ? ' target="_blank"' : '';
                        $nofollow = $item['UA_tabs_button_url']['nofollow'] ? ' rel="nofollow"' : '';

						$this->add_render_attribute( $tab_description_setting_key, [
							'id'   => 'tab' . $tab_count,
							'role' => 'tabpanel',
						] );

						if($item['UA_tabs_image_alignments'] === 'left') {
							?>
                            <div <?php $this->print_render_attribute_string( $tab_description_setting_key ); ?> class="tab-pane fade <?php echo esc_attr($item['UA_tabs_image_alignments']); ?> <?php echo esc_attr($tab_first_active_class); ?>">
                                <div class="row">
									<?php if(!empty( $item['UA_tabs_image']['url'])) {
										?>
                                        <div class="col-md-<?php if (!empty($item['UA_tabs_description']) || !empty($item['UA_tabs_button_tx'])) {
											echo esc_attr__('6', 'useful-addons-elementor');
										} else {
											echo esc_attr__('12', 'useful-addons-elementor');
										} ?> no-padding-l">
											<img src="<?php echo esc_url($item['UA_tabs_image']['url']); ?>" alt="<?php esc_attr_e('Image', 'useful-addons-elementor'); ?>" class="tab-img tab-img1">
                                        </div>
										<?php
									} ?>
                                    <div class="col-md-<?php if(!empty( $item['UA_tabs_image']['url'])) {echo esc_attr__('6', 'useful-addons-elementor'); }else { echo esc_attr__('12', 'useful-addons-elementor'); } ?>">
                                        <div class="tab-desc-box">
											<?php if(!empty( $item['UA_tabs_description'])) { ?>
                                                <p class="tab__desc">
													<?php echo $item['UA_tabs_description']; ?>
                                                </p>
											<?php } if(!empty($item['UA_tabs_button_tx']) || !empty($item['UA_tabs_button_icon'])) {
												if($item['UA_tabs_button_icon_position'] == 'right' || $item['UA_tabs_button_icon_position'] == 'default' || $item['UA_tabs_button_icon_position'] == 'top' || $item['UA_tabs_button_icon_position'] == 'bottom') {
													?>
                                                    <a href="<?php echo esc_url($item['UA_tabs_button_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($item['UA_tabs_button_icon_position']); ?>">
														<?php echo esc_html($item['UA_tabs_button_tx']); ?>
														<?php
														if ( $item['UA_tabs_button_icon_dependency'] === 'yes' )
														{
															if ( !empty( $item['UA_tabs_button_icon'] ) ) {
																Icons_Manager::render_icon( $item['UA_tabs_button_icon'], ['class' => 'fa__arrow ', 'aria-hidden' => 'true' ] );
															}
														} ?>
                                                    </a>
													<?php
												} elseif($item['UA_tabs_button_icon_position'] == 'left') {
													?>
                                                    <a href="<?php echo esc_url($item['UA_tabs_button_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($item['UA_tabs_button_icon_position']); ?>">
														<?php
														if ( $item['UA_tabs_button_icon_dependency'] === 'yes' ) {
															if ( !empty( $item['UA_tabs_button_icon'] ) ) {
																Icons_Manager::render_icon( $item['UA_tabs_button_icon'], ['class' => 'fa__arrow ', 'aria-hidden' => 'true' ] );
															}
														} ?>
														<?php echo esc_html($item['UA_tabs_button_tx']); ?>
                                                    </a>
													<?php
												} else {
													?>
                                                    <a href="<?php echo esc_url($item['UA_tabs_button_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($item['UA_tabs_button_icon_position']); ?>">
														<?php echo esc_html($item['UA_tabs_button_tx']); ?>
														<?php
														if ( $item['UA_tabs_button_icon_dependency'] === 'yes' ) {
															if ( !empty( $item['UA_tabs_button_icon'] ) ) {
																Icons_Manager::render_icon( $item['UA_tabs_button_icon'], ['class' => 'fa__arrow ', 'aria-hidden' => 'true' ] );
															}
														} ?>
                                                    </a>
													<?php
												}
											} ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<?php
						}

                        elseif($item['UA_tabs_image_alignments'] === 'right') {
							?>
                            <div <?php $this->print_render_attribute_string( $tab_description_setting_key ); ?> class="tab-pane fade <?php echo esc_attr($item['UA_tabs_image_alignments']); ?> <?php echo esc_attr($tab_first_active_class); ?>">
                                <div class="row">
                                    <div class="col-md-<?php if(!empty( $item['UA_tabs_image']['url'])) {echo esc_attr__('6', 'useful-addons-elementor');}else {echo esc_attr__('12', 'useful-addons-elementor');} ?>">
                                        <div class="tab-desc-box">
											<?php if(!empty( $item['UA_tabs_description'])) { ?>
                                                <p class="tab__desc">
													<?php echo $item['UA_tabs_description']; ?>
                                                </p>
											<?php } if(!empty($item['UA_tabs_button_tx']) || !empty($item['UA_tabs_button_icon'])) {
												if($item['UA_tabs_button_icon_position'] == 'right' || $item['UA_tabs_button_icon_position'] == 'default' || $item['UA_tabs_button_icon_position'] == 'top' || $item['UA_tabs_button_icon_position'] == 'bottom') {
													?>
                                                    <a href="<?php echo esc_url($item['UA_tabs_button_url']['url']); ?>" <?php echo esc_url($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($item['UA_tabs_button_icon_position']); ?>">
														<?php echo esc_html($item['UA_tabs_button_tx']); ?>
														<?php
														if ( $item['UA_tabs_button_icon_dependency'] === 'yes' )
														{
															if ( !empty( $item['UA_tabs_button_icon'] ) ) {
																Icons_Manager::render_icon( $item['UA_tabs_button_icon'], ['class' => 'fa__arrow ', 'aria-hidden' => 'true' ] );
															}
														} ?>
                                                    </a>
													<?php
												} elseif($item['UA_tabs_button_icon_position'] == 'left') {
													?>
                                                    <a href="<?php echo esc_url($item['UA_tabs_button_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($item['UA_tabs_button_icon_position']); ?>">
														<?php
														if ( $item['UA_tabs_button_icon_dependency'] === 'yes' ) {
															if ( !empty( $item['UA_tabs_button_icon'] ) ) {
																Icons_Manager::render_icon( $item['UA_tabs_button_icon'], ['class' => 'fa__arrow ', 'aria-hidden' => 'true' ] );
															}
														} ?>
														<?php echo esc_html($item['UA_tabs_button_tx']); ?>
                                                    </a>
													<?php
												} else {
													?>
                                                    <a href="<?php echo esc_url($item['UA_tabs_button_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($item['UA_tabs_button_icon_position']); ?>">
														<?php echo esc_html($item['UA_tabs_button_tx']); ?>
														<?php
														if ( $item['UA_tabs_button_icon_dependency'] === 'yes' ) {
															if ( !empty( $item['UA_tabs_button_icon'] ) ) {
																Icons_Manager::render_icon( $item['UA_tabs_button_icon'], ['class' => 'fa__arrow ', 'aria-hidden' => 'true' ] );
															}
														} ?>
                                                    </a>
													<?php
												}
											} ?>
                                        </div><!-- end tab-desc-box -->
                                    </div>
									<?php if(!empty( $item['UA_tabs_image']['url'])) {
										?>
                                        <div class="col-md-<?php if (!empty($item['UA_tabs_description']) || !empty($item['UA_tabs_button_tx'])) {
											echo esc_attr__('6', 'useful-addons-elementor');
										} else {
											echo esc_attr__('12', 'useful-addons-elementor');
										} ?> no-padding-l">
											<img src="<?php echo esc_url($item['UA_tabs_image']['url']); ?>" alt="<?php esc_attr_e('Image', 'useful-addons-elementor'); ?>" class="tab-img tab-img1">
                                        </div>
										<?php
									} ?>
                                </div><!-- end row -->
                            </div>
							<?php
						}
						else {
							?>
                            <div <?php $this->print_render_attribute_string( $tab_description_setting_key ); ?> class="tab-pane fade <?php echo esc_attr($item['UA_tabs_image_alignments']); ?> <?php echo esc_attr($tab_first_active_class); ?>">
                                <div class="row">
                                    <div class="col-md-<?php if(!empty( $item['UA_tabs_image']['url']) ) { echo esc_attr__('6', 'useful-addons-elementor');}else {echo esc_attr__('12', 'useful-addons-elementor');} ?>">
                                        <div class="tab-desc-box">
											<?php if(!empty( $item['UA_tabs_description'])) { ?>
                                                <p class="tab__desc">
													<?php echo $item['UA_tabs_description']; ?>
                                                </p>
											<?php }

											if ( !empty($item['UA_tabs_button_tx']) || !empty($item['UA_tabs_button_icon']['value'])) {
												?>
                                                <a href="<?php echo esc_url($item['UA_tabs_button_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($item['UA_tabs_button_icon_position']); ?>">
													<?php echo esc_html($item['UA_tabs_button_tx']); ?>
													<?php
													if($item['UA_tabs_button_icon_dependency'] === 'yes' )
														if ( !empty( $item['UA_tabs_button_icon']['value'] ) ) {
															Icons_Manager::render_icon( $item['UA_tabs_button_icon'], ['class' => 'fa__arrow ', 'aria-hidden' => 'true' ] );
														}
													?>
                                                </a>
											<?php } ?>
                                        </div><!-- end tab-desc-box -->
                                    </div>
                                </div><!-- end row -->
                            </div>
							<?php
						}
					}
					?>
                </div><!-- end tab-content -->
            </div>
		<?php } elseif( $settings['UA_tabs_different_style'] == 'style_2' ) { ?>

            <section class="howitworks-area howitworks-area2">
                <div class="container">
                    <div class="hiw-content">
                        <div class="col-md-4">
                            <div class="tab-content-shared ">
                                <!-- Nav tabs -->
                                <ul class="nav nav-tabs nav-tabs2" role="tablist">
									<?php
									if($settings['tabs_st2_nav_shape_show'] == 'yes') {
										$tabs_st2_nav_sp_show = ' ';
									} else {
										$tabs_st2_nav_sp_show = ' hide_shape ';
									}

									foreach ($tabs_st2 as $index => $item ) {
										$tab_st2_count = $index + 1;
										if($tab_st2_count == 1) {
											$tab_st2_first_active = ' active';
										} else {
											$tab_st2_first_active = ' ';
										}
										?>
                                        <li role="presentation" class="<?php echo esc_attr($tabs_st2_nav_sp_show);?>">
                                            <a class="<?php echo esc_attr__( $tab_st2_first_active); ?> UA_tabs_st2_title" role="tab" data-toggle="tab" href="#tabs<?php echo esc_attr($tab_st2_count); ?>" aria-expanded="true">
												<?php echo esc_html($item['UA_tabs_st2_title']);
												if(!empty( $item['UA_tabs_st2_description'])) { ?>
                                                    <span>
                                                        <?php echo $item['UA_tabs_st2_description']; ?>
                                                    </span>
												<?php } ?>
                                            </a>
                                        </li>
									<?php } ?>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="tab-content-shared">
                                <!-- Tab panes -->
                                <div class="tab-content tab-content2 clearfix">
									<?php
									foreach ($tabs_st2 as $index => $item ) {
										$tab_st2_count = $index + 1;
										if($tab_st2_count == 1) {
											$tab_st2_first_active = ' in active';
										} else {
											$tab_st2_first_active = ' ';
										}
										$tab_st2_content_title_setting_key = $this->get_repeater_setting_key( 'UA_tabs_st2_description', 'UA_tabs_st2', $index );

										$this->add_render_attribute( $tab_st2_content_title_setting_key, [
											'id'   => 'tabs' . $tab_st2_count,
											'role' => 'tabpanel',
										] );
										?>
                                        <div <?php $this->print_render_attribute_string( $tab_st2_content_title_setting_key ); ?> class="tab-pane fade <?php echo esc_attr($tab_st2_first_active); ?>">
                                            <div class="tab-desc-box row">
                                                <div class="tab-top-item">
													<?php if(!empty( $item['UA_get_page_template'])) {
														$UA_template_id = $item['UA_get_page_template'];
														$UA_frontend    = new Frontend;
														echo $UA_frontend->get_builder_content( $UA_template_id, true );
													} else {
														esc_html_e("Create templates for tabs section","useful-addons-elementor");
													} ?>
                                                </div><!-- end tab-top-item -->
                                            </div><!-- end tab-desc-box -->
                                        </div><!-- end tab-pane -->
									<?php } ?>
                                </div><!-- end tab-content -->
                            </div><!-- end tab-content-shared -->
                        </div><!-- end col-md-12  -->
                    </div><!-- end hiw-content -->
                </div><!-- end container -->
            </section>
		<?php } if($settings['UA_tabs_different_style'] === 'style_3') { ?>


            <section class="ua-tab-st3-wrapper">
                <div class="ua-tab-st3-form-box">
                    <div class="ua-tab-st3-form-title-wrap">
                        <div class="ua-tab-st3-contact-filter">
                            <div class="ua-tab-st3-section-tab">
                                <ul class="nav nav-tabs align-items-center justify-content-center" id="myTab" role="tablist">

                                    <?php
                                    foreach ($tabs_st3_lists as $index => $item ) {
                                    $tab_st3_count = $index + 1;
                                    if($tab_st3_count === 1) {
                                        $tab_st3_first_active = ' active';
                                    } else {
                                        $tab_st3_first_active = ' ';
                                    }
                                    ?>
                                        <li class="nav-item">
                                            <a class="<?php echo esc_attr($tab_st3_first_active); ?> nav-link UA_tabs_st3_title" role="tab" data-toggle="tab" href="#tabs<?php echo esc_attr($tab_st3_count); ?>" aria-expanded="true">
                                                <?php
                                                    if($item['tabs_st3_icon_show'] === 'yes') {
                                                        Icons_Manager::render_icon( $item['tabs_st3_icon'], [ 'aria-hidden' => 'true' ] );
                                                    }
                                                    echo esc_html($item['tabs_st3_title']);
                                                ?>
                                            </a>
                                        </li>
                                    <?php } ?>

                                </ul>
                            </div>
                        </div><!-- contact-filter -->
                    </div><!-- end ua-tab-st3-form-title-wrap -->
                    <div class="ua-tab-st3-form-content">
                        <div class="tab-content" id="myTabContent">

                            <?php
                            foreach ($tabs_st3_lists as $index => $item ) {
                                $tab_st3_count = $index + 1;
                                if($tab_st3_count == 1) {
                                    $tab_st3_first_active = ' show in active';
                                } else {
                                    $tab_st3_first_active = ' ';
                                }
                                $tab_st3_content_title_setting_key = $this->get_repeater_setting_key( 'UA_tabs_st2_description', 'UA_tabs_st2', $index );

                                $this->add_render_attribute( $tab_st3_content_title_setting_key, [
                                    'id'   => 'tabs' . $tab_st3_count,
                                    'role' => 'tabpanel',
                                ] );
                                ?>
                                <div <?php $this->print_render_attribute_string( $tab_st3_content_title_setting_key ); ?> class="tab-pane fade <?php echo esc_attr($tab_st3_first_active); ?>" >
                                    <div class="ua-tab-st3-contact-form-box">
                                        <div class="ua-tab-st3-contact-form-action">
                                            <?php if(!empty( $item['tabs_st3_get_page_template'])) {
                                                $UA_template2_id = $item['tabs_st3_get_page_template'];
                                                $UA_frontend2    = new Frontend;
                                                echo $UA_frontend2->get_builder_content( $UA_template2_id, true );
                                            } else {
                                                esc_html_e("Create templates for tabs section", "useful-addons-elementor");
                                            } ?>
                                        </div><!-- end contact-form-action -->
                                    </div>
                                </div><!-- end tab-pane -->
                            <?php } ?>

                        </div>
                    </div><!-- end form-content -->
                </div><!-- end form-box -->
            </section><!-- end contact-area -->

        <?php }
	}

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_tabs() );