<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_portfolio extends Widget_Base {
	public function get_name() {
		return 'UA_portfolio';
	}

	public function get_title() {
		return esc_html__( 'Portfolio', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-filter ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* Portfolio Query Setting */
	private function get_content_portfolio_query( ){
		$this->start_controls_section( 'portfolio_query_setting',
			[
				'label' => __( 'Query', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'portfolio_post_per_page',
			[
				'label'   => __( 'Posts Per Page', 'useful-addons-elementor' ),
				'type' 	  => Controls_Manager::NUMBER,
				'min' 	  => -1,
				'max' 	  => 100,
				'step'    => 1,
				'default' => -1,
			]
		);
		$this->add_control( 'portfolio_order_by',
			[
				'label'   => __( 'Order By', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'ID' 			=> 'Post ID',
					'author' 		=> 'Post Author',
					'title' 		=> 'Title',
					'date' 			=> 'Date',
					'modified' 		=> 'Last Modified Date',
					'parent' 	    => 'Parent Id',
					'rand' 		    => 'Random',
					'comment_count' => 'Comment Count',
					'menu_order' 	=> 'Menu Order',
				],
			]
		);
		$this->add_control( 'portfolio_order',
			[
				'label'    => __('Order', 'useful-addons-elementor'),
				'type' 	   => Controls_Manager::SELECT,
				'options'  => [
					'asc'  => 'Ascending',
					'desc' => 'Descending',
				],
				'default'  => 'desc',

			]
		);
		$this->end_controls_section();
	}
	/* Portfolio Layout Setting */
	private function get_layout_portfolio( ){
		$this->start_controls_section( 'portfolio_layout_setting',
			[
				'label' => __( 'Layout', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control('portfolio_layout_style',
            [
                'label'   => __( 'Layout Style', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'style_1',
                'options' => [
                    'style_1'  => __( 'Style 1', 'useful-addons-elementor' ),
                    'style_2'  => __( 'Style 2', 'useful-addons-elementor' ),
                ],
            ]
        );
		$this->add_control( 'portfolio_nav_alignment',
			[
				'label'   => __('Nav Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0' => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => '1',
			]
		);
		$this->add_control( 'portfolio_show_overlay',
			[
				'label'        => __('Show Overlay', 'useful-addons-elementor'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'useful-addons-elementor' ),
                'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'    => [
                    'portfolio_layout_style' => 'style_1'
                ]
			]
		);
		$this->add_control( 'portfolio_show_title',
			[
				'label'        => __('Show Title', 'useful-addons-elementor'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'useful-addons-elementor' ),
                'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
                'return_value' => 'yes',
                'default'      => 'yes',
				'condition' => [
					'portfolio_show_overlay' => 'yes',
                    'portfolio_layout_style' => 'style_1'
				],
			]
		);
		$this->add_control( 'portfolio_show_tag',
			[
				'label'        => __('Show Tag', 'useful-addons-elementor'),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Show', 'useful-addons-elementor' ),
                'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
                'return_value' => 'yes',
                'default'      => 'yes',
				'condition'    => [
					'portfolio_show_overlay' => 'yes',
                    'portfolio_layout_style' => 'style_1'
				],
			]
		);

		/* Portfolio Two */
        $this->add_control('pt2_fancy_icon',
            [
                'label'   => __( 'Icon', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::ICONS,
                'default' => [
                    'value'   => 'la la-plus',
                    'library' => 'solid',
                ],
            ]
        );

		$this->end_controls_section();
	}
	/* Portfolio Tabs Styles */
	private function get_style_portfolio_tabs( ){
		$this->start_controls_section( 'portfolio_tabs_styles',
			[
				'label'     => __( 'Tabs Nav', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'portfolio_layout_style' => 'style_1'
                ]
			]
		);
		// nav box
		$this->add_control( 'portfolio_tabs_box_hd',
			[
				'label' 	=> __( 'Box', 'useful-addons-elementor' ),
				'type' 	    => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
		$this->add_control( 'portfolio_tabs_box_bg',
			[
				'label' 	=> __( 'Background', 'useful-addons-elementor' ),
				'type' 		=> Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'portfolio_tabs_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter',
                'fields_options'  => [
                    'border'      => [
                        'default' => 'solid',
                    ],
                    'width'       => [
                        'default' => [
                            'top'      => '2',
                            'right'    => '2',
                            'bottom'   => '2',
                            'left'     => '2',
                            'isLinked' => true,
                        ],
                    ],
                    'color' => [
                        'default' => 'rgba(103,114,134,0.1)',
                    ],
                ],
			]
		);
		$this->add_responsive_control( 'portfolio_tabs_box_radius',
			[
				'label' 	 => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'	   => '8',
					'right'	   => '8',
					'bottom'   => '8',
					'left'     => '8',
					'unit'     => 'px',
					'isLinked' => true
				],
				'selectors'   => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'portfolio_tabs_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter',
			]
		);
		$this->add_responsive_control( 'portfolio_tabs_box_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'	   => '15',
					'right'	   => '0',
					'bottom'   => '15',
					'left'	   => '0',
					'unit'	   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'portfolio_tabs_box_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// tabs nav
		$this->add_control( 'portfolio_tabs_nav_hd',
			[
				'label' 	=> __( 'Nav', 'useful-addons-elementor' ),
				'type' 		=> Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		// start tab
		$this->start_controls_tabs( 'portfolio_tabs_nav_tab_start',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'portfolio_tabs_normal_nav',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'portfolio_tabs_nav_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default' 	=> '#677286',
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'portfolio_tabs_nav_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'portfolio_tabs_nav_normal_radius',
			[
				'label' 	 => __( 'Border Radius', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' 	 => [
					'top' 	   => '30',
					'right'	   => '30',
					'bottom'   => '30',
					'left' 	   => '30',
					'unit' 	   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 	   => 'portfolio_tabs_nav_normal_shadow',
				'label'	   => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'portfolio_tabs_nav_normal_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li',
			]
		);
		$this->add_responsive_control( 'portfolio_tabs_nav_normal_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '6',
					'right'    => '20',
					'bottom'   => '6',
					'left'     => '20',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'portfolio_tabs_nav_normal_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'portfolio_tabs_hover_nav',
			[
				'label' => __( 'Hover/Active', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'portfolio_tabs_nav_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li:hover, {{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li.active' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'portfolio_tabs_nav_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li:hover, {{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li.active' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'portfolio_tabs_nav_hover_radius',
			[
				'label' 	 => __( 'Border Radius', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li:hover, {{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'portfolio_tabs_nav_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li:hover, {{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li.active',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'portfolio_tabs_nav_hover_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li:hover, {{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li.active',
			]
		);
		$this->add_responsive_control( 'portfolio_tabs_nav_hover_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li:hover, {{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li.active' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'portfolio_tabs_nav_hover_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li:hover, {{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li.active' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_portfolio_tabs_nav_tabs',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 	   => 'portfolio_tabs_nav_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .ua-portfolio-filter li',
			]
		);
		$this->end_controls_section();
	}
	/* Portfolio Title Styles */
	private function get_style_portfolio_title( ){
		$this->start_controls_section( 'portfolio_title_styles',
			[
				'label' 	=> __( 'Title', 'useful-addons-elementor' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'portfolio_show_overlay' => 'yes',
					'portfolio_show_title'   => 'yes',
                    'portfolio_layout_style' => 'style_1'
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'portfolio_title_tabs_start',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'portfolio_title_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'portfolio_title_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover .hover-text a h4' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'portfolio_title_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'portfolio_title_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover .hover-text a:hover h4' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'UA_end_title_tabs_style',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'portfolio_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover .hover-text a h4',
			]
		);
		$this->add_responsive_control( 'portfolio_title_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover .hover-text a h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'portfolio_title_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '5',
					'right'    => '0',
					'bottom'   => '5',
					'left' 	   => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover .hover-text a h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* Portfolio Tag Styles */
	private function get_style_portfolio_tag( ){
		$this->start_controls_section( 'portfolio_tag_styles',
			[
				'label' 	=> __( 'Sub Title', 'useful-addons-elementor' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'portfolio_show_overlay' => 'yes',
					'portfolio_show_tag'     => 'yes',
                    'portfolio_layout_style' => 'style_1'
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'portfolio_tag_tabs_start',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'portfolio_tag_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'portfolio_tag_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#a0aec6',
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover .hover-text a span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'portfolio_tag_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'portfolio_tag_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#a0aec6',
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover .hover-text a:hover span' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'UA_end_tag_tabs_style',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'portfolio_tag_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover .hover-text a span',
			]
		);
		$this->add_responsive_control( 'portfolio_tag_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover .hover-text a span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'portfolio_tag_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover .hover-text a span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* Portfolio Overlay and Box Styles*/
	private function get_style_portfolio_overlay_and_box( ){
	    /* Overlay */
		$this->start_controls_section( 'portfolio_overlay_styles',
			[
				'label' 	=> __( 'Overlay', 'useful-addons-elementor' ),
				'tab' 	    => Controls_Manager::TAB_STYLE,
				'condition' => [
					'portfolio_show_overlay' => 'yes',
                    'portfolio_layout_style' => 'style_1'
				],
			]
		);
		$this->add_control( 'portfolio_overlay_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(59,62,121,0.9)',
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'portfolio_overlay_width',
			[
				'label' 	 => __( 'Width', 'useful-addons-elementor' ),
				'type' 	 	 => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range' 	 => [
					'%' 	 => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'portfolio_overlay_height',
			[
				'label' 	 => __( 'Height', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range' 	 => [
					'%' 	 => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'portfolio_overlay_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'portfolio_overlay_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'portfolio_overlay_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner .portfolio-hover',
			]
		);
		$this->end_controls_section();

        /* Box */
		$this->start_controls_section( 'portfolio_box_styles',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'portfolio_layout_style' => 'style_1'
                ]
			]
		);
		$this->add_responsive_control( 'portfolio_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' 	 => [
					'top'  	   => '4',
					'right'    => '4',
					'bottom'   => '4',
					'left'	   => '4',
					'unit'	   => 'px',
					'isLinked' => true
				],
				'selectors' => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'portfolio_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'portfolio_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item  .portfolio-inner',
			]
		);
		$this->add_responsive_control( 'portfolio_box_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'portfolio_box_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' 	 => [
					'top' 	   => '0',
					'right'    => '0',
					'bottom'   => '30',
					'left' 	   => '0',
					'unit' 	   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-portfolio-area .portfolio-list .single-portfolio-item .portfolio-inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	/* Portfolio Style Two Controls */
    private function get_style_pt2_nav() {
        $this->start_controls_section( 'pt2_nav_style',
            [
                'label'     => __( 'Nav', 'useful-addons-elementor' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'portfolio_layout_style' => 'style_2'
                ]
            ]
        );
        $this->add_responsive_control('pt2_nav_width',
            [
                'label'      => __( 'Width', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('pt2_nav_height',
            [
                'label'      => __( 'Height', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('pt2_nav_spc',
            [
                'label'      => __( 'Space between nav', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('pt2_nav_wrapper_mg',
            [
                'label'      => __( 'Nav Wrapper Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '30',
                    'right'    => '0',
                    'bottom'   => '35',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-filter-2'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Typography::get_type(),
            [
                'name'     => 'pt2_nav_typography',
                'label'    => __( 'Typography', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-filter-2 li',
            ]
        );
        /* Start Tab */
        $this->start_controls_tabs( 'pt2_nav_tabs',
            [
                'separator' => 'before'
            ]
        );
        // Normal Tab
        $this->start_controls_tab( 'pt2_nav_tab_nrml',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('pt2_nav_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#233d63',
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('pt2_nav_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'pt2_nav_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-filter-2 li',
            ]
        );
        $this->add_responsive_control('pt2_nav_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '4',
                    'right'    => '4',
                    'bottom'   => '4',
                    'left'     => '4',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'pt2_nav_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-filter-2 li',
            ]
        );
        $this->add_responsive_control('pt2_nav_pd',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '8',
                    'right'    => '25',
                    'bottom'   => '8',
                    'left'     => '25',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        // Hover Tab
        $this->start_controls_tab( 'pt2_nav_tab_hv',
            [
                'label' => __( 'Hover/Active', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('pt2_nav_color_hv',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ua-portfolio-filter-2 li.active' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('pt2_nav_bg_hv',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#51be78',
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li:hover' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .ua-portfolio-filter-2 li.active' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'pt2_nav_border_hv',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-filter-2 li:hover, {{WRAPPER}} .ua-portfolio-filter-2 li.active',
            ]
        );
        $this->add_responsive_control('pt2_nav_radius_hv',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .ua-portfolio-filter-2 li.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'pt2_nav_shadow_hv',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'fields_options' => [
                    'box_shadow_type' => [
                        'default'     =>'yes'
                    ],
                    'box_shadow'  => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical'   => 10,
                            'blur'       => 30,
                            'spread'     => 0,
                            'color'      => 'rgba(81, 190, 120, 0.2)'
                        ]
                    ]
                ],
                'selector' => '{{WRAPPER}} .ua-portfolio-filter-2 li:hover, {{WRAPPER}} .ua-portfolio-filter-2 li.active',
            ]
        );
        $this->add_responsive_control('pt2_nav_pd_hv',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-filter-2 li:hover'  => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .ua-portfolio-filter-2 li.active' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        // End Tab
        $this->end_controls_section();
    }
    private function get_style_pt2_icon()
    {
        $this->start_controls_section('pt2_icon_style',
            [
                'label'     => __('Icon', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'portfolio_layout_style' => 'style_2'
                ]
            ]
        );
        $this->add_responsive_control('pt2_icon_width',
            [
                'label'      => __( 'Width', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 60,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('pt2_icon_height',
            [
                'label'      => __( 'Height', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 200,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 60,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('pt2_icon_size',
            [
                'label'      => __( 'Font size', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 26,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        /* Start Tab */
        $this->start_controls_tabs( 'pt2_icon_tabs',
            [
                'separator' => 'before'
            ]
        );
        // Normal Tab
        $this->start_controls_tab( 'pt2_icon_tab_nrml',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('pt2_icon_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('pt2_icon_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#233d63',
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'pt2_icon_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i',
            ]
        );
        $this->add_responsive_control('pt2_icon_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '50',
                    'right'    => '50',
                    'bottom'   => '50',
                    'left'     => '50',
                    'unit'     => '%',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        // Hover Tab
        $this->start_controls_tab( 'pt2_icon_tab_hv',
            [
                'label' => __( 'Hover', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('pt2_icon_color_hv',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('pt2_icon_bg_hv',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i:hover' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'pt2_icon_border_hv',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i:hover',
            ]
        );
        $this->add_responsive_control('pt2_icon_radius_hv',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        // End Tab
        $this->add_responsive_control('pt2_icon_pd',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('pt2_icon_mg',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_pt2_image()
    {
        $this->start_controls_section('pt2_image_style',
            [
                'label'     => __('Image', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'portfolio_layout_style' => 'style_2'
                ]
            ]
        );
        $this->add_responsive_control('pt2_image_width',
            [
                'label'      => __( 'Width', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 600,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('pt2_image_height',
            [
                'label'      => __( 'Height', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 600,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'pt2_image_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link img',
            ]
        );
        $this->add_responsive_control('pt2_image_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'pt2_image_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link img',
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_pt2_box()
    {
        $this->start_controls_section('pt2_box_style',
            [
                'label'     => __('Box', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'portfolio_layout_style' => 'style_2'
                ]
            ]
        );
        $this->add_control('pt2_box_hv_overlay',
            [
                'label'     => __( 'Hover Overlay BG', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(35, 61, 99,0.5)',
                'selectors' => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover .portfolio-link:after' => 'background: {{VALUE}}',
                ],
            ]
        );
        /* Start Tab */
        $this->start_controls_tabs( 'pt2_box_tabs',
            [
                'separator' => 'before'
            ]
        );
        // Normal Tab
        $this->start_controls_tab( 'pt2_box_tab_nrml',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'pt2_box_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover',
            ]
        );
        $this->add_responsive_control('pt2_box_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '4',
                    'right'    => '4',
                    'bottom'   => '4',
                    'left'     => '4',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'pt2_box_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover',
            ]
        );
        $this->end_controls_tab();
        // Hover Tab
        $this->start_controls_tab( 'pt2_box_tab_hv',
            [
                'label' => __( 'Hover', 'useful-addons-elementor' ),
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'pt2_box_border_hv',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover:hover',
            ]
        );
        $this->add_responsive_control('pt2_box_radius_hv',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'pt2_box_shadow_hv',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover:hover',
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        // End Tab
        $this->add_control(
            'pt2_box_hr',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );
        $this->add_responsive_control('pt2_box_pd',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('pt2_box_mg',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '30',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-portfolio-list-2 .ua-portfolio-2-item .portfolio-hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

	protected function _register_controls() {
	    $this->get_content_portfolio_query();
	    $this->get_layout_portfolio();
	    $this->get_style_portfolio_tabs();
	    $this->get_style_portfolio_title();
	    $this->get_style_portfolio_tag();
	    $this->get_style_portfolio_overlay_and_box();

	    /* Portfolio Two control's function enqueue */
        $this->get_style_pt2_nav();
        $this->get_style_pt2_icon();
        $this->get_style_pt2_image();
        $this->get_style_pt2_box();
	}
	protected function render( ) {
		$settings = $this->get_settings_for_display();

		if($settings['portfolio_nav_alignment'] == '0') {
		    $portfolio_nav_alignment = 'text-left justify-content-start';
		} elseif($settings['portfolio_nav_alignment'] == '1') {
		    $portfolio_nav_alignment = 'text-center justify-content-center';
		} elseif($settings['portfolio_nav_alignment'] == '2') {
		    $portfolio_nav_alignment = 'text-right justify-content-end';
		} else {
			$portfolio_nav_alignment = 'text-center justify-content-center';
		}

        $portfolio_per_page_number = $settings['portfolio_post_per_page'];
        $portfolio_orderby         = $settings['portfolio_order_by'];
        $portfolio_order           = $settings['portfolio_order'];

        $portfolio_loop = new \WP_Query(
            array(
                'post_type' 	 => 'portfolio',
                'posts_per_page' => $portfolio_per_page_number,
                'order_by' 		 => $portfolio_orderby,
                'order' 		 => $portfolio_order,
            )
        );
        global $post;


        if($settings['portfolio_layout_style'] == 'style_1') {
    ?>

        <section class="ua-portfolio-area">
            <?php if($portfolio_loop->have_posts()) { ?>
            <div class="row">
                <div class="col-md-8 col-md-offset-2 col-lg-8 offset-lg-2 <?php echo esc_attr($portfolio_nav_alignment); ?>">
                    <?php
                        if(!empty( get_terms("catportfolio"))) {
                        $terms = get_terms( "catportfolio" );
                        $count = count( $terms );

                        echo '<ul class="ua-portfolio-filter">';
                        echo '<li data-filter="*" class="active">'.esc_html__('All', 'useful-addons-elementor').'</li>';
                        if ( $count > 0 ) {
                            foreach ( $terms as $term ) {
                                $termname = strtolower( $term->name );
                                $termname = str_replace( ' ', '-', $termname );
                                echo '
                                <li data-filter=".' . esc_attr($termname) . '">
                                    ' . esc_html($term->name) . '
                                </li>';
                            }
                        }
                        echo "</ul>";
                    }
                    ?>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 portfolio-column">
                    <div class="portfolio-list text-center justify-content-center">
                        <?php if ( $portfolio_loop ) :
                            while ( $portfolio_loop->have_posts() ) : $portfolio_loop->the_post();

                                $terms = get_the_terms( $post->ID, 'catportfolio' );
                                if ( $terms && ! is_wp_error( $terms ) ) :
                                    $links = array();
                                    foreach ( $terms as $term ) {
                                        $links[] = $term->name;
                                    }
                                    $links = str_replace(' ', '-', $links);
                                    $tax   = join( " ", $links );
                                else :
                                    $tax = '';
                                endif;
                                ?>
                                <div class="single-portfolio-item col-md-4 col-sm-6 all <?php echo strtolower($tax); ?>">
                                    <div class="portfolio-inner">
                                        <?php the_post_thumbnail('wpminzel-portfolio-grid-square');

                                        if($settings['portfolio_show_overlay'] == 'yes') { ?>
											<div class="portfolio-hover">
												<div class="hover-text">
													<?php if($settings['portfolio_show_tag'] == 'yes' || $settings['portfolio_show_title'] == 'yes' ) { ?>
                                                        <a href="<?php the_permalink(); ?>">
                                                            <?php if($settings['portfolio_show_title'] == 'yes' && !empty(get_the_title())) { ?>
                                                                <h4><?php the_title(); ?></h4>
                                                            <?php
                                                            }
                                                            $terms = wp_get_post_terms( $post->ID, 'tagportfolio');
                                                            if(!empty( $terms) && $settings['portfolio_show_tag'] == 'yes') { ?>
                                                                <span>
                                                                    <?php foreach ( $terms as $term ) {
                                                                        echo esc_html($term->slug).' ';
                                                                    } ?>
                                                                </span>
                                                            <?php } ?>
                                                        </a>
													<?php } ?>
												</div>
											</div>
										<?php } ?>
                                    </div>
                                </div>

                            <?php endwhile; else: ?>
                        <?php endif;
                            wp_reset_query();
                        ?>

                    </div>
                </div>
            </div>
            <?php
            } else { ?>
	            <h2 class="empty_post">
                    <?php esc_html_e('Empty Portfolio!.', 'useful-addons-elementor'); ?>
                </h2>
            <?php }
            ?>
        </section>

        <?php } else { ?>

        <section class="ua-portfolio-gallery-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <?php
                        if(!empty( get_terms("catportfolio"))) {
                            $pt2_terms = get_terms('catportfolio');
                            $pt2_count = count($pt2_terms);
                        ?>
                            <ul class="ua-portfolio-filter-2 <?php echo esc_attr($portfolio_nav_alignment); ?>">
                                <li data-filter="*" class="active">
                                    <?php esc_html_e('All', 'useful-addons-elementor'); ?>
                                </li>
                                <?php if($pt2_count > 0) {
                                    foreach ($pt2_terms as $pt2_term) {
                                        $pt2_termname = strtolower( $pt2_term->name );
                                        $pt2_termname = str_replace( ' ', '-', $pt2_termname ); ?>
                                        <li data-filter=".<?php echo esc_attr($pt2_termname); ?>" class="">
                                            <?php echo esc_html($pt2_term->name); ?>
                                        </li>
                                    <?php } ?>
                                <?php } ?>
                            </ul>
                        <?php } ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ua-portfolio-list-2 row">
                        <?php if ( $portfolio_loop ) {
                            while ( $portfolio_loop->have_posts() ) { $portfolio_loop->the_post();
                                $pt2_terms = get_the_terms( $post->ID, 'catportfolio' );
                                if ( $pt2_terms && ! is_wp_error( $pt2_terms ) ) {
                                    $pt2_links = array();
                                    foreach ($pt2_terms as $pt2_term) {
                                        $pt2_links[] = $pt2_term->name;
                                    }
                                    $pt2_links = str_replace(' ', '-', $pt2_links);
                                    $pt2_tax   = join(" ", $pt2_links);
                                } else {
                                    $pt2_tax = '';
                                }
                                ?>
                                    <div class="ua-portfolio-2-item col-md-6 col-lg-4 <?php echo strtolower($pt2_tax); ?>">
                                        <div class="portfolio-hover">
                                            <a class="portfolio-link" href="<?php the_post_thumbnail_url(); ?>" data-fancybox="gallery" data-caption="<?php esc_attr_e('Gallery Image', 'useful-addons-elementor'); ?>">
                                                <?php the_post_thumbnail(); ?>
                                                <?php Icons_Manager::render_icon( $settings['pt2_fancy_icon'], ['class' => 'icon-element', 'aria-hidden' => 'true' ] ); ?>
                                            </a>
                                        </div>
                                    </div>
                            <?php }
                            }
                            wp_reset_query();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <script>
            jQuery('.ua-portfolio-list-2').isotope({
                itemSelector: '.ua-portfolio-2-item',
                percentPosition: true,
                masonry: {
                    // use outer width of grid-sizer for columnWidth
                    columnWidth: '.ua-portfolio-2-item',
                    horizontalOrder: true
                }
            });

            jQuery(document).on( 'click', '.ua-portfolio-filter-2 li', function() {
                var filterData = jQuery( this ).attr('data-filter');

                // use filterFn if matches value
                jQuery('.ua-portfolio-list-2').isotope({
                    filter: filterData,
                });

                jQuery('.ua-portfolio-filter-2 li').removeClass('active');
                jQuery(this).addClass('active');
            });
        </script>
	<?php
        }
    }

	protected function _content_template() { }
}

Plugin::instance()->widgets_manager->register_widget_type( new UA_portfolio() );