<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class ua_edd_gallery_slider extends Widget_Base {
	public function get_name() {
		return 'ua_edd_gallery_slider';
	}

	public function get_title() {
		return esc_html__( 'EDD Gallery Slider', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-slider-album ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA EDD gallery slider content */
    private function get_edd_gallery_slider_content() {
	    $this->start_controls_section( 'ua_edd_gallery_slider_content',
		    [
			    'label' => __( 'Content', 'useful-addons-elementor' ),
			    'tab'   => Controls_Manager::TAB_CONTENT,
		    ]
	    );
	    $this->add_control('ua_edd_gallery_mockup_img',
		    [
			    'label'   => __( 'Mockup Image', 'useful-addons-elementor' ),
			    'type'    => Controls_Manager::MEDIA,
			    'default' => [
				    'url' => UA_ELEMENTOR_URL.'assets/images/frame-img.png',
			    ],
		    ]
        );

	    $this->end_controls_section();
    }
    /* UA EDD Gallery Slider query */
	private function get_edd_gallery_slider_query() {
		$this->start_controls_section( 'ua_get_edd_gallery_slider_query',
			[
				'label' => __( 'Query', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'ua_edd_gallery_slide_item_per_page',
			[
				'label'   => __( 'item Per page', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
				'default' => 9,
			]
		);
		$this->add_control( 'ua_edd_gallery_slide_per_view',
			[
				'label'   => __( 'Slider Per View', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 10,
				'step'    => 1,
				'default' => 1,
			]
		);
		$this->add_control( 'ua_edd_gallery_slide_space_between',
			[
				'label'   => __( 'Space Between', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 100,
				'step'    => 1,
				'default' => 30,
			]
		);
		$this->add_control( 'ua_edd_gallery_slide_speed',
			[
				'label'   => __( 'Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 50000,
				'step'    => 50,
				'default' => 900,
			]
		);
		$this->add_control( 'ua_edd_gallery_slide_loop',
			[
				'label'        => __( 'Infinite Loop', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'ua_edd_gallery_slide_autoplay',
			[
				'label'        => __( 'Autoplay', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'ua_edd_gallery_slide_autoplay_speed',
			[
				'label'   => __( 'Autoplay Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 50000,
				'step'    => 50,
				'default' => 900,
                'condition' => [
                    'ua_edd_gallery_slide_autoplay' => 'yes'
                ]
			]
		);
		$this->add_control( 'ua_edd_gallery_slide_dots',
			[
				'label'        => __( 'Pagination', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->end_controls_section();
	}
	/* UA EDD Gallery Slider Image */
	private function get_edd_gallery_slider_img_style() {
		$this->start_controls_section( 'ua_edd_gallery_slider_img_style',
			[
				'label' => __( 'Image', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_gallery_slider_img_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-gallery-slider .product-link img',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '0',
							'right'    => '0',
							'bottom'   => '1',
							'left'     => '0',
							'isLinked' => false,
						],
					],
					'color' => [
						'default' => 'rgba(128, 137, 150, 0.1)',
					],
				],
			]
		);
		$this->add_control( 'ua_edd_gallery_slider_img_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-gallery-slider .swiper-slide:not(.swiper-slide-active) img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_gallery_slider_img_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-gallery-slider .swiper-slide:not(.swiper-slide-active) img',
				'fields_options' => [
                    'box_shadow_type' => [
                        'default'     =>'yes'
                    ],
                    'box_shadow'  => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical'   => 0,
                            'blur'       => 10.53,
                            'spread'     => 2.47,
                            'color'      => 'rgba(0, 0, 0, 0.05)'
                        ]
                    ]
                ],
			]
		);
		$this->end_controls_section();
	}
	/* UA EDD Gallery Slider Pagination Style */
	private function get_edd_gallery_slider_pagination_style() {
		$this->start_controls_section( 'ua_edd_gallery_slider_pagination_style',
			[
				'label' => __( 'Dots', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'ua_edd_gallery_slider_dots_tabs',
			[
				'separator' => 'before',
				'condition' => [
					'ua_edd_gallery_slide_dots' => 'yes'
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_edd_gallery_slider_dots_nrml',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'ua_edd_gallery_slide_dots' => 'yes'
				],
			]
		);
		$this->add_control( 'ua_edd_gallery_slider_dots_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 20,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'ua_edd_gallery_slider_dots_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 20,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'ua_edd_gallery_slider_dots_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_gallery_slider_dots_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'rgba(19, 41, 104, 0.1)',
					],
				],
			]
		);
		$this->add_control( 'ua_edd_gallery_slider_dots_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '50',
                    'right'  => '50',
                    'bottom' => '50',
                    'left'   => '50',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_edd_gallery_slider_dots_hv',
			[
				'label'     => __( 'Hover / Active', 'useful-addons-elementor' ),
				'condition' => [
					'ua_edd_gallery_slide_dots' => 'yes'
				],
			]
		);
		$this->add_control( 'ua_edd_gallery_slider_dots_width_hv',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 20,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} {{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet:hover, {{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'ua_edd_gallery_slider_dots_height_hv',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 20,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} {{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet:hover, {{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'ua_edd_gallery_slider_dots_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet:hover, .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_gallery_slider_dots_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet:hover, {{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet.swiper-pagination-bullet-active',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#3BACE4',
					],
				],
			]
		);
		$this->add_control( 'ua_edd_gallery_slider_dots_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet:hover, {{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control( 'ua_edd_gallery_slider_dots_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '6',
					'bottom' => '0',
					'left'   => '6',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-gallery-slider-swiper-bullet .swiper-pagination-bullet' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls() {
        $this->get_edd_gallery_slider_content();
        $this->get_edd_gallery_slider_query();
        $this->get_edd_gallery_slider_img_style();
        $this->get_edd_gallery_slider_pagination_style();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();


		$default = [
			'posts_per_page' => $settings['ua_edd_gallery_slide_item_per_page'],
			'post_type'      => 'download',
		];

		/**
		 * Setup the post arguments.
		 */
		// Post Query
		$post_query = new \WP_Query( $default );

		if($post_query->have_posts()) {
		?>

        <section class="ua-edd-gallery-slider-wrapper">
            <?php if(!empty($settings['ua_edd_gallery_mockup_img'])) { ?>
                <div class="ua-edd-gallery-slider-frame">
                    <img src="<?php echo esc_url($settings['ua_edd_gallery_mockup_img']['url']); ?>" alt="<?php esc_attr_e('Laptop Mockup', 'useful-addons-elementor'); ?>">
                </div>
            <?php } ?>

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-4 column-t-half mx-auto">
                        <div class="swiper-container ua-edd-gallery-slider ua-edd-feature-product-wrap">
                            <div class="swiper-wrapper">

	                            <?php
	                            while ($post_query->have_posts()) {
		                            $post_query->the_post();
		                            ?>
                                    <div class="swiper-slide">
                                        <a href="<?php the_permalink(); ?>" class="product-link">
                                            <?php the_post_thumbnail('ua-download-gallery-img'); ?>
                                        </a>
                                    </div>
                                <?php  } ?>

                            </div>
                            <?php if($settings['ua_edd_gallery_slide_dots'] === 'yes') { ?>
                                <div class="swiper-pagination ua-edd-gallery-slider-swiper-bullet"></div>
                            <?php } ?>
                        </div><!-- end swiper-container -->
                    </div>
                </div><!-- row -->
            </div><!-- container -->
            <div class="stroke-line stroke-line2">
                <span class="stroke__line"></span>
                <span class="stroke__line"></span>
                <span class="stroke__line"></span>
            </div>
        </section><!-- end feature-area -->

        <script>

            //initialize swiper when document ready
            if(jQuery(".ua-edd-gallery-slider").length) {
                var swiper = new Swiper('.ua-edd-gallery-slider', {
                    slidesPerView: <?php if(!empty($settings['ua_edd_gallery_slide_per_view'])) { echo esc_attr($settings['ua_edd_gallery_slide_per_view']); } else { echo 1; } ?>,
                    spaceBetween: <?php if(!empty($settings['ua_edd_gallery_slide_space_between'])) { echo esc_attr($settings['ua_edd_gallery_slide_space_between']); } else { echo 0;}  ?>,
                    autoplay: <?php if($settings['ua_edd_gallery_slide_autoplay'] === 'yes') { echo 'true'; } else { echo 'false'; } ?>,
                    autoplaySpeed: <?php if(!empty($settings['ua_edd_gallery_slide_autoplay_speed'])) { echo esc_attr($settings['ua_edd_gallery_slide_autoplay_speed']); } else { echo 0;}  ?>,
                    loop: <?php if($settings['ua_edd_gallery_slide_loop'] === 'yes') { echo 'true'; } else { echo 'false'; } ?>,
                    speed: <?php if(!empty($settings['ua_edd_gallery_slide_speed'])) { echo esc_attr($settings['ua_edd_gallery_slide_speed']); } else { echo 0;}  ?>,

                    <?php if($settings['ua_edd_gallery_slide_dots'] === 'yes') { ?>
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true,
                    }
                    <?php } ?>
                });
            }

        </script>

        <?php
        }

	}

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new ua_edd_gallery_slider() );