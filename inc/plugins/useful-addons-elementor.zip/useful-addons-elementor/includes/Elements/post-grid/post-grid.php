<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_post_grid extends Widget_Base {

	public function get_name() {
		return 'UA-post-grids';
	}
	public function get_title() {
		return __( 'Post Grid', 'useful-addons-elementor' );
	}
	public function get_icon() {
		return 'eicon-posts-grid ua-addons-icon';
	}
	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/**
	 * All authors name and ID, who published at least 1 post.
	 * @return array
	 */
	public function get_authors() {
		$user_query = new \WP_User_Query(
			[
				'who' => 'authors',
				'has_published_posts' => true,
				'fields' => [
					'ID',
					'display_name',
				],
			]
		);

		$authors = [];

		foreach ($user_query->get_results() as $result) {
			$authors[$result->ID] = $result->display_name;
		}

		return $authors;
	}

	/* UA Post Grid Query Controls */
	private function get_query_post_grid( ){
		$this->start_controls_section( 'post_grid_query_setting',
			[
				'label' => __( 'Query', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'blog_authors',
			[
				'label'       => __('Author', 'useful-addons-elementor'),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'default'     => [],
				'options'     => $this->get_authors(),

			]
		);
        $this->add_control('post_grid_post_by_ids',
            [
                'label'       => __( 'Post By ID', 'useful-addons-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter course ids here for example: <strong>1, 2, 3</strong>', 'useful-addons-elementor' ),
            ]
        );
		$this->add_control( 'post_grid_post_per_page',
			[
				'label'   => __( 'Posts Per Page', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
				'default' => 9,
			]
		);
		$this->add_control( 'post_grid_order_by',
			[
				'label'             => __( 'Order By', 'useful-addons-elementor' ),
				'type'              => Controls_Manager::SELECT,
				'default'           => 'date',
				'options'           => [
					'ID'            => 'Post ID',
					'author'        => 'Post Author',
					'title'         => 'Title',
					'date'          => 'Date',
					'modified'      => 'Last Modified Date',
					'parent'        => 'Parent Id',
					'rand'          => 'Random',
					'comment_count' => 'Comment Count',
					'menu_order'    => 'Menu Order',
				],
			]
		);
		$this->add_control( 'post_grid_order',
			[
				'label'    => __('Order', 'useful-addons-elementor'),
				'type'     => Controls_Manager::SELECT,
				'options'  => [
					'asc'  => 'Ascending',
					'desc' => 'Descending',
				],
				'default'  => 'desc',

			]
		);
		$this->end_controls_section();
	}
	/* UA Post Grid Layout Controls */
	private function get_layout_post_grid( ){
		$this->start_controls_section( 'post_grid_layout_setting',
			[
				'label' => __( 'Layout', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'post_grid_layout_style',
			[
				'label'        => __( 'Layout Style', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'grid',
				'options'      => [
					'grid'     => 'Grid',
					'carousel' => 'Carousel',
				],
			]
		);
		$this->add_control( 'post_grid_grid_style',
			[
				'label'       => __( 'Grid Style', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'style_1',
				'options'     => [
					'style_1' => 'Style 1',
					'style_2' => 'Style 2',
					'style_3' => 'Style 3',
				],
			]
		);
		$this->add_control( 'post_grid_columns',
			[
				'label'   => __( 'Number of Columns', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '4',
				'options' => [
					'12'  => __( '1 Column', 'useful-addons-elementor' ),
					'6'   => __( '2 Columns', 'useful-addons-elementor' ),
					'4'   => __( '3 Columns', 'useful-addons-elementor' ),
					'3'   => __( '4 Columns', 'useful-addons-elementor' ),
					'1'   => __( '6 Columns', 'useful-addons-elementor' ),
				],
                'condition' => [
                    'post_grid_layout_style' => 'grid',
                ]
			]
		);
		$this->add_control( 'post_grid_show_date',
			[
				'label'        => __('Show Date', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
					'post_grid_grid_style'   => 'style_2'
                ]
			]
		);
		$this->add_control( 'post_grid_show_image',
			[
				'label'        => __('Show Image', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'post_grid_grid_style' => ['style_1', 'style_2']
				]
			]
		);
		$this->add_control( 'post_grid_show_image_overlay',
			[
				'label'        => __('Show Image Overlay', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'post_grid_show_image' => 'yes',
					'post_grid_grid_style' => 'style_1',
				],
			]
		);
		$this->add_control('post_grid_image_overlay_icon',
			[
				'label'            => __( 'Image Overlay Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-plus',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'plus',
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'post_grid_show_image'         => 'yes',
					'post_grid_show_image_overlay' => 'yes',
					'post_grid_grid_style' => 'style_1',
				],
			]
		);
		$this->add_control( 'post_grid_show_title',
			[
				'label'        => __('Show Title', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'	   => [
					'post_grid_grid_style' => ['style_1', 'style_2']
				]
			]
		);
		$this->add_control( 'post_grid_show_excerpt',
			[
				'label'        => __('Show Excerpt', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
                    'post_grid_grid_style' => 'style_1'
                ]
			]
		);
		$this->add_control( 'post_grid_excerpt_word',
			[
				'label'     => __( 'Excerpt Words', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 5,
				'max'       => 500,
				'step'      => 1,
				'default'   => 16,
				'condition' => [
					'post_grid_show_excerpt' => 'yes',
                    'post_grid_grid_style'   => 'style_1'
				],
			]
		);
		$this->add_control( 'post_grid_show_readmore_btn',
			[
				'label'        => __('Show Read More Button', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
                    'post_grid_grid_style' => 'style_1'
                ]
			]
		);
		$this->add_control( 'post_grid_readmore_btn_text',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Read More', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type button text here', 'useful-addons-elementor' ),
				'condition'   => [
					'post_grid_show_readmore_btn' => 'yes',
					'post_grid_grid_style'        => 'style_1',
				],
			]
		);
		$this->add_control( 'post_grid_button_icon_condition',
			[
				'label'        => __( 'Show Button Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'post_grid_show_readmore_btn' => 'yes',
					'post_grid_grid_style'        => 'style_1',
				],
			]
		);
		$this->add_control('post_grid_button_icon',
			[
				'label'            => __( 'Button Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'la la-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'post_grid_button_icon_condition' => 'yes',
					'post_grid_show_readmore_btn'     => 'yes',
					'post_grid_grid_style'            => 'style_1',
				],
			]
		);
		$this->add_control( 'post_grid_show_author',
			[
				'label'        => __('Show Author', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
                    'post_grid_grid_style' => 'style_2'
                ]
			]
		);
		$this->add_control( 'post_grid_show_comments',
			[
				'label'        => __('Show Comments', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'	   => [
					'post_grid_grid_style' => ['style_1', 'style_2']
				]
			]
		);
		$this->add_control('post_grid_comment_icon',
			[
				'label'            => __( 'Comment Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'far fa-comment',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'commenting-o',
						'comment',
						'comment-alt',
						'comment-dots',
						'comments',
						'comment',
						'comment-alt',
						'comment-dollar',
						'comment-dots',
						'comment-medical',
						'comment-slash',
						'comments',
						'comments-dollar',
						'envelope',
						'envelope-open',
						'envelope',
						'envelope-open',
						'envelope-open-text',
						'envelope-square',
					],
				],
				'condition' => [
					'post_grid_show_comments' => 'yes',
					'post_grid_grid_style'    => 'style_1',
				],
			]
		);
		$this->add_control( 'post_grid_show_meta',
			[
				'label'        => __('Show Meta', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
                    'post_grid_grid_style' => 'style_1'
                ]
			]
		);
		$this->add_control( 'post_grid_meta_position',
			[
				'label'   => __( 'Meta Position', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'before_title',
				'options' => [
					'before_title'  => __( 'Before Title', 'useful-addons-elementor' ),
					'after_title'   => __( 'After Title', 'useful-addons-elementor' ),
				],
				'condition' => [
					'post_grid_show_meta'  => 'yes',
					'post_grid_grid_style' => 'style_1',
				],
			]
		);
		$this->add_control( 'post_grid_pagination',
			[
				'label'        => __('Show Pagination', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->end_controls_section();
	}
	/* UA Post Grid Carousel Controls */
	private function get_carousel_controls_post_grid( ){
		$this->start_controls_section( 'post_grid_carousel_setting',
			[
				'label'     => __( 'Carousel Setting', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'post_grid_layout_style' => 'carousel',
				],
			]
		);
		$this->add_control( 'post_grid_carousel_slides_show_num',
			[
				'label'   => __( 'Slides To Show', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 9,
				'step'    => 1,
				'default' => 3,
			]
		);
		$this->add_control( 'post_grid_carousel_infinite_lope',
			[
				'label'        => __( 'Infinite Loop', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'post_grid_carousel_autoplay',
			[
				'label'        => __( 'Autoplay', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'post_grid_carousel_autop_spd',
			[
				'label'   => __( 'Autoplay Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 100,
				'max'     => 50000,
				'step'    => 50,
				'default' => 500,
                'condition' => [
                    'post_grid_carousel_autoplay' => 'yes'
                ]
			]
		);
		$this->add_control( 'post_grid_carousel_autoheight',
			[
				'label'        => __( 'AutoHeight', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'post_grid_carousel_navigation',
			[
				'label'   => __( 'Navigation', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dots',
				'options' => [
					'arrows_dots' => __( 'Arrows And Dots', 'useful-addons-elementor' ),
					'arrows'      => __( 'Arrows', 'useful-addons-elementor' ),
					'dots'        => __( 'Dots', 'useful-addons-elementor' ),
					'none'        => __( 'None', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control('post_grid_carousel_left_arrow_icon',
			[
				'label'            => __( 'Arrow Left', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-left',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'post_grid_carousel_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control('post_grid_carousel_right_arrow_icon',
			[
				'label'            => __( 'Arrow Right', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'la la-angle-right',
					'library' => 'solid',
				],
				'recommended'  => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'post_grid_carousel_animation_spd',
			[
				'label'   => __( 'Animation Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 100,
				'max'     => 50000,
				'step'    => 50,
				'default' => 500,
			]
		);
		$this->add_control( 'post_grid_carousel_spc_between',
			[
				'label'   => __( 'Space Between', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 100,
				'step'    => 1,
				'default' => 30,
			]
		);
		$this->end_controls_section();
	}
	/* UA Post Grid Box Style Controls */
	private function get_style_post_grid_box( ){
		$this->start_controls_section( 'post_grid_box_styles',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'post_grid_grid_style' => 'style_1'
                ]
			]
		);


		/* Start Tab */
		$this->start_controls_tabs( 'ua_post_grid_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_post_grid_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'post_grid_box_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item, {{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'post_grid_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item',
			]
		);
		$this->add_responsive_control( 'post_grid_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_grid_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item',
			]
		);
		$this->add_responsive_control( 'post_grid_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_box_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '30',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_post_grid_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'post_grid_box_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item:hover, {{WRAPPER}} .ua-blog-post-wrapper .blog-post-item:hover .blog-post-body',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'post_grid_box_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item:hover',
			]
		);
		$this->add_responsive_control( 'post_grid_box_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_grid_box_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item:hover',
			]
		);
		$this->add_responsive_control( 'post_grid_box_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_box_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */

		//shape
		$this->add_control( 'box_shape',
			[
				'label'     => __( 'Box Shape', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'post_grid_box_shape_dependency',
			[
				'label'        => __( 'Show Box Shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'post_grid_box_shape_bg',
			[
				'label'     => __( 'Box Shape Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img:before' => 'border-bottom: 12px solid {{VALUE}}',
				],
				'condition' => [
					'post_grid_box_shape_dependency' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_box_shape_size',
			[
				'label'      => __( 'Shape Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img:before' => 'border-width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_box_shape_dependency' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_box_shape_rotate',
			[
				'label'      => __( 'Shape Rotate', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'deg' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 360,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 360,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img:before' => 'transform: rotate({{SIZE}}deg);',
				],
				'condition' => [
					'post_grid_box_shape_dependency' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_box_shape_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_box_shape_dependency' => 'yes',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_post_grid_img( ){
		$this->start_controls_section( 'post_grid_image_styles',
			[
				'label'     => __( 'Image', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'post_grid_grid_style' => 'style_1'
                ]
			]
		);
		$this->add_responsive_control( 'post_grid_image_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '20',
					'left'     => '20',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_grid_image_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img img',
			]
		);
		$this->add_responsive_control( 'post_grid_image_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_image_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// Image Overlay
		$this->add_control( 'image_overlay',
			[
				'label'     => __( 'Image Overlay', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'post_grid_image_overlay_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(35, 61, 99, 0.85)',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img .item-overlay' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_grid_image_overlay_icon_clr',
			[
				'label'     => __( 'Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img .item-overlay a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control('post_grid_img_overlay_icon_size',
			[
				'label'      => __( 'Icon size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img .item-overlay a' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'post_grid_image_overlay_icon_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-img .item-overlay a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_post_grid_title()
	{
		$this->start_controls_section('post_grid_title_styles',
			[
				'label'     => __('Title', 'useful-addons-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_show_title' => 'yes',
					'post_grid_grid_style' => 'style_1',
				],
			]
		);
		$this->add_control( 'post_grid_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .blog__title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_grid_title_hv_clr',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .blog__title:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_grid_title_alignment',
			[
				'label'   => __('Title Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0'   => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
					'3' => [
						'title' => __('Justify', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'default' => '0',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'post_grid_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .blog__title',
			]
		);
		$this->add_responsive_control( 'post_grid_title_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .blog__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .blog__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_post_grid_excerpt()
	{
		$this->start_controls_section('post_grid_excerpt_styles',
			[
				'label'     => __('Excerpt', 'useful-addons-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_show_excerpt' => 'yes',
					'post_grid_grid_style'   => 'style_1',
				],
			]
		);
		$this->add_control( 'post_grid_excerpt_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#677286',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_grid_excerpt_alignment',
			[
				'label'    => __('Excerpt Alignment', 'useful-addons-elementor'),
				'type'     => Controls_Manager::CHOOSE,
				'options' => [
					'0'   => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
					'3' => [
						'title' => __('Justify', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'default' => '0',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'post_grid_excerpt_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body p',
			]
		);
		$this->add_responsive_control( 'post_grid_excerpt_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_excerpt_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top'      => '24',
					'right'    => '0',
					'bottom'   => '25',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_show_excerpt' => 'yes',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Post Grid ReadMore Button */
	private function get_style_post_grid_btn(){
		$this->start_controls_section('post_grid_btns_styles',
			[
				'label'     => __('ReadMore Button', 'useful-addons-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_show_readmore_btn' => 'yes',
					'post_grid_grid_style'        => 'style_1',
				],
			]
		);
		$this->add_control( 'post_grid_readmore_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_grid_readmore_hv_clr',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__btn:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'post_grid_readmore_typography',
				'label'    => __( 'ReadMore Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__btn',
			]
		);
		$this->add_responsive_control( 'post_grid_readmore_padding',
			[
				'label'      => __( 'ReadMore Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '35',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_readmore_margin',
			[
				'label'      => __( 'ReadMore Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// readmore button icon
		$this->add_responsive_control( 'post_grid_readmore_btn_icon_size',
			[
				'label'      => __( 'Button Icon Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__btn .fa__arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_readmore_btn_icon_margin',
			[
				'label'      => __( 'Button Icon Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top' => '1',
					'right' => '-5',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__btn .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Post Grid Meta */
	private function get_style_post_grid_meta() {
		$this->start_controls_section( 'post_grid_meta_styles',
			[
				'label'     => __( 'Meta', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_show_meta'  => 'yes',
					'post_grid_grid_style' => 'style_1',
				],
			]
		);
		$this->add_control( 'post_grid_post_meta_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#677286',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__meta li' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_grid_post_meta_alignment',
			[
				'label'   => __('Meta Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0'   => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
					'3' => [
						'title' => __('Justify', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'default' => '0',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'post_grid_post_meta_typography',
				'label'     => __( 'Typography', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__meta li',
				'condition' => [
					'post_grid_show_meta' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_post_meta_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__meta li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_show_meta' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_post_meta_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '5',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_show_meta' => 'yes',
				],
			]
		);
		$this->add_control( 'post_grid_post_meta_link_clr',
			[
				'label'     => __( 'Meta Link Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__meta li a' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_grid_show_meta' => 'yes',
				],
			]
		);
		$this->add_control( 'post_grid_post_meta_link_hv_clr',
			[
				'label'     => __( 'Meta Link hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__meta li a:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_grid_show_meta' => 'yes',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'post_grid_post_meta_link_typography',
				'label'     => __( 'Meta Link Typography', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__meta li a',
				'condition' => [
					'post_grid_show_meta' => 'yes',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Post Grid Typography Style Controls */
	private function get_style_post_grid_comments( ){
		$this->start_controls_section( 'post_grid_comments_styles',
			[
				'label'     => __( 'Comments', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_show_comments' => 'yes',
					'post_grid_grid_style'    => 'style_1',
				],
			]
		);
		$this->add_control( 'post_grid_comment_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__com' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_grid_comment_hv_clr',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__com:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'      => 'post_grid_comment_typography',
				'label'     => __( 'Typography', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__com',
			]
		);
		$this->add_responsive_control( 'post_grid_comment_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__com' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_comment_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__com' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// Post's comment Icon
		$this->add_control( 'post_grid_comments_icon_styles',
			[
				'label'     => __( 'Comments Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control( 'post_grid_comment_icon_size',
			[
				'label'      => __( 'Comment Icon Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__com i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_comment_icon_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__com i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_grid_comment_icon_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '5',
					'unit' => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-post-wrapper .blog-post-item .blog-post-body .post__bottom li a.blog__com i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Post Grid Navigation Style Controls */
	private function get_style_post_grid_navigation( ){
		$this->start_controls_section( 'post_grid_navigation_styles',
			[
				'label'     => __( 'Navigation', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_layout_style' => 'carousel',
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots', 'arrows'],
				],
			]
		);
		//dots
		$this->add_control( 'post_grid_nav_dots_hd',
			[
				'label'     => __( 'Dots', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_dots_bx_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'post_grid_nav_dots_tab_control',
			[
				'separator' => 'before',
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'post_grid_nav_dots_normal_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'post_grid_nav_dots_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot' => 'background: {{VALUE}}',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'post_grid_nav_dots_normal_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#233d63',
					],
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_dots_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'post_grid_nav_dots_normal_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot',
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_dots_normal_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_dots_normal_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'post_grid_nav_dots_hover_tab',
			[
				'label'     => __( 'Hover/Active', 'useful-addons-elementor' ),
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'post_grid_nav_dots_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot.active' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'post_grid_nav_dots_hv_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot.active',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#f66b5d',
					],
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_dots_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_grid_nav_dots_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot.active',
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_dots_hv_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot.active' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_dots_hv_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot.active' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_responsive_control( 'post_grid_nav_dots_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-dots .owl-dot' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		//arrows
		$this->add_control( 'post_grid_nav_arws_hd',
			[
				'label'     => __( 'Arrows', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_arws_bx_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'post_grid_nav_arws_tab_control',
			[
				'separator' => 'before',
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'post_grid_nav_arws_normal_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'post_grid_nav_arws_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66a5d',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'post_grid_nav_arws_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i' => 'background: {{VALUE}}',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'post_grid_nav_arws_normal_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i',
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_arws_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_grid_nav_arws_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i',
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_arws_normal_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_arws_normal_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_arws_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'post_grid_nav_arws_hover_tab',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'post_grid_nav_arws_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i:hover, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'post_grid_nav_arws_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66a5d',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i:hover, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i:hover' => 'background: {{VALUE}}',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'post_grid_nav_arws_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i:hover, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i:hover',
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_arws_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i:hover, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_grid_nav_arws_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i:hover, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i:hover',
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_arws_hv_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i:hover, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i:hover' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_arws_hv_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i:hover, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i:hover' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_arws_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev i:hover, .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next i:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_post_grid_nav_arws_tab',
			[
				'type'      => Controls_Manager::DIVIDER,
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_larws_margin',
			[
				'label'      => __( 'Left Arrow Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-prev' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'post_grid_nav_rarws_margin',
			[
				'label'      => __( 'Right Arrow Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .ua-blog-post-wrapper .blog-post-carousel .owl-nav > .owl-next' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'post_grid_carousel_navigation' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Post Grid Pagination */
	private function get_style_post_pagination() {
		$this->start_controls_section( 'post_grid_pagination_styles',
			[
				'label'     => __( 'Pagination', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_pagination' => 'yes',
					'post_grid_grid_style' => 'style_1',
				]
			]
		);
		$this->add_responsive_control('pagination_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a, .ua-blog-area .pagination-wrapper .pagination-list span' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('pagination_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a, .ua-blog-area .pagination-wrapper .pagination-list span' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('pagination_lheight',
			[
				'label'      => __( 'Line Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a, .ua-blog-area .pagination-wrapper .pagination-list span' => 'line-height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('pagination_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a, .ua-blog-area .pagination-wrapper .pagination-list span' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/*-----Start Tab-----*/
		$this->start_controls_tabs( 'pagination_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'pagination_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('pagination_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'pagination_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pagination_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a',
			]
		);
		$this->add_responsive_control('pagination_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pagination_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a',
			]
		);
		$this->add_responsive_control('pagination_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('pagination_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a,  .ua-blog-area .pagination-wrapper .pagination-list span.current' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'pagination_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('pagination_hv_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a:hover,  .ua-blog-area .pagination-wrapper .pagination-list span.current' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'pagination_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a:hover,  .ua-blog-area .pagination-wrapper .pagination-list span.current',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pagination_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a:hover,  .ua-blog-area .pagination-wrapper .pagination-list span.current',
			]
		);
		$this->add_responsive_control('pagination_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a:hover,  .ua-blog-area .pagination-wrapper .pagination-list span.current' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pagination_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a:hover,  .ua-blog-area .pagination-wrapper .pagination-list span.current',
			]
		);
		$this->add_responsive_control('pagination_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a:hover,  .ua-blog-area .pagination-wrapper .pagination-list span.current' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('pagination_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog-area .pagination-wrapper .pagination-list a:hover,  .ua-blog-area .pagination-wrapper .pagination-list span.current' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/*----- End Tab -----*/
		$this->end_controls_section();
	}


	/* UA Post Grid Style 2 */
	private function get_post_st2_date_style() {
		$this->start_controls_section( 'post_st2_date_style',
			[
				'label'     => __( 'Date', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_2',
					'post_grid_show_date'  => 'yes',
				]
			]
		);
		$this->add_control( 'post_st2_date_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-date .ua-blog2-date-label' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_st2_date_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-date .ua-blog2-date-label' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-date .ua-blog2-date-label:after' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'post_st2_date_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-item .ua-blog2-date .ua-blog2-date-label',
			]
		);
		$this->add_control( 'post_st2_date_radius',
			[
				'label'      => __( 'Border-radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'     => '4',
					'right'   => '4',
					'bottom'  => '4',
					'left'    => '0',
					'unit'    => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-date .ua-blog2-date-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_st2_date_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '10',
					'bottom'   => '4',
					'left'     => '12',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-date .ua-blog2-date-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_st2_date_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-date .ua-blog2-date-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_st2_image_style() {
		$this->start_controls_section( 'post_st2_image_style',
			[
				'label'     => __( 'Image', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_2',
					'post_grid_show_image' => 'yes',
				]
			]
		);
		$this->add_control( 'post_st2_img_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '4',
                    'right'  => '4',
                    'bottom' => '0',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-image a img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_st2_img_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-item .ua-blog2-image a img',
			]
		);
		$this->add_responsive_control( 'post_st2_img_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-image a img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_st2_img_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-image a img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_st2_title_style() {
		$this->start_controls_section( 'post_st2_title_style',
			[
				'label'     => __( 'Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_2',
					'post_grid_show_title' => 'yes',
				]
			]
		);
		$this->add_control( 'post_st2_title_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-content .ua-blog2-title a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_st2_title_color_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-content .ua-blog2-title a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'post_st2_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-item .ua-blog2-content .ua-blog2-title',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'post_st2_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-item .ua-blog2-content .ua-blog2-title',
			]
		);
		$this->add_responsive_control( 'post_st2_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-content .ua-blog2-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_st2_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '15',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-content .ua-blog2-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_st2_author_style() {
		$this->start_controls_section( 'post_st2_author_style',
			[
				'label'     => __( 'Author', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style'  => 'style_2',
					'post_grid_show_author' => 'yes',
				]
			]
		);
		$this->add_control( 'post_st2_author_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-author a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-author' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_st2_author_color_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-author a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'post_st2_author_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-author',
			]
		);
		$this->add_responsive_control( 'post_st2_author_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-author' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_st2_author_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '15',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-author' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_st2_comment_style() {
		$this->start_controls_section( 'post_st2_cmnt_style',
			[
				'label'     => __( 'Comments', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style'    => 'style_2',
					'post_grid_show_comments' => 'yes',
				]
			]
		);
		$this->add_control( 'post_st2_cmnt_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-comments a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-comments' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_st2_cmnt_color_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-comments a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'post_st2_cmnt_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-comments',
			]
		);
		$this->add_responsive_control( 'post_st2_cmnt_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-comments' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_st2_cmnt_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-duration .ua-blog2-comments' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_st2_pagination_style() {
		$this->start_controls_section( 'post_st2_pagination_style',
			[
				'label'     => __( 'Pagination', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_2',
					'post_grid_pagination' => 'yes',
				]
			]
		);
		$this->add_responsive_control( 'post_st2_pagination_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_st2_pagination_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'post_st2_pagination_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-pagination-list > *',
			]
		);
		/*-----Start Tab-----*/
		$this->start_controls_tabs( 'post_st2_pagination_tab',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'post_st2_pagination_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'post_st2_pagination_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_st2_pagination_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'post_st2_pagination_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-pagination-list > *',
			]
		);
		$this->add_control( 'post_st2_pagination_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '50',
                    'right'  => '50',
                    'bottom' => '50',
                    'left'   => '50',
                    'unit'   => '%',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_st2_pagination_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-pagination-list > *',
				'fields_options' => [
					'box_shadow_type' => [
						'default' =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.2)'
						]
					]
				],
			]
		);
		$this->add_responsive_control( 'post_st2_pagination_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'post_st2_pagination_hv',
			[
				'label' => __( 'Hover/Active', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'post_st2_pagination_color_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ua-blog2-pagination-list .current' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_st2_pagination_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *:hover' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-blog2-pagination-list .current' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'post_st2_pagination_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-pagination-list > *:hover, {{WRAPPER}} .ua-blog2-pagination-list .current',
			]
		);
		$this->add_control( 'post_st2_pagination_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *:hover, {{WRAPPER}} .ua-blog2-pagination-list .current' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_st2_pagination_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-pagination-list > *:hover, {{WRAPPER}} .ua-blog2-pagination-list .current',
			]
		);
		$this->add_responsive_control( 'post_st2_pagination_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *:hover, {{WRAPPER}} .ua-blog2-pagination-list .current' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/*----- End Tab -----*/
		$this->add_control( 'post_st2_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control( 'post_st2_pagination_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '30',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-pagination-list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_st2_pagination_spc_between',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-pagination-list > *' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
	}
	private function get_post_st2_box_style() {
		$this->start_controls_section( 'post_st2_box_style',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_2',
				]
			]
		);
		/*-----Start Tab-----*/
		$this->start_controls_tabs( 'post_st2_box_tab',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'post_st2_box_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'post_st2_box_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-item' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-blog2-item .ua-blog2-image:after' => 'border-bottom: 12px solid {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'            => 'post_st2_box_border',
				'label'           => __( 'Border', 'useful-addons-elementor' ),
				'selector'        => '{{WRAPPER}} .ua-blog2-item',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'rgba(127, 136, 151, 0.2)',
					],
				],
			]
		);
		$this->add_control( 'post_st2_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '4',
                    'right'  => '4',
                    'bottom' => '4',
                    'left'   => '4',
                    'unit'   => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_st2_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-item',
			]
		);
		$this->add_responsive_control( 'post_st2_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_st2_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '30',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'post_st2_box_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'post_st2_box_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-blog2-item:hover' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-blog2-item:hover .ua-blog2-image:after' => 'border-bottom: 12px solid {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'post_st2_box_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-item:hover',
			]
		);
		$this->add_control( 'post_st2_box_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_st2_box_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-blog2-item:hover',
				'fields_options' => [
					'box_shadow_type' => [
						'default' =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
			]
		);
		$this->add_responsive_control( 'post_st2_box_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'post_st2_box_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-blog2-item:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/*----- End Tab -----*/
		$this->end_controls_section();
	}


	/* UA Port Grid Style 3 */
	private function get_post_grid3_title_style( ){
		$this->start_controls_section( 'post_grid3_title_style',
			[
				'label' => __( 'Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_3'
				]
			]
		);
		$this->add_control( 'post_grid3_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-title a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'post_grid3_title_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#287dfa',
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-title:hover a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(Group_Control_Typography::get_type(),
			[
				'name'     => 'post_grid3_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-title',
			]
		);
		$this->add_responsive_control('post_grid3_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'	 => '0',
					'right'	 => '0',
					'bottom' => '5',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_grid3_meta_date_style( ){
		$this->start_controls_section( 'post_grid3_meta_date_style',
			[
				'label' => __( 'Meta Date', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_3'
				]
			]
		);
		$this->add_control( 'post_grid3_meta_date_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-meta' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(Group_Control_Typography::get_type(),
			[
				'name'     => 'post_grid3_meta_date_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-meta',
			]
		);
		$this->add_responsive_control('post_grid3_meta_date_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'	 => '0',
					'right'	 => '0',
					'bottom' => '10',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_grid3_meta_cat_style( ){
		$this->start_controls_section( 'post_grid3_meta_cat_style',
			[
				'label' => __( 'Meta Category', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_3'
				]
			]
		);
		/*-----Start Tab-----*/
		$this->start_controls_tabs( 'post_grid3_meta_cat_tab',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'post_grid3_meta_cat_tab_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('post_grid3_meta_cat_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0d233e',
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-post-body .post-categories li a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('post_grid3_meta_cat_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-post-body .post-categories li a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control('post_grid3_meta_cat_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'	  => '30',
					'right'	  => '30',
					'bottom'  => '30',
					'left'    => '30',
					'unit'    => 'px',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-post-body .post-categories li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'post_grid3_meta_cat_tab_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('post_grid3_meta_cat_clr_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-post-body .post-categories li a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('post_grid3_meta_cat_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#287dfa',
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-post-body .post-categories li a:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control('post_grid3_meta_cat_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-post-body .post-categories li a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/*----- End Tab -----*/
        $this->add_control('post_grid3_meta_cat_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control('post_grid3_meta_cat_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'	  => '4',
					'right'	  => '8',
					'bottom'  => '4',
					'left'    => '8',
					'unit'    => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-post-body .post-categories li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('post_grid3_meta_cat_spc_between',
			[
				'label' 	 => __( 'Space Between', 'useful-addons-elementor' ),
				'type'  	 => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-post-body .post-categories li a' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('post_grid3_meta_cat_margin',
			[
				'label'      => __( 'Wrapper Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'	  => '0',
					'right'	  => '0',
					'bottom'  => '25',
					'left'    => '0',
					'unit'    => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-post-body .post-categories' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_grid3_img_overlay_style( ){
		$this->start_controls_section( 'post_grid3_img_overlay_style',
			[
				'label'     => __( 'Image Overlay', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_3'
				]
			]
		);
		$this->add_control('post_grid3_img_overlay_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0d233e',
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-img:before' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control('post_grid3_img_overlay_opacity',
			[
				'label'   => __( 'Opacity', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 1,
				'step'    => .1,
				'default' => .6,
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-img:before' => 'opacity: {{VALUE}}',
				]
			]
		);
		$this->end_controls_section();
	}
	private function get_post_grid3_author_box_style( ){
		$this->start_controls_section( 'post_grid3_author_box_style',
			[
				'label'     => __( 'Author Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_3'
				]
			]
		);
		$this->add_control('post_grid3_author_box_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-footer' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control('post_grid3_author_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'	  => '20',
					'right'	  => '20',
					'bottom'  => '20',
					'left'    => '20',
					'unit'    => 'px',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_grid3_author_img_style( ){
		$this->start_controls_section( 'post_grid3_author_img_style',
			[
				'label'     => __( 'Author Image', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_3'
				]
			]
		);
		$this->add_responsive_control('post_grid3_author_img_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-author-content img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('post_grid3_author_img_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-author-content img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(Group_Control_Border::get_type(),
			[
				'name'     => 'post_grid3_author_img_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '3',
							'right'    => '3',
							'bottom'   => '3',
							'left'     => '3',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#ffffff',
					],
				],
				'selector' => '{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-author-content img',
			]
		);
		$this->add_responsive_control('post_grid3_author_img_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'	  => '50',
					'right'	  => '50',
					'bottom'  => '50',
					'left'    => '50',
					'unit'    => '%',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-author-content img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_grid3_author_img_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.05)'
						]
					]
				],
				'selector' => '{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-author-content img',
			]
		);
		$this->add_responsive_control('post_grid3_author_img_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'	  => '0',
					'right'	  => '10',
					'bottom'  => '0',
					'left'    => '0',
					'unit'    => '%',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-author-content img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_grid3_author_name_style( ){
		$this->start_controls_section( 'post_grid3_author_name_style',
			[
				'label'     => __( 'Author Name', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_3'
				]
			]
		);
		$this->add_control('post_grid3_author_name_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0d233e',
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-author-content a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('post_grid3_author_name_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#287dfa',
				'selectors' => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-author-content a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(Group_Control_Typography::get_type(),
			[
				'name'     => 'post_grid3_author_name_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-author-content a',
			]
		);
		$this->add_responsive_control('post_grid3_author_name_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card .ua-post-grid3-author-content a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_post_grid3_card_style( ){
		$this->start_controls_section( 'post_grid3_card_style',
			[
				'label'     => __( 'Card', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'post_grid_grid_style' => 'style_3'
				]
			]
		);
		$this->add_group_control(Group_Control_Border::get_type(),
			[
				'name'     => 'post_grid3_author_card_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-post-grid3-card',
			]
		);
		$this->add_responsive_control('post_grid3_author_card_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'     => '5',
					'right'	  => '5',
					'bottom'  => '5',
					'left'    => '5',
					'unit'    => 'px',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'post_grid3_author_card_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
				'selector' => '{{WRAPPER}} .ua-post-grid3-card',
			]
		);
		$this->add_responsive_control('post_grid3_author_card_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('post_grid3_author_card_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'     => '0',
					'right'	  => '0',
					'bottom'  => '30',
					'left'    => '0',
					'unit'    => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-post-grid3-card' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls() {
		$this->get_query_post_grid();
		$this->get_layout_post_grid();
		$this->get_carousel_controls_post_grid();
		$this->get_style_post_grid_img();
		$this->get_style_post_grid_title();
		$this->get_style_post_grid_excerpt();
		$this->get_style_post_grid_meta();
		$this->get_style_post_grid_btn();
		$this->get_style_post_grid_comments();
		$this->get_style_post_grid_navigation();
		$this->get_style_post_pagination();
		$this->get_style_post_grid_box();

		/* Post Style 2 */
		$this->get_post_st2_date_style();
		$this->get_post_st2_image_style();
		$this->get_post_st2_title_style();
		$this->get_post_st2_author_style();
		$this->get_post_st2_comment_style();
		$this->get_post_st2_pagination_style();
		$this->get_post_st2_box_style();

		/* Post Grid Style 3 */
		$this->get_post_grid3_title_style();
		$this->get_post_grid3_meta_date_style();
		$this->get_post_grid3_meta_cat_style();
		$this->get_post_grid3_img_overlay_style();
		$this->get_post_grid3_author_box_style();
		$this->get_post_grid3_author_img_style();
		$this->get_post_grid3_author_name_style();
		$this->get_post_grid3_card_style();
	}

	protected function render() {
		$settings = $this->get_settings();

        $blog_post_by_id   = explode(',', $settings['post_grid_post_by_ids']);
		$blog_post_by      = $settings['blog_authors'];
		$blog_post_per     = $settings['post_grid_post_per_page'];
		$post_grid_orderby = $settings['post_grid_order_by'];
		$post_grid_order   = $settings['post_grid_order'];

		if(!empty( $settings['post_grid_post_by_ids'] )) {
			$default = [
				'posts_per_page' => $blog_post_per,
				'orderby'        => $post_grid_orderby,
                'post__in'       => $blog_post_by_id,
				'order'          => $post_grid_order,
				'author'         => $blog_post_by,
				'post_type'      => 'post',
				'paged'          => get_query_var('paged') ? get_query_var('paged') : 1
			];
		} else {
			$default = [
				'posts_per_page' => $blog_post_per,
				'orderby'        => $post_grid_orderby,
				'order'          => $post_grid_order,
				'author'         => $blog_post_by,
				'post_type'      => 'post',
				'paged'          => get_query_var('paged') ? get_query_var('paged') : 1
			];
		}

		/**
		 * Setup the post arguments.
		 */
		// Post Query
		$post_query  = new \WP_Query( $default );

		if($settings['post_grid_layout_style'] == 'grid') {
			?>
            <section class="ua-blog-area">
                <div class="row ua-blog-post-wrapper">
					<?php
                    if($settings['post_grid_grid_style'] === 'style_1') {
                        if($post_query->have_posts()) {
                            ?>
                            <div class="ua-blog-masonry">
                                <?php
                                while ($post_query->have_posts()) {
                                    $post_query->the_post();
                                    ?>
                                    <div class="col-md-<?php echo esc_attr($settings['post_grid_columns']); ?> col-sm-6 msy-width">
                                        <div <?php post_class('blog-post-item'); ?>>

                                            <?php if ( !empty(get_the_post_thumbnail_url()) && $settings['post_grid_show_image'] == 'yes') {

                                                if ($settings['post_grid_box_shape_dependency'] === 'yes') {
                                                    $hide_shape = ' ';
                                                } else {
                                                    $hide_shape = ' hide_shape';
                                                }
                                                ?>
                                                <div class="blog-post-img <?php echo esc_attr($hide_shape); ?>">
                                                    <a href="<?php the_permalink(); ?>">
                                                        <?php the_post_thumbnail('wpminzel-blog-square-big'); ?>
                                                    </a>
                                                    <?php if ($settings['post_grid_show_image_overlay'] == 'yes') {

                                                        if ( !empty( $settings['post_grid_image_overlay_icon']['value']) ) { ?>
                                                            <div class="item-overlay">
                                                                <a href="<?php the_permalink(); ?>">
                                                                    <?php
                                                                    Icons_Manager::render_icon( $settings['post_grid_image_overlay_icon'], [ 'aria-hidden' => 'true' ] )
                                                                    ?>
                                                                </a>
                                                            </div>
                                                            <?php
                                                        }
                                                    } ?>
                                                </div><!-- end blog-post-img -->
                                            <?php } ?>
                                            <div class="blog-post-body">
                                                <?php if ($settings['post_grid_meta_position'] == 'before_title') { ?>
                                                    <?php if ($settings['post_grid_show_meta'] == 'yes') {
                                                        if ($settings['post_grid_post_meta_alignment'] == 0) {
                                                            $meta_alignments = 'text-left justify-content-start';
                                                        } elseif ($settings['post_grid_post_meta_alignment'] == 1) {
                                                            $meta_alignments = 'text-center justify-content-center';
                                                        } elseif ($settings['post_grid_post_meta_alignment'] == 2) {
                                                            $meta_alignments = 'text-right justify-content-end';
                                                        } else {
                                                            $meta_alignments = 'text-justify justify-content-between';
                                                        }
                                                        ?>
                                                        <ul class="post__meta <?php echo esc_attr($meta_alignments); ?>">
                                                            <li><?php the_time( get_option( 'date_format' ) ); ?></li>
                                                            <li><?php esc_html_e('By ', 'useful-addons-elementor'); ?>
                                                                <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">
                                                                    <?php the_author_meta('display_name'); ?>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    <?php } ?>
                                                    <?php if ($settings['post_grid_show_title'] == 'yes' && !empty(get_the_title())) {
                                                        if ($settings['post_grid_title_alignment'] == 0) {
                                                            $title_alignments = 'text-left justify-content-start';
                                                        } elseif ($settings['post_grid_title_alignment'] == 1) {
                                                            $title_alignments = 'text-center justify-content-center';
                                                        } elseif ($settings['post_grid_title_alignment'] == 2) {
                                                            $title_alignments = 'text-right justify-content-end';
                                                        } else {
                                                            $title_alignments = 'text-justify justify-content-between';
                                                        }
                                                        ?>
                                                        <a href="<?php the_permalink(); ?>" class="blog__title <?php echo esc_attr($title_alignments); ?>">
                                                            <?php the_title(); ?>
                                                        </a>
                                                        <?php
                                                    } ?>
                                                <?php } else { ?>
                                                    <?php if ($settings['post_grid_show_meta'] == 'yes') { ?>
                                                        <?php if ($settings['post_grid_show_title'] == 'yes' && !empty(get_the_title())) {
                                                            if ($settings['post_grid_title_alignment'] == 0) {
                                                                $title_alignments = 'text-left justify-content-start';
                                                            } elseif ($settings['post_grid_title_alignment'] == 1) {
                                                                $title_alignments = 'text-center justify-content-center';
                                                            } elseif ($settings['post_grid_title_alignment'] == 2) {
                                                                $title_alignments = 'text-right justify-content-end';
                                                            } else {
                                                                $title_alignments = 'text-justify justify-content-between';
                                                            }
                                                            ?>
                                                            <a href="<?php the_permalink(); ?>"
                                                               class="blog__title <?php echo esc_attr($title_alignments); ?>">
                                                                <?php the_title(); ?>
                                                            </a>
                                                            <?php
                                                        } ?>
                                                        <ul class="post__meta">
                                                            <li><?php the_time( get_option( 'date_format' ) ); ?></li>
                                                            <li><?php esc_html_e('By ', 'useful-addons-elementor'); ?>
                                                                <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">
                                                                    <?php the_author_meta('display_name'); ?>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    <?php } ?>
                                                <?php } ?>
                                                <?php
                                                if ($settings['post_grid_show_excerpt'] == 'yes' && !empty(get_the_content())) {
                                                    if ($settings['post_grid_excerpt_alignment'] == 0) {
                                                        $title_alignments = 'text-left justify-content-start';
                                                    } elseif ($settings['post_grid_excerpt_alignment'] == 1) {
                                                        $title_alignments = 'text-center justify-content-center';
                                                    } elseif ($settings['post_grid_excerpt_alignment'] == 2) {
                                                        $title_alignments = 'text-right justify-content-end';
                                                    } else {
                                                        $title_alignments = 'text-justify justify-content-between';
                                                    }
                                                    $excerpt_words = $settings['post_grid_excerpt_word'];
                                                    echo '<p class="' . esc_attr($title_alignments) . '">' . wp_trim_words(get_the_content(), $excerpt_words, ' ') . '</p>';
                                                }
                                                ?>
                                                <ul class="post__bottom">
                                                    <?php if (!empty($settings['post_grid_readmore_btn_text']) && $settings['post_grid_show_readmore_btn'] == 'yes') { ?>
                                                        <li>
                                                            <a href="<?php the_permalink(); ?>" class="blog__btn">
                                                                <?php echo esc_html($settings['post_grid_readmore_btn_text']);

                                                                if ( $settings['post_grid_button_icon_condition'] == 'yes' ) {
                                                                    if (!empty( $settings['post_grid_button_icon'])) {
                                                                        Icons_Manager::render_icon( $settings['post_grid_button_icon'], ['class' => 'fa__arrow ', ' aria-hidden' => 'true' ] );
                                                                    }
                                                                } ?>
                                                            </a>
                                                        </li>
                                                    <?php }
                                                    if ($settings['post_grid_show_comments'] == 'yes') { ?>
                                                        <li>
                                                            <a href="<?php the_permalink(); ?>" class="blog__com">
                                                                <?php echo get_comments_number();
                                                                if ( !empty( $settings['post_grid_comment_icon'] ) ) {
                                                                    Icons_Manager::render_icon( $settings['post_grid_comment_icon'], [ 'aria-hidden' => 'true' ] );
                                                                }
                                                                ?>
                                                            </a>
                                                        </li>
                                                    <?php } ?>
                                                </ul>
                                            </div><!-- end blog-post-body -->
                                        </div><!-- end blog-post-item -->
                                    </div><!-- end col-md-4 -->
                                    <?php
                                }
                                ?>
                            </div>
                            <?php

                            if ( $settings['post_grid_pagination'] == 'yes' ) {
                                ?>
                                <div class="col-md-12">
                                    <div class="pagination-wrapper text-center">
                                        <div class="pagination-list">
                                            <?php
                                            $total_pages = $post_query->max_num_pages;
                                            echo paginate_links( [
                                                'format'    => '?paged=%#%',
                                                'current'   => max(1, get_query_var('paged')),
                                                'prev_text' => __('<i class="la la-angle-double-left"></i>', 'useful-addons-elementor'),
                                                'next_text' => __('<i class="la la-angle-double-right"></i>', 'useful-addons-elementor'),
                                                'total'     => $total_pages,
                                            ] );
                                            ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                        }
                        wp_reset_query();
                    } elseif($settings['post_grid_grid_style'] === 'style_3') {
						if($post_query->have_posts()) { 
							?>
							<div class="ua-blog-masonry">
                                <?php
                                while ($post_query->have_posts()) {
									$post_query->the_post();
									if($settings['post_grid_show_image'] === 'yes' && get_the_post_thumbnail()) {
									    $empty_img = ' ';
									} else {
										$empty_img = ' empty-image';
									}
									?>
                                    <div class="col-lg-<?php echo esc_attr($settings['post_grid_columns']); ?> col-sm-6 msy-width">
										<div id="post-<?php the_ID(  ); ?>" <?php post_class( 'ua-post-grid3-card ' . $empty_img ); ?>>
											<div class="ua-post-grid3-img">
												<?php the_post_thumbnail(); ?>
												<div class="ua-post-grid3-post-format">
													<i class="la la-photo"></i>
												</div>
												<div class="ua-post-grid3-post-body">
													<?php
													the_category();
													if(get_the_title()) {
														?>
														<h3 class="ua-post-grid3-title">
															<a href="<?php the_permalink(); ?>">
																<?php the_title(); ?>
															</a>
														</h3>
													<?php } ?>
													<p class="ua-post-grid3-meta">
														<span class="ua-post-grid3-date"> <?php the_time( get_option( 'date_format' ) ); ?></span>
													</p>
												</div>
											</div>
											<div class="ua-post-grid3-footer d-flex align-items-center justify-content-between">
												<div class="ua-post-grid3-author-content d-flex align-items-center">
													<?php echo get_avatar(get_the_ID()); ?>
													<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="ua-post-grid3-author-bio">
														<?php echo get_the_author(); ?>
													</a>
												</div>
												<div class="ua-post-grid3-share">
													<i class="la la-share ua-post-grid3-share-icon"></i>
													<ul class="ua-post-grid3-share-social d-flex align-items-center">
														<li><a href="#"><i class="lab la-facebook-f"></i></a></li>
														<li><a href="#"><i class="lab la-twitter"></i></a></li>
														<li><a href="#"><i class="lab la-instagram"></i></a></li>
													</ul>
												</div>
											</div>
										</div>
									</div>
								<?php } ?>
							</div>
                            <?php
                            if($settings['post_grid_pagination'] === 'yes') { ?>
                                <div class="col-lg-12">
                                    <div class="ua-blog2-pagination-list d-flex flex-wrap justify-content-center align-items-center text-center">
                                        <?php
                                        $total_pages = $post_query->max_num_pages;
                                            echo paginate_links( [
                                                'format'    => '?paged=%#%',
                                                'current'   => max(1, get_query_var('paged')),
                                                'prev_text' => __('<i class="la la-arrow-left"></i>', 'useful-addons-elementor'),
                                                'next_text' => __('<i class="la la-arrow-right"></i>', 'useful-addons-elementor'),
                                                'total'     => $total_pages,
                                            ] );
                                        ?>
                                    </div>
                                </div>
							<?php }
						}
						?>
					<script>
						if(jQuery(".ua-blog-post-wrapper .ua-blog-masonry").length ) {
							jQuery('.ua-blog-post-wrapper .ua-blog-masonry').isotope({
								itemSelector: '.ua-blog-post-wrapper .ua-blog-masonry .msy-width',
								percentPosition: true,
								masonry: {
									columnWidth: '.ua-blog-post-wrapper .ua-blog-masonry .msy-width'
								}
							});
						}
					</script>
					<?php
					} else {
                        if($post_query->have_posts()) { ?>
							<div class="ua-blog-masonry">
                                <?php
                                while ($post_query->have_posts()) {
									$post_query->the_post();
									if($settings['post_grid_show_image'] === 'yes' && get_the_post_thumbnail()) {
									    $hide_img_shape = ' ';
									} else {
										$hide_img_shape = ' empty-image';
									}
									?>
                                    <div class="col-lg-<?php echo esc_attr($settings['post_grid_columns']); ?> col-sm-6 msy-width">
                                        <div class="ua-blog2-item">
                                            <?php if(!empty(get_the_post_thumbnail() )) { ?>
												<div class="ua-blog2-image position-relative <?php echo esc_attr($hide_img_shape); ?>">
													<?php if(get_the_post_thumbnail() && $settings['post_grid_show_image'] === 'yes') { ?>
														<a href="<?php the_permalink(); ?>" class="position-relative d-block">
															<?php the_post_thumbnail('ua-blog-grid-img'); ?>
														</a>
													<?php } if($settings['post_grid_show_date'] === 'yes') { ?>
														<div class="ua-blog2-date position-absolute">
															<span class="ua-blog2-date-label position-relative d-inline-block">
																<?php the_time( get_option( 'date_format' ) ); ?>
															</span>
														</div>
													<?php } ?>
												</div>
                                            <?php } ?>
                                            <div class="ua-blog2-content">
                                                <?php if(empty(get_the_post_thumbnail())) { ?>
                                                    <span class="post-date-meta badge-label">
                                                        <?php the_time( get_option( 'date_format' ) ); ?>
                                                    </span>
                                                <?php } if(get_the_title() && $settings['post_grid_show_title'] === 'yes') { ?>
                                                    <h3 class="ua-blog2-title">
                                                        <a href="<?php the_permalink(); ?>">
                                                            <?php the_title(); ?>
                                                        </a>
                                                    </h3>
                                                <?php } ?>
                                                <div class="ua-blog2-action">
                                                    <ul class="ua-blog2-duration d-flex align-items-center">
                                                        <?php if($settings['post_grid_show_author'] === 'yes') { ?>
                                                            <li class="position-relative ua-blog2-author">
                                                                <?php esc_html_e('By ', 'useful-addons-elementor'); ?>
                                                                <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">
                                                                    <?php the_author_meta('display_name'); ?>
                                                                </a>
                                                            </li>
                                                        <?php } if($settings['post_grid_show_comments'] === 'yes') { ?>
                                                            <li class="position-relative ua-blog2-comments">
                                                                <?php comments_popup_link(esc_html__('0 Comment', 'useful-addons-elementor'), esc_html__('1 Comment', 'useful-addons-elementor'), '% Comments', 'comments-link', esc_html__('Comments off', 'useful-addons-elementor')); ?>
                                                            </li>
                                                        <?php } ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php
                                }
                                wp_reset_query();
                                ?>
                            </div>
                            <?php
                            if($settings['post_grid_pagination'] === 'yes') { ?>
                                <div class="col-lg-12">
                                    <div class="ua-blog2-pagination-list d-flex flex-wrap justify-content-center align-items-center text-center">
                                        <?php
                                        $total_pages = $post_query->max_num_pages;
                                            echo paginate_links( [
                                                'format'    => '?paged=%#%',
                                                'current'   => max(1, get_query_var('paged')),
                                                'prev_text' => __('<i class="la la-arrow-left"></i>', 'useful-addons-elementor'),
                                                'next_text' => __('<i class="la la-arrow-right"></i>', 'useful-addons-elementor'),
                                                'total'     => $total_pages,
                                            ] );
                                        ?>
                                    </div>
                                </div>
							<?php }
                        }
					}
					?>
                </div><!-- end ua-blog-post-wrapper -->
            </section>
            <script>
                if(jQuery(".ua-blog-post-wrapper .ua-blog-masonry").length ) {
                    jQuery('.ua-blog-post-wrapper .ua-blog-masonry').isotope({
                        itemSelector: '.ua-blog-post-wrapper .ua-blog-masonry .msy-width',
                        percentPosition: true,
                        masonry: {
                            columnWidth: '.ua-blog-post-wrapper .ua-blog-masonry .msy-width'
                        }
                    });
                }
            </script>
		<?php } elseif($settings['post_grid_layout_style'] == 'carousel') { ?>
            <section class="ua-blog-area">
                <div class="ua-blog-post-wrapper">
                    <div class="blog-post-carousel owl-carousel">
						<?php
                        if($settings['post_grid_grid_style'] === 'style_1') {
                            if ( $post_query->have_posts() ){
                                while ( $post_query->have_posts() ) { $post_query->the_post();
                                    ?>
                                    <div <?php post_class( 'blog-post-item' ); ?>>
                                        <?php if ( ! empty( get_the_post_thumbnail_url() ) && $settings['post_grid_show_image'] == 'yes' ) {
                                            if ( $settings['post_grid_box_shape_dependency'] === 'yes' ) {
                                                $hide_shape = ' ';
                                            } else {
                                                $hide_shape = ' hide_shape';
                                            }
                                            ?>
                                            <div class="blog-post-img <?php echo esc_attr($hide_shape); ?>">
                                                <a href="<?php the_permalink(); ?>">
                                                    <?php
                                                    the_post_thumbnail('wpminzel-blog-square-big');
                                                    ?>
                                                </a>
                                                <?php if ( $settings['post_grid_show_image_overlay'] == 'yes' ) {

                                                    if ( !empty( $settings['post_grid_image_overlay_icon']) ) { ?>
                                                        <div class="item-overlay ">
                                                            <a href="<?php the_permalink(); ?>">
                                                                <?php
                                                                Icons_Manager::render_icon( $settings['post_grid_image_overlay_icon'], [ 'aria-hidden' => 'true' ] )
                                                                ?>
                                                            </a>
                                                        </div>
                                                        <?php
                                                    }
                                                } ?>
                                            </div><!-- end blog-post-img -->
                                        <?php } ?>
                                        <div class="blog-post-body">
                                            <?php if ( $settings['post_grid_meta_position'] == 'before_title' ) { ?>
                                                <?php if ( $settings['post_grid_show_meta'] == 'yes' ) {
                                                    if ( $settings['post_grid_post_meta_alignment'] == 0 ) {
                                                        $meta_alignments = 'text-left justify-content-start';
                                                    } elseif ( $settings['post_grid_post_meta_alignment'] == 1 ) {
                                                        $meta_alignments = 'text-center justify-content-center';
                                                    } elseif ( $settings['post_grid_post_meta_alignment'] == 2 ) {
                                                        $meta_alignments = 'text-right justify-content-end';
                                                    } else {
                                                        $meta_alignments = 'text-justify justify-content-between';
                                                    }
                                                    ?>
                                                    <ul class="post__meta <?php echo esc_attr($meta_alignments); ?>">
                                                        <li><?php the_time( get_option( 'date_format' ) ); ?></li>
                                                        <li><?php esc_html_e( 'By ', 'useful-addons-elementor' ); ?>
                                                            <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
                                                                <?php the_author_meta( 'display_name' ); ?>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                <?php } ?>
                                                <?php if ( $settings['post_grid_show_title'] == 'yes' && !empty( get_the_title() ) ) {
                                                    if ( $settings['post_grid_title_alignment'] == 0 ) {
                                                        $title_alignments = 'text-left justify-content-start';
                                                    } elseif ( $settings['post_grid_title_alignment'] == 1 ) {
                                                        $title_alignments = 'text-center justify-content-center';
                                                    } elseif ( $settings['post_grid_title_alignment'] == 2 ) {
                                                        $title_alignments = 'text-right justify-content-end';
                                                    } else {
                                                        $title_alignments = 'text-justify justify-content-between';
                                                    }
                                                    ?>
                                                    <a href="<?php the_permalink(); ?>" class="blog__title <?php echo esc_attr($title_alignments); ?>">
                                                        <?php the_title(); ?>
                                                    </a>
                                                <?php } ?>
                                            <?php } else { ?>
                                                <?php if ( $settings['post_grid_show_meta'] == 'yes' ) { ?>
                                                    <?php if ( $settings['post_grid_show_title'] == 'yes' && !empty( get_the_title() ) ) {
                                                        if ( $settings['post_grid_title_alignment'] == 0 ) {
                                                            $title_alignments = 'text-left justify-content-start';
                                                        } elseif ( $settings['post_grid_title_alignment'] == 1 ) {
                                                            $title_alignments = 'text-center justify-content-center';
                                                        } elseif ( $settings['post_grid_title_alignment'] == 2 ) {
                                                            $title_alignments = 'text-right justify-content-end';
                                                        } else {
                                                            $title_alignments = 'text-justify justify-content-between';
                                                        } ?>
                                                        <a href="<?php the_permalink(); ?>" class="blog__title <?php echo esc_attr($title_alignments); ?>">
                                                            <?php the_title(); ?>
                                                        </a>
                                                    <?php } ?>
                                                    <ul class="post__meta">
                                                        <li><?php the_time( get_option( 'date_format' ) ); ?></li>
                                                        <li><?php esc_html_e( 'By ', 'useful-addons-elementor' ); ?>
                                                            <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
                                                                <?php the_author_meta( 'display_name' ); ?>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                <?php } ?>
                                            <?php } ?>
                                            <?php
                                            if ( $settings['post_grid_show_excerpt'] == 'yes' ) {
                                                if ( $settings['post_grid_excerpt_alignment'] == 0 ) {
                                                    $title_alignments = 'text-left justify-content-start';
                                                } elseif ( $settings['post_grid_excerpt_alignment'] == 1 ) {
                                                    $title_alignments = 'text-center justify-content-center';
                                                } elseif ( $settings['post_grid_excerpt_alignment'] == 2 ) {
                                                    $title_alignments = 'text-right justify-content-end';
                                                } else {
                                                    $title_alignments = 'text-justify justify-content-between';
                                                }
                                                $excerpt_words = $settings['post_grid_excerpt_word'];
                                                echo '<p class="' . esc_attr($title_alignments) . '">' . wp_trim_words( get_the_content(), $excerpt_words, ' ' ) . '</p>';
                                            }
                                            ?>
                                            <ul class="post__bottom">
                                                <?php if ( ! empty( $settings['post_grid_readmore_btn_text'] ) && $settings['post_grid_show_readmore_btn'] == 'yes' ) { ?>
                                                    <li>
                                                        <a href="<?php the_permalink(); ?>" class="blog__btn">
                                                            <?php esc_html( $settings['post_grid_readmore_btn_text'] );

                                                            if ( $settings['post_grid_button_icon_condition'] == 'yes' ) {
                                                                if (!empty( $settings['post_grid_button_icon'])) {
                                                                    Icons_Manager::render_icon( $settings['post_grid_button_icon'], ['class' => 'fa__arrow ', 'aria-hidden' => 'true' ] );
                                                                }
                                                            } ?>
                                                        </a>
                                                    </li>
                                                <?php }
                                                if ( $settings['post_grid_show_comments'] == 'yes' ) { ?>
                                                    <li>
                                                        <a href="<?php the_permalink(); ?>" class="blog__com">
                                                            <?php echo get_comments_number();
                                                            if ( !empty( $settings['post_grid_comment_icon'] ) ) {
                                                                Icons_Manager::render_icon( $settings['post_grid_comment_icon'], [ 'aria-hidden' => 'true' ] );
                                                            }
                                                            ?>
                                                        </a>
                                                    </li>
                                                <?php } ?>
                                            </ul>
                                        </div>
                                    </div><!-- end blog-post-item -->
                                    <?php
                                }
                            }
                            wp_reset_query();
                        } else {
							if($post_query->have_posts()) {
                                while ($post_query->have_posts()) {
                                    $post_query->the_post();
                                    if($settings['post_grid_show_image'] === 'yes' && get_the_post_thumbnail()) {
                                        $hide_img_shape = ' ';
                                    } else {
                                        $hide_img_shape = ' empty-image';
                                    }
                                    ?>
                                        <div class="ua-blog2-item">
											<?php if(!empty(get_the_post_thumbnail())) { ?>
												<div class="ua-blog2-image position-relative <?php echo esc_attr($hide_img_shape); ?>">
													<?php if(get_the_post_thumbnail() && $settings['post_grid_show_image'] === 'yes') { ?>
														<a href="<?php the_permalink(); ?>" class="position-relative d-block">
															<?php the_post_thumbnail('ua-blog-grid-img'); ?>
														</a>
													<?php } if($settings['post_grid_show_date'] === 'yes') { ?>
														<div class="ua-blog2-date position-absolute">
                                                            <span class="ua-blog2-date-label position-relative d-inline-block">
                                                                <?php the_time( get_option( 'date_format' ) ); ?>
                                                            </span>
														</div>
													<?php } ?>
												</div>
											<?php } ?>
                                            <div class="ua-blog2-content">
												<?php if(empty(get_the_post_thumbnail())) { ?>
													<span class="post-date-meta badge-label">
														<?php the_time( get_option( 'date_format' ) ); ?>
													</span>
                                                <?php } if(get_the_title() && $settings['post_grid_show_title'] === 'yes') { ?>
                                                    <h3 class="ua-blog2-title">
                                                        <a href="<?php the_permalink(); ?>">
                                                            <?php the_title(); ?>
                                                        </a>
                                                    </h3>
                                                <?php } ?>
                                                <div class="ua-blog2-action">
                                                    <ul class="ua-blog2-duration d-flex align-items-center">
                                                        <?php if($settings['post_grid_show_author'] === 'yes') { ?>
                                                            <li class="position-relative ua-blog2-author">
                                                                <?php esc_html_e('By ', 'useful-addons-elementor'); ?>
                                                                <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>">
                                                                    <?php the_author_meta('display_name'); ?>
                                                                </a>
                                                            </li>
                                                        <?php } if($settings['post_grid_show_comments'] === 'yes') { ?>
                                                            <li class="position-relative ua-blog2-comments">
                                                                <?php comments_popup_link(esc_html__('0 Comment', 'useful-addons-elementor'), esc_html__('1 Comment', 'useful-addons-elementor'), '% Comments', 'comments-link', esc_html__('Comments off', 'useful-addons-elementor')); ?>
                                                            </li>
                                                        <?php } ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                }
							}
							wp_reset_query();
                        }
						?>
                    </div>
                </div>
                <!-- end ua-blog-post-wrapper -->
            </section>
			<?php
			$slides_items = $settings['post_grid_carousel_slides_show_num'];
			if($settings['post_grid_carousel_infinite_lope'] == 'yes') {
				$slides_loop = 'true';
			} else {
				$slides_loop = 'false';
			}
			if($settings['post_grid_carousel_autoplay'] == 'yes') {
				$slides_autoplay = 'true';
			} else {
				$slides_autoplay = 'false';
			}
			if($settings['post_grid_carousel_autoheight'] == 'yes') {
				$slides_autoh = 'true';
			} else {
				$slides_autoh = 'false';
			}
			if($settings['post_grid_carousel_navigation'] == 'dots' || $settings['post_grid_carousel_navigation'] == 'arrows_dots') {
				$slides_dots = 'true';
			} else {
				$slides_dots = 'false';
			}
			if($settings['post_grid_carousel_navigation'] == 'arrows' || $settings['post_grid_carousel_navigation'] == 'arrows_dots') {
				$slides_arws = 'true';
			} else {
				$slides_arws = 'false';
			}
			$slides_autop_spd     = $settings['post_grid_carousel_autop_spd']; // autoplay speed
			$slides_animation_spd = $settings['post_grid_carousel_animation_spd']; // Animation speed
			$slides_spc_between   = $settings['post_grid_carousel_spc_between']; // Space Between
			?>
            <script>

                jQuery('.blog-post-carousel').owlCarousel({
                    loop: <?php echo esc_attr($slides_loop); ?>,
                    autoplay: <?php echo esc_attr($slides_autoplay); ?>,
                    autoHeight: <?php echo esc_attr($slides_autoh); ?>,
                    dots: <?php echo esc_attr($slides_dots); ?>,
                    nav: <?php echo esc_attr($slides_arws); ?>,
					<?php if($settings['post_grid_carousel_navigation'] == 'arrows' || $settings['post_grid_carousel_navigation'] == 'arrows_dots') { ?>
                    navText: ['<?php if ( !empty( $settings['post_grid_carousel_left_arrow_icon'] ) ) { Icons_Manager::render_icon( $settings['post_grid_carousel_left_arrow_icon'], [ 'aria-hidden' => 'true' ] ); } ?>', '<?php if ( !empty( $settings['post_grid_carousel_right_arrow_icon'] ) ) { Icons_Manager::render_icon( $settings['post_grid_carousel_right_arrow_icon'], [ 'aria-hidden' => 'true' ] ); } ?>'],
					<?php } ?>
                    items: <?php echo esc_attr($slides_items); ?>,
                    smartSpeed: <?php echo esc_attr($slides_animation_spd); ?>,
                    autoplaySpeed: <?php echo esc_attr($slides_autop_spd); ?>,
                    margin: <?php echo esc_attr($slides_spc_between); ?>,
                    responsive : {
                        // breakpoint from 0 up
                        0 : {
                            items: 1
                        },
                        // breakpoint from 480 up
                        480 : {
                            items: 1
                        },
                        // breakpoint from 768 up
                        767 : {
                            items: 2
                        },
                        // breakpoint from 768 up
                        1024 : {
                            items: <?php echo esc_attr($slides_items); ?>
                        }
                    }
                });
            </script>
			<?php
		}
	}

	protected function _content_template() {}
}

Plugin::instance()->widgets_manager->register_widget_type( new UA_post_grid() );