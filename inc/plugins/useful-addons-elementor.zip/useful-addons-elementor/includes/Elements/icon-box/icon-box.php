<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_icon_box extends Widget_Base {
	public function get_name() {
		return 'UA_icon_box';
	}

	public function get_title() {
		return esc_html__( 'Icon Box', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-icon-box ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* Icon box Content Controls */
	private function get_content_icon_box_content_controls() {
		/**
		 * Icon Box Content Settings
		 */
		$this->start_controls_section( 'icon_box',
			[
				'label' => __( 'Icon Box', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		// Icon Box Design
		$this->add_control( 'icon_box_different_design',
			[
				'label'   => __( 'Layout Design', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'normal',
				'options' => [
					'normal'  => __( 'Normal', 'useful-addons-elementor' ),
					'slider'  => __( 'Slider', 'useful-addons-elementor' ),
				],
			]
		);
		// hover box animation style
		$this->add_control( 'icon_box_hover_box_styles',
			[
				'label'   => __( 'Box Hover Style', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style_1',
				'options' => [
					'style_1'  => __( 'Style 1', 'useful-addons-elementor' ),
					'style_2'  => __( 'Style 2', 'useful-addons-elementor' ),
					'style_3'  => __( 'Style 3', 'useful-addons-elementor' ),
					'style_4'  => __( 'Style 4', 'useful-addons-elementor' ),
				],
				'condition' => [
					'icon_box_different_design' => 'normal',
				],
			]
		);
		/* card box shape */
		$this->add_control( 'icon_box4_card_box_shape',
			[
				'label'        => __( 'Show Box Shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'icon_box_different_design' => 'normal',
					'icon_box_hover_box_styles' => 'style_4'
				],
			]
		);
		// Icon Switcher
		$this->add_control( 'icon_box_icon_dependant',
			[
				'label'        => __( 'Show Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3', 'style_4']
				],
			]
		);
		$this->add_control( 'icon_box_icon_shape_switcher',
			[
				'label'        => __( 'Show Icon Shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'icon_box_icon_dependant'   => 'yes',
					'icon_box_different_design' => 'normal',
					'icon_box_hover_box_styles' => ['style_1', 'style_3', 'style_4']
				],
			]
		);
		$this->add_control( 'icon_box_content_alignment',
			[
				'label'   => __('Content Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0'   => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1'   => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2'   => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
					'3'   => [
						'title' => __('Justify', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'default'   => '1',
				'condition' => [
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		$this->add_control( 'icon_box4_content_alignment',
			[
				'label'   => __('Content Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0'   => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1'   => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2'   => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
					'3'   => [
						'title' => __('Justify', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'default'   => '0',
				'condition' => [
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => 'style_4'
				],
			]
		);
		// Icon
		$this->add_control('icon_box_icon',
			[
				'label'            => __( 'Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'la la-user',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'icon_box_icon_dependant'   => 'yes',
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		// Title
		$this->add_control( 'icon_box_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Finance Management.', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
				'condition'   => [
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		$this->add_control( 'icon_box_titles_url',
			[
				'label'        => __( 'Show Title Link', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		$this->add_control( 'icon_box_title_url',
			[
				'label'         => __( 'Title Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'       => 'http://',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition' => [
					'icon_box_titles_url'       => 'yes',
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);

		// Description
		$this->add_control( 'icon_box_description',
			[
				'label'       => __( 'Description', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => __( 'sed quia lipsum dolor sit atur adipiscing elit is nunc quis tellus sed ligula porta ultricies quis nec neulla.', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
				'condition'   => [
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		// Number Switcher
		$this->add_control( 'icon_box_hv_number_sh',
			[
				'label'        => __( 'Show Hover Number', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'icon_box_hover_box_styles' => 'style_1',
					'icon_box_different_design' => 'normal',
				],
			]
		);
		// Number
		$this->add_control( 'icon_box_hv_number',
			[
				'label'       => __( 'Hover Number', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '01', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your box number', 'useful-addons-elementor' ),
				'condition'   => [
					'icon_box_hover_box_styles' => 'style_1',
					'icon_box_hv_number_sh'     => 'yes',
					'icon_box_different_design' => 'normal',
				]
			]
		);
		// Button
		$this->add_control( 'icon_box_button_sh',
			[
				'label'        => __( 'Show ReadMore Button', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		$this->add_control( 'icon_box_button_text',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Learn More', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your button\'s text here', 'useful-addons-elementor' ),
				'condition'   => [
					'icon_box_button_sh'        => 'yes',
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		$this->add_control( 'icon_box_button_url',
			[
				'label'         => __( 'Button Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => 'http://',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition' => [
					'icon_box_button_sh'        => 'yes',
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		// Button Icon
		$this->add_control( 'icon_box_button_icon_sh',
			[
				'label'        => __( 'Show Button Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'icon_box_button_sh'        => 'yes',
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);

		$this->add_control('icon_box_button_icon',
			[
				'label'            => __( 'Button Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'icon_box_button_icon_sh'   => 'yes',
					'icon_box_button_sh'        => 'yes',
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);

		$repeater = new Repeater();
		$repeater->add_control('icon_box_content_alignment',
			[
				'label'   => __('Content Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0' => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
					'3' => [
						'title' => __('Justify', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'default' => '0',
			]
		);

		$repeater->add_control('icon_box_icon',
			[
				'label'            => __( 'Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'la la-star',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
			]
		);
		// title
		$repeater->add_control('icon_box_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Consumer Products', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
			]
		);
		$repeater->add_control('icon_box_titles_url',
			[
				'label'        => __( 'Show Title Link', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater->add_control('icon_box_title_url',
			[
				'label'         => __( 'Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => 'http://',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition' => [
					'icon_box_titles_url' => 'yes',
				],
			]
		);
		// Description
		$repeater->add_control('icon_box_description',
			[
				'label'       => __( 'Description', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => __( 'Lorem ipsum dolor sit amet, consectetur adipisicing', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
			]
		);
		// button
		$repeater->add_control('icon_box_button_sh2',
			[
				'label'        => __( 'Show ReadMore Button', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater->add_control('icon_box_button_text',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Learn More', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your button\'s text here', 'useful-addons-elementor' ),
				'condition'   => [
					'icon_box_button_sh2' => 'yes',
				],
			]
		);
		$repeater->add_control('icon_box_button_url',
			[
				'label'         => __( 'Button Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => 'http://',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition' => [
					'icon_box_button_sh2' => 'yes',
				],
			]
		);
		// Button Icon
		$repeater->add_control('icon_box_button_icon_sh',
			[
				'label'        => __( 'Show Button Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'icon_box_button_sh2' => 'yes',
				],
			]
		);
		$repeater->add_control('icon_box_button_icon',
			[
				'label'            => __( 'Button Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'icon_box_button_icon_sh' => 'yes',
					'icon_box_button_sh2'     => 'yes',
				],
			]
		);

		/* Icon Carousel list */
		$this->add_control( 'UA_icon_carousel_lists',
			[
				'label'     => __( 'Icon Carousel List', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::REPEATER,
				'condition' => [
					'icon_box_different_design' => 'slider',
				],
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
						'icon_box_title'       => 'Consumer Products',
						'icon_box_icon'        => 'fa fa-clock-o',
						'icon_box_description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing',
					],
					[
						'icon_box_title'       => 'Adult Marketing',
						'icon_box_icon'        => 'fa fa-briefcase',
						'icon_box_description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing',
					],
					[
						'icon_box_title'       => 'Banking Advising',
						'icon_box_icon'        => 'fa fa-dollar',
						'icon_box_description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing',
					]
				],
				'title_field' => '{{{ icon_box_title }}}',
			]
		);

		/* icon 4 content */
		$this->add_control('icon_box4_icon',
			[
				'label'            => __( 'Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'la la-user',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'icon_box_icon_dependant'   => 'yes',
					'icon_box_different_design' => 'normal',
					'icon_box_hover_box_styles' => 'style_4'
				],
			]
		);
		$this->add_control( 'icon_box4_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Default title', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
				'condition'   => [
					'icon_box_hover_box_styles' => 'style_4'
				],
			]
		);
		$this->add_control( 'icon_box4_content',
			[
				'label'       => __( 'Content', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos excepturi magni odio quaerat quidem tempora.', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
				'condition'   => [
					'icon_box_hover_box_styles' => 'style_4'
				],
			]
		);
		$this->end_controls_section();
	}
	/* Icon Box Carousel Content Controls */
	private function get_content_icon_box_carousel_controls() {

		$this->start_controls_section( 'icon_box_carousel_content_setting',
			[
				'label'     => __( 'Carousel Content', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'icon_box_different_design' => 'slider',
				],
			]
		);
		$this->add_control( 'icon_box_carousel_pre_items',
			[
				'label'   => __( 'Slides to Show', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 20,
				'step'    => 1,
				'default' => 2,
			]
		);
		$this->add_control( 'icon_box_carousel_loop_condition',
			[
				'label'        => __( 'Infinite Loop', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'icon_box_carousel_autoplay_condition',
			[
				'label'        => __( 'Autoplay', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'icon_box_carousel_autopaly_spd',
			[
				'label'     => __( 'Autoplay Speed', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1,
				'max'       => 50000,
				'step'      => 50,
				'default'   => 500,
				'condition' => [
					'icon_box_carousel_autoplay_condition' => 'yes'
				]
			]
		);
		$this->add_control( 'icon_box_carousel_autoheight_condition',
			[
				'label'        => __( 'AutoHeight', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'icon_box_carousel_arrows_dots',
			[
				'label'   => __( 'Navigation', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dots',
				'options' => [
					'arrows_dots' => __( 'Arrows and Dots', 'useful-addons-elementor' ),
					'arrows'      => __( 'Arrows', 'useful-addons-elementor' ),
					'dots'        => __( 'Dots', 'useful-addons-elementor' ),
					'none'        => __( 'None', 'useful-addons-elementor' ),
				],
			]
		);

		$this->add_control('icon_box_carousel_arrow_left_icon',
			[
				'label'            => __( 'Arrow Left', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-left',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);

		$this->add_control('icon_box_carousel_arrow_right_icon',
			[
				'label'            => __( 'Arrow Right', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended'  => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'icon_box_carousel_animation_spd',
			[
				'label'   => __( 'Animation Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 50000,
				'step'    => 50,
				'default' => 500,
			]
		);
		$this->add_control( 'icon_box_carousel_margin',
			[
				'label'   => __( 'Margin', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
				'default' => 30,
			]
		);
		$this->end_controls_section();

	}
	/* Icon Box Icon Style Controls */
	private function get_style_icon_box_icon_style_controls() {
		// Icon
		$this->start_controls_section( 'icon_box_styles',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'normal',
					'icon_box_icon_dependant'   => 'yes',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_size',
			[
				'label'      => __( 'Font-size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 45,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_line_height',
			[
				'label'      => __( 'Line Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( '_tabs_image_effects',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( '_tab_image_effects_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_icon_color',
			[
				'label'     => __( 'Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_box_hover_box_styles' => ['style_1', 'style_2']
				]
			]
		);
		$this->add_control( 'icon_box_icon_color2',
			[
				'label'     => __( 'Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_box_hover_box_styles' => 'style_3'
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box_icon_background',
				'label'    => __( 'Icon Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient'],
				'default'  => 'rgba(246,107,93,0.1)',
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_icon_nrml_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item div.ua-feature__icon, {{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon',
			]
		);
		$this->add_responsive_control( 'icon_box_icon_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top'      => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => '%',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box_icon_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon',
			]
		);
		$this->add_responsive_control( 'icon_box_icon_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '30',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_icon_hv_color',
			[
				'label'     => __( 'Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .ua-feature__icon' => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_box_hover_box_styles' => ['style_1', 'style_2']
				]
			]
		);
		$this->add_control( 'icon_box_icon_hv_color2',
			[
				'label'     => __( 'Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f42ec',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .ua-feature__icon' => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_box_hover_box_styles' => 'style_3'
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box_icon_hv_background',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .ua-feature__icon',
				'default'  => [
					'classic' => '#f66b5d',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_icon_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item:hover div.ua-feature__icon',
			]
		);
		$this->add_responsive_control( 'icon_box_icon_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .ua-feature__icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box_icon_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .ua-feature__icon',
			]
		);
		$this->add_responsive_control( 'icon_box_icon_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_icon_box_icon_tab',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		// icon shape
		$this->add_control( 'icon_box_icon_shape_setting',
			[
				'label'     => __( 'Icon Shape', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
				],
			]
		);
		$this->add_control( 'icon_box_icon_shape_lines',
			[
				'label'   => __( 'Shape Lines', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'three',
				'options' => [
					'one'    => __( 'One', 'useful-addons-elementor' ),
					'two'    => __( 'Two', 'useful-addons-elementor' ),
					'three'  => __( 'Three', 'useful-addons-elementor' ),
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => 'style_3',
				],
			]
		);
		$this->add_control( 'icon_box_icon_shape_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon:after, {{WRAPPER}} .ua-feature-box.ua_hv_style_3 .ua-feature-item .ua-feature__icon .div-strokes .stroke__bar' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
				],
			]
		);
		$this->add_control( 'icon_box_icon_shape_hv_bg',
			[
				'label'     => __( 'Hover Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .ua-feature__icon:after' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => ['style_1', 'style_2'],
				],
			]
		);
		$this->add_control( 'icon_box_icon_shape3_hv_bg',
			[
				'label'     => __( 'Hover Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f42ec',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box.ua_hv_style_3 .ua-feature-item:hover .ua-feature__icon .div-strokes .stroke__bar' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => 'style_3',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_shape_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon:after, {{WRAPPER}} .ua-feature-box.ua_hv_style_3 .ua-feature-item .ua-feature__icon .div-strokes .stroke__bar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_shape_rotate',
			[
				'label'      => __( 'Rotate', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 360,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon:after' => 'transform: rotate({{SIZE}}deg);',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => ['style_1', 'style_2'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_shape3_rotate',
			[
				'label'      => __( 'Rotate', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range'  => [
					'px' => [
						'min'  => -360,
						'max'  => 360,
						'step' => 1,
					],
				],
				'default'  => [
					'size' => '-55'
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box.ua_hv_style_3 .ua-feature-item .ua-feature__icon .div-strokes' => 'transform: rotate({{SIZE}}deg);',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => 'style_3',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_shape_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon:after' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => ['style_1', 'style_2'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_shape3_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box.ua_hv_style_3 .ua-feature-item .ua-feature__icon .div-strokes' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => 'style_3',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_shape_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 25,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon:after' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => ['style_1', 'style_2'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_shape3_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 3,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box.ua_hv_style_3 .ua-feature-item .ua-feature__icon .div-strokes .stroke__bar' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => 'style_3',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_shape_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__icon:after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => ['style_1', 'style_2'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_shape3_ln_space',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '3',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box.ua_hv_style_3 .ua-feature-item .ua-feature__icon .div-strokes .stroke__bar' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => 'style_3',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_icon_shape3_ln_bx_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box.ua_hv_style_3 .ua-feature-item .ua-feature__icon .div-strokes' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes',
					'icon_box_hover_box_styles'    => 'style_3',
				],
			]
		);
		$this->end_controls_section();
	}
	/* Icon Box Carousel Icon Style Controls */
	private function get_style_icon_box_carousel_icon_style_controls() {
		$this->start_controls_section( 'icon_box_carousel_icons_styles',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'slider',
				],
			]
		);
		$this->add_control( 'icon_box_carousel_icon_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service-icon .ua-service__icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'icon_box_carousel_icon_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service-icon .ua-service__icon' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service-icon .ua-service__icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service-icon .ua-service__icon' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_icon_size',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => '65',
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service-icon .ua-service__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_icon_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service-icon .ua-service__icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_icon_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service-icon .ua-service__icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_icon_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '25',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* Icon Box Title & Icon Box Carousel Title Style Controls */
	private function get_style_icon_box_title_and_carousel_title_style_controls() {
		// Normal Icon Box title
		$this->start_controls_section( 'icon_box_title_style',
			[
				'label'     => __( 'Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'icon_box_title_hover_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_title_normal_clr',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_title_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .feature__title a, {{WRAPPER}} .ua-feature-box .ua-feature-item .feature__title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_title_hover_clr',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_title_hv_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .feature__title a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .feature__title'   => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_box_hover_box_styles' => 'style_1',
				]
			]
		);
		$this->add_control( 'icon_box_title_hv_color2',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .feature__title a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .feature__title'   => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_box_hover_box_styles' => ['style_2','style_3']
				]
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_icon_box_title_divider',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'icon_box_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item .feature__title',
			]
		);
		$this->add_responsive_control( 'icon_box_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 24,
					'left'     => 0,
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .feature__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_title_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .feature__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		// Slider Icon Box Title
		$this->start_controls_section( 'icon_box_carousel_title_styles',
			[
				'label'     => __( 'Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'slider',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'icon_box_carousel_title_tabs_control',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_carousel_title_normal_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_carousel_title_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__title a, {{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_carousel_title_hover_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_carousel_title_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__title a:hover, {{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__title:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_icon_box_carousel_tabs_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'icon_box_carousel_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__title',
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top'      => '5',
					'right'    => '0',
					'bottom'   => '18',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* Icon Box Desc & Icon box carousel desc style controls */
	private function get_style_icon_box_desc_and_carousel_desc_style_controls() {
		// Normal Icon Box Description
		$this->start_controls_section( 'icon_box_desc_style',
			[
				'label'     => __( 'Description', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'icon_box_description_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_description_normal_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_desc_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#677286',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_description_hover_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_desc_hv_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover p' => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_box_hover_box_styles' => 'style_1',
				],
			]
		);
		$this->add_control( 'icon_box_desc_hv_color2',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover p' => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_box_hover_box_styles' => ['style_2', 'style_3'],
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_icon_box_desc_divider',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'    => 'icon_box_desc_typography',
				'label'   => __( 'Typography', 'useful-addons-elementor' ),
				'default' => [
					'font_weight' => '500',
					'font_size'   => '16px',
					'line_height' => '28px',
				],
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item p',
			]
		);
		$this->add_responsive_control( 'icon_box_desc_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_desc_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		// Slider Icon Box Description
		$this->start_controls_section( 'icon_box_carousel_desc_styles',
			[
				'label'     => __( 'Description', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'slider',
				],
			]
		);
		$this->add_control( 'icon_box_carousel_desc_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#677286',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__desc' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'icon_box_carousel_desc_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__desc',
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_desc_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '18',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* Icon Box Button Style Controls */
	private function get_style_icon_box_button_style_controls() {
		// Button
		$this->start_controls_section( 'icon_box_button_style',
			[
				'label'     => __( 'Button', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_button_sh' => 'yes',
					'icon_box_different_design' => 'normal',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'icon_box_buttons_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_button_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_button_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box_button_normal_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_button_normal_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn',
			]
		);
		$this->add_control( 'icon_box_button_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box_button_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn',
			]
		);
		$this->add_responsive_control( 'icon_box_button_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '',
					'right'    => '35',
					'bottom'   => '',
					'left'     => '',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_button_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '18',
					'right'     => '',
					'bottom'    => '',
					'left'      => '',
					'unit'      => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_button_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_button_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .read__btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box_button_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .read__btn',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_button_hover_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn:hover',
			]
		);
		$this->add_control( 'icon_box_button_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box_button_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn:hover',
			]
		);
		$this->add_responsive_control( 'icon_box_button_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '',
					'right'    => '35',
					'bottom'   => '',
					'left'     => '',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_button_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '18',
					'right'     => '',
					'bottom'    => '',
					'left'      => '',
					'unit'      => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_icon_box_btn_divider',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'icon_box_button_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn',
			]
		);
		$this->add_control( 'more_options',
			[
				'label'     => __( 'Button Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control( 'icon_box_button_icon_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn .fa__arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_button_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn .fa__arrow' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_button_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn .fa__arrow' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		/* Start Tab */
		$this->start_controls_tabs( 'icon_box_buttons_icon_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_button_icon_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('icon_box_btn_icon_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn .fa__arrow' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('icon_box_btn_icon_nrml_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn .fa__arrow' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_button_icon_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn .fa__arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_button_icon_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_button_icon_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('icon_box_btn_icon_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .read__btn .fa__arrow' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('icon_box_btn_icon_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .read__btn .fa__arrow' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_button_icon_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover .read__btn .fa__arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_button_icon_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .read__btn:hover .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* Icon Box Carousel Button Style Controls */
	private function get_style_icon_box_carousel_button_style_controls () {
		// Slider Button
		$this->start_controls_section( 'icon_box_carousel_button_styles',
			[
				'label'     => __( 'Button', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'slider',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'icon_box_carousel_button_tabs_control',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_carousel_button_normal_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_carousel_btn_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'icon_box_carousel_btn_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_btn_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_button_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '20',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_button_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_carousel_button_hover_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_carousel_btn_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'icon_box_carousel_btn_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_btn_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_button_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_button_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_icon_box_carousel_button_tabs_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'icon_box_carousel_button_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn',
			]
		);
		$this->add_control( 'icon_box_carousel_btn_icon_hd',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_btn_icon_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn .fa__arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'icon_box_carousel_btn_icon_tabs_control',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_carousel_btn_icon_normal_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_btn_icon_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_carousel_btn_icon_hover_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_btn_icon_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item .ua-service__btn:hover .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* Icon Box Carousel Box Style Controls */
	private function get_style_icon_box_carousel_box_style_controls() {
		// Slider Box
		$this->start_controls_section( 'icon_box_carousel_box_styles',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'slider',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'icon_box_carousel_box_tabs_control',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_carousel_box_normal_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_carousel_box_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'  => 'icon_box_carousel_box_normal_border',
				'label' => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#233d63',
					],
				],
				'selector' => '{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box_carousel_box_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item',
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_box_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '20',
					'right'    => '0',
					'bottom'   => '20',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_box_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '53',
					'right'    => '30',
					'bottom'   => '38',
					'left'     => '30',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_box_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_carousel_box_hover_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box_carousel_box_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_carousel_box_hover_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box_carousel_box_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item:hover',
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_box_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '20',
					'bottom'   => '0',
					'left'     => '20',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_box_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_box_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .ua-service-item:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* Icon Box carousel navigation style controls */
	private function get_style_icon_box_carousel_nav_style_controls() {

		// Slider Navigation
		$this->start_controls_section( 'icon_box_carousel_navigation_styles',
			[
				'label'     => __( 'Navigation', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design'     => 'slider',
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows', 'dots'],
				],
			]
		);
		$this->add_control( 'icon_box_carousel_navigation_dots_hd',
			[
				'label'     => __( 'Dots', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_dots_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_dots_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'icon_box_carousel_navigation_dots_tab_control',
			[
				'separator' => 'before',
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_carousel_navigation_dots_normal_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'icon_box_carousel_navigation_dots_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_carousel_navigation_dots_normal_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#233d63',
					],
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_dots_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => '%',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_dots_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_dots_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '3',
					'bottom'   => '0',
					'left'     => '3',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_carousel_navigation_dots_hover_tab',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'icon_box_carousel_navigation_dots_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot.active' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_carousel_navigation_dots_hover_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot.active',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#f66b5d',
					],
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_dots_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_dots_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot.active' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_dots_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-service-area .ua-service-content .owl-dots .owl-dot.active' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		// arrow
		$this->add_control( 'icon_box_carousel_navigation_arrow_hd',
			[
				'label'     => __( 'Arrows', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_arrow_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_arrow_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_arrow_size',
			[
				'label'      => __( 'Font-Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'icon_box_carousel_navigation_arrow_tab_control',
			[
				'separator' => 'before',
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_carousel_navigation_arrow_normal_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'icon_box_carousel_navigation_arrow_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div' => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'icon_box_carousel_navigation_arrow_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_carousel_navigation_arrow_normal_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#233d63',
					],
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_arrow_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => '%',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'icon_box_carousel_navigation_arrow_normal_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div',
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_arrow_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_arrow_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_carousel_navigation_arrow_hover_tab',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'icon_box_carousel_navigation_arrow_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'icon_box_carousel_navigation_arrow_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div:hover' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'icon_box_carousel_navigation_arrow_hover_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div:hover',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#f66b5d',
					],
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_arrow_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'icon_box_carousel_navigation_arrow_hover_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div:hover',
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_dots_arrow_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->add_responsive_control( 'icon_box_carousel_navigation_arrow_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-service-area .ua-service-content .owl-nav > div:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_carousel_arrows_dots' => ['arrows_dots', 'arrows'],
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* Icon box number and box style controls*/
	private function get_style_icon_box_num_and_box_style_controls() {
		// Number
		$this->start_controls_section( 'icon_box_number_style',
			[
				'label'      => __( 'Number', 'useful-addons-elementor' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'condition'  => [
					'icon_box_hv_number_sh'     => 'yes',
					'icon_box_different_design' => 'normal',
					'icon_box_hover_box_styles' => 'style_1'
				]
			]
		);
		$this->add_control( 'icon_box_number_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(35,61,92,0.3)',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__number' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'icon_box_number_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__number',
				'default'  => [
					'font_weight' => '600',
					'font_family' => 'Barlow',
					'font_size'   => '35px',
					'line_height' => '55px',
				]
			]
		);
		$this->add_responsive_control( 'icon_box_number_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item .ua-feature__number' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->end_controls_section();

		// Box
		$this->start_controls_section( 'icon_box_box_styles',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'normal',
					'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				],
			]
		);
        $this->add_responsive_control('icon_box_box_width',
            [
                'label'      => __( 'Width', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 500,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-feature-box .ua-feature-item' => 'width: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ua-feature-box' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('icon_box_box_height',
            [
                'label'      => __( 'Height', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 500,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-feature-box .ua-feature-item' => 'height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .ua-feature-box' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
		/* Start Tab */
		$this->start_controls_tabs( 'icon_box_box_tab_control',
			[
				'separator' => 'before',
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box_box_normal_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box_box_background',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient'],
				'default'  => '#ffffff',
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item',
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'      => 'icon_box_box_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-feature-box .ua-feature-item',
				'condition' => [
					'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				]
			]
		);
		$this->add_responsive_control( 'icon_box_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '20',
					'right'    => '0',
					'bottom'   => '20',
					'left'     => '0',
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item',
				'fields_options' => [
					'box_shadow_type' => [
						'default' =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82,85,90,0.1)'
						]
					]
				],
				'condition' => [
					'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				]
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box_box_hover_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box_box_hv_background',
				'label'    => __( 'Box Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item:hover',
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'      => 'icon_box_box_border_hv',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-feature-box .ua-feature-item:hover',
				'condition' => [
					'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				]
			]
		);
		$this->add_control('icon_box_box_before_hd',
			[
				'label'     => __( 'Box Before BG', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'icon_box_hover_box_styles' => ['style_1', 'style_2']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'icon_box_box_hv_before_background',
				'label'     => __( 'Box Before BG', 'useful-addons-elementor' ),
				'types'     => [ 'classic', 'gradient'],
				'selector'  => '{{WRAPPER}} .ua-feature-box .ua-feature-item:before',
				'condition' => [
					'icon_box_hover_box_styles' => ['style_1', 'style_2']
				]
			]
		);
		$this->add_responsive_control( 'icon_box_box_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'isLinked' => true
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box_box_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-feature-box .ua-feature-item:hover',
				'condition' => [
					'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				]
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'end_icon_box_box_divider',
			[
				'type' => Controls_Manager::DIVIDER,
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->add_responsive_control( 'icon_box_box_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => 0,
					'right'    => 0,
					'bottom'   => 30,
					'left'     => 0,
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->add_responsive_control( 'icon_box_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => 45,
					'right'    => 30,
					'bottom'   => 40,
					'left'     => 30,
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->add_control( 'icon_box_box_bottom_shape_show_hide',
			[
				'label'        => __( 'Show Box Overlay', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition' => [
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
                ]
			]
		);
		$this->add_control( 'box_shape_heading',
			[
				'label'     => __( 'Box Overlay', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'icon_box_box_bottom_shape_show_hide' => 'yes',
                    'icon_box_hover_box_styles' => ['style_1', 'style_2', 'style_3']
				]
			]
		);
		$this->add_responsive_control( 'icon_box_box_shape',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:after' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_box_bottom_shape_show_hide' => 'yes',
					'icon_box_hover_box_styles'           => 'style_1',
				]
			]
		);
		$this->add_responsive_control( 'icon_box_box_shape_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:after' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_box_bottom_shape_show_hide' => 'yes',
					'icon_box_hover_box_styles'           => 'style_2',
				]
			]
		);
		$this->add_control( 'icon_box_box_shape_bg2',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(59,62,121,0.9)',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:after' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_box_bottom_shape_show_hide' => 'yes',
					'icon_box_hover_box_styles'           => 'style_2'
				]
			]
		);
		$this->add_control( 'icon_box_box_shape_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:after' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_box_bottom_shape_show_hide' => 'yes',
					'icon_box_hover_box_styles'           => 'style_1'
				]
			]
		);
		$this->add_responsive_control( 'icon_box_box_shape_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '4',
					'left'     => '4',
					'isLinked' => true
				],
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box .ua-feature-item:after, {{WRAPPER}} .ua-feature-box.hv_style_2 .ua-feature-item:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'icon_box_box_bottom_shape_show_hide' => 'yes',
					'icon_box_hover_box_styles'           => ['style_1', 'style_2'],
				]
			]
		);
		// shape style 3
		$this->add_control( 'icon_box_box_shape_st3_bg_1',
			[
				'label'     => __( 'Background 1', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(255, 255, 255, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box.ua_show_multi_shape.ua_hv_style_3 .ua-feature-item:before' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_box_bottom_shape_show_hide' => 'yes',
					'icon_box_hover_box_styles'           => 'style_3',
				],
			]
		);
		$this->add_control( 'icon_box_box_shape_st3_bg_2',
			[
				'label'     => __( 'Background 2', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(255, 255, 255, 0.2)',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box.ua_show_multi_shape.ua_hv_style_3 .ua-feature-item .hover-overlay:before' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_box_bottom_shape_show_hide' => 'yes',
					'icon_box_hover_box_styles'           => 'style_3',
				],
			]
		);
		$this->add_control( 'icon_box_box_shape_st3_bg_3',
			[
				'label'     => __( 'Background 2', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(255, 255, 255, 0.3)',
				'selectors' => [
					'{{WRAPPER}} .ua-feature-box.ua_show_multi_shape.ua_hv_style_3 .ua-feature-item .hover-overlay:after' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_box_bottom_shape_show_hide' => 'yes',
					'icon_box_hover_box_styles'           => 'style_3',
				],
			]
		);
		$this->end_controls_section();
	}

	/* Icon box 4 Icon style */
	private function get_icon_box4_icon_style() {
		$this->start_controls_section( 'icon_box4_icon_style',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_icon_dependant' => 'yes',
					'icon_box_different_design' => 'normal',
					'icon_box_hover_box_styles' => 'style_4'
				]
			]
		);
		$this->add_responsive_control( 'icon_box4_icon_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 35,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'icon_box4_icon_tab',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box4_icon_nrml_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box4_icon_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box4_icon_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box4_icon_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon',
			]
		);
		$this->add_control( 'icon_box4_icon_radius',
			[
				'label' => __( 'Border Radius', 'useful-addons-elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'   => [
					'top' => '50',
					'right' => '50',
					'bottom' => '50',
					'left' => '50',
					'unit' => '%',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box4_icon_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon',
				'fields_options' => [
					'box_shadow_type' => [
						'default' =>'yes'
					],
					'box_shadow' => [
						'default' => [
							'horizontal' => 0,
							'vertical' => 0,
							'blur' => 41,
							'spread' => 0,
							'color' => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
			]
		);
		$this->add_control( 'icon_box4_icon_margin',
			[
				'label' => __( 'Margin', 'useful-addons-elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'   => [
					'top' => '0',
					'right' => '0',
					'bottom' => '24',
					'left' => '0',
					'unit' => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'icon_box4_icon_pd',
			[
				'label' => __( 'Padding', 'useful-addons-elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box4_icon_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_box4_icon_color_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3:hover .ua-icon-box3-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box4_icon_bg_hv',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-icon-box3:hover .ua-icon-box3-icon',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box4_icon_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-box3:hover .ua-icon-box3-icon',
			]
		);
		$this->add_control( 'icon_box4_icon_radius_hv',
			[
				'label' => __( 'Border Radius', 'useful-addons-elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3:hover .ua-icon-box3-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box4_icon_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-box3:hover .ua-icon-box3-icon',
			]
		);
		$this->add_control( 'icon_box4_icon_margin_hv',
			[
				'label' => __( 'Margin', 'useful-addons-elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3:hover .ua-icon-box3-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'icon_box4_icon_pd_hv',
			[
				'label' => __( 'Padding', 'useful-addons-elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3:hover .ua-icon-box3-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'icon_box4_icon_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control( 'icon_box4_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 70,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box4_icon_height',
			[
				'label' => __( 'Height', 'useful-addons-elementor' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 70,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		/* Icon shape */
		$this->add_control( 'icon_box4_icon_shape_title',
			[
				'label'     => __( 'Icon\'s Shape', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
                'condition' => [
                    'icon_box_icon_shape_switcher' => 'yes'
                ]
			]
		);
		$this->add_control( 'icon_box4_icon_shape_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon .line-bg' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes'
				]
			]
		);
		$this->add_control( 'icon_box4_icon_shape_bg_hv',
			[
				'label'     => __( 'Hover Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3:hover .ua-icon-box3-icon .line-bg' => 'background: {{VALUE}}',
				],
				'condition' => [
					'icon_box_icon_shape_switcher' => 'yes'
				]
			]
		);
		$this->add_responsive_control( 'icon_box4_icon_shape_rotate',
			[
				'label' => __( 'Rotate', 'useful-addons-elementor' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'deg' ],
				'range' => [
					'px' => [
						'min' => -360,
						'max' => 360,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'deg',
					'size' => 35,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon .line-bg' => 'transform: rotate({{SIZE}}{{UNIT}});',
				],
			]
		);
		$this->add_responsive_control( 'icon_box4_icon_shape_width',
			[
				'label' => __( 'Width', 'useful-addons-elementor' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 20,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon .line-bg' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box4_icon_shape_height',
			[
				'label' => __( 'Height', 'useful-addons-elementor' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 20,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .ua-icon-box3-icon .line-bg' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}
	private function get_icon_box4_title_style() {
		$this->start_controls_section( 'icon_box4_title_style',
			[
				'label'     => __( 'Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'normal',
					'icon_box_hover_box_styles' => 'style_4'
				]
			]
		);
		$this->add_control( 'icon_box4_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 h1' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'icon_box4_title_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3:hover h4' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'icon_box4_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-box3 h1',
			]
		);
		$this->add_control( 'icon_box4_title_pd',
			[
				'label' => __( 'Padding', 'useful-addons-elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'   => [
					'top' => '0',
					'right' => '0',
					'bottom' => '16',
					'left' => '0',
					'unit' => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'icon_box4_title_mg',
			[
				'label' => __( 'Margin', 'useful-addons-elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_icon_box4_content_style() {
		$this->start_controls_section( 'icon_box4_content_style',
			[
				'label'     => __( 'Content', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'normal',
					'icon_box_hover_box_styles' => 'style_4'
				]
			]
		);
		$this->add_control( 'icon_box4_content_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#748494',
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'icon_box4_content_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3:hover p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'icon_box4_content_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-box3 p',
			]
		);
		$this->add_control( 'icon_box4_content_pd',
			[
				'label' => __( 'Padding', 'useful-addons-elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'icon_box4_content_mg',
			[
				'label' => __( 'Margin', 'useful-addons-elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_icon_box4_box_style() {
		$this->start_controls_section( 'icon_box4_box_style',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'icon_box_different_design' => 'normal',
					'icon_box_hover_box_styles' => 'style_4'
				]
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'icon_box4_box_tab',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_box4_box_nrml_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'icon_box4_box_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-icon-box3',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name' => 'icon_box4_box_border',
				'label' => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-box3',
			]
		);
		$this->add_control( 'icon_box4_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top' => '8',
					'right' => '8',
					'bottom' => '8',
					'left' => '8',
					'unit' => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-box3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box4_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-box3',
				'fields_options' => [
					'box_shadow_type' => [
						'default' =>'yes'
					],
					'box_shadow' => [
						'default' => [
							'horizontal' => 0,
							'vertical' => 0,
							'blur' => 41,
							'spread' => 0,
							'color' => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
			]
		);
		$this->add_responsive_control( 'icon_box4_box_translatey',
			[
				'label' => __( 'TranslateY', 'useful-addons-elementor' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => -360,
						'max' => 360,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3' => 'transform: translateY({{SIZE}}{{UNIT}});',
				],
			]
		);
		$this->add_responsive_control( 'icon_box4_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top' => '30',
					'right' => '30',
					'bottom' => '30',
					'left' => '30',
					'unit' => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-box3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box4_box_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-box3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_box4_box_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name' => 'icon_box4_box_bg_hv',
				'label' => __( 'Background', 'useful-addons-elementor' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-icon-box3:hover',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name' => 'icon_box4_box_border_hv',
				'label' => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-box3:hover',
			]
		);
		$this->add_control( 'icon_box4_box_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-box3:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_box4_box_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-box3:hover',
			]
		);
		$this->add_responsive_control( 'icon_box4_box_translatey_hv',
			[
				'label' => __( 'TranslateY', 'useful-addons-elementor' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => -360,
						'max' => 360,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => -2,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3:hover' => 'transform: translateY({{SIZE}}{{UNIT}});',
				],
			]
		);
		$this->add_responsive_control( 'icon_box4_box_padding_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-box3:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box4_box_margin_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-box3:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'icon_box4_box_shape_title',
			[
				'label'     => __( 'Box\'s Shape', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
                'condition' => [
                    'icon_box4_card_box_shape' => 'yes'
                ]
			]
		);
		$this->add_control( 'icon_box4_box_shape_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3bace4',
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3 .info-svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'icon_box4_card_box_shape' => 'yes'
				]
			]
		);
		$this->add_control( 'icon_box4_box_shape_color_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-icon-box3:hover .info-svg' => 'fill: {{VALUE}}',
				],
				'condition' => [
					'icon_box4_card_box_shape' => 'yes'
				]
			]
		);
		$this->add_control( 'icon_box4_box_shape_opacity',
			[
				'label'   => __( 'Opacity', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 1,
				'step'    => 0.1,
				'default' => 0.4,
				'condition' => [
					'icon_box4_card_box_shape' => 'yes'
				]
			]
		);
		$this->end_controls_section();
	}

	protected function _register_controls() {

		$this->get_content_icon_box_content_controls();
		$this->get_content_icon_box_carousel_controls();
		$this->get_style_icon_box_icon_style_controls();
		$this->get_style_icon_box_carousel_icon_style_controls();
		$this->get_style_icon_box_title_and_carousel_title_style_controls();
		$this->get_style_icon_box_desc_and_carousel_desc_style_controls();
		$this->get_style_icon_box_button_style_controls();
		$this->get_style_icon_box_carousel_button_style_controls();
		$this->get_style_icon_box_carousel_box_style_controls();
		$this->get_style_icon_box_carousel_nav_style_controls();
		$this->get_style_icon_box_num_and_box_style_controls();

		/* Icon box 4 */
        $this->get_icon_box4_icon_style();
        $this->get_icon_box4_title_style();
        $this->get_icon_box4_content_style();
        $this->get_icon_box4_box_style();

	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'icon_box_title', 'none' );
		$this->add_inline_editing_attributes( 'icon_box_description', 'none' );

		$this->add_render_attribute( 'icon_box_title', 'class' , 'feature__title');
		$this->add_render_attribute( 'icon_box_description', 'class' , 'feature__desc');

		if($settings['icon_box_hover_box_styles'] == 'style_2') {
			$icon_box_hv_styles = ' hv_style_2';
		} else {
			$icon_box_hv_styles = ' ';
		}
		if($settings['icon_box_hover_box_styles'] == 'style_3') {
			$icon_box_hv_st_3 = ' ua_hv_style_3 ';
		} else {
			$icon_box_hv_st_3 = ' ';
		}

		if($settings['icon_box_different_design'] == 'normal') {
			if($settings['icon_box_box_bottom_shape_show_hide'] == 'yes' && $settings['icon_box_hover_box_styles'] == 'style_3') {
				$icon_box_multi_shape = ' ua_show_multi_shape ';
			} else {
				$icon_box_multi_shape = ' ';
			}
			if($settings['icon_box_hover_box_styles'] === 'style_1' || $settings['icon_box_hover_box_styles'] === 'style_3' || $settings['icon_box_hover_box_styles'] === 'style_2') {
				if($settings['icon_box_hover_box_styles'] == 'style_1') {
					$overflow_inherit = ' overflow-inherit';
				}else {
					$overflow_inherit = '';
				}
			?>
                <div class="ua-feature-box <?php echo esc_attr($icon_box_hv_styles);  echo esc_attr($icon_box_hv_st_3); echo esc_attr($icon_box_multi_shape);?>">
				<?php
				if ( $settings['icon_box_content_alignment'] == '0' ) {
					$icon_box_contents_position = 'text-left justify-content-start';
				} elseif ( $settings['icon_box_content_alignment'] == '1' ) {
					$icon_box_contents_position = 'text-center justify-content-center';
				} elseif ( $settings['icon_box_content_alignment'] == '2' ) {
					$icon_box_contents_position = 'text-right justify-content-end';
				} elseif ( $settings['icon_box_content_alignment'] == '3' ) {
					$icon_box_contents_position = 'text-justify justify-content-between';
				} else {
					$icon_box_contents_position = 'text-center justify-content-center';
				}
				?>
                <div class="ua-feature-item transition-all-3s <?php echo esc_attr( $overflow_inherit ) .' '. esc_attr($icon_box_contents_position); ?>">
					<?php if($settings['icon_box_box_bottom_shape_show_hide'] == 'yes' && $settings['icon_box_hover_box_styles'] == 'style_3') { ?>
                        <div class="hover-overlay"></div>
					<?php } if ( ! empty( $settings['icon_box_hv_number'] ) ) { ?>
                        <span class="ua-feature__number transition-all-3s">
                            <?php echo esc_html($settings['icon_box_hv_number']); ?>
                        </span>
					<?php }
					if ( $settings['icon_box_icon_shape_switcher'] == 'yes' )
					{
						$icon_box_icon_shape = ' ';
					} else {
						$icon_box_icon_shape = 'after_shape';
					}
					if ( $settings['icon_box_icon_dependant'] == 'yes' && $settings['icon_box_hover_box_styles'] !== 'style_3' )
					{
						if (!empty( $settings['icon_box_icon'])) {
							Icons_Manager::render_icon( $settings['icon_box_icon'], ['class' => 'ua-feature__icon ' . $icon_box_icon_shape . '', ' aria-hidden' => 'true' ] );
						}
					}
					if($settings['icon_box_hover_box_styles'] == 'style_3') {
						if (!empty($settings['icon_box_icon'])) {
							?>
                            <div class="ua-feature__icon remove_before_shape">
								<?php if ($settings['icon_box_icon_shape_switcher'] == 'yes') { ?>
                                    <div class="div-strokes">
										<?php if ($settings['icon_box_icon_shape_lines'] == 'three') { ?>
                                            <span class="stroke__bar stroke__one"></span>
                                            <span class="stroke__bar stroke__two"></span>
                                            <span class="stroke__bar stroke__three"></span>
										<?php } elseif ($settings['icon_box_icon_shape_lines'] == 'two') { ?>
                                            <span class="stroke__bar stroke__one"></span>
                                            <span class="stroke__bar stroke__three"></span>
										<?php } else { ?>
                                            <span class="stroke__bar stroke__three"></span>
										<?php } ?>
                                    </div>
									<?php
								}
								Icons_Manager::render_icon( $settings['icon_box_icon'], ['class' => 'ua-feature__icon remove_before_shape ', ' aria-hidden' => 'true' ] );
								?>
                            </div>
							<?php
						}
					}
					if ( !empty( $settings['icon_box_title'] ) ) {
						?>
                        <h1 <?php $this->print_render_attribute_string('icon_box_title') ?>>
							<?php if ($settings['icon_box_titles_url'] == 'yes') {

								echo '
                                <a class="transition-all-3s" href=" ' . esc_url($settings['icon_box_title_url']['url']) . ' " >
                                ' . esc_html($settings['icon_box_title']) . '
                                </a>
                                ';
							} else {
								echo esc_html($settings['icon_box_title']);
							} ?>
                        </h1>
						<?php
					}

					if ( ! empty( $settings['icon_box_description'] ) )
					{
						?>
                        <p <?php $this->print_render_attribute_string( 'icon_box_description' ) ?>>
							<?php echo $settings['icon_box_description']; ?>
                        </p>
					<?php }
					if ( ! empty( $settings['icon_box_button_sh'] == 'yes' ) ) { ?>
						<?php
						if ( $settings['icon_box_button_icon_sh'] == 'yes' && !empty( $settings['icon_box_icon']) )
						{
							?>
                            <a href="<?php echo esc_url($settings['icon_box_button_url']['url']); ?>" class="read__btn transition-all-3s">
								<?php
								    echo esc_html($settings['icon_box_button_text']);
								Icons_Manager::render_icon( $settings['icon_box_button_icon'], ['class' => 'fa__arrow', ' aria-hidden' => 'true' ] )
								?>
                            </a>
							<?php
						} else {
							?>
                            <a href=" <?php echo esc_url($settings['icon_box_button_url']['url']); ?> " class="read__btn transition-all-3s">
								<?php
								    echo esc_html($settings['icon_box_button_text']);
								?>
                            </a>
							<?php
						}
					}
					?>

                </div>
                <!-- end feature-item -->
            </div>
			<?php
            }

            if($settings['icon_box_hover_box_styles'] === 'style_4') {

	            if ( $settings['icon_box4_content_alignment'] == '0' ) {
		            $icon_box_contents_position = 'text-left justify-content-start';
	            } elseif ( $settings['icon_box4_content_alignment'] == '1' ) {
		            $icon_box_contents_position = 'text-center justify-content-center';
	            } elseif ( $settings['icon_box4_content_alignment'] == '2' ) {
		            $icon_box_contents_position = 'text-right justify-content-end';
	            } elseif ( $settings['icon_box4_content_alignment'] == '3' ) {
		            $icon_box_contents_position = 'text-justify justify-content-between';
	            } else {
		            $icon_box_contents_position = 'text-center justify-content-center';
	            }

	            ?>
                <div class="ua-icon-box3 <?php echo esc_attr($icon_box_contents_position); ?>">
                    <?php if($settings['icon_box_icon_dependant'] === 'yes' && !empty($settings['icon_box4_icon'])) { ?>
                    <div class="ua-icon-box3-icon">
                        <?php if($settings['icon_box_icon_shape_switcher'] === 'yes') { ?>
                            <span class="line-bg line-bg-one"></span>
                            <span class="line-bg line-bg-two"></span>
                            <span class="line-bg line-bg-three"></span>
                        <?php }
                        Icons_Manager::render_icon( $settings['icon_box4_icon'], [' aria-hidden' => 'true' ] );
                        ?>
                    </div>
                    <?php }
                    if(!empty($settings['icon_box4_title']) || $settings['icon_box4_content']) { ?>
                        <div class="ua-icon-box3-content">
                            <?php if(!empty($settings['icon_box4_title'])) { ?>
                                <h1>
                                    <?php echo esc_html($settings['icon_box4_title']); ?>
                                </h1>
                            <?php }

                            if(!empty($settings['icon_box4_content'])) { ?>
                                <p>
                                    <?php echo esc_html($settings['icon_box4_content']); ?>
                                </p>
                            <?php } ?>
                        </div>
                    <?php }
                    if($settings['icon_box4_card_box_shape'] === 'yes') { ?>
                        <svg class="info-svg" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 192.5 192.5" xml:space="preserve" data-parent="#SVGheroBGShapes" style="opacity: <?php echo esc_attr($settings['icon_box4_box_shape_opacity']); ?>;">
                            <path opacity=".15" d="M0.5,69.5c0.2,0,0.3,0,0.5,0c37.8,0,68.5-30.7,68.5-68.5c0-0.2,0-0.3,0-0.5h-69V69.5z"></path>
                            <path opacity=".12" d="M0.5,100c0.2,0,0.5,0,0.7,0C55.8,100,100,55.8,100,1.2c0-0.2,0-0.5,0-0.7H0.5V100z"></path>
                            <path opacity=".10" d="M0.5,141c0.3,0,0.7,0,1,0C78.6,141,141,78.6,141,1.5c0-0.3,0-0.7,0-1H0.5V141z"></path>
                        </svg>
                    <?php } ?>
                </div>
            <?php
            }
		}
		if( $settings['icon_box_different_design'] == 'slider' ) {
			$UA_iconcarousel_lists = $this->get_settings_for_display( 'UA_icon_carousel_lists' );

			?>
            <section class="ua-service-area">
                <div class="ua-service-content service-content-slider owl-carousel">
					<?php
					foreach ( $UA_iconcarousel_lists as $index => $UA_iconcarousel_list ) {
						if ( $UA_iconcarousel_list['icon_box_content_alignment'] == '0' ) {
							$icon_box_contents_position = 'text-left justify-content-start';
						} elseif ( $UA_iconcarousel_list['icon_box_content_alignment'] == '1' ) {
							$icon_box_contents_position = 'text-center justify-content-center';
						} elseif ( $UA_iconcarousel_list['icon_box_content_alignment'] == '2' ) {
							$icon_box_contents_position = 'text-right justify-content-end';
						} elseif ( $UA_iconcarousel_list['icon_box_content_alignment'] == '3' ) {
							$icon_box_contents_position = 'text-justify justify-content-between';
						}
						?>
                        <div class="ua-service-item <?php echo esc_attr($icon_box_contents_position);?>">

							<?php
							if (!empty( $UA_iconcarousel_list['icon_box_icon'])) {
								?>
                                <div class="ua-service-icon">
									<?php
									Icons_Manager::render_icon( $UA_iconcarousel_list['icon_box_icon'], ['class' => 'ua-service__icon', ' aria-hidden' => 'true' ] )
									?>
                                </div>
								<?php
							}

							if(!empty( $UA_iconcarousel_list['icon_box_title'])) { ?>

                                <h1 class="ua-service__title">
									<?php if($UA_iconcarousel_list['icon_box_titles_url'] == 'yes') {
										echo '
                                    <a href=" ' . esc_url($UA_iconcarousel_list['icon_box_title_url']['url']) . ' ">
                                    ' . esc_html($UA_iconcarousel_list['icon_box_title']) . '
                                    </a>
                                    ';
									} else {
										echo esc_html($UA_iconcarousel_list['icon_box_title']);
									} ?>
                                </h1>
							<?php } if(!empty( $UA_iconcarousel_list['icon_box_description'])) { ?>
                                <p class="ua-service__desc">
									<?php echo $UA_iconcarousel_list['icon_box_description']; ?>
                                </p>
							<?php } if($UA_iconcarousel_list['icon_box_button_sh2'] == 'yes') { ?>
                                <a href="<?php echo esc_url($UA_iconcarousel_list['icon_box_button_url']['url']) ?>" class="ua-service__btn transition-all-3s">
									<?php echo esc_html($UA_iconcarousel_list['icon_box_button_text']);

									if (
										$UA_iconcarousel_list['icon_box_button_icon_sh'] == 'yes'
									) {
										if (!empty( $UA_iconcarousel_list['icon_box_button_icon'])) {
											Icons_Manager::render_icon( $UA_iconcarousel_list['icon_box_button_icon'], ['class' => 'fa__arrow transition-all-3s ', ' aria-hidden' => 'true' ] );
										}
									} ?>
                                </a>
							<?php } ?>
                        </div><!-- ua-service-item -->
					<?php } ?>
                </div><!-- ua-service-content -->
            </section><!-- ua-service-area -->

            <script>
                jQuery('.service-content-slider').owlCarousel({
                    items: <?php echo $settings['icon_box_carousel_pre_items']; ?>,
                    loop: <?php if($settings['icon_box_carousel_loop_condition'] == 'yes') { ?>true <?php } else { ?> false <?php } ?>,
                    autoplay: <?php if($settings['icon_box_carousel_autoplay_condition'] == 'yes') { ?>true <?php } else { ?> false <?php } ?>,
                    autoHeight: <?php if($settings['icon_box_carousel_autoheight_condition'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                    nav: <?php if($settings['icon_box_carousel_arrows_dots'] == 'arrows' || $settings['icon_box_carousel_arrows_dots'] == 'arrows_dots') { ?>true <?php } else { ?> false <?php } ?>,
					<?php if($settings['icon_box_carousel_arrows_dots'] == 'arrows' || $settings['icon_box_carousel_arrows_dots'] == 'arrows_dots') { ?>
                    navText: ['<?php if ( !empty( $settings['icon_box_carousel_arrow_left_icon']) ) { Icons_Manager::render_icon( $settings['icon_box_carousel_arrow_left_icon'], [ 'aria-hidden' => 'true' ] ); } ?>', '<?php if ( !empty( $settings['icon_box_carousel_arrow_right_icon']) ) { Icons_Manager::render_icon( $settings['icon_box_carousel_arrow_right_icon'], [ 'aria-hidden' => 'true' ] ); } ?>'],
					<?php } ?>
                    dots: <?php if($settings['icon_box_carousel_arrows_dots'] == 'dots' || $settings['icon_box_carousel_arrows_dots'] == 'arrows_dots') { ?>true <?php } else { ?> false <?php } ?>,
                    smartSpeed: <?php echo $settings['icon_box_carousel_animation_spd']; ?>,
                    autoplaySpeed: <?php echo $settings['icon_box_carousel_autopaly_spd']; ?>,
                    margin: <?php echo $settings['icon_box_carousel_margin']; ?>,
                    responsive : {
                        // breakpoint from 0 up
                        0 : {
                            items: 1
                        },
                        // breakpoint from 480 up
                        480 : {
                            items: 1
                        },
                        // breakpoint from 767 up
                        767 : {
                            items: <?php echo $settings['icon_box_carousel_pre_items']; ?>
                        },
                    }
                });
            </script>
		<?php }
	}

	protected function _content_template() {}

}


Plugin::instance()->widgets_manager->register_widget_type( new UA_icon_box() );