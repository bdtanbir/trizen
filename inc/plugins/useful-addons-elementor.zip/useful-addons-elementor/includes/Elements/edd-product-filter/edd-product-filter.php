<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class ua_edd_product_filter extends Widget_Base {
	public function get_name() {
		return 'ua_edd_product_filter';
	}

	public function get_title() {
		return esc_html__( 'EDD Product Filter', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-filter ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA edd product filter layout */
	private function get_edd_pf_layout() {
		$this->start_controls_section( 'ua_edd_product_filter_layout',
			[
				'label' => __( 'Layout', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'ua_edd_pf_item_per_page',
			[
				'label'   => __( 'Item Per Page', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 50,
				'step'    => 1,
				'default' => 6,
			]
		);
		$this->add_control( 'ua_edd_pf_orderby',
			[
				'label'             => __( 'Order By', 'useful-addons-elementor' ),
				'type'              => Controls_Manager::SELECT,
				'default'           => 'date',
				'options'           => [
					'ID'            => 'Post ID',
					'author'        => 'Post Author',
					'title'         => 'Title',
					'date'          => 'Date',
					'modified'      => 'Last Modified Date',
					'parent'        => 'Parent Id',
					'rand'          => 'Random',
					'comment_count' => 'Comment Count',
					'menu_order'    => 'Menu Order',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_order',
			[
				'label'    => __('Order', 'useful-addons-elementor'),
				'type'     => Controls_Manager::SELECT,
				'options'  => [
					'asc'  => 'Ascending',
					'desc' => 'Descending',
				],
				'default'  => 'desc',
			]
		);
		$this->add_control( 'ua_edd_pf_show_excerpt',
			[
				'label'        => __( 'Show Excerpt', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'ua_edd_pf_excerpt_length',
			[
				'label'     => __( 'Excerpt Length', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1,
				'max'       => 100,
				'step'      => 1,
				'default'   => 10,
                'condition' => [
                    'ua_edd_pf_show_excerpt' => 'yes'
                ]
			]
		);

		$this->end_controls_section();
    }
	private function get_edd_pf_navigation_style() {
		$this->start_controls_section( 'ua_edd_pf_navigation_style',
			[
				'label' => __( 'Navigation', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_nav_spc_between',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-nav li + li' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'ua_edd_pf_nav_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_edd_pf_nav_tab_nrml',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'ua_edd_pf_nav_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-nav li' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_nav_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-nav li' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_pf_nav_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-nav li',
			]
		);
		$this->add_control( 'ua_edd_pf_nav_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '30',
					'right'  => '30',
					'bottom' => '30',
					'left'   => '30',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-nav li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_pf_nav_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-nav li',
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_nav_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '7',
					'right'  => '30',
					'bottom' => '7',
					'left'   => '30',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-nav li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_edd_pf_nav_hv_tab',
			[
				'label'     => __( 'Active', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'ua_edd_pf_nav_color_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-nav li.active ' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_nav_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-nav li.active ' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_pf_nav_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-nav li.active',
			]
		);
		$this->add_control( 'ua_edd_pf_nav_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-nav li.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_pf_nav_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-nav li.active',
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_nav_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-nav li.active' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'ua_edd_pf_nav_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'ua_edd_pf_nav_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-nav li',
			]
		);
		$this->end_controls_section();
	}
	private function get_edd_pf_title_style() {
		$this->start_controls_section( 'ua_edd_pf_title_style',
			[
				'label' => __( 'Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'ua_edd_pf_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-title a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_title_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-title a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_pf_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-title',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'ua_edd_pf_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-title',
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '5',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_edd_pf_excerpt_style() {
		$this->start_controls_section( 'ua_edd_pf_excerpt_style',
			[
				'label'     => __( 'Excerpt', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_edd_pf_show_excerpt' => 'yes'
                ]
			]
		);
		$this->add_control( 'ua_edd_pf_excerpt_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#748494',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-cart-content p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_pf_excerpt_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-cart-content p',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'ua_edd_pf_excerpt_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-cart-content p',
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_excerpt_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-cart-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_excerpt_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '16',
					'right'  => '0',
					'bottom' => '24',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-cart-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_edd_pf_price_style() {
		$this->start_controls_section( 'ua_edd_pf_price_style',
			[
				'label'     => __( 'Price', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'ua_edd_pf_price_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-price' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_pf_price_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-price',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'ua_edd_pf_price_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-price',
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_price_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_price_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_edd_pf_meta_style() {
		$this->start_controls_section( 'ua_edd_pf_meta_style',
			[
				'label'     => __( 'Meta', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'ua_edd_pf_meta_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#748494',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-label a, {{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-label' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_meta_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-label a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'ua_edd_pf_meta_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-label',
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_meta_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_meta_spc_between',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-body .ua-edd-product-filter-card-label a + a' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_edd_pf_preview_btn_style() {
		$this->start_controls_section( 'ua_edd_pf_preview_btn_style',
			[
				'label'     => __( 'Preview Button', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'ua_edd_pf_preview_btn_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_edd_pf_preview_btn_tab_nrml',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'ua_edd_pf_preview_btn_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_preview_btn_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'  => 'ua_edd_pf_preview_btn_border',
				'label' => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#3BACE4',
					],
				],
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light',
			]
		);
		$this->add_control( 'ua_edd_pf_preview_btn_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'    => '.25',
                    'right'  => '.25',
                    'bottom' => '.25',
                    'left'   => '.25',
                    'unit'   => 'rem',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_pf_preview_btn_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light',
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_preview_btn_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
					'top'    => '5',
					'right'  => '10',
					'bottom' => '5',
					'left'   => '10',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_preview_btn_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_edd_pf_preview_btn_hv_tab',
			[
				'label'     => __( 'Active', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'ua_edd_pf_preview_btn_clr_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_preview_btn_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'  => 'ua_edd_pf_preview_btn_border_hv',
				'label' => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'transparent',
					],
				],
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light:hover',
			]
		);
		$this->add_control( 'ua_edd_pf_preview_btn_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_pf_preview_btn_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light:hover',
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_preview_btn_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_preview_btn_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'ua_edd_pf_preview_btn_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control( 'ua_edd_pf_preview_btn_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_preview_btn_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'ua_edd_pf_preview_btn_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn > .td-btn-light',
			]
		);
		$this->end_controls_section();
	}
	private function get_edd_pf_cart_btn_style() {
		$this->start_controls_section( 'ua_edd_pf_cart_btn_style',
			[
				'label'     => __( 'Cart Button', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'ua_edd_pf_cart_btn_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_edd_pf_cart_btn_tab_nrml',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'ua_edd_pf_cart_btn_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_cart_btn_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'  => 'ua_edd_pf_cart_btn_border',
				'label' => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#3BACE4',
					],
				],
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart',
			]
		);
		$this->add_control( 'ua_edd_pf_cart_btn_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
					'top'    => '.25',
					'right'  => '.25',
					'bottom' => '.25',
					'left'   => '.25',
					'unit'   => 'rem',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_pf_cart_btn_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart',
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_cart_btn_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
					'top'    => '5',
					'right'  => '10',
					'bottom' => '5',
					'left'   => '10',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_cart_btn_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_edd_pf_cart_btn_hv_tab',
			[
				'label'     => __( 'Active', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'ua_edd_pf_cart_btn_clr_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_cart_btn_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'  => 'ua_edd_pf_cart_btn_border_hv',
				'label' => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'transparent',
					],
				],
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart:hover',
			]
		);
		$this->add_control( 'ua_edd_pf_cart_btn_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_pf_cart_btn_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart:hover',
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_cart_btn_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_edd_pf_cart_btn_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'ua_edd_pf_cart_btn_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control( 'ua_edd_pf_cart_btn_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_cart_btn_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card .ua-edd-product-filter-card-btn .edd_download_purchase_form .edd_purchase_submit_wrapper .edd-add-to-cart' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_edd_pf_cart_box_style() {
		$this->start_controls_section( 'ua_edd_pf_card_box_style',
			[
				'label'     => __( 'Card Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'ua_edd_pf_card_box_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_edd_pf_card_box_tab_nrml',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'ua_edd_pf_card_box_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_pf_card_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card',
			]
		);
		$this->add_control( 'ua_edd_pf_card_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '8',
					'right'  => '8',
					'bottom' => '8',
					'left'   => '8',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_pf_card_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card',
				'fields_options' => [
					'box_shadow_type' => [
						'default' =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
			]
		);
		$this->add_control( 'ua_edd_pf_card_box_translatey',
			[
				'label'      => __( 'TranslateY', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range'  => [
					'px' => [
						'min'  => -360,
						'max'  => 360,
						'step' => 1,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card' => 'transform: translateY({{SIZE}}{{UNIT}});',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_card_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_card_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '30',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_edd_pf_card_box_hv_tab',
			[
				'label'     => __( 'Active', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'ua_edd_pf_card_box_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_pf_card_box_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card:hover',
			]
		);
		$this->add_control( 'ua_edd_pf_card_box_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_pf_card_box_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-product-filter-card:hover',
			]
		);
		$this->add_control( 'ua_edd_pf_card_box_translatey_hv',
			[
				'label'      => __( 'TranslateY', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range' => [
					'px' => [
						'min'  => -360,
						'max'  => 360,
						'step' => 1,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => -2,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-product-filter-card:hover' => 'transform: translateY({{SIZE}}{{UNIT}});',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_card_box_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'ua_edd_pf_card_box_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-product-filter-card:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->end_controls_section();
	}


	protected function _register_controls() {
        $this->get_edd_pf_layout();
        $this->get_edd_pf_navigation_style();
        $this->get_edd_pf_title_style();
        $this->get_edd_pf_excerpt_style();
        $this->get_edd_pf_price_style();
        $this->get_edd_pf_meta_style();
        $this->get_edd_pf_preview_btn_style();
        $this->get_edd_pf_cart_btn_style();
        $this->get_edd_pf_cart_box_style();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();


		$default = [
			'posts_per_page' => $settings['ua_edd_pf_item_per_page'],
			'post_type'      => 'download',
            'orderby'        => $settings['ua_edd_pf_orderby'],
            'order'          => $settings['ua_edd_pf_order'],
		];

		/**
		 * Setup the post arguments.
		 */
		// Post Query
        global $post;
		$post_query = new \WP_Query( $default );

		if($post_query->have_posts()) {
		?>
            <section class="product-area">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ua-edd-product-filter text-center">
	                        <?php
	                        if(!empty( get_terms("download_category"))) {
		                        $terms = get_terms( "download_category" );
		                        $count = count( $terms );

		                        echo '<ul class="ua-edd-product-filter-nav nav-tabs justify-content-center">';
		                        echo '<li data-filter="*" class="active">All</li>';
		                        if ( $count > 0 ) {
			                        foreach ( $terms as $term ) {
				                        $termname = strtolower( $term->name );
				                        $termname = str_replace( ' ', '-', $termname );
				                        echo '
                                        <li data-filter=".' . $termname . '">
                                            ' . $term->name . '
                                        </li>';
			                        }
		                        }
		                        echo "</ul>";
	                        }
	                        ?>
                        </div><!-- ua-edd-product-filter -->
                    </div><!-- col-lg-12 -->
                </div><!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ua-edd-product-filter-list">

	                        <?php if ( $post_query ) :
	                        while ( $post_query->have_posts() ) : $post_query->the_post();

	                        $terms = get_the_terms( $post->ID, 'download_category' );
	                        if ( $terms && ! is_wp_error( $terms ) ) :
		                        $links = array();
		                        foreach ( $terms as $term ) {
			                        $links[] = $term->name;
		                        }
		                        $links = str_replace(' ', '-', $links);
		                        $tax   = join( " ", $links );
	                        else :
		                        $tax = '';
	                        endif;
	                        ?>
                                <div class="ua-edd-product-filter-item col-lg-4 all <?php echo strtolower($tax); ?>">
                                    <div class="ua-edd-product-filter-card">
                                        <?php if(get_the_post_thumbnail()) { ?>
                                            <div class="ua-edd-product-filter-card-img">
                                                <a href="<?php the_permalink(); ?>" class="d-block">
                                                    <?php
                                                        the_post_thumbnail();
                                                    ?>
                                                </a>
                                            </div>
                                        <?php } ?>
                                        <div class="ua-edd-product-filter-card-body">
                                            <?php if(get_the_title()) { ?>
                                                <h5 class="ua-edd-product-filter-card-title">
                                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                </h5>
                                            <?php } if(!empty(get_the_term_list( get_the_ID(), 'download_category' ))) { ?>
                                            <div class="ua-edd-product-filter-card-label">
                                                <i class="la la-tags"></i>
                                                <?php echo get_the_term_list( get_the_ID(), 'download_category' ); ?>
                                            </div>
                                            <?php } if ( has_excerpt() && $settings['ua_edd_pf_show_excerpt'] === 'yes' ) : // Only show custom excerpts not autoexcerpts ?>
                                                <div class="ua-edd-product-filter-cart-content">
                                                    <?php $shortexcerpt = wp_trim_words(get_the_excerpt(), $settings['ua_edd_pf_excerpt_length'],'...'); ?>
                                                    <p class="techydevs-custom-excerpt"><?php echo esc_html($shortexcerpt); ?></p>
                                                </div>
                                            <?php endif; ?>
                                            <div class="ua-edd-product-filter-card-action flex-wrap d-flex align-items-center justify-content-between">
                                                <div class="ua-edd-product-filter-card-price">
                                                    <?php //check if variable price
                                                    $defaultPriceID=edd_get_default_variable_price( get_the_ID() );
                                                    if (edd_has_variable_prices(get_the_ID()) ) {
                                                        $lowp  = edd_get_lowest_price_option( get_the_ID() );
                                                        $highp = edd_get_highest_price_option( get_the_ID() );
                                                        ?>
                                                        <span class="var-price edd_price"><?php echo edd_currency_filter(edd_format_amount($lowp)); ?> - <?php echo edd_currency_filter(edd_format_amount($highp)); ?></span>
                                                    <?php } elseif (edd_is_free_download(get_the_ID()) ) { ?>
                                                        <span class="free-price edd_price"><?php esc_html_e("Free","techydevs"); ?></span>
                                                    <?php } else { ?>
                                                        <span class="norm-price edd_price"><?php edd_price(get_the_ID(),true,$defaultPriceID); ?></span>
                                                    <?php } ?>
                                                </div>
                                                <div class="ua-edd-product-filter-card-btn">
                                                    <?php
                                                    $preview_url = get_post_meta( get_the_ID(), 'techydevs_download_preview_url', true );
                                                    if(!empty($preview_url)) {
                                                    ?>
                                                    <a href="<?php echo esc_url($preview_url); ?>" class="btn td-btn td-btn-light" target="_blank">
                                                        <?php esc_html_e('Preview', 'techydevs'); ?>
                                                    </a>
                                                    <?php } if(!ua_check_if_added_to_cart(get_the_ID())){
                                                        ?>
                                                        <?php
                                                        $purchase_link_args = array(
                                                            'download_id' => get_the_ID(),
                                                            'price'       => false,
                                                            'direct'      => false,
                                                            'style'       => 'plain',
                                                            'class'       => 'la la-shopping-cart icon-cart cart-icon-btn btn  td-btn-light edd-add-to-cart',
                                                            'text'        => '',
                                                        );
                                                        $purchase_link_args = apply_filters( 'edd_rp_purchase_link_args', $purchase_link_args );
                                                        echo  edd_get_purchase_link( $purchase_link_args );
                                                        ?>
                                                    <?php } else { ?>
                                                        <a href="<?php echo edd_get_checkout_uri(); ?>" class="cart-added btn td-btn td-btn-light" ><i class="la la-check"></i></a>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- card -->
                                </div>
	                        <?php endwhile; else: ?>
	                        <?php endif;
	                        wp_reset_query();
	                        ?>

                        </div>
                    </div>
                </div>
            </section>


            <script>
                var $container = jQuery('.ua-edd-product-filter-list');
                $container.isotope({
                    filter: '*',
                    animationOptions: {
                        duration: 750,
                        easing: 'linear',
                        queue: false
                    }
                });

                jQuery('.ua-edd-product-filter-nav li').click(function () {
                    jQuery('.ua-edd-product-filter-nav li').removeClass('active');
                    jQuery(this).addClass('active');

                    var selector = jQuery(this).attr('data-filter');
                    $container.isotope({
                        filter: selector,
                        animationOptions: {
                            duration: 750,
                            easing: 'linear',
                            queue: false
                        }
                    });
                    return false;
                });
            </script>
        <?php
        }

	}

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new ua_edd_product_filter() );