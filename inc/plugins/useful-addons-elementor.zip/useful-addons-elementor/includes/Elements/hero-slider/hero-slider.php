<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_hero_slider extends Widget_Base {
	public function get_name() {
		return 'UA_hero_slider';
	}

	public function get_title() {
		return esc_html__( 'Hero Slider', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-post-slider ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Hero Slider Content Setting */
	private function get_content_hero_slider( ){
		$this->start_controls_section( 'UA_hero_slider_content_setting',
			[
				'label' => __( 'Hero Slider Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new Repeater();
		$repeater->add_control('UA_hero_slider_alignment',
			[
				'label'   => __('Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0' => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
					'3' => [
						'title' => __('Justify', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'default' => '0',
			]
		);
		$repeater->add_control('UA_hero_slider_column',
			[
				'label'   => __( 'Content Width', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-8',
				'options' => [
					'col-lg-1'  => __( 'Column 1', 'useful-addons-elementor' ),
					'col-lg-2'  => __( 'Columns 2', 'useful-addons-elementor' ),
					'col-lg-3'  => __( 'Columns 3', 'useful-addons-elementor' ),
					'col-lg-4'  => __( 'Columns 4', 'useful-addons-elementor' ),
					'col-lg-5'  => __( 'Columns 5', 'useful-addons-elementor' ),
					'col-lg-6'  => __( 'Columns 6', 'useful-addons-elementor' ),
					'col-lg-7'  => __( 'Columns 7', 'useful-addons-elementor' ),
					'col-lg-8'  => __( 'Columns 8', 'useful-addons-elementor' ),
					'col-lg-9'  => __( 'Columns 9', 'useful-addons-elementor' ),
					'col-lg-10' => __( 'Columns 10', 'useful-addons-elementor' ),
					'col-lg-11' => __( 'Columns 11', 'useful-addons-elementor' ),
					'col-lg-12' => __( 'Columns 12', 'useful-addons-elementor' ),
				],
			]
		);
		$repeater->add_control('UA_hero_slider_ofst_column',
			[
				'label'       => __( 'Content Offset Width', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::SELECT,
				'label_block' => true,
				'default'     => 'select-offset-lg',
				'options'     => [
					'select-offset-lg'  => __( 'Select Offset Columns', 'useful-addons-elementor' ),
					'offset-lg-1'       => __( 'Column 1', 'useful-addons-elementor' ),
					'offset-lg-2'       => __( 'Columns 2', 'useful-addons-elementor' ),
					'offset-lg-3'       => __( 'Columns 3', 'useful-addons-elementor' ),
					'offset-lg-4'       => __( 'Columns 4', 'useful-addons-elementor' ),
					'offset-lg-5'       => __( 'Columns 5', 'useful-addons-elementor' ),
					'offset-lg-6'       => __( 'Columns 6', 'useful-addons-elementor' ),
					'offset-lg-7'       => __( 'Columns 7', 'useful-addons-elementor' ),
					'offset-lg-8'       => __( 'Columns 8', 'useful-addons-elementor' ),
					'offset-lg-9'       => __( 'Columns 9', 'useful-addons-elementor' ),
					'offset-lg-10'      => __( 'Columns 10', 'useful-addons-elementor' ),
					'offset-lg-11'      => __( 'Columns 11', 'useful-addons-elementor' ),
					'offset-lg-12'      => __( 'Columns 12', 'useful-addons-elementor' ),
				],
			]
		);
		$repeater->add_control('UA_hero_slider_image',
			[
				'label'   => __( 'Choose Image', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control('UA_hero_slider_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default'     => __( 'We Help People to Run Successful Business.', 'useful-addons-elementor' ),
				'placeholder' => __( 'Enter the title for slider', 'useful-addons-elementor' )
			]
		);
		$repeater->add_control('UA_hero_slider_desc',
			[
				'label'       => __( 'Description', 'useful-addons-elementor' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem veritatis et quasi architecto beatae vitae dicta.', 'useful-addons-elementor' ),
				'placeholder' => __( 'Enter the description for slider', 'useful-addons-elementor' ),
			]
		);
		$repeater->add_control('UA_hero_slider_btns_switcher',
			[
				'label'        => __( 'Show Buttons', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater->add_control('UA_hero_slider_btns_style',
			[
				'label'   => __( 'Button Types', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dual_btn',
				'options' => [
					'single_btn'  => __( 'Single Button', 'useful-addons-elementor' ),
					'dual_btn'    => __( 'Dual Button', 'useful-addons-elementor' ),
				],
				'condition' => [
					'UA_hero_slider_btns_switcher' => 'yes'
				]
			]
		);
		$repeater->add_control('hero_slider_btn1_video',
			[
				'label'        => __( 'Use This Video Button 1', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition' => [
					'UA_hero_slider_btns_switcher' => 'yes'
				]
			]
		);
		$repeater->add_control('UA_hero_slider_btns1_hnd_tx',
			[
				'label'     => __( 'Button 1', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'UA_hero_slider_btns_switcher' => 'yes',
				]
			]
		);
		$repeater->add_control('UA_hero_slider_btn_1_tx',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Let\'s Start Now' , 'useful-addons-elementor' ),
				'placeholder' => __( 'Enter the button 1 text here', 'useful-addons-elementor' ),
				'condition'   => [
					'UA_hero_slider_btns_switcher' => 'yes',
				]
			]
		);
		$repeater->add_control('UA_hero_slider_btn_1_url',
			[
				'label'         => __( 'Button URL', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition' => [
					'UA_hero_slider_btns_switcher' => 'yes',
				]
			]
		);

		$repeater->add_control('UA_hero_slider_btn_1_icon',
			[
				'label'            => __( 'Button Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'UA_hero_slider_btns_switcher' => 'yes',
				]
			]
		);
		/* Button Two */
		$repeater->add_control('UA_hero_slider_btn_2_hnd_tx',
			[
				'label'     => __( 'Button 2', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'UA_hero_slider_btns_switcher' => 'yes',
					'UA_hero_slider_btns_style'    => 'dual_btn'
				]
			]
		);
        $repeater->add_control('hero_slider_btn2_video',
            [
                'label'        => __( 'Use This Video Button', 'useful-addons-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
                'label_off'    => __( 'No', 'useful-addons-elementor' ),
                'return_value' => 'yes',
                'default'      => 'no',
                'condition' => [
                    'UA_hero_slider_btns_switcher' => 'yes'
                ]
            ]
        );
		$repeater->add_control('UA_hero_slider_btn_2_tx',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Learn More' , 'useful-addons-elementor' ),
				'placeholder' => __( 'Enter the button 2 text here', 'useful-addons-elementor' ),
				'condition'   => [
					'UA_hero_slider_btns_switcher' => 'yes',
					'UA_hero_slider_btns_style'    => 'dual_btn'
				]
			]
		);
		$repeater->add_control('UA_hero_slider_btn_2_url',
			[
				'label'         => __( 'Button URL', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition' => [
					'UA_hero_slider_btns_switcher' => 'yes',
					'UA_hero_slider_btns_style'    => 'dual_btn'
				]
			]
		);
		$repeater->add_control('UA_hero_slider_btn_2_icon',
			[
				'label'            => __( 'Button Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'UA_hero_slider_btns_switcher' => 'yes',
					'UA_hero_slider_btns_style'    => 'dual_btn'
				]
			]
		);
		$this->add_control( 'UA_hero_slider_items',
			[
				'label'   => __( 'Slider Items', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[
						'UA_hero_slider_title' => __( 'We Help People to Run Successful Business.', 'useful-addons-elementor' ),
						'UA_hero_slider_desc'  => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem veritatis et quasi architecto beatae vitae dicta.', 'useful-addons-elementor' ),
						'UA_hero_slider_btn_1_tx'  => __("Let's Start Now", "useful-addons-elementor"),
						'UA_hero_slider_btn_2_tx'  => __("Learn More", "useful-addons-elementor"),
						'UA_hero_slider_alignment' => '0'
					],
					[
						'UA_hero_slider_title' => __( 'We Take Extra Care of Your Business.', 'useful-addons-elementor' ),
						'UA_hero_slider_desc'  => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem veritatis et quasi architecto beatae vitae dicta.', 'useful-addons-elementor' ),
						'UA_hero_slider_btn_1_tx'  => __("Get Started", "useful-addons-elementor"),
						'UA_hero_slider_btn_2_tx'  => __("Learn More", "useful-addons-elementor"),
						'UA_hero_slider_alignment' => '0'
					],
					[
						'UA_hero_slider_title' => __( 'Smart and effective Solutions for Business.', 'useful-addons-elementor' ),
						'UA_hero_slider_desc'  => __( 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem veritatis et quasi architecto beatae vitae dicta.', 'useful-addons-elementor' ),
						'UA_hero_slider_btn_1_tx'  => __("Let's Start Now", "useful-addons-elementor"),
						'UA_hero_slider_btn_2_tx'  => __("Learn More", "useful-addons-elementor"),
						'UA_hero_slider_alignment' => '1'
					],
				],
				'title_field' => '{{{ UA_hero_slider_title }}}',
			]
		);
		$this->end_controls_section();
	}
	/* UA Hero Slider Query Setting */
	private function get_query_hero_slider( ){
		$this->start_controls_section( 'UA_hero_slider_query_setting',
			[
				'label' => __( 'Hero Slider Control', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control('UA_hero_slider_show_number',
			[
				'label'   => __( 'Slide To Show', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 10,
				'step'    => 1,
				'default' => 1,
			]
		);
		$this->add_control('UA_hero_slider_infinite_loop',
			[
				'label'        => __( 'Infinite Loop', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control('UA_hero_slider_autoplay',
			[
				'label'        => __( 'Autoplay', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control('UA_hero_slider_autop_spd',
			[
				'label'     => __( 'Autoplay Speed', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 50,
				'max'       => 50000,
				'step'      => 50,
				'default'   => 500,
				'condition' => [
					'UA_hero_slider_autoplay' => 'yes'
				]
			]
		);
		$this->add_control('UA_hero_slider_autoheight',
			[
				'label'        => __( 'AutoHeight', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control('UA_hero_slider_navigation',
			[
				'label'   => __( 'Navigation', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'arrow',
				'options' => [
					'arrow_dots'  => __( 'Arrow and Dots', 'useful-addons-elementor' ),
					'arrow'       => __( 'Arrow', 'useful-addons-elementor' ),
					'dots'        => __( 'Dots', 'useful-addons-elementor' ),
					'none'        => __( 'None', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control('ua_hero_slider_arw_styles',
			[
				'label'   => __('Arrow Styles', 'useful-addons-elementor'),
				'type'    => Controls_Manager::SELECT,
				'default' => 'st1',
				'options' => [
					'st1' => __('Style 1', 'useful-addons-elementor'),
					'st2' => __('Style 2', 'useful-addons-elementor'),
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('UA_hero_slider_prev_icon',
			[
				'label'            => __( 'Prev Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-left',
					'library' => 'solid',
				],
				'recommended'  => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);

		$this->add_control('UA_hero_slider_next_icon',
			[
				'label'            => __( 'Next Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended'  => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('ua_hero_slider_animate_in',
			[
				'label'   => __( 'Animate In', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'slideInDown',
				'options' => [
					'fadeIn'       => __( 'Fade In', 'useful-addons-elementor' ),
					'fadeInRight'  => __( 'Fade In Right', 'useful-addons-elementor' ),
					'fadeInLeft'   => __( 'Fade In Left', 'useful-addons-elementor' ),
					'fadeInDown'   => __( 'Fade In Down', 'useful-addons-elementor' ),
					'fadeInUp'     => __( 'Fade In Up', 'useful-addons-elementor' ),
					'slideInLeft'  => __( 'Slide In Left', 'useful-addons-elementor' ),
					'slideInRight' => __( 'Slide In Right', 'useful-addons-elementor' ),
					'slideInUp'    => __( 'Slide In Up', 'useful-addons-elementor' ),
					'slideInDown'  => __( 'Slide In Down', 'useful-addons-elementor' ),
					'zoomIn'       => __( 'Zoom In', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control('ua_hero_slider_animate_out',
			[
				'label'   => __( 'Animate Out', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'fadeOut',
				'options' => [
					'fadeOut'       => __( 'Fade Out', 'useful-addons-elementor' ),
					'fadeOutRight'  => __( 'Fade Out Right', 'useful-addons-elementor' ),
					'fadeOutLeft'   => __( 'Fade Out Left', 'useful-addons-elementor' ),
					'fadeOutDown'   => __( 'Fade Out Down', 'useful-addons-elementor' ),
					'fadeOutUp'     => __( 'Fade Out Up', 'useful-addons-elementor' ),
					'slideOutLeft'  => __( 'Slide Out Left', 'useful-addons-elementor' ),
					'slideOutRight' => __( 'Slide Out Right', 'useful-addons-elementor' ),
					'slideOutUp'    => __( 'Slide Out Up', 'useful-addons-elementor' ),
					'slideOutDown'  => __( 'Slide Out Down', 'useful-addons-elementor' ),
					'zoomOut'       => __( 'Zoom Out', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control('UA_hero_slider_animation_spd',
			[
				'label'   => __( 'Animation Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 50,
				'max'     => 50000,
				'step'    => 50,
				'default' => 500,
			]
		);
		$this->add_responsive_control('UA_hero_slider_margin',
			[
				'label'   => __( 'Space Between', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 500,
				'step'    => 1,
				'default' => 10,
			]
		);
		$this->end_controls_section();
	}
	/* UA Hero Slider Title Style */
	private function get_style_hero_slider_title() {
		$this->start_controls_section( 'UA_hero_slider_title_styles',
			[
				'label' => __( 'Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control('UA_hero_slider_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content h1' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_hero_slider_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content h1',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_hero_slider_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content h1',
			]
		);
		$this->add_responsive_control('UA_hero_slider_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '20',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Hero Slider Description Style */
	private function get_style_hero_slider_desc() {
		$this->start_controls_section( 'UA_hero_slider_desc_styles',
			[
				'label' => __( 'Description', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control('UA_hero_slider_desc_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_hero_slider_desc_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content p',
			]
		);
		$this->add_responsive_control('UA_hero_slider_desc_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('add_responsive_control',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '38',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Hero Slider First Button Style */
	private function get_style_hero_slider_first_btn() {
		$this->start_controls_section( 'UA_hero_slider_first_btn_styles',
			[
				'label' => __( 'First Button', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_hero_slider_btn1_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_hero_slider_btn1_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_hero_slider_btn1_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_hero_slider_btn1_nrml_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_nrml_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '4',
					'left'     => '4',
					'unit'     => 'px',
					'isLinked' => true
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_hero_slider_bnt1_nrml_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_hero_slider_btn1_nrml_bshadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_nrml_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_nrml_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'UA_hero_slider_btn1_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_hero_slider_btn1_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_hero_slider_btn1_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_hero_slider_bnt1_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_hero_slider_btn1_hv_bshadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_hv_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control('UA_hero_slider_btn1_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_hero_slider_btn1_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child',
			]
		);
		/* Icon */
		$this->add_control('UA_hero_slider_btn1_icon_heading',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control('ua_hero_slider_btn1_icon_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_hero_slider_btn1_icon_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_hero_slider_btn1_icon_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_hero_slider_btn1_icon_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_hero_slider_btn1_icon_nrml_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child i',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'UA_hero_slider_btn1_icon_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child i',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_icon_nrml_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_icon_nrml_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child i' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_icon_nrml_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child i' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_icon_nrml_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_icon_nrml_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'UA_hero_slider_btn1_icon_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_hero_slider_btn1_icon_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_hero_slider_btn1_icon_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover i',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'UA_hero_slider_btn1_icon_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover i',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_icon_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_icon_hv_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover i' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_icon_hv_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover i' => 'height: {{SIZE}}{{UNIT}};  line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_icon_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn1_icon_hv_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:first-child:hover i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* UA Hero Slider First Button Style */
	private function get_style_hero_slider_snd_btn() {
		$this->start_controls_section( 'UA_hero_slider_snd_btn_styles',
			[
				'label' => __( 'Second Button', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_hero_slider_btn2_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_hero_slider_btn2_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_hero_slider_btn2_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_hero_slider_btn2_nrml_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_nrml_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '4',
					'left'     => '4',
					'unit'     => 'px',
					'isLinked' => true
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_hero_slider_bnt2_nrml_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_hero_slider_btn2_nrml_bshadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_nrml_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_nrml_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'UA_hero_slider_btn2_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_hero_slider_btn2_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_hero_slider_btn2_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_hero_slider_bnt2_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_hero_slider_btn2_hv_bshadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_hv_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control('UA_hero_slider_btn2_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_hero_slider_btn2_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child',
			]
		);
		/* Icon */
		$this->add_control('UA_hero_slider_btn2_icon_heading',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control('ua_hero_slider_btn2_icon_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_hero_slider_btn2_icon_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_hero_slider_btn2_icon_normal',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_hero_slider_btn2_icon_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_hero_slider_btn2_icon_nrml_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child i',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'UA_hero_slider_btn2_icon_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child i',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_icon_nrml_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_icon_nrml_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child i' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_icon_nrml_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child i' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_icon_nrml_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_icon_nrml_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'UA_hero_slider_btn2_icon_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_hero_slider_btn2_icon_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_hero_slider_btn2_icon_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover i',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'UA_hero_slider_btn2_icon_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover i',
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_icon_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_icon_hv_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover i' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_icon_hv_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover i' => 'height: {{SIZE}}{{UNIT}};  line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_icon_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_btn2_icon_hv_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider .UA-hero-slider-content .UA-hero-slider-buttons .theme-button:last-child:hover i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* UA Hero Slider Navigation Style */
	private function get_style_hero_slider_navigations() {
		$this->start_controls_section( 'UA_hero_slider_navigation_styles',
			[
				'label'     => __( 'Navigation', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow', 'dots']
				]
			]
		);
		/* Arrow */
		$this->add_control('ua_hero_slider_nav_arw_hd',
			[
				'label'     => __( 'Arrow', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('ua_hero_slider_nav_arw_alignment',
			[
				'label'   => __('Arrow Position', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0' => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'eicon-h-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'eicon-h-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'eicon-h-align-right',
					]
				],
				'default'   => '2',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_nav_arw_bx_pd',
			[
				'label'      => __( 'Box Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '50',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'ua_hero_slider_nav_arw_alignment' => '0',
					'UA_hero_slider_navigation'        => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_nav_arw_bx_pd2',
			[
				'label'      => __( 'Box Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'ua_hero_slider_nav_arw_alignment' => '1',
					'UA_hero_slider_navigation'        => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_nav_arw_bx_pd3',
			[
				'label'      => __( 'Box Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '50',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'ua_hero_slider_nav_arw_alignment' => '2',
					'UA_hero_slider_navigation'        => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_nav_arw_bx_mg',
			[
				'label'      => __( 'Box Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_hero_slider_nav_arw_tabs',
			[
				'separator' => 'before',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_hero_slider_arw_normal',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_nrml_size',
			[
				'label'      => __( 'Font-size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 18,
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('ua_hero_slider_arw_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div' => 'color: {{VALUE}}',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'ua_hero_slider_arw_nrml_bg',
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'ua_hero_slider_arw_nrml_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_nrml_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow'],
					'ua_hero_slider_arw_styles' => 'st1'
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_nrml_radius2',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '15',
					'right'    => '0',
					'bottom'   => '15',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div, {{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow'],
					'ua_hero_slider_arw_styles' => 'st2'
				]
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'ua_hero_slider_arw_nrml_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_nrml_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_nrml_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_nrml_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_nrml_spc_between',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div:last-child' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'UA_hero_slider_arw_hover',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_hv_size',
			[
				'label'      => __( 'Font-size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div:hover' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('ua_hero_slider_arw_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'ua_hero_slider_arw_hv_bg',
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div:hover',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'ua_hero_slider_arw_hv_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div:hover',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'ua_hero_slider_arw_hv_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div:hover',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_hv_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div:hover' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_hv_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div:hover' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_arw_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-nav > div:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab

		/* Dots */
		$this->add_control('ua_hero_slider_nav_dts_hd',
			[
				'label'     => __( 'Dots', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_control('ua_hero_slider_nav_dts_alignment',
			[
				'label'   => __('Dots Position', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0' => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'eicon-h-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'eicon-h-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'eicon-h-align-right',
					]
				],
				'default'   => '1',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_dts_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elemnetor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '50',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper.nav-dots-right .owl-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation'        => ['arrow_dots', 'dots'],
					'ua_hero_slider_nav_dts_alignment' => '0'
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_dts_box_pd2',
			[
				'label'      => __( 'Padding', 'useful-addons-elemnetor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper.nav-dots-right .owl-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation'        => ['arrow_dots', 'dots'],
					'ua_hero_slider_nav_dts_alignment' => '1'
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_dts_box_pd3',
			[
				'label'      => __( 'Padding', 'useful-addons-elemnetor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '50',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper.nav-dots-right .owl-dots' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation'        => ['arrow_dots', 'dots'],
					'ua_hero_slider_nav_dts_alignment' => '2'
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_dts_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elemnetor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper.nav-dots-right .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_hero_slider_nav_dts_tabs',
			[
				'separator' => 'before',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_hero_slider_dts_normal',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_control('ua_hero_slider_nav_dts_nrml_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot' => 'background: {{VALUE}}',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_nav_dts_nrml_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_nav_dts_nrml_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'ua_hero_slider_nav_dts_nrml_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_nav_dts_nrml_rd',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'ua_hero_slider_nav_dts_nrml_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'UA_hero_slider_dts_hover',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_control('ua_hero_slider_nav_dts_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot:hover, {{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot.active' => 'background: {{VALUE}}',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_nav_dts_hv_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot:hover, {{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot.active' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_nav_dts_hv_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot:hover, {{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot.active' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'ua_hero_slider_nav_dts_hv_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot:hover, {{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot.active',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_responsive_control('ua_hero_slider_nav_dts_hv_rd',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot:hover, {{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'ua_hero_slider_nav_dts_hv_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot:hover, {{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot.active',
				'condition' => [
					'UA_hero_slider_navigation' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control('ua_hero_slider_nav_dts_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control('ua_hero_slider_nav_dts_space',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots > .owl-dot' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_hero_slider_dot_margin',
			[
				'label'      => __( 'Dot\'s wrapper Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Hero Slider box style */
	private function get_style_hero_slider_box() {
		$this->start_controls_section( 'UA_hero_slider_box_styles',
			[
				'label' => __( 'Box', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control('UA_hero_slider_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_hero_slider_box_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'vh' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 2000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'vh' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'vh',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control('UA_hero_slider_box_overlay_hd',
			[
				'label'     => __( 'Box Overlay', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control('UA_hero_slider_box_overlay_switcher',
			[
				'label'        => __( 'Show Overlay', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'UA_hero_slider_box_overlay_bg',
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .UA-hero-slider-wrapper .UA-hero-slider:before',
				'condition' => [
					'UA_hero_slider_box_overlay_switcher' => 'yes'
				]
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls()  {
		/* UA Hero Slider Content */
		$this->get_content_hero_slider();
		/* UA Hero Slider Query */
		$this->get_query_hero_slider();
		/* UA Hero Slider Title Style */
		$this->get_style_hero_slider_title();
		/* UA Hero Slider Description Style */
		$this->get_style_hero_slider_desc();
		/* UA Hero Slider First Button Style */
		$this->get_style_hero_slider_first_btn();
		/* UA Hero Slider Second Button Style */
		$this->get_style_hero_slider_snd_btn();
		/* UA Hero Slider Navigation Style */
		$this->get_style_hero_slider_navigations();
		/* UA Hero Slider Box Style */
		$this->get_style_hero_slider_box();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();
		$slider_rpt_lists = $this->get_settings_for_display('UA_hero_slider_items');


		/* Navigation Arrow Position */
		if($settings['ua_hero_slider_nav_arw_alignment'] == '0') {
			$arw_position = 'nav-arw-start';
		} elseif($settings['ua_hero_slider_nav_arw_alignment'] == '1') {
			$arw_position = 'nav-arw-center';
		} else {
			$arw_position = 'nav-arw-end';
		}

		/* Navigation Dots position */
		if($settings['ua_hero_slider_nav_dts_alignment'] == '0') {
			$dots_position = 'nav-dots-left';
		} elseif($settings['ua_hero_slider_nav_dts_alignment'] == '1') {
			$dots_position = 'nav-dots-center';
		} elseif($settings['ua_hero_slider_nav_dts_alignment'] == '2') {
			$dots_position = 'nav-dots-right';
		} else {
			$dots_position = 'nav-dots-center';
		}

		/* Arrow Styles */
		if($settings['ua_hero_slider_arw_styles'] == 'st1') {
			$arrow_styles = ' ';
		} else {
			$arrow_styles = 'arrow_position_center';
		}

		?>

        <section class="UA-hero-slider-wrapper <?php echo esc_attr($arw_position); echo ' ' . esc_attr($dots_position); echo ' ' . esc_attr($arrow_styles); ?>">
			<?php foreach ($slider_rpt_lists as $slider_rpt_list) {
				if($slider_rpt_list['UA_hero_slider_alignment'] == '0') {
					$alignment_class = 'text-left';
				} elseif ($slider_rpt_list['UA_hero_slider_alignment'] == '1') {
					$alignment_class = 'text-center';
				} elseif ($slider_rpt_list['UA_hero_slider_alignment'] == '2') {
					$alignment_class = 'text-right';
				} elseif ($slider_rpt_list['UA_hero_slider_alignment'] == '3') {
					$alignment_class = 'text-justify';
				} else {
					$alignment_class = 'text-left';
				}

				/* Button 1*/
				$target_one   = $slider_rpt_list['UA_hero_slider_btn_1_url']['is_external'] ? ' target="_blank"' : '';
				$nofollow_one = $slider_rpt_list['UA_hero_slider_btn_1_url']['nofollow'] ? ' rel="nofollow"' : '';
				/* Button 2 */
				$target_two   = $slider_rpt_list['UA_hero_slider_btn_2_url']['is_external'] ? ' target="_blank"' : '';
				$nofollow_two = $slider_rpt_list['UA_hero_slider_btn_2_url']['nofollow'] ? ' rel="nofollow"' : '';

				if($settings['UA_hero_slider_box_overlay_switcher'] == 'yes') {
					$hero_slider_overlay = ' ';
				} else {
					$hero_slider_overlay = 'hide_slider_overlay';
				}

				if($slider_rpt_list['hero_slider_btn1_video'] === 'yes') {
					$btn1_video_class = ' html5lightbox ';
				} else {
					$btn1_video_class = ' ';
				}

				if($slider_rpt_list['hero_slider_btn2_video'] === 'yes') {
					$btn2_video_class = ' html5lightbox ';
				} else {
					$btn2_video_class = ' ';
				}
				?>

                <div class="UA-hero-slider <?php echo esc_attr($alignment_class); echo ' '. esc_attr($hero_slider_overlay); ?>" <?php if(!empty($slider_rpt_list['UA_hero_slider_image']['url'])) { ?> style="background-image: url(<?php echo esc_url($slider_rpt_list['UA_hero_slider_image']['url']); ?>)" <?php } ?>>
                    <div class="container">
                        <div class="row">
                            <div class="<?php echo esc_attr($slider_rpt_list['UA_hero_slider_column']) . ' '; echo esc_attr($slider_rpt_list['UA_hero_slider_ofst_column']); ?>">
                                <div class="UA-hero-slider-content">
									<?php if(!empty($slider_rpt_list['UA_hero_slider_title'])) { ?>
                                        <h1>
                                            <?php echo $slider_rpt_list['UA_hero_slider_title']; ?>
                                        </h1>
									<?php } if(!empty($slider_rpt_list['UA_hero_slider_desc'])) { ?>
                                        <p>
											<?php echo $slider_rpt_list['UA_hero_slider_desc']; ?>
                                        </p>
									<?php } if($slider_rpt_list['UA_hero_slider_btns_switcher'] == 'yes') { ?>
                                        <div class="UA-hero-slider-buttons">
											<?php if(!empty($slider_rpt_list['UA_hero_slider_btn_1_tx'])) { ?>
                                                <a href="<?php echo esc_url($slider_rpt_list['UA_hero_slider_btn_1_url']['url']); ?>" class="theme-button <?php echo esc_attr($btn1_video_class); ?>" <?php echo esc_attr($target_one) .' '. esc_attr($nofollow_one); ?>>
													<?php echo esc_html($slider_rpt_list['UA_hero_slider_btn_1_tx']);

													if (!empty( $slider_rpt_list['UA_hero_slider_btn_1_icon'])) {
														Icons_Manager::render_icon( $slider_rpt_list['UA_hero_slider_btn_1_icon'], ['class' => 'fa__arrow ', ' aria-hidden' => 'true' ] );
													}
													?>
                                                </a>
											<?php } if($slider_rpt_list['UA_hero_slider_btns_style'] == 'dual_btn' && !empty($slider_rpt_list['UA_hero_slider_btn_2_tx'])) { ?>
                                                <a href="<?php echo esc_url($slider_rpt_list['UA_hero_slider_btn_2_url']['url']); ?>" class="theme-button <?php echo esc_attr($btn2_video_class); ?>" <?php echo esc_attr($target_two) . esc_attr($nofollow_two); ?>>
													<?php echo esc_html($slider_rpt_list['UA_hero_slider_btn_2_tx']);

													if (!empty( $slider_rpt_list['UA_hero_slider_btn_2_icon'])) {
														Icons_Manager::render_icon( $slider_rpt_list['UA_hero_slider_btn_2_icon'], ['class' => 'fa__arrow ', ' aria-hidden' => 'true' ] );
													}
													?>
                                                </a>
											<?php } ?>
                                        </div>
									<?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!--end .UA-hero-slider-->
			<?php } ?>
        </section>


        <script>
            jQuery('.UA-hero-slider-wrapper').owlCarousel({
                items: <?php echo esc_attr($settings['UA_hero_slider_show_number']); ?>,
                loop: <?php if($settings['UA_hero_slider_infinite_loop'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                autoplay: <?php if($settings['UA_hero_slider_autoplay'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                autoHeight: <?php if($settings['UA_hero_slider_autoheight'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                margin: <?php echo esc_attr($settings['UA_hero_slider_margin']); ?>,
                nav: <?php if($settings['UA_hero_slider_navigation'] == 'arrow' || $settings['UA_hero_slider_navigation'] == 'arrow_dots') { ?> true <?php } else { ?> false <?php } ?>,
                navText: ['<?php if (!empty( $settings['UA_hero_slider_prev_icon'])) { Icons_Manager::render_icon( $settings['UA_hero_slider_prev_icon'], [ 'aria-hidden' => 'true' ] ); } ?>', '<?php if (!empty( $settings['UA_hero_slider_next_icon'])) { Icons_Manager::render_icon( $settings['UA_hero_slider_next_icon'], [ 'aria-hidden' => 'true' ] ); } ?>'],
                dots: <?php if($settings['UA_hero_slider_navigation'] == 'dots' || $settings['UA_hero_slider_navigation'] == 'arrow_dots') { ?> true <?php } else { ?> false <?php } ?>,
                animateOut: '<?php echo esc_attr($settings['ua_hero_slider_animate_out']); ?>',
                animateIn: '<?php echo esc_attr($settings['ua_hero_slider_animate_in']); ?>',
				<?php if($settings['UA_hero_slider_autoplay'] == 'yes') { ?>
                autoplaySpeed: <?php echo esc_attr($settings['UA_hero_slider_autop_spd']); ?>,
				<?php } ?>
                smartSpeed: <?php echo esc_attr($settings['UA_hero_slider_animation_spd']); ?>,
                responsive: {
                    // breakpoint from 0 up
                    0: {
                        items: 1
                    },
                    // breakpoint from 480 up
                    480: {
                        items: 1
                    },
                    // breakpoint from 768 up
                    767: {
                        items: <?php echo esc_attr($settings['UA_hero_slider_show_number']); ?>,
                    }
                }
            });
        </script>

		<?php

	}

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_hero_slider() );