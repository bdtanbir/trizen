<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class ua_edd_slider extends Widget_Base {
	public function get_name() {
		return 'ua_edd_slider';
	}

	public function get_title() {
		return esc_html__( 'EDD Slider', 'useful-addons-elementor' );
	}
	public function get_icon() {
		return 'eicon-post-slider ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA EDD Slider Content Setting */
	private function get_content_edd_slider() {
		$this->start_controls_section('ua_edd_slider_setting',
			[
				'label' => __( 'Slider Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control('ua_edd_slider_shortcode',
			[
				'label'       => __( 'EDD Shortcode', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => '[downloads columns=1]',
				'placeholder' => __( '[shortcode columns=2]', 'useful-addons-elementor' ),
				'description' => __('Paste here EDD shortcode', 'useful-addons-elementor')
			]
		);

		$this->end_controls_section();
	}
	/* UA EDD Slider Control Setting */
	private function get_edd_slider_control() {
		$this->start_controls_section('ua_edd_slider_ctrl',
			[
				'label' => __( 'Slider Control', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control('ua_edd_slider_slide_show',
			[
				'label'   => __( 'Slide To Show', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 10,
				'step'    => 1,
				'default' => 3,
			]
		);
		$this->add_control('ua_edd_slider_infinite_loop',
			[
				'label'         => __( 'Infinite Loop', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::SWITCHER,
				'label_on'      => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'     => __( 'No', 'useful-addons-elementor' ),
				'return_value'  => 'yes',
				'default'       => 'yes',
			]
		);
		$this->add_control('ua_edd_slider_aplay',
			[
				'label'         => __( 'Autoplay', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::SWITCHER,
				'label_on'      => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'     => __( 'No', 'useful-addons-elementor' ),
				'return_value'  => 'yes',
				'default'       => 'yes',
			]
		);
		$this->add_control('ua_edd_slider_apspeed',
			[
				'label'     => __( 'Autoplay Speed', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 50,
				'max'       => 50000,
				'step'      => 50,
				'default'   => 500,
				'condition' => [
					'ua_edd_slider_aplay' => 'yes'
				]
			]
		);
		$this->add_control('ua_edd_slider_aheight',
			[
				'label'         => __( 'AutoHeight', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::SWITCHER,
				'label_on'      => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'     => __( 'No', 'useful-addons-elementor' ),
				'return_value'  => 'yes',
				'default'       => 'yes',
			]
		);
		$this->add_control('ua_edd_slider_navigations',
			[
				'label'   => __( 'Navigation', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dots',
				'options' => [
					'arrow_dots'  => __( 'Arrow and Dots', 'useful-addons-elementor' ),
					'arrow'       => __( 'Arrow', 'useful-addons-elementor' ),
					'dots'        => __( 'Dots', 'useful-addons-elementor' ),
					'none'        => __( 'None', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control('ua_edd_slider_arw_prev',
			[
				'label'            => __( 'Prev Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-left',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);

		$this->add_control('ua_edd_slider_arw_next',
			[
				'label'            => __( 'Next Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);

		$this->add_control('ua_edd_slider_animation_spd',
			[
				'label'   => __( 'Animation Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 50,
				'max'     => 50000,
				'step'    => 50,
				'default' => 500,
			]
		);
		$this->add_control('ua_edd_slider_spc',
			[
				'label'   => __( 'Space Between', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 100,
				'step'    => 1,
				'default' => 0,
			]
		);
		$this->end_controls_section();
	}
	/* UA EDD Slider Image Style */
	private function get_style_edd_slider_image() {
		$this->start_controls_section('ua_edd_slider_img_style',
			[
				'label' => __( 'Image', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control('ua_edd_slider_img_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .thumb a img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_img_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .thumb a img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'ua_edd_slider_img_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_edd_slider_img_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_slider_img_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .thumb a img',
			]
		);
		$this->add_responsive_control('ua_edd_slider_img_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .thumb a img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_slider_img_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .thumb a img',
			]
		);
		$this->add_responsive_control('ua_edd_slider_img_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .thumb a img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_img_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .thumb a img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_edd_slider_img_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_slider_img_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover .thumb a img',
			]
		);
		$this->add_responsive_control('ua_edd_slider_img_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover .thumb a img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_slider_img_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover .thumb a img',
			]
		);
		$this->add_responsive_control('ua_edd_slider_img_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover .thumb a img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_img_hv_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover .thumb a img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* UA EDD Slider title style */
	private function get_style_edd_slide_title() {
		$this->start_controls_section('ua_edd_slider_title_style',
			[
				'label' => __( 'Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control('ua_edd_slider_title_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-name a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('ua_edd_slider_title_hv_color',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffd400',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-name a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'ua_edd_slider_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-name',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_slider_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-name',
			]
		);
		$this->add_responsive_control('ua_edd_slider_title_pd',
			[
				'label'        => __( 'Padding', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::DIMENSIONS,
				'size_units'   => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '10',
					'right'    => '0',
					'bottom'   => '5',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'    => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA EDD Slider Price Style */
	private function get_style_edd_slider_price() {
		$this->start_controls_section('ua_edd_slider_price_style',
			[
				'label' => __( 'Price', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control('ua_edd_slider_price_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9c9c9c',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-price' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'ua_edd_slider_price_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-price',
			]
		);
		$this->add_responsive_control('ua_edd_slider_price_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_price_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA EDD Slider Price Style */
	private function get_style_edd_slider_meta() {
		$this->start_controls_section('ua_edd_slider_meta_style',
			[
				'label' => __( 'Meta', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control('ua_edd_slider_meta_icon_dpd',
			[
				'label'        => __( 'Show Meta Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control('ua_edd_slider_meta_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9c9c9c',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-author' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('ua_edd_slider_meta_hv_clr',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffd400',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-author a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'ua_edd_slider_meta_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-author',
			]
		);
		$this->add_responsive_control('ua_edd_slider_meta_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-author a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_meta_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .product-author a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'ua_edd_slider_bx_border',
				'label'     => __( 'Box Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom',
			]
		);
		$this->add_responsive_control('ua_edd_slider_meta_bx_pd',
			[
				'label'        => __( 'Box Padding', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::DIMENSIONS,
				'size_units'   => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '15',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'    => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_meta_bx_mg',
			[
				'label'        => __( 'Box Margin', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::DIMENSIONS,
				'size_units'   => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '20',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'    => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA EDD Slider Buttons Style */
	private function get_style_edd_slider_btns() {
		$this->start_controls_section('ua_edd_slider_btns_style',
			[
				'label' => __( 'Buttons', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		// start tab
		$this->start_controls_tabs( 'ua_edd_slider_btns_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_edd_slider_btns_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('ua_edd_slider_btns_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9c9c9c',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('ua_edd_slider_btns_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_slider_btns_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a',
			]
		);
		$this->add_responsive_control('ua_edd_slider_btns_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_slider_btns_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a',
			]
		);
		$this->add_responsive_control('ua_edd_slider_btns_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_btns_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_edd_slider_btns_nv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('ua_edd_slider_btns_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffd400',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('ua_edd_slider_btns_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_slider_btns_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a:hover',
			]
		);
		$this->add_responsive_control('ua_edd_slider_btns_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_slider_btns_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a:hover',
			]
		);
		$this->add_responsive_control('ua_edd_slider_btns_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_btns_hv_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control('ua_edd_slider_btns_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control('ua_edd_slider_btns_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'unit'  => 'px',
					'size'  => '14'
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_btns_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_btns_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner .product-details .details-bottom .product-options a' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA EDD Slider Navigation Style */
	private function get_style_edd_slider_nav() {
		$this->start_controls_section('ua_edd_slider_nav_style',
			[
				'label'     => __( 'Navigation', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow', 'dots']
				]
			]
		);
		/* Arrow */
		$this->add_control('ua_edd_slider_nav_arw_hd',
			[
				'label'     => __( 'Arrow', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_edd_slider_arw_size',
			[
				'label'      => __( 'Font Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('ua_edd_slider_arw_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('ua_edd_slider_arw_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		// start tab
		$this->start_controls_tabs( 'ua_edd_slider_arw_tab',
			[
				'separator' => 'before',
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_edd_slider_arw_nrml_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('ua_edd_slider_arw_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#6b6b6b',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div' => 'color: {{VALUE}}',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('ua_edd_slider_arw_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div' => 'background: {{VALUE}}',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'ua_edd_slider_arw_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div',
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_edd_slider_arw_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'ua_edd_slider_arw_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div',
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_edd_slider_arw_hv_tab',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('ua_edd_slider_arw_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_control('ua_edd_slider_arw_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffd400',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div:hover' => 'background: {{VALUE}}',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'ua_edd_slider_arw_hv_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div:hover',
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_responsive_control('ua_edd_slider_arw_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'ua_edd_slider_arw_hv_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-nav div:hover',
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'arrow']
				]
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab


		/* Dots */
		$this->add_control('ua_edd_slider_nav__hd',
			[
				'label'     => __( 'Dots', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_responsive_control('ua_edd_slider_dts_bx_margin',
			[
				'label'        => __( 'Margin', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::DIMENSIONS,
				'size_units'   => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '10',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'    => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control('ua_edd_slider_dts_spc_btw',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot:first-child' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'ua_edd_slider_dts_tab',
			[
				'separator' => 'before',
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'dots']
				]
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_edd_slider_dts_nrml_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_control('ua_edd_slider_dts_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_control('ua_edd_slider_dts_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_control('ua_edd_slider_dts_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0ad2ad',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot' => 'background: {{VALUE}}',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_slider_dts_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot',
			]
		);
		$this->add_responsive_control('ua_edd_slider_dts_radius',
			[
				'label'        => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::DIMENSIONS,
				'size_units'   => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => '%',
					'isLinked' => true
				],
				'selectors'    => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_slider_dts_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot',
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_edd_slider_dts_hv_tab',
			[
				'label'     => __( 'Hover/Active', 'useful-addons-elementor' ),
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_control('ua_edd_slider_dts_hv_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot.active' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_control('ua_edd_slider_dts_hv_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot.active' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_control('ua_edd_slider_dts_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffd400',
				'selectors' => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot.active' => 'background: {{VALUE}}',
				],
				'condition' => [
					'ua_edd_slider_navigations' => ['arrow_dots', 'dots']
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_slider_dts_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot.active',
			]
		);
		$this->add_responsive_control('ua_edd_slider_dts_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_slider_dts_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-edd-slider .edd_downloads_list .owl-dots .owl-dot.active',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* UA EDD Slider Box Style */
	private function get_style_edd_slider_box() {
		$this->start_controls_section('ua_edd_slider_box_style',
			[
				'label' => __( 'Box', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		// start tab
		$this->start_controls_tabs( 'ua_edd_slider_box_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_edd_slider_box_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'ua_edd_slider_box_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_slider_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_slider_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner',
			]
		);
		$this->add_responsive_control('ua_edd_slider_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_box_pd',
			[
				'label'        => __( 'Padding', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::DIMENSIONS,
				'size_units'   => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '15',
					'right'    => '15',
					'bottom'   => '15',
					'left'     => '15',
					'unit'     => 'px',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_box_mg',
			[
				'label'        => __( 'Margin', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::DIMENSIONS,
				'size_units'   => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '10',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_edd_slider_box_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'ua_edd_slider_box_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_edd_slider_box_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_edd_slider_box_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover',
			]
		);
		$this->add_responsive_control('ua_edd_slider_box_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_box_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_edd_slider_box_hv_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-edd-slider .edd_downloads_list .edd_download_inner:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}


	protected function _register_controls()  {
		/* UA EDD Slider Content */
		$this->get_content_edd_slider();
		/* UA EDD Slider Control */
		$this->get_edd_slider_control();
		/* UA EDD Slider Image Style */
		$this->get_style_edd_slider_image();
		/* UA EDD Slider title Style */
		$this->get_style_edd_slide_title();
		/* UA EDD Slider Price Style */
		$this->get_style_edd_slider_price();
		/* UA EDD Slider Meta Style */
		$this->get_style_edd_slider_meta();
		/* UA EDD Slider Buttons Style */
		$this->get_style_edd_slider_btns();
		/* UA EDD Slider Navigation Style */
		$this->get_style_edd_slider_nav();
		/* UA EDD Slider Box Style */
		$this->get_style_edd_slider_box();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();

		/* Meta Icon dependence class */
		if($settings['ua_edd_slider_meta_icon_dpd'] == 'yes') {
			$meta_icon_class = ' ';
		} else {
			$meta_icon_class = 'hide_card_meta_icon';
		}

		?>

        <div class="ua-edd-slider <?php echo esc_attr($meta_icon_class); ?>">
			<?php $edd_shortcode = $settings['ua_edd_slider_shortcode']; ?>
			<?php
			if (!empty($edd_shortcode)) {
				echo do_shortcode("$edd_shortcode");
			}
			?>
        </div>




        <script>
            jQuery('.ua-edd-slider .edd_downloads_list').owlCarousel({
                autoplay: <?php if($settings['ua_edd_slider_aplay'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                loop: <?php if($settings['ua_edd_slider_infinite_loop'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                autoHeight: <?php if($settings['ua_edd_slider_aheight'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                nav: <?php if($settings['ua_edd_slider_navigations'] == 'arrow_dots' || $settings['ua_edd_slider_navigations'] == 'arrow') { ?> true <?php } else { ?> false <?php } ?>,
				<?php
				if($settings['ua_edd_slider_navigations'] == 'arrow_dots' || $settings['ua_edd_slider_navigations'] == 'arrow') {
				?>
                navText: ['<?php if ( !empty( $settings['ua_edd_slider_arw_prev']) ) { Icons_Manager::render_icon( $settings['ua_edd_slider_arw_prev'], [ 'aria-hidden' => 'true' ] ); } ?>', '<?php if ( !empty( $settings['ua_edd_slider_arw_next']) ) { Icons_Manager::render_icon( $settings['ua_edd_slider_arw_next'], [ 'aria-hidden' => 'true' ] ); } ?>'],
				<?php
				} ?>
                dots: <?php if($settings['ua_edd_slider_navigations'] == 'arrow_dots' || $settings['ua_edd_slider_navigations'] == 'dots') { ?> true <?php } else { ?> false <?php } ?>,
				<?php if($settings['ua_edd_slider_aplay'] == 'yes') { ?>
                autoplaySpeed: <?php echo esc_attr($settings['ua_edd_slider_apspeed']); ?>,
				<?php } ?>
                smartSpeed: <?php echo esc_attr($settings['ua_edd_slider_animation_spd']); ?>,
                margin: <?php echo esc_attr($settings['ua_edd_slider_spc']); ?>,
                responsive: {
                    // breakpoint from 0 up
                    0: {
                        items: 1
                    },
                    // breakpoint from 480 up
                    480: {
                        items: 2
                    },
                    // breakpoint from 768 up
                    767: {
                        items: <?php echo esc_attr($settings['ua_edd_slider_slide_show']); ?>,
                    }
                }
            });
        </script>

		<?php

	}

	protected function content_template() { ?>


		<?php
	}
}


Plugin::instance()->widgets_manager->register_widget_type( new ua_edd_slider() );