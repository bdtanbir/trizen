<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_search_form extends Widget_Base {
	public function get_name() {
		return 'UA_search_form';
	}

	public function get_title() {
		return esc_html__( 'Search Form', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-search ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}


	private function get_search_form_content() {
        $this->start_controls_section( 'search_form_contents',
            [
                'label' => __( 'Search Form', 'useful-addons-elementor' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('search_form_input_placeholder_txt',
            [
                'label'       => __( 'Input Placeholder Text', 'useful-addons-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => __( 'What do you want to learn?', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('search_form_search_icon',
            [
                'label'   => __( 'Search Icon', 'text-domain' ),
                'type'    => Controls_Manager::ICONS,
                'default' => [
                    'value'   => 'la la-search',
                    'library' => 'solid',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_search_form_input_style() {
        $this->start_controls_section( 'search_form_input_style',
            [
                'label' => __( 'Input', 'useful-addons-elementor' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        /*
         * TAB START
         * */
        $this->start_controls_tabs(
                'search_form_input_tabs'
        );
        // Normal
        $this->start_controls_tab('search_form_input_tab_nrml',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('search_form_input_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#233d63',
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form input' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('search_form_input_placeholder_color',
            [
                'label'     => __( 'Placeholder Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#233d63',
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form input::placeholder' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('search_form_input_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form input' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'search_form_input_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-search-form input',
            ]
        );
        $this->add_responsive_control('search_form_input_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '5',
                    'right'    => '5',
                    'bottom'   => '5',
                    'left'     => '5',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-search-form input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'search_form_input_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-search-form input',
            ]
        );
        $this->end_controls_tab();
        // Focus
        $this->start_controls_tab('search_form_input_tab_fc',
            [
                'label' => __( 'Focus', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('search_form_input_placeholder_fc_color',
            [
                'label'     => __( 'Placeholder Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form input:focus::placeholder' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('search_form_input_fc_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form input:focus' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'search_form_input_fc_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-search-form input:focus',
            ]
        );
        $this->add_responsive_control('search_form_input_fc_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-search-form input:focus' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'search_form_input_shadow_fc',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-search-form input:focus',
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        /*
         * TAB END
         * */
        $this->add_control('search_form_input_hr',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );
        $this->add_group_control(Group_Control_Typography::get_type(),
            [
                'name'     => 'search_form_input_typography',
                'label'    => __( 'Typography', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-search-form input',
            ]
        );
        $this->add_responsive_control('search_form_input_width',
            [
                'label'      => __( 'Width', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 570,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('search_form_input_height',
            [
                'label'      => __( 'Height', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form input' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('search_form_input_mg',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-search-form' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('search_form_input_pd',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '10',
                    'right'    => '20',
                    'bottom'   => '10',
                    'left'     => '20',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-search-form input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }
    private function get_search_form_btn_style()
    {
        $this->start_controls_section('search_form_btn_style',
            [
                'label' => __('Button', 'useful-addons-elementor'),
                'tab'  => Controls_Manager::TAB_STYLE,
            ]
        );

        /*
         * TAB START
         * */
        $this->start_controls_tabs(
            'search_form_btn_tabs'
        );
        // Normal
        $this->start_controls_tab('search_form_btn_tab_nrml',
            [
                'label' => __('Normal', 'useful-addons-elementor'),
            ]
        );
        $this->add_control('search_form_btn_color',
            [
                'label'     => __('Color', 'useful-addons-elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#233d63',
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form button' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('search_form_btn_bg',
            [
                'label'     => __('Background', 'useful-addons-elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'transparent',
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form button' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'search_form_btn_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-search-form button',
            ]
        );
        $this->add_responsive_control('search_form_btn_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-search-form button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'search_form_btn_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-search-form button',
            ]
        );
        $this->end_controls_tab();
        // Focus
        $this->start_controls_tab('search_form_btn_tab_hv',
            [
                'label' => __('Hover', 'useful-addons-elementor'),
            ]
        );
        $this->add_control('search_form_btn_color_hv',
            [
                'label'     => __('Color', 'useful-addons-elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#51be78',
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form button:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('search_form_btn_bg_hv',
            [
                'label'     => __('Background', 'useful-addons-elementor'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-search-form button:hover' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'search_form_btn_border_hv',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-search-form button:hover',
            ]
        );
        $this->add_responsive_control('search_form_btn_radius_hv',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-search-form button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'search_form_btn_shadow_hv',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-search-form button:hover',
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        /*
         * TAB END
         * */
        $this->add_control('search_form_btn_hr',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );
        $this->add_responsive_control('search_form_btn_pd',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '15',
                    'right'    => '15',
                    'bottom'   => '15',
                    'left'     => '15',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-search-form button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('search_form_btn_mg',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-search-form button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }

	protected function _register_controls() {
		$this->get_search_form_content();
		$this->get_search_form_input_style();
		$this->get_search_form_btn_style();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();

		?>

        <form class="ua-search-form" role="search" method="GET" action="<?php echo esc_url( home_url( '/' ) ); ?>">
            <input
                class="ua-search-form-input"
                type="search"
                name="s"
                placeholder="<?php echo esc_attr($settings['search_form_input_placeholder_txt']); ?>"
                value="<?php echo get_search_query(); ?>">
            <?php if(!empty($settings['search_form_search_icon'])) { ?>
                <button type="submit" class="ua-search-form-input-icon">
                    <?php Icons_Manager::render_icon( $settings['search_form_search_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </button>
            <?php } ?>
        </form>

        <?php

	}

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_search_form() );