<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_default_button extends Widget_Base {
	public function get_name() {
		return 'button';
	}

	public function get_title() {
		return esc_html__( 'Button', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-button ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Button Content Controls */
	private function get_content_button_controls( ){
		$this->start_controls_section( 'UA_button',
			[
				'label' => __( 'Button', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_responsive_control('ua_button_alignment',
			[
				'label'   => __('Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left'      => [
						'title' => __( 'Left', 'useful-addons-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'useful-addons-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'useful-addons-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'prefix_class' => 'elementor%s-align-', //here %s = mobile/tablet/desktop. eg. elementor-{mobile}-align-{value}
				'default'      => '',
			]
		);
		$this->add_control( 'UA_video_button',
			[
				'label'        => __( 'Use This Video Button', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);
		$this->add_control( 'button_text',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Button', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'button_url',
			[
				'label'         => __( 'Button URl', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				],
			]
		);
		$this->add_control( 'UA_button_shape_dependent',
			[
				'label'        => __( 'Show Button\'s Shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);
		$this->add_control( 'button_icon_dependent',
			[
				'label'        => __( 'Show Button\'s Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control('selected_icon',
			[
				'label'            => __( 'Button Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'la la-angle-right',
					'library' => 'recommended',
				],
				'recommended' => [
					'fa-solid' => [
						'play',
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'button_icon_dependent' => 'yes',
				]
			]
		);

		$this->add_control('button_icon_position',
			[
				'label'   => __( 'Icon Position', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default' => __( 'Default', 'useful-addons-elementor' ),
					'top'     => __( 'Top', 'useful-addons-elementor' ),
					'right'   => __( 'Right', 'useful-addons-elementor' ),
					'bottom'  => __( 'Bottom', 'useful-addons-elementor' ),
					'left'    => __( 'Left', 'useful-addons-elementor' ),
				],
				'condition' => [
					'button_icon_dependent' => 'yes',
				]
			]
		);
		$this->add_control( 'button_icon_shape_dependent',
			[
				'label'        => __( 'Show Icon Shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'button_icon_dependent' => 'yes',
				]
			]
		);
		$this->end_controls_section();
	}
	/* UA Button Style Controls */
	private function get_style_button_style( ){
		$this->start_controls_section('UA_button_style',
			[
				'label' => __( 'Button', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		// start tab
		$this->start_controls_tabs('UA_default_button_tags',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab('UA_default_normal_button',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_default_btn_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .theme-button' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_default_btn_normal_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'default'  => '#233d63',
				'types'    => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .theme-button',
			]
		);
		$this->add_responsive_control('UA_default_btn_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '4',
					'left'     => '4',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_btn_normal_border',
				'label'    => esc_html__( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .theme-button'
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_default_btn_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .theme-button',
				'default'  => '0 0 40px rgba(82,85,90,0.1)',
			]
		);
		$this->add_responsive_control('UA_default_btn_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '13',
					'right'    => '40',
					'bottom'   => '13',
					'left'     => '25',
					'isLinked' => false,
				],
				'selectors'    => [
					'{{WRAPPER}} .theme-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_default_btn_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_default_btn_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .theme-button:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_default_btn_hover_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'default'  => '#f66b5d',
				'types'    => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .theme-button:hover',
			]
		);
		$this->add_responsive_control('UA_default_btn_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_btn_hover_border',
				'label'    => esc_html__( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .theme-button:hover'
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_default_btn_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .theme-button:hover',
			]
		);
		$this->add_responsive_control('UA_default_btn_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_default_btn_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'UA_button_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'UA_button_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_button_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .theme-button',
			]
		);
		// button shape
		$this->add_control( 'UA_button_shape_hd',
			[
				'label'     => __( 'Shape', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'UA_button_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_control( 'UA_button_shape_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .theme-button.ua_button_shape_sh:before, .theme-button.ua_button_shape_sh:after' => 'background: {{VALUE}}',
				],
				'condition' => [
					'UA_button_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_control( 'UA_button_shape_opacity',
			[
				'label'      => __( 'Opacity', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1,
						'step' => .1,
					],
				],
				'default'  => [
					'size' => 0.1,
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button.ua_button_shape_sh:hover:before, {{WRAPPER}} .theme-button.ua_button_shape_sh:hover:after' => 'opacity: {{SIZE}};',
				],
				'condition' => [
					'UA_button_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_control( 'UA_button_shape_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 90,
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button.ua_button_shape_sh:before, {{WRAPPER}} .theme-button.ua_button_shape_sh:after' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_button_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_control( 'UA_button_shape_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 120,
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button.ua_button_shape_sh:before, {{WRAPPER}} .theme-button.ua_button_shape_sh:after' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'UA_button_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'UA_button_shape_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => '%',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button.ua_button_shape_sh:before, {{WRAPPER}} .theme-button.ua_button_shape_sh:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_button_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'UA_button_shape_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .theme-button.ua_button_shape_sh:before, {{WRAPPER}} .theme-button.ua_button_shape_sh:after',
				'condition' => [
					'UA_button_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'UA_button_shape_tp_margin',
			[
				'label'      => __( 'Top Shape Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button.ua_button_shape_sh:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'UA_button_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'UA_button_shape_bt_margin',
			[
				'label'      => __( 'Bottom Shape Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button.ua_button_shape_sh:after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'  => [
					'UA_button_shape_dependent' => 'yes',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Button Icon Style Controls */
	private function get_style_button_icon_style( ){
		$this->start_controls_section('UA_button_icon_style',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'button_icon_dependent' => 'yes',
				]
			]
		);
		$this->add_control( 'UA_button_icon_size',
			[
				'label'      => __( 'Font Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button .fa__arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'UA_button_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button .fa__arrow' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'UA_button_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button .fa__arrow' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs(
			'UA_default_icon_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab('UA_normal_icon',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_icon_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .theme-button .fa__arrow, {{WRAPPER}} .theme-button.left .fa__arrow, {{WRAPPER}} .theme-button.top .fa__arrow, {{WRAPPER}} .theme-button.bottom .fa__arrow, {{WRAPPER}} .theme-button.right .fa__arrow' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_icon_normal_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .theme-button .fa__arrow, {{WRAPPER}} .theme-button.left .fa__arrow, {{WRAPPER}} .theme-button.top .fa__arrow, {{WRAPPER}} .theme-button.bottom .fa__arrow, {{WRAPPER}} .theme-button.right .fa__arrow',
			]
		);
		$this->add_responsive_control('UA_button_icon_radius',
			[
				'label'      => __( 'Border radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button .fa__arrow, {{WRAPPER}} .theme-button.top .fa__arrow, {{WRAPPER}} .theme-button.bottom .fa__arrow, {{WRAPPER}} .theme-button.right .fa__arrow, {{WRAPPER}} .theme-button.default .fa__arrow, {{WRAPPER}} .theme-button.left .fa__arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_button_icon_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button .fa__arrow, {{WRAPPER}} .theme-button.top .fa__arrow, {{WRAPPER}} .theme-button.bottom .fa__arrow, {{WRAPPER}} .theme-button.right .fa__arrow, {{WRAPPER}} .theme-button.default .fa__arrow, {{WRAPPER}} .theme-button.left .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_button_icon_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button .fa__arrow, {{WRAPPER}} .theme-button.top .fa__arrow, {{WRAPPER}} .theme-button.bottom .fa__arrow, {{WRAPPER}} .theme-button.right .fa__arrow, {{WRAPPER}} .theme-button.default .fa__arrow, {{WRAPPER}} .theme-button.left .fa__arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'UA_button_icon_shape_normal_more_option',
			[
				'label'     => __( 'Icon\'s Shape Normal', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'button_icon_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'UA_button_icon_shape_bg',
				'label'     => __('Background', 'useful-addons-elementor'),
				'types'     => ['classic','gradient'],
				'selector'  => '{{WRAPPER}} .theme-button .fa__arrow.display_block_shape:after',
				'condition' => [
					'button_icon_shape_dependent' => 'yes',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'UA_icon_hover',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_icon_hover_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .theme-button:hover .fa__arrow, {{WRAPPER}} .theme-button.left:hover .fa__arrow, {{WRAPPER}} .theme-button.top:hover .fa__arrow, {{WRAPPER}} .theme-button.bottom:hover .fa__arrow, {{WRAPPER}} .theme-button.right:hover .fa__arrow' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_icon_hover_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .theme-button:hover .fa__arrow, {{WRAPPER}} .theme-button.left:hover .fa__arrow, {{WRAPPER}} .theme-button.top:hover .fa__arrow, {{WRAPPER}} .theme-button.bottom:hover .fa__arrow, {{WRAPPER}} .theme-button.right:hover .fa__arrow',
			]
		);
		$this->add_responsive_control( 'UA_button_icon_hover_radius',
			[
				'label'      => __( 'Border radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button:hover .fa__arrow, {{WRAPPER}} .theme-button.top:hover .fa__arrow, {{WRAPPER}} .theme-button.bottom:hover .fa__arrow, {{WRAPPER}} .theme-button.right:hover .fa__arrow, {{WRAPPER}} .theme-button.default:hover .fa__arrow, {{WRAPPER}} .theme-button.left:hover .fa__arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_button_icon_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button:hover .fa__arrow, {{WRAPPER}} .theme-button.top:hover .fa__arrow, {{WRAPPER}} .theme-button.bottom:hover .fa__arrow, {{WRAPPER}} .theme-button.right:hover .fa__arrow, {{WRAPPER}} .theme-button.default:hover .fa__arrow, {{WRAPPER}} .theme-button.left:hover .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('UA_button_icon_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button:hover .fa__arrow, {{WRAPPER}} .theme-button.top:hover .fa__arrow, {{WRAPPER}} .theme-button.bottom:hover .fa__arrow, {{WRAPPER}} .theme-button.right:hover .fa__arrow, {{WRAPPER}} .theme-button.default:hover .fa__arrow, {{WRAPPER}} .theme-button.left:hover .fa__arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'UA_button_icon_shape_hv_hd',
			[
				'label'     => __( 'Icon\'s Shape Hover', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'button_icon_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'UA_button_icon_shape_hover_bg',
				'label'     => __('Background', 'useful-addons-elementor'),
				'types'     => ['classic','gradient'],
				'selector'  => '{{WRAPPER}} .theme-button:hover .fa__arrow.display_block_shape:after',
				'condition' => [
					'button_icon_shape_dependent' => 'yes',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab

		// Icon shape
		$this->add_control( 'more_options',
			[
				'label'     => __( 'Icon\'s Shape', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'button_icon_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_control( 'UA_button_icon_shape_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 30,
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button .fa__arrow.display_block_shape:after' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'button_icon_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_control( 'UA_button_icon_shape_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button .fa__arrow.display_block_shape:after' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'button_icon_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'UA_button_icon_shape_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button .fa__arrow.display_block_shape:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'button_icon_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_control( 'UA_button_icon_shape_rotate',
			[
				'label'      => __( 'Rotate', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range'  => [
					'px' => [
						'min'  => -360,
						'max'  => 360,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .theme-button .fa__arrow.display_block_shape:after' => 'transform: rotate({{SIZE}}deg);',
				],
				'condition' => [
					'button_icon_shape_dependent' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'UA_button_icon_shape_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .theme-button .fa__arrow.display_block_shape:after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'button_icon_shape_dependent' => 'yes',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Video Frame Style Controls */
	private function get_style_video_frame( ){
		$this->start_controls_section( 'UA_video_button_style',
			[
				'label'     => __( 'Video Frame', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'UA_video_button' => 'yes',
				]
			]
		);
		$this->add_responsive_control( 'UA_video_frame_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 590,
				],
				'selectors' => [
					'{{WRAPPER}} #html5-lightbox-box' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_video_frame_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 400,
				],
				'selectors' => [
					'{{WRAPPER}} #html5-lightbox-box' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	protected function _register_controls() {

		$this->get_content_button_controls();
		$this->get_style_button_style();
		$this->get_style_button_icon_style();
		$this->get_style_video_frame();

	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();

		$target   = $settings['button_url']['is_external'] ? ' target=_blank' : '';
		$nofollow = $settings['button_url']['nofollow'] ? ' rel=nofollow' : '';


		if($settings['UA_video_button'] == 'yes') {
			$UA_video_btn_class = ' html5lightbox ';
		} else {
			$UA_video_btn_class = '';
		}
		if($settings['button_icon_shape_dependent'] == 'yes') {
			$UA_btn_icon_shape_class = 'display_block_shape';
		} else {
			$UA_btn_icon_shape_class = 'display_none_shape';
		}
		if($settings['UA_button_shape_dependent'] == 'yes') {
			$ua_button_shape_sh = ' ua_button_shape_sh ';
		} else {
			$ua_button_shape_sh = '';
		}

		?>

		<?php if(!empty( $settings['button_text'])) {
			if($settings['button_icon_position'] == 'right' || $settings['button_icon_position'] == 'default') {
				?>
                <a href="<?php echo esc_url($settings['button_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($settings['button_icon_position']) . ' ' . esc_attr($UA_video_btn_class) .' '. esc_attr($ua_button_shape_sh); ?>" 
				<?php if(!empty($settings['UA_video_frame_width']['size'])) { ?> 
					data-width="<?php echo esc_attr($settings['UA_video_frame_width']['size']); ?>" 
					<?php } 
					if(!empty($settings['UA_video_frame_height']['size'])) { ?> 
					data-height="<?php echo esc_attr($settings['UA_video_frame_height']['size']); ?>"
					 <?php } ?>>
					<?php echo esc_html($settings['button_text']); ?>

					<?php
					if($settings['button_icon_dependent'] == 'yes') {
						if (!empty( $settings['selected_icon'])) {
							Icons_Manager::render_icon( $settings['selected_icon'], [ 'class' => 'fa__arrow ' . $UA_btn_icon_shape_class . '',' aria-hidden' => 'true' ] );
						}
					}
					?>
                </a>
			<?php } elseif($settings['button_icon_position'] == 'left') { ?>
                <a href="<?php echo esc_url($settings['button_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($settings['button_icon_position']) . ' ' . esc_attr($UA_video_btn_class) .' '. esc_attr($ua_button_shape_sh); ?>" 
				<?php if(!empty($settings['UA_video_frame_width']['size'])) { ?> 
					data-width="<?php echo esc_attr($settings['UA_video_frame_width']['size']); ?>" 
					<?php } 
					if(!empty($settings['UA_video_frame_height']['size'])) { ?> 
					data-height="<?php echo esc_attr($settings['UA_video_frame_height']['size']); ?>"
					 <?php } ?>>
					<?php
					if($settings['button_icon_dependent'] == 'yes') {
						if (!empty( $settings['selected_icon'])) {
							Icons_Manager::render_icon( $settings['selected_icon'], [ 'class' => 'fa__arrow ' . $UA_btn_icon_shape_class . '',' aria-hidden' => 'true' ] );
						}
					}

					echo esc_html($settings['button_text']); ?>
                </a>
				<?php
			} elseif($settings['button_icon_position'] == 'top') { ?>
                <a href="<?php echo esc_url($settings['button_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($settings['button_icon_position']) .' '. esc_attr($UA_video_btn_class) .' '. esc_attr($ua_button_shape_sh); ?>" 
				<?php if(!empty($settings['UA_video_frame_width']['size'])) { ?> 
					data-width="<?php echo esc_attr($settings['UA_video_frame_width']['size']); ?>" 
					<?php } 
					if(!empty($settings['UA_video_frame_height']['size'])) { ?> 
					data-height="<?php echo esc_attr($settings['UA_video_frame_height']['size']); ?>"
					 <?php } ?>>
					<?php echo esc_html($settings['button_text']);

					if($settings['button_icon_dependent'] == 'yes') {
						if (!empty( $settings['selected_icon'])) {
							Icons_Manager::render_icon( $settings['selected_icon'], [ 'class' => 'fa__arrow ' . $UA_btn_icon_shape_class . '',' aria-hidden' => 'true' ] );
						}
					}
					?>
                </a>
				<?php
			} elseif($settings['button_icon_position'] == 'bottom') { ?>
                <a href="<?php echo esc_url($settings['button_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> class="theme-button <?php echo esc_attr($settings['button_icon_position']) . ' ' . esc_attr($UA_video_btn_class) .' '. esc_attr($ua_button_shape_sh); ?>" 
				
				<?php if(!empty($settings['UA_video_frame_width']['size'])) { ?> 
					data-width="<?php echo esc_attr($settings['UA_video_frame_width']['size']); ?>" 
					<?php } 
					if(!empty($settings['UA_video_frame_height']['size'])) { ?> 
					data-height="<?php echo esc_attr($settings['UA_video_frame_height']['size']); ?>"
					 <?php } ?>>
					<?php echo esc_html($settings['button_text']);

					if($settings['button_icon_dependent'] == 'yes') {
						if (!empty( $settings['selected_icon'])) {
							Icons_Manager::render_icon( $settings['selected_icon'], [ 'class' => 'fa__arrow ' . $UA_btn_icon_shape_class . '',' aria-hidden' => 'true' ] );
						}
					}
					?>
                </a>
				<?php
			} else { ?>
                <a href="<?php echo esc_url($settings['button_url']['url']); ?>" 
				<?php echo esc_attr($target) .' '. esc_attr($nofollow); ?> 
				class="theme-button <?php echo esc_attr($UA_video_btn_class) .' '. esc_attr($ua_button_shape_sh); ?>" 
				<?php if(!empty($settings['UA_video_frame_width']['size'])) { ?> 
					data-width="<?php echo esc_attr($settings['UA_video_frame_width']['size']); ?>" 
					<?php } 
					if(!empty($settings['UA_video_frame_height']['size'])) { ?> 
					data-height="<?php echo esc_attr($settings['UA_video_frame_height']['size']); ?>"
					 <?php } ?>>
					<?php echo esc_html($settings['button_text']);

					if($settings['button_icon_dependent'] == 'yes') {
						if (!empty( $settings['selected_icon'])) {
							Icons_Manager::render_icon( $settings['selected_icon'], [ 'class' => 'fa__arrow ' . $UA_btn_icon_shape_class . '',' aria-hidden' => 'true' ] );
						}
					}
					?>
                </a>
				<?php
			}
		}
		?>

	<?php }

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_default_button() );