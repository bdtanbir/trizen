<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

class UA_search_Hotel extends Widget_Base {
    public function get_name()
    {
        return 'UA_search_Hotel';
    }

    public function get_title()
    {
        return esc_html__('Search Hotel', 'useful-addons-elementor');
    }

    public function get_icon()
    {
        return 'eicon-date ua-addons-icon';
    }

    public function get_categories()
    {
        return ['useful-addons-elementor-category'];
    }


    private function get_search_hotel_content_setting() {
        $this->start_controls_section('sh_content_setting',
            [
                'label' => __('Content', 'useful-addons-elementor'),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
	    $this->add_control( 'sh_hero_title_before',
		    [
			    'label'       => __( 'Hero Title Before', 'useful-addons-elementor' ),
			    'type'        => Controls_Manager::TEXT,
			    'label_block' => true,
			    'default'     => __( 'Amazing', 'useful-addons-elementor' ),
			    'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
			    'condition' => [
				    'show_hero_title' => 'yes'
			    ]
		    ]
	    );

	    $repeater = new Repeater();
	    $repeater->add_control('sh_hero_title', [
		    'label'       => __( 'Title', 'useful-addons-elementor' ),
		    'type'        => Controls_Manager::TEXT,
		    'default'     => __( 'Hotels' , 'useful-addons-elementor' ),
		    'label_block' => true,
	    ]);
	    $this->add_control( 'sh_hero_title_lists',
		    [
			    'label' => __( 'Hero Title List', 'useful-addons-elementor' ),
			    'type' => Controls_Manager::REPEATER,
			    'condition' => [
				    'show_hero_title' => 'yes'
			    ],
			    'fields' => $repeater->get_controls(),
			    'default' => [
				    [
					    'sh_hero_title' => __( 'Hotels', 'useful-addons-elementor' ),
				    ],
				    [
					    'sh_hero_title' => __( 'Fun', 'useful-addons-elementor' ),
				    ],
			    ],
			    'title_field' => '{{{ sh_hero_title }}}',
		    ]
	    );
	    $this->add_control( 'sh_hero_title_after',
		    [
			    'label'       => __( 'Hero Title After', 'useful-addons-elementor' ),
			    'type'        => Controls_Manager::TEXT,
			    'label_block' => true,
			    'default'     => __( 'Waiting for You', 'useful-addons-elementor' ),
			    'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
			    'condition' => [
				    'show_hero_title' => 'yes'
			    ]
		    ]
	    );

	    $this->add_control( 'sh_search_btn_tx',
		    [
			    'label'       => __( 'Search Button', 'useful-addons-elementor' ),
			    'type'        => Controls_Manager::TEXT,
			    'default'     => __( 'Search Now', 'useful-addons-elementor' ),
			    'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),

		    ]
	    );
        $this->end_controls_section();
    }
    private function get_search_hotel_control_setting() {
        $this->start_controls_section('sh_control_setting',
            [
                'label' => __('Controls', 'useful-addons-elementor'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
	    $this->add_control( 'show_hero_title',
		    [
			    'label'        => __( 'Show Hero Title', 'useful-addons-elementor' ),
			    'type'         => Controls_Manager::SWITCHER,
			    'label_on'     => __( 'Show', 'useful-addons-elementor' ),
			    'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
			    'return_value' => 'yes',
			    'default'      => 'yes',
		    ]
	    );
	    $this->add_control( 'show_advanced_search_option',
		    [
			    'label'        => __( 'Show More Search Option', 'useful-addons-elementor' ),
			    'type'         => Controls_Manager::SWITCHER,
			    'label_on'     => __( 'Show', 'useful-addons-elementor' ),
			    'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
			    'return_value' => 'yes',
			    'default'      => 'no',
		    ]
	    );
        $this->end_controls_section();
    }

    /* Styles */
    private function get_search_hotel_title_style() {
	    $this->start_controls_section('sh_title_style',
		    [
			    'label'     => __('Title', 'useful-addons-elementor'),
			    'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_hero_title' => 'yes'
                ]
		    ]
	    );
	    $this->add_control( 'sh_title_clr',
		    [
			    'label'     => __( 'Color', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#0d233e',
			    'selectors' => [
				    '{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-section-title' => 'color: {{VALUE}};',
			    ],
		    ]
	    );
	    $this->add_group_control( Group_Control_Typography::get_type(),
		    [
			    'name'     => 'sh_title_typography',
			    'label'    => __( 'Typography', 'useful-addons-elementor' ),
			    'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-section-title',
		    ]
	    );
	    $this->add_responsive_control( 'sh_title_padding',
		    [
			    'label'      => __( 'Padding', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em', 'rem' ],
			    'default'    => [
                    'top'     => '0',
                    'right'   => '0',
                    'bottom'  => '3',
                    'left'    => '0',
                    'unit'    => 'rem',
                    'isLinked' => false
                ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-section-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'sh_title_margin',
		    [
			    'label'      => __( 'Margin', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->end_controls_section();
    }
	private function get_search_hotel_input_label_style() {
		$this->start_controls_section( 'sh_input_label_style',
			[
				'label'     => __( 'Input Label', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'sh_input_label_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0d233e',
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .input-box label' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'sh_input_label_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .input-box label',
			]
		);
		$this->add_responsive_control( 'sh_input_label_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .input-box label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'sh_input_label_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
					'top'     => '0',
					'right'   => '0',
					'bottom'  => '.5',
					'left'    => '0',
					'unit'    => 'rem',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .input-box label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_search_hotel_input_style() {
		$this->start_controls_section( 'sh_input_style',
			[
				'label' => __( 'Input', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'sh_input_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0d233e',
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-group .dropdown-btn' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-control' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-control::-webkit-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-group .form-icon' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control( 'sh_input_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-group .dropdown-btn' => 'background: {{VALUE}};',
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-control' => 'background: {{VALUE}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'sh_input_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-group .dropdown-btn, {{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-control ',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'sh_input_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'rgba(128, 137, 150, 0.2)',
					],
				],
				'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-group .dropdown-btn, {{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-control',
			]
		);
		$this->add_responsive_control( 'sh_input_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'      => '3',
                    'right'    => '3',
                    'bottom'   => '3',
                    'left'     => '3',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-group .dropdown-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-control' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'sh_input_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'      => '10',
                    'right'    => '20',
                    'bottom'   => '10',
                    'left'     => '40',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-group .dropdown-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-control' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'sh_input_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-group .dropdown-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap .form-control' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_search_hotel_more_opt_style() {
		$this->start_controls_section( 'sh_more_opt_style',
			[
				'label' => __( 'More Option', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_advanced_search_option' => 'yes'
                ]
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'sh_more_opt_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'sh_more_opt_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'sh_more_opt_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0d233e',
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control( 'sh_more_opt_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn' => 'background: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(Group_Control_Border::get_type(),
			[
				'name'     => 'sh_more_opt_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn',
			]
		);
		$this->add_responsive_control( 'sh_more_opt_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'      => '.25',
                    'right'    => '.25',
                    'bottom'   => '.25',
                    'left'     => '.25',
                    'unit'     => 'rem',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab how to change editor tree line color in phpstorm
		$this->start_controls_tab( 'sh_more_opt_hv_tab',
			[
				'label' => __( 'Hover/Active', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'sh_more_opt_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn[aria-expanded="true"]' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control( 'sh_more_opt_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(128, 137, 150, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn:hover' => 'background: {{VALUE}};',
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn[aria-expanded="true"]' => 'background: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(Group_Control_Border::get_type(),
			[
				'name'     => 'sh_more_opt_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn:hover',
			]
		);
		$this->add_responsive_control( 'sh_more_opt_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'sh_more_opt_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'sh_more_opt_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn',
			]
		);
		$this->add_responsive_control( 'sh_more_opt_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'      => '.375',
                    'right'    => '.75',
                    'bottom'   => '.375',
                    'left'     => '.75',
                    'unit'     => 'rem',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-advanced-wrap .ua-theme-advanced-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_search_hotel_search_btn_style() {
		$this->start_controls_section( 'sh_search_btn_style',
			[
				'label' => __( 'Search Button', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'sh_search_btn_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'sh_search_btn_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'sh_search_btn_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control( 'sh_search_btn_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#287dfa',
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn' => 'background: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(Group_Control_Border::get_type(),
			[
				'name'     => 'sh_search_btn_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#287dfa',
					],
				],
				'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn',
			]
		);
		$this->add_responsive_control( 'sh_search_btn_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'      => '4',
                    'right'    => '4',
                    'bottom'   => '4',
                    'left'     => '4',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab how to change editor tree line color in phpstorm
		$this->start_controls_tab( 'sh_search_btn_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'sh_search_btn_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'	=> '#287dfa',
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control( 'sh_search_btn_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn:hover' => 'background: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(Group_Control_Border::get_type(),
			[
				'name'     => 'sh_search_btn_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn:hover',
			]
		);
		$this->add_responsive_control( 'sh_search_btn_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'sh_search_btn_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'sh_search_btn_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn',
			]
		);
		$this->add_responsive_control( 'sh_search_btn_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'	 => [
					'top'	   => '0',
					'right'	   => '20',
					'bottom'   => '0',
					'left'	   => '20',
					'unit'	   => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'sh_search_btn_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-submit-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_search_hotel_form_box_style() {
		$this->start_controls_section( 'sh_form_box_style',
			[
				'label' => __( 'Form Box', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'sh_form_box_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap' => 'background: {{VALUE}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'sh_form_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#eeeeee',
					],
				],
				'selector' => '{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap',
			]
		);
		$this->add_responsive_control( 'sh_form_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'      => '8',
                    'right'    => '8',
                    'bottom'   => '8',
                    'left'     => '8',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'sh_form_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'      => '20',
                    'right'    => '20',
                    'bottom'   => '20',
                    'left'     => '20',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'sh_form_box_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-search-hotel-wrapper .ua-search-hotel-form-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

    protected function _register_controls() {
        $this->get_search_hotel_content_setting();
        $this->get_search_hotel_control_setting();

        $this->get_search_hotel_title_style();
        $this->get_search_hotel_input_label_style();
        $this->get_search_hotel_input_style();
        $this->get_search_hotel_more_opt_style();
		$this->get_search_hotel_search_btn_style();
		$this->get_search_hotel_form_box_style();
    }


    protected function render() {
        $settings = $this->get_settings_for_display();

	    $action_page = get_option('hotel_search_result_page');
        ?>
        <div class="ua-search-hotel-wrapper">
            <?php if($settings['show_hero_title'] == 'yes') { ?>
                <h2 class="ua-search-hotel-section-title cd-headline zoom">
                    <?php echo $settings['sh_hero_title_before']; ?>
                    <span class="cd-words-wrapper">
                        <?php
                        $count = 0;
                        foreach ($settings['sh_hero_title_lists'] as $item) {
	                        $count++;
                            if($count == 1) {
                                $is_visible = 'is-visible';
                            } else {
                                $is_visible = '';
                            }
                        ?>
                            <b class="<?php echo $is_visible; ?>">
                                <?php echo $item['sh_hero_title']; ?>
                            </b>
                        <?php } ?>
                        </span>
                    <?php echo $settings['sh_hero_title_after']; ?>
                </h2>
            <?php } ?>

            <div class="ua-search-hotel-form-wrap hotel-search-form-home hotel-search-form">
                <form method="get" action="<?php echo esc_url(home_url($action_page)); ?>" class="row form align-items-start">
                    <div class="col-lg-4 pr-0">
				        <?php
				        require_once UA_ELEMENTOR_PATH . 'includes/Elements/search-hotel/hotel/location.php'
				        ?>
                    </div>

			        <?php
			        require_once UA_ELEMENTOR_PATH . 'includes/Elements/search-hotel/hotel/date.php'
			        ?>

                    <div class="col-lg-4">
				        <?php
				        require_once UA_ELEMENTOR_PATH . 'includes/Elements/search-hotel/hotel/guest.php'
				        ?>
                    </div>
			        <?php
                    if($settings['show_advanced_search_option'] == 'yes') {
	                    require_once UA_ELEMENTOR_PATH . 'includes/Elements/search-hotel/hotel/advanced.php';
			        } ?>
                    <div class="col-lg-12">
                        <div class="btn-box">
                            <button class="ua-submit-btn btn-search" type="submit">
						        <?php echo esc_html($settings['sh_search_btn_tx']); ?>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <?php

    }

    protected function _content_template()
    {
    }
}


Plugin::instance()->widgets_manager->register_widget_type(new UA_search_Hotel());