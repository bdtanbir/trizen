<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_section_divider extends Widget_Base {
	public function get_name() {
		return 'UA_section_divider';
	}

	public function get_title() {
		return esc_html__( 'Divider', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-divider-shape ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA divider content setting */
	private function get_content_divider_content_controls() {
		$this->start_controls_section( 'UA_divider_setting',
			[
				'label' => __( 'Divider', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'divider_styles',
			[
				'label'   => __( 'Border Style', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style_1',
				'options' => [
					'style_1'  => __( 'Style 1', 'useful-addons-elementor' ),
					'style_2'  => __( 'Style 2', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_responsive_control('ua_divider_alignment',
			[
				'label'   => __('Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left'      => [
						'title' => __( 'Left', 'useful-addons-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'useful-addons-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'useful-addons-elementor' ),
						'icon'  => 'fa fa-align-right',
					]
				],
				'prefix_class' => 'elementor%s-align-', //here %s = mobile/tablet/desktop. eg. elementor-{mobile}-align-{value}
				'default'      => 'center',
				'condition' => [
					'divider_styles' => 'style_2'
				]
			]
		);
		$this->add_control( 'UA_divider_alignment',
			[
				'label'   => __('Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0' => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => '1',
                'condition' => [
                    'divider_styles' => 'style_1'
                ]
			]
		);
		$this->add_control( 'all_divider_lines',
			[
				'label'  => __( 'Divider List', 'useful-addons-elementor' ),
				'type'   => Controls_Manager::REPEATER,
				'fields' => [
					[
						'name'        => 'divider_line',
						'label'       => __( 'Divider Line', 'useful-addons-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'default'     => __( 'Divider 1' , 'useful-addons-elementor' ),
						'label_block' => true,
					]
				],
				'default' => [
					[
						'divider_line' => __( 'Divider #1', 'useful-addons-elementor' ),
					],
					[
						'divider_line' => __( 'Divider #2', 'useful-addons-elementor' ),
					],
					[
						'divider_line' => __( 'Divider #3', 'useful-addons-elementor' ),
					],
				],
				'title_field' => '{{{ divider_line }}}',
				'condition'   => [
					'divider_styles' => 'style_1'
				]
			]
		);
		$this->end_controls_section();
	}
	/* UA divider Style setting */
	private function get_style_divider_style_controls() {
		$this->start_controls_section( 'UA_divider_style',
			[
				'label'     => __( 'Divider Style', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'divider_styles' => 'style_1'
				]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'divider_background',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-divider .ua-divider__dot',
			]
		);
		$this->add_responsive_control( 'divider_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-divider .ua-divider__dot' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'divider_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-divider .ua-divider__dot' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'divider_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '4',
					'left'     => '4',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-divider .ua-divider__dot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'divider_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-divider .ua-divider__dot',
			]
		);
		$this->add_responsive_control( 'divider_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '15',
					'bottom'   => '0',
					'left'     => '15',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-divider .ua-divider__dot' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_divider_style2() {
		$this->start_controls_section( 'ua_divider_style2',
			[
				'label'     => __( 'Divider Style', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'divider_styles' => 'style_2'
				]
			]
		);
		$this->add_control( 'divider_line',
			[
				'label'     => __( 'Line', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
		$this->add_control( 'ua_divider_style2_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(60, 170, 247, 0.2)',
				'selectors' => [
					'{{WRAPPER}} .ua-section-divider' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'ua_divider_style2_line_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 90,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-section-divider' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_divider_style2_line_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 5,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-section-divider' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'ua_divider_style2_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-section-divider',
			]
		);
		$this->add_responsive_control( 'ua_divider_style2_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '30',
                    'right'  => '30',
                    'bottom'   => '30',
                    'left'     =>'30',
                    'unit'     => 'px',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-section-divider' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_divider_style2_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-section-divider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'ua_divider_style2_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-section-divider' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		/* Divider Dot */
		$this->add_control( 'divider_dot',
			[
				'label'     => __( 'Dot', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'divider_dot_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3CAAF7',
				'selectors' => [
					'{{WRAPPER}} .ua-section-divider:after' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'divider_dot_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-section-divider:after' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'divider_dot_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-section-divider:after' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'divider_dot_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-section-divider:after',
			]
		);
		$this->add_responsive_control( 'divider_dot_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '50',
					'right'  => '50',
					'bottom'   => '50',
					'left'     =>'50',
					'unit'     => '%',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-section-divider:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'divider_dot_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-section-divider:after' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
    }

	protected function _register_controls() {
		$this->get_content_divider_content_controls();
        $this->get_style_divider_style_controls();
        $this->get_style_divider_style2();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();


    if( $settings['all_divider_lines']) {

        if( $settings['UA_divider_alignment'] == '0') {

            $ua_divider_alignments = 'text-left justify-content-start';

        } elseif( $settings['UA_divider_alignment'] == '1') {

	        $ua_divider_alignments = 'text-center justify-content-center';

        } elseif( $settings['UA_divider_alignment'] == '2') {

	        $ua_divider_alignments = 'text-right justify-content-end';

        } else {

	        $ua_divider_alignments = 'text-left justify-content-left';

        }

        if($settings['divider_styles'] == 'style_1') {
        ?>
            <section class="ua-divider <?php echo esc_attr($ua_divider_alignments); ?>">
                <?php foreach ( $settings['all_divider_lines'] as $items ) { ?>
                    <span class="ua-divider__dot" title="<?php echo esc_attr($items['divider_line']); ?>"></span>
                <?php } ?>
            </section>

        <?php
            }
    }
        if($settings['divider_styles'] == 'style_2'){
                ?>
                <div class="ua-section-divider"></div>
            <?php
            }
	}

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_section_divider() );