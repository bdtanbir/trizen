<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_testimonial extends Widget_Base {
	public function get_name() {
		return 'UA_testimonial';
	}

	public function get_title() {
		return esc_html__( 'Testimonial', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-testimonial ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Testimonial Content Setting */
	private function get_content_testimonial_contents( ){
		$this->start_controls_section( 'testimonial_content_setting',
			[
				'label' => __( 'Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'testimonial_layout_styles',
			[
				'label'   => __( 'Layout Style', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style_1',
				'options' => [
					'style_1'  => __( 'Style 1', 'useful-addons-elementor' ),
					'style_2'  => __( 'Style 2', 'useful-addons-elementor' ),
					'style_3'  => __( 'Style 3', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control( 'testimonial_content_position_styles',
			[
				'label'   => __( 'Content Position', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'after_author',
				'options' => [
					'before_author' => __( 'Before Author', 'useful-addons-elementor' ),
					'after_author'  => __( 'After Author', 'useful-addons-elementor' ),
				],
                'condition' => [
                    'testimonial_layout_styles' => 'style_2'
                ]
			]
		);
		$this->add_control('testimonial_shape_sh',
			[
				'label'        => __( 'Show Triangle Shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'testimonial_layout_styles' => 'style_1',
				],
			]
		);
		/* Testimonial Lists */
		$repeater = new Repeater();
		$repeater->add_control('testimonial_image',
			[
				'label'   => __( 'Choose Image', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control('testimonial_name_title',
			[
				'label'       => __( 'Name', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Denwel_evil', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type name here', 'useful-addons-elementor' ),
			]
		);
		$repeater->add_control('testimonial_cityname',
			[
				'label'       => __( 'Sub Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'United States', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type Subtitle here', 'useful-addons-elementor' ),
			]
		);
		$repeater->add_control('testimonial_bio',
			[
				'label'       => __( 'Content', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => __( 'Enjoy the diversity of ThePin. Check this numerous demos, made for different purposes. Easy to import & highly customizable. All of the presented elements, layouts & styles can be theme.', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type testimonial content here', 'useful-addons-elementor' ),
			]
		);
		$repeater->add_control('team_quote_icon_sh',
			[
				'name'         => '',
				'label'        => __( 'Show Quote Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater->add_control('testimonial_quote_icon',
			[
				'label'            => __( 'Quote Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-quote-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'quote-right',
						'quote-left',
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'team_quote_icon_sh' => 'yes',
				],
			]
		);
		$repeater->add_control('testimonial_rating_div_hd',
			[
				'label'     => __( 'Rating', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater->add_control('testimonial_rating_scale',
			[
				'label'   => __( 'Rating Scale', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'5'   => '0-5',
					'10'  => '0-10',
				],
				'default' => '5',
			]
		);
		$repeater->add_control('testimonial_rating',
			[
				'label'   => __( 'Rating', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 10,
				'step'    => 0.1,
				'default' => 5,
			]
		);
		$this->add_control( 'testimonial_lists',
			[
				'label'     => __( 'Testimonial List', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::REPEATER,
				'condition' => [
					'testimonial_layout_styles' => 'style_1',
				],
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'testimonial_name_title'   => __( 'Denwel_evil', 'useful-addons-elementor' ),
						'testimonial_cityname'     => 'United states',
						'testimonial_bio'          => 'Enjoy the diversity of ThePin. Check this numerous demos, made for different purposes. Easy to import & highly customizable. All of the presented elements, layouts & styles can be theme.',
						'testimonial_rating_scale' => '5',
						'testimonial_rating'       => '5'
					],
					[
						'testimonial_name_title'   => __( 'Amanda_evil', 'useful-addons-elementor' ),
						'testimonial_cityname'     => 'United states',
						'testimonial_bio'          => 'Enjoy the diversity of ThePin. Check this numerous demos, made for different purposes. Easy to import & highly customizable. All of the presented elements, layouts & styles can be theme.',
						'testimonial_rating_scale' => '5',
						'testimonial_rating'       => '4.5',
					],
					[
						'testimonial_name_title'   => __( 'Shanewel_evil', 'useful-addons-elementor' ),
						'testimonial_cityname'     => 'United states',
						'testimonial_bio'          => 'Enjoy the diversity of ThePin. Check this numerous demos, made for different purposes. Easy to import & highly customizable. All of the presented elements, layouts & styles can be theme.',
						'testimonial_rating_scale' => '5',
						'testimonial_rating'       => '3.7',
					],
				],
				'title_field' => '{{{ testimonial_name_title }}}',
			]
		);

		/* Testimonial List 2 */
		$repeater2 = new Repeater();
		$repeater2->add_control('testimonial_image',
			[
				'label'   => __( 'Choose Image', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater2->add_control('testimonial_name_title',
			[
				'label'       => __( 'Name', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Denwel_evil', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type name here', 'useful-addons-elementor' ),
			]
		);
		$repeater2->add_control('testimonial_cityname',
			[
				'label'       => __( 'Sub Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'United States', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type Subtitle here', 'useful-addons-elementor' ),
			]
		);
		$repeater2->add_control('testimonial_bio',
			[
				'label'       => __( 'Content', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => __( 'This is an awesome package. It is so awesome, that I have also purchased a lifetime developer license. I love the plugin and I love', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type testimonial content here', 'useful-addons-elementor' ),
			]
		);
		$repeater2->add_control('team_quote_icon_sh',
			[
				'label'        => __( 'Show Quote Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater->add_control('testimonial_quote_icon',
			[
				'label'            => __( 'Quote Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-quote-right',
					'library' => 'solid',
				],
				'recommended'  => [
					'fa-solid' => [
						'quote-right',
						'quote-left',
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'team_quote_icon_sh' => 'yes',
				],
			]
		);
		$repeater2->add_control('testimonial_rating_div_hd',
			[
				'label'     => __( 'Rating', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$repeater2->add_control('testimonial_rating_scale',
			[
				'label'   => __( 'Rating Scale', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'5'   => '0-5',
					'10'  => '0-10',
				],
				'default' => '5',
			]
		);
		$repeater2->add_control('testimonial_rating',
			[
				'label'   => __( 'Rating', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 10,
				'step'    => 0.1,
				'default' => 5,
			]
		);
		$this->add_control( 'testimonial_lists2',
			[
				'label'     => __( 'Testimonial List', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::REPEATER,
				'condition' => [
					'testimonial_layout_styles' => 'style_2',
				],
				'fields'    => $repeater2->get_controls(),
				'default'   => [
					[
						'testimonial_name_title'   => __( 'Denwel_evil', 'useful-addons-elementor' ),
						'testimonial_cityname'     => 'United Sates',
						'testimonial_bio'          => 'This is an awesome package. It is so awesome, that I have also purchased a lifetime developer license. I love the plugin and I love',
						'testimonial_rating_scale' => '5',
						'testimonial_rating'       => '5'
					],
					[
						'testimonial_name_title'   => __( 'Amanda_evil', 'useful-addons-elementor' ),
						'testimonial_cityname'     => 'United Sates',
						'testimonial_bio'          => 'This is an awesome package. It is so awesome, that I have also purchased a lifetime developer license. I love the plugin and I love',
						'testimonial_rating_scale' => '5',
						'testimonial_rating'       => '4.5',
					],
					[
						'testimonial_name_title'   => __( 'Shanewel_evil', 'useful-addons-elementor' ),
						'testimonial_cityname'     => 'United Sates',
						'testimonial_bio'          => 'This is an awesome package. It is so awesome, that I have also purchased a lifetime developer license. I love the plugin and I love',
						'testimonial_rating_scale' => '5',
						'testimonial_rating'       => '3.7',
					],
					[
						'testimonial_name_title'   => __( 'Mike Wood', 'useful-addons-elementor' ),
						'testimonial_cityname'     => 'United Kingdom',
						'testimonial_bio'          => 'This is an awesome package. It is so awesome, that I have also purchased a lifetime developer license. I love the plugin and I love',
						'testimonial_rating_scale' => '5',
						'testimonial_rating'       => '4.7',
					],
					[
						'testimonial_name_title'   => __( 'Daniel Ward', 'useful-addons-elementor' ),
						'testimonial_cityname'     => 'Costa Rica',
						'testimonial_bio'          => 'This is an awesome package. It is so awesome, that I have also purchased a lifetime developer license. I love the plugin and I love',
						'testimonial_rating_scale' => '5',
						'testimonial_rating'       => '2.7',
					],
				],
				'title_field' => '{{{ testimonial_name_title }}}',
			]
		);

		/* Testimonial 3 control */
		$this->add_control( 'testimonial_st3_lists',
			[
				'label'     => __( 'Testimonial List', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::REPEATER,
				'condition' => [
					'testimonial_layout_styles' => 'style_3'
				],
				'fields'  => [
					[
						'name'        => 'testimonial_st3_name',
						'label'       => __( 'Name', 'useful-addons-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'default'     => __( 'johndoe' , 'useful-addons-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'testimonial_st3_stitle',
						'label'       => __( 'Sub Title', 'useful-addons-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'default'     => __( '- TechyDevs' , 'useful-addons-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'testimonial_st3_content',
						'label'       => __( 'Content', 'useful-addons-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'row'         => 8,
						'default'     => __( 'Your content will go from here', 'useful-addons-elementor' ),
						'placeholder' => __( 'Type your content here', 'useful-addons-elementor' ),
					],
					[
						'name'    => 'testimonial_rating_scale',
						'label'   => __( 'Rating Scale', 'useful-addons-elementor' ),
						'type'    => Controls_Manager::SELECT,
						'options' => [
							'5'   => '0-5',
							'10'  => '0-10',
						],
						'default' => 5,
					],
					[
						'name'    => 'testimonial_rating',
						'label'   => __( 'Rating', 'useful-addons-elementor' ),
						'type'    => Controls_Manager::NUMBER,
						'min'     => 0,
						'max'     => 10,
						'step'    => 0.1,
						'default' => 5,
					]
				],
				'default' => [
					[
						'testimonial_st3_name'    => __( 'johndoe', 'useful-addons-elementor' ),
						'testimonial_st3_stitle'   => __( '- ThemeForest', 'useful-addons-elementor' ),
						'testimonial_st3_content'  => __( 'Your content will go from here', 'useful-addons-elementor' ),
						'testimonial_rating_scale' => 5,
						'testimonial_rating' => 5,
					],
					[
						'testimonial_st3_name'    => __( 'jimdoe', 'useful-addons-elementor' ),
						'testimonial_st3_stitle'   => __( '- ThemeForest', 'useful-addons-elementor' ),
						'testimonial_st3_content'  => __( 'Your content will go from here', 'useful-addons-elementor' ),
						'testimonial_rating_scale' => 5,
						'testimonial_rating' => 5,
					],
					[
						'testimonial_st3_name'    => __( 'janedoe', 'useful-addons-elementor' ),
						'testimonial_st3_stitle'   => __( '- ThemeForest', 'useful-addons-elementor' ),
						'testimonial_st3_content'  => __( 'Your content will go from here', 'useful-addons-elementor' ),
						'testimonial_rating_scale' => 5,
						'testimonial_rating' => 5,
					],
				],
				'title_field' => '{{{ testimonial_st3_name }}}',
			]
		);

		$this->end_controls_section();
	}
	/* UA Testimonial Query Setting */
	private function get_content_testimonial_query() {
		$this->start_controls_section( 'testimonial_query_setting',
			[
				'label'     => __( 'Query', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'testimonial_layout_styles' => 'style_1',
				],
			]
		);
		$this->add_control( 'testimonial_slides_show_num',
			[
				'label'   => __( 'Slides To Show', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 50,
				'step'    => 1,
				'default' => 2,
			]
		);
		$this->add_control( 'testimonial_infinite_lope',
			[
				'label'        => __( 'Infinite Loop', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'testimonial_autoplay',
			[
				'label'        => __( 'Autoplay', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'testimonial_autoplay_spd',
			[
				'label'     => __( 'Autoplay Speed', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 100,
				'max'       => 50000,
				'step'      => 100,
				'default'   => 500,
				'condition' => [
					'testimonial_autoplay' => 'yes'
				]
			]
		);
		$this->add_control( 'testimonial_autoheight',
			[
				'label'        => __( 'AutoHeight', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'testimonial_navigation',
			[
				'label'   => __( 'Navigation', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dots',
				'options' => [
					'arrows_dots'  => __( 'Arrows And Dots', 'useful-addons-elementor' ),
					'arrows'       => __( 'Arrows', 'useful-addons-elementor' ),
					'dots'         => __( 'Dots', 'useful-addons-elementor' ),
					'none'         => __( 'None', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control('testimonial_left_arrow_icon',
			[
				'label'            => __( 'Arrow Left', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-left',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);

		$this->add_control('testimonial_right_arrow_icon',
			[
				'label'            => __( 'Arrow Right', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_animation_spd',
			[
				'label'   => __( 'Animation Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 100,
				'max'     => 50000,
				'step'    => 100,
				'default' => 500,
			]
		);
		$this->add_control( 'testimonial_slide_space_between',
			[
				'label'   => __( 'Space Between', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 500,
				'step'    => 1,
				'default' => 30,
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Image Style */
	private function get_style_testimonial_image( ){
		$this->start_controls_section( 'testimonial_img_style',
			[
				'label'     => __( 'Image', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_1',
				],
			]
		);
		$this->add_control( 'testimonial_img_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi__img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'testimonial_img_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi__img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_img_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi__img img',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '10',
							'right'    => '10',
							'bottom'   => '10',
							'left'     => '10',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#ffffff',
					],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_img_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .testi__img',
			]
		);
		$this->add_responsive_control( 'testimonial_img_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => '%',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi__img, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi__img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_img_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi__img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Name & City Style */
	private function get_style_testimonial_name_and_city() {
		/* Testimonial Name */
		$this->start_controls_section( 'testimonial_name_setting',
			[
				'label'     => __( 'Name', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_1',
				],
			]
		);
		$this->add_control( 'testimonial_name_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-tesi__title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_name_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-tesi__title',
			]
		);
		$this->add_responsive_control( 'testimonial_name_margin',
			[
				'label'        => __( 'Margin', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::DIMENSIONS,
				'size_units'   => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '5',
					'right'    => '0',
					'bottom'   => '5',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'    => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-tesi__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		/* Testimonial City */
		$this->start_controls_section( 'testimonial_ctname_style',
			[
				'label'     => __( 'Sub Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_1',
				],
			]
		);
		$this->add_control( 'testimonial_ctname_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#929fb1',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-testi__meta' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_ctname_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-testi__meta',
			]
		);
		$this->add_responsive_control( 'testimonial_ctname_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-testi__meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Bio and Rating Style */
	private function get_style_testimonial_bio_and_rating( ){
		/* UA Testimonial bio Style */
		$this->start_controls_section( 'testimonial_bio_style',
			[
				'label'     => __( 'Content', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_1',
				],
			]
		);
		$this->add_control( 'testimonial_bio_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#677286',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box .ua-testi__desc' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_bio_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box .ua-testi__desc',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_bio_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box .ua-testi__desc',
			]
		);
		$this->add_responsive_control( 'testimonial_bio_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box .ua-testi__desc' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_bio_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box .ua-testi__desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		/* UA Testimonial Rating Style */
		$this->start_controls_section( 'testimonial_rating_style',
			[
				'label'     => __( 'Rating', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_1',
				],
			]
		);
		$this->add_control( 'testimonial_rating_act_clr',
			[
				'label'     => __( 'Active Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-testi__rating li i:before' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_rating_dbl_clr',
			[
				'label'     => __( 'Disable Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#eceef1',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-testi__rating li' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_rating_size',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-testi__rating li' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_rating_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-testi__rating li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_rating_bx_margin',
			[
				'label'      => __( 'Box Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-title-box .ua-testi__rating' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

	}
	/* UA Testimonial Navigation Style */
	private function get_style_testimonial_nav() {
		$this->start_controls_section( 'testimonial_navigation_style',
			[
				'label'     => __( 'Navigation', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_navigation'    => ['arrows_dots', 'arrows', 'dots'],
					'testimonial_layout_styles' => 'style_1',
				],
			]
		);
		// Dots
		$this->add_control( 'testimonial_navigation_dots_hd',
			[
				'label'     => __( 'Dots', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_nav_dots_box_margin',
			[
				'label'      => __( 'Box Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'testimonial_navigation_dots_tab_control',
			[
				'separator' => 'before',
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'testimonial_nav_dots_normal_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_dots_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot' => 'background: {{VALUE}}',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'testimonial_nav_dots_normal_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#233d63',
					],
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_nav_dots_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .client-testimonial .owl-dots .owl-dot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'testimonial_nav_dots_normal_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot',
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_dots_normal_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_dots_normal_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'testimonial_nav_dots_hover_tab',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_dots_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot.active' => 'background: {{VALUE}}',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'testimonial_nav_dots_hover_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot.active',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#f66b5d',
					],
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_nav_dots_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'testimonial_nav_dots_hover_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot.active',
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_dots_hover_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot.active' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_dots_hover_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot.active' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'testimonial_nav_dots_end_tab',
			[
				'type'      => Controls_Manager::DIVIDER,
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_nav_dots_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-dots .owl-dot' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows_dots', 'dots'],
				],
			]
		);

		/* arrows */
		$this->add_control( 'testimonial_navigation_arrows_hd',
			[
				'label'     => __( 'Arrows', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'testimonial_navigation' => [ 'arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_arws_size',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_arws_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'       => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .client-testimonial .owl-nav > .owl-next i, .ua-testimonial-area .client-testimonial .owl-nav > .owl-prev i' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_arws_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'testimonial_navigation_arws_tab_control',
			[
				'separator' => 'before',
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'testimonial_nav_arws_normal_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_arws_normal_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i' => 'color: {{VALUE}}',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_arws_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i' => 'background: {{VALUE}}',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'testimonial_nav_arws_normal_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i',
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'testimonial_nav_arws_normal_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i',
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_nav_arws_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'testimonial_nav_arws_hover_tab',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_arws_hover_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i:hover, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i:focus, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i:focus' => 'color: {{VALUE}}',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_nav_arws_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i:hover, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i:focus, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i:focus' => 'background: {{VALUE}}',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'testimonial_nav_arws_hover_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i:hover, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i:focus, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i:focus',
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'testimonial_nav_arws_hover_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i:hover, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i:focus, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i:focus',
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_nav_arws_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i:hover, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i:hover, {{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i:focus, .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i:focus' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'testimonial_nav_arws_end_tabs',
			[
				'type'      => Controls_Manager::DIVIDER,
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_nav_arws_lt_margin',
			[
				'label'      => __( 'Left Arrow Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-prev i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_nav_arws_rt_margin',
			[
				'label'      => __( 'Right Arrow Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .owl-nav > .owl-next i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Quote Style */
	private function get_style_testimonial_quote( ){
		$this->start_controls_section( 'testimonial_quote_style',
			[
				'label'     => __( 'Quote Icon', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_1',
				],
			]
		);
		$this->add_control( 'testimonial_quote_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(35, 61, 99, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box .quote_icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_quote_size',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 65,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box .quote_icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'testimonial_quote_lheight',
			[
				'label'      => __( 'Line Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 25,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box .quote_icon' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_quote_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box .quote_icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Box Style */
	private function get_style_testimonial_box( ){
		$this->start_controls_section( 'testimonial_box_style',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_1',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'testimonial_box_tab_control',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'testimonial_box_normal_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'testimonial_box_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_box_normal_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'transparent',
					],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_box_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '4',
					'left'     => '4',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_box_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box',
			]
		);
		$this->add_responsive_control( 'testimonial_box_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '22',
					'right'    => '20',
					'bottom'   => '22',
					'left'     => '20',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_box_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '20',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'testimonial_box_hover_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'testimonial_box_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item:hover .ua-testi-desc-box' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_box_hover_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item:hover .ua-testi-desc-box',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#f66b5d',
					],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_box_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item:hover .ua-testi-desc-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_box_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item:hover .ua-testi-desc-box',
			]
		);
		$this->add_responsive_control( 'testimonial_box_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item:hover .ua-testi-desc-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_box_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item:hover .ua-testi-desc-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'testimonial_triangle_hd',
			[
				'label'     => __( 'Triangle Shape', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'testimonial_shape_sh' => 'yes',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'testimonial_triangle_tab_control',
			[
				'separator' => 'before',
				'condition' => [
					'testimonial_shape_sh' => 'yes',
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'testimonial_triangle_normal_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_shape_sh' => 'yes',
				],
			]
		);
		$this->add_control( 'testimonial_triangle_normal_bg',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box:before' => 'border-top-color: {{VALUE}}',
				],
				'condition' => [
					'testimonial_shape_sh' => 'yes',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'testimonial_triangle_hover_tab',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_shape_sh' => 'yes',
				],
			]
		);
		$this->add_control( 'testimonial_triangle_hv_bg',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item:hover .ua-testi-desc-box:before' => 'border-top-color: {{VALUE}}',
				],
				'condition' => [
					'testimonial_shape_sh' => 'yes',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'testimonial_triangle_end_tabs',
			[
				'type'      => Controls_Manager::DIVIDER,
				'condition' => [
					'testimonial_shape_sh' => 'yes',
				],
			]
		);
		$this->add_control( 'testimonial_triangle_size',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box:before' => 'border-width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_shape_sh' => 'yes',
				],
			]
		);
		$this->add_control( 'testimonial_triangle_rotate',
			[
				'label' => __( 'Rotate', 'useful-addons-elementor' ),
				'type'  => Controls_Manager::SLIDER,
				'range' => [
					'px'      => [
						'min' => 0,
						'max' => 360,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box:before' => 'transform: rotate({{SIZE}}deg);',
				],
				'condition' => [
					'testimonial_shape_sh' => 'yes',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_triangle_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-client-testimonial .ua-testimonial-item .ua-testi-desc-box:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	// Testimonial 2 style query controls
	private function get_query_test_st2_query( ){
		$this->start_controls_section( 'testimonial_st2_query_setting',
			[
				'label'     => __( 'Query', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'testimonial_layout_styles' => 'style_2',
				],
			]
		);
		$this->add_control( 'testimonial_st2_slide_to_show',
			[
				'label'   => __( 'Slide to Show', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 10,
				'step'    => 1,
				'default' => 3,
			]
		);
		$this->add_control( 'testimonial_st2_infinite_loop',
			[
				'label'        => __( 'Infinite Loop', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'testimonial_st2_aplay',
			[
				'label'        => __( 'Autoplay', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'testimonial_st2_ap_spd',
			[
				'label'     => __( 'Autoplay Speed', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 100,
				'max'       => 50000,
				'step'      => 50,
				'default'   => 500,
				'condition' => [
					'testimonial_st2_aplay' => 'yes'
				]
			]
		);
		$this->add_control( 'testimonial_st2_aheight',
			[
				'label'        => __( 'AutoHeight', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'testimonial_st2_nav',
			[
				'label'   => __( 'Navigation', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dots',
				'options' => [
					'arrows_dots' => __( 'Arrows and Dots', 'useful-addons-elementor' ),
					'arrows'      => __( 'Arrows', 'useful-addons-elementor' ),
					'dots'        => __( 'Dots', 'useful-addons-elementor' ),
					'none'        => __( 'None', 'useful-addons-elementor' ),
				],
			]
		);

		$this->add_control('testimonial_st2_nav_left_icon',
			[
				'label'            => __( 'Arrow Left', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-left',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'testimonial_st2_nav' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control('testimonial_st2_nav_right_icon',
			[
				'label'            => __( 'Arrow Right', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'testimonial_st2_nav' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_animation_spd',
			[
				'label'   => __( 'Animation Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 100,
				'max'     => 50000,
				'step'    => 50,
				'default' => 500,
			]
		);
		$this->add_control( 'testimonial_st2_spc_between',
			[
				'label'   => __( 'Space Between', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 100,
				'step'    => 1,
				'default' => 30,
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Image style */
	private function get_style_test_st2_img( ){
		$this->start_controls_section( 'testimonial_st2_img_styles',
			[
				'label'     => __( 'Image', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_2',
				],
			]
		);
		$this->add_control( 'UA_tm-st2_img_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 54,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'UA_tm-st2_img_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 54,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st2_img_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name img',
			]
		);
		$this->add_responsive_control( 'testimonial_st2_img_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => '%',
					'isLinked' => true,
				],
				'selectors'    => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_st2_img_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name img',
			]
		);
		$this->add_responsive_control( 'testimonial_st2_img_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_img_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Title Style */
	private function get_style_test_st2_title( ){
		$this->start_controls_section( 'testimonial_st2_title_styles',
			[
				'label'     => __( 'Name', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_2',
				],
			]
		);
		$this->add_control( 'testimonial_st2_title_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#2e3d62',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_st2_title_hv_clr',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover .ua-testimonial__name .ua-testimonial__name-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_st2_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-title',
			]
		);
		$this->add_responsive_control( 'testimonial_st2_title_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial City Style */
	private function get_style_test_st2_city( ){
		$this->start_controls_section( 'testimonial_st2_ct_name_styles',
			[
				'label'     => __( 'Sub Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_2',
				],
			]
		);
		$this->add_control( 'testimonial_st2_ct_name_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-meta' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_st2_ct_name_hv_clr',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover .ua-testimonial__name .ua-testimonial__name-meta' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_st2_ct_name_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-meta',
			]
		);
		$this->add_responsive_control( 'testimonial_st2_ct_name_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_ct_name_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '8',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Bio Style */
	private function get_style_test_st2_bio( ){
		$this->start_controls_section( 'testimonial_st2_bio_styles',
			[
				'label'     => __( 'Content', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_2',
				],
			]
		);
		$this->add_control( 'testimonial_st2_bio_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__desc .ua-testimonial__desc-desc' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_st2_bio_hv_clr',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover .ua-testimonial__desc .ua-testimonial__desc-desc' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_st2_bio_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__desc .ua-testimonial__desc-desc',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st2_bio_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__desc',
			]
		);
		$this->add_control( 'testimonial_st2_bio_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__desc' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_bio_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_bio_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '20',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Rating Style */
	private function get_style_test_st2_rating( ){
		$this->start_controls_section( 'testimonial_st2_rating_styles',
			[
				'label'     => __( 'Rating', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_2',
				],
			]
		);
		$this->add_control( 'testimonial_st2_rating_active_color',
			[
				'label'     => __( 'Active Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f0ad4e',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-rating li i:before' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_st2_rating_deactivate_color',
			[
				'label'     => __( 'Deactivate Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#CCD6DF',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-rating' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_control( 'testimonial_st2_rating_hv_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control( 'testimonial_st2_rating_hv_active_color',
			[
				'label'     => __( 'Hover Active Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f0ad4e',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover .ua-testimonial__name .ua-testimonial__name-rating li i:before' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_st2_rating_hv_deactivate_color',
			[
				'label'     => __( 'Deactivate Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#CCD6DF',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover .ua-testimonial__name .ua-testimonial__name-rating' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_control( 'testimonial_st2_rating_size',
			[
				'label'      => __( 'Font Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 5,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-rating' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'testimonial_st2_rating_spc_between',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .ua-testimonial__name-rating li' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_rating_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .testimonial__name-rating' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Quote Style */
	private function get_style_test_st2_quote( ){
		$this->start_controls_section( 'testimonial_st2_quote_styles',
			[
				'label'     => __( 'Quote', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_2',
				],
			]
		);
		$this->add_control( 'testimonial_st2_quote_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f3f4f5',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .qt_icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_quote_size',
			[
				'label'      => __( 'Font Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 90,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .qt_icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_quote_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item .ua-testimonial__name .qt_icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Navigation Style */
	private function get_style_test_st2_nav( ){
		$this->start_controls_section( 'testimonial_st2_nav_styles',
			[
				'label'     => __( 'Navigation', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_2',
				],
			]
		);
		// dots
		$this->add_control( 'testimonial_st2_nav_dots_hd',
			[
				'label'     => __( 'Dots', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_dots_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_dots_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'testimonial_st2_nav_dots_tab_controls',
			[
				'separator' => 'before',
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'testimonial_st2_nav_dots_nrml_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_dots_nrml_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot' => 'background: {{VALUE}}',
				],
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'testimonial_st2_nav_dots_nrml_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot',
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_nav_dots_nrml_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'testimonial_st2_nav_dots_nrml_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot',
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_dots_nrml_scale',
			[
				'label'      => __( 'Scale', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 10,
						'step' => .1,
					],
				],
				'default'  => [
					'size' => 0.8,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot' => 'transform: scale({{SIZE}});',
				],
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'testimonial_st2_nav_dots_hv_tab',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_dots_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f42ec',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot.active' => 'background: {{VALUE}}',
				],
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'      => 'testimonial_st2_nav_dots_hv_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot.active',
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_nav_dots_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'      => 'testimonial_st2_nav_dots_hv_shadow',
				'label'     => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot.active',
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_dots_hv_scale',
			[
				'label'      => __( 'Scale', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 10,
						'step' => .1,
					],
				],
				'default'  => [
					'size' => 1,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot:hover, {{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot.active' => 'transform: scale({{SIZE}});',
				],
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'testimonial_st2_nav_dots_spc_between',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots .owl-dot' => 'margin: 0 {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_nav_dots_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '60',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-dots' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st2_nav' => ['dots', 'arrows_dots'],
				],
			]
		);
		// arrows
		$this->add_control( 'testimonial_st2_nav_arws_hd',
			[
				'label'     => __( 'Arrows', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'testimonial_st2_nav' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_arws_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 45,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st2_nav' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_arws_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 45,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st2_nav' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_arws_size',
			[
				'label'      => __( 'Font Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st2_nav' => ['arrows', 'arrows_dots'],
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'testimonial_st2_nav_arws_tab_controls',
			[
				'separator' => 'before',
				'condition' => [
					'testimonial_st2_nav' => ['arrows', 'arrows_dots'],
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'testimonial_st2_nav_arwws_nrml_tab',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_st2_nav' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_arws_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f42ec',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_arws_nrml_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st2_nav_arws_nrml_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *',
			]
		);
		$this->add_responsive_control( 'testimonial_st2_nav_arws_nrml_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_st2_nav_arws_nrml_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *',
			]
		);
		$this->add_responsive_control( 'testimonial_st2_nav_arws_nrml_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'testimonial_st2_nav_arws_hv_tab',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_st2_nav' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_arws_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_st2_nav_arws_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f42ec',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st2_nav_arws_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *:hover',
			]
		);
		$this->add_responsive_control( 'testimonial_st2_nav_arws_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_st2_nav_arws_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *:hover',
			]
		);
		$this->add_responsive_control( 'testimonial_st2_nav_arws_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav > *:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'testimonial_st2_nav_arrow_hhr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control( 'testimonial_st2_nav_larrow_margin',
			[
				'label'      => __( 'Left Arrow Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav .owl-prev' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_nav_rarrow_margin',
			[
				'label'      => __( 'Right Arrow Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .owl-nav .owl-next' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Testimonial Box Style */
	private function get_style_test_st2_box( ){
		$this->start_controls_section( 'testimonial_st2_box_styles',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_2',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'testimonial_st2_box_tab_controls',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'testimonial_st2_box_normal_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'testimonial_st2_box_nrml_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st2_box_nrml_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_st2_nrml_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item',
			]
		);
		$this->add_responsive_control( 'testimonial_st2_box_nrml_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_box_nrml_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '40',
					'right'    => '40',
					'bottom'   => '40',
					'left'     => '40',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_box_nrml_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'testimonial_st2_box_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'testimonial_st2_box_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st2_box_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_st2_hv_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover',
			]
		);
		$this->add_responsive_control( 'testimonial_st2_box_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_box_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st2_box_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'testimonial_st2_box_before_bg_sh',
			[
				'label'        => __( 'Show Hover Before BG', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'      => 'testimonial_st2_box_before_background',
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'types'     => [ 'classic', 'gradient' ],
				'selector'  => '{{WRAPPER}} .ua-testimonial-area .ua-testimonial-wrap .ua-testimonial-item:after',
				'condition' => [
					'testimonial_st2_box_before_bg_sh' => 'yes',
				],
			]
		);
		$this->end_controls_section();
	}


	/* Testimonial3 Styles */
	private function get_style_tm3_name_style( ) {
		$this->start_controls_section( 'testimonial_st3_name_style',
			[
				'label'     => __( 'Name', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_3',
				],
			]
		);
		$this->add_control( 'testimonial_st3_name_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title span:first-child' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st3_name_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title span:first-child',
			]
		);
		$this->add_control( 'testimonial_st3_name_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title span:first-child' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_st3_name_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title span:first-child',
			]
		);
		$this->add_responsive_control( 'testimonial_st3_name_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title span:first-child' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_name_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title span:first-child' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_tm3_subtitle_style( ) {
		$this->start_controls_section( 'testimonial_st3_stitle_style',
			[
				'label'     => __( 'Sub Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_3',
				],
			]
		);
		$this->add_control( 'testimonial_st3_stitle_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#6c757d',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title .stitle' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st3_stitle_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title .stitle',
			]
		);
		$this->add_control( 'testimonial_st3_stitle_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title .stitle' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_st3_stitle_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title .stitle',
			]
		);
		$this->add_responsive_control( 'testimonial_st3_stitle_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title .stitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_stitle_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3__title .stitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_tm3_content_style( ) {
		$this->start_controls_section( 'testimonial_st3_content_style',
			[
				'label'     => __( 'Content', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_3',
				],
			]
		);
		$this->add_control( 'testimonial_st3_content_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#748494',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3-content .ua-testimonial3__desc' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'testimonial_st3_content_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3-content .ua-testimonial3__desc',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st3_content_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '0',
							'right'    => '0',
							'bottom'   => '1',
							'left'     => '0',
							'isLinked' => false,
						],
					],
					'color' => [
						'default' => 'rgba(128, 137, 150, 0.1)',
					],
				],
				'selector' => '{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3-content .ua-testimonial3__desc',
			]
		);
		$this->add_control( 'testimonial_st3_content_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3-content .ua-testimonial3__desc' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_content_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '0',
                    'bottom' => '24',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked'=> false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3-content .ua-testimonial3__desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_content_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '24',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked'=> false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3-content .ua-testimonial3__desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_tm3_rating_style( ) {
		$this->start_controls_section( 'testimonial_st3_rating_style',
			[
				'label'     => __( 'Rating', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_3',
				],
			]
		);
		$this->add_control( 'testimonial_st3_rating_active_color',
			[
				'label'     => __( 'Active Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f0ad4e',
				'selectors' => [
					'{{WRAPPER}} .elementor-star-rating i:before' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_st3_rating_disable_color',
			[
				'label'     => __( 'Disable Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#CCD6DF',
				'selectors' => [
					'{{WRAPPER}} .elementor-star-rating' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'testimonial_st3_rating_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 17,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3-author .rating li' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_rating_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '4',
                    'bottom' => '0',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked'=> false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item .ua-testimonial3-author .rating li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_tm3_box_style( ) {
		$this->start_controls_section( 'testimonial_st3_box_style',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_3',
				],
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'testimonial_st3_box_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .ua-testimonial3-item',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st3_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial3-item',
			]
		);
		$this->add_control( 'testimonial_st3_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '8',
                    'right'  => '8',
                    'bottom' => '8',
                    'left'   => '8',
                    'unit'   => 'px',
                    'isLinked'=> true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_st3_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' =>
					[
                        'box_shadow_type' => [
                            'default' =>'yes'
                        ],
                    'box_shadow' => [
                        'default' =>
                            [
                                'horizontal' => 0,
                                'vertical' => 0,
                                'blur' => 40,
                                'spread' => 0,
                                'color' => 'rgba(82, 85, 90, 0.1)'
                            ]
                    ]
                ],
				'selector' => '{{WRAPPER}} .ua-testimonial3-item',
			]
		);
		$this->add_control( 'testimonial_st3_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '30',
					'right'  => '35',
					'bottom' => '30',
					'left'   => '35',
					'unit'   => 'px',
					'isLinked'=> false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'testimonial_st3_box_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_tm3_navigation( ) {
		$this->start_controls_section( 'testimonial_st3_navigation_style',
			[
				'label'     => __( 'Navigation', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'testimonial_layout_styles' => 'style_3',
                    'testimonial_st3_navigation'   => ['arrow_dots', 'arrows', 'dots']
				],
			]
		);
		/* Arrow */
		$this->add_control( 'testimonial_st3_navigation_arrow_heading',
			[
				'label'     => __( 'Arrow', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'arrows']
				],
			]
		);
		$this->add_control( 'testimonial_st3_arrow_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev, .ua-testimonial3-area .swiper-button-next' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_arrow_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev, .ua-testimonial3-area .swiper-button-next' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_arrow_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev, .ua-testimonial3-area .swiper-button-next' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'testimonial_st3_arrow_tabs',
			[
				'separator' => 'before',
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'testimonial_st3_arrow_nrml',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_arrow_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev, .ua-testimonial3-area .swiper-button-next' => 'color: {{VALUE}}',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_arrow_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev, .ua-testimonial3-area .swiper-button-next' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st3_arrow_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev, .ua-testimonial3-area .swiper-button-next',
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_arrow_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '50',
                    'right'  => '50',
                    'bottom' => '50',
                    'left'   => '50',
                    'unit'   => '%',
                    'isLinked'=>true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev, .ua-testimonial3-area .swiper-button-next' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_st3_arrow_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' =>
					[
						'box_shadow_type' => [
							'default' =>'yes'
						],
						'box_shadow' => [
							'default' =>
								[
									'horizontal' => 0,
									'vertical' => 0,
									'blur' => 40,
									'spread' => 0,
									'color' => 'rgba(82, 85, 90, 0.11)'
								]
						]
					],
				'selector' => '{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev, .ua-testimonial3-area .swiper-button-next',
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'arrows']
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_arrow_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev, .ua-testimonial3-area .swiper-button-next' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'arrows']
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_arrow_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev, .ua-testimonial3-area .swiper-button-next' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'arrows']
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'testimonial_st3_arrow_hv',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_arrow_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev:hover, .ua-testimonial3-area .swiper-button-next:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_arrow_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev:hover, .ua-testimonial3-area .swiper-button-next:hover' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st3_arrow_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev:hover, .ua-testimonial3-area .swiper-button-next:hover',
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_arrow_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev:hover, .ua-testimonial3-area .swiper-button-next:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows'],
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_st3_arrow_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev:hover, .ua-testimonial3-area .swiper-button-next:hover',
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'arrows']
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_arrow_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev:hover, .ua-testimonial3-area .swiper-button-next:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'arrows']
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_arrow_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-testimonial3-area .swiper-button-prev:hover, .ua-testimonial3-area .swiper-button-next:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'arrows']
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */

		/* Dots */
		$this->add_control( 'testimonial_st3_navigation_dots_heading',
			[
				'label'     => __( 'Dots', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'dots']
				],
			]
		);
		$this->add_control( 'testimonial_st3_dots_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_dots_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%', 'rem', 'em' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'testimonial_st3_dots_tabs',
			[
				'separator' => 'before',
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		// normal tab
		$this->start_controls_tab( 'testimonial_st3_dots_nrml',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_dots_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st3_dots_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => false,
						],
					],
					'color' => [
						'default' => 'rgba(19, 41, 104, 0.1)',
					],
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_dots_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '50',
					'right'  => '50',
					'bottom' => '50',
					'left'   => '50',
					'unit'   => '%',
					'isLinked'=>true
				],
				'selectors'  => [
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_st3_dots_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet',
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'dots']
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_dots_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '6',
                    'bottom' => '0',
                    'left'   => '6',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'dots']
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'testimonial_st3_dots_hv',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_dots_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#3BACE4',
				'selectors' => [
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet:hover' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'testimonial_st3_dots_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet:hover, .swiper-bullet .swiper-pagination-bullet.swiper-pagination-bullet-active',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => false,
						],
					],
					'color' => [
						'default' => '#3BACE4',
					],
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		$this->add_control( 'testimonial_st3_dots_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'dots'],
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'testimonial_st3_dots_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet:hover, .swiper-bullet .swiper-pagination-bullet.swiper-pagination-bullet-active',
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'dots']
				],
			]
		);
		$this->add_responsive_control( 'testimonial_st3_dots_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .swiper-bullet .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'testimonial_st3_navigation'   => ['arrow_dots', 'dots']
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */

		$this->end_controls_section();
	}

	/* Testimonial3 Query */
	private function get_content_tm3_query( ) {
		$this->start_controls_section( 'testimonial_st3_query',
			[
				'label'     => __( 'Query', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'testimonial_layout_styles' => 'style_3',
				],
			]
		);
		$this->add_control( 'testimonial_st3_slide_to_show',
			[
				'label'   => __( 'Slide to show', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 6,
				'step'    => 1,
				'default' => 1,
			]
		);
		$this->add_control( 'testimonial_st3_spc_between',
			[
				'label'   => __( 'Space Between', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 500,
				'step'    => 1,
				'default' => 65,
			]
		);
		$this->add_control( 'testimonial_st3_speed',
			[
				'label'   => __( 'Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 50000,
				'step'    => 50,
				'default' => 900,
			]
		);
		$this->add_control( 'testimonial_st3_loop',
			[
				'label'        => __( 'Loop', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'testimonial_st3_autoplay',
			[
				'label'        => __( 'Autoplay', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'testimonial_st3_autoplay_speed',
			[
				'label'   => __( 'Autoplay Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 50000,
				'step'    => 100,
				'default' => 8000,
                'condition' => [
                    'testimonial_st3_autoplay' => 'yes'
                ]
			]
		);
		$this->add_control( 'testimonial_st3_autoheight',
			[
				'label'        => __( 'Autoheight', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'testimonial_st3_navigation',
			[
				'label'   => __( 'Navigation', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dots',
				'options' => [
					'arrow_dots'  => __( 'Arrow & Dots', 'useful-addons-elementor' ),
					'dots'        => __( 'Dots', 'useful-addons-elementor' ),
					'arrows'      => __( 'Arrow', 'useful-addons-elementor' ),
					'none'        => __( 'None', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control( 'testimonial_st3_prev_icon',
			[
				'label'       => __( 'Previous Arrow', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => [
					'value'   => 'la la-angle-left',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'play',
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
                'condition' => [
                    'testimonial_st3_navigation' => ['arrow_dots', 'arrows']
                ]
			]
		);
		$this->add_control( 'testimonial_st3_next_icon',
			[
				'label'       => __( 'Next Arrow', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::ICONS,
				'default'     => [
					'value'   => 'la la-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'play',
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'testimonial_st3_navigation' => ['arrow_dots', 'arrows']
				]
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls()  {
		$this->get_content_testimonial_contents();
		$this->get_content_testimonial_query();
		$this->get_style_testimonial_image();
		$this->get_style_testimonial_name_and_city();
		$this->get_style_testimonial_bio_and_rating();
		$this->get_style_testimonial_nav();
		$this->get_style_testimonial_quote();
		$this->get_style_testimonial_box();

		/* Testimonial 2 Styles & Query Controls */
		$this->get_query_test_st2_query();
		$this->get_style_test_st2_img();
		$this->get_style_test_st2_title();
		$this->get_style_test_st2_city();
		$this->get_style_test_st2_bio();
		$this->get_style_test_st2_rating();
		$this->get_style_test_st2_quote();
		$this->get_style_test_st2_nav();
		$this->get_style_test_st2_box();

		/* Testimonial 3 Styles */
        $this->get_content_tm3_query();
		$this->get_style_tm3_name_style();
		$this->get_style_tm3_subtitle_style();
		$this->get_style_tm3_content_style();
		$this->get_style_tm3_rating_style();
		$this->get_style_tm3_navigation();
		$this->get_style_tm3_box_style();

	}

	protected function render_tm_stars( $rating_data, $icon ) {
		$rating = $rating_data[0];
		$scale  = $rating_data[1];
		$floored_rating = (int) $rating; // full number
		$stars_html = '';

		for ( $stars = 1; $stars <= $scale; $stars++ ) { // loop will run 5|10 times
			if ( $stars <= $floored_rating ) { // full stars
				$stars_html .= '<li><i class="elementor-star-full">' . $icon . '</i></li>';
			} elseif ( $floored_rating + 1 === $stars && $rating !== $floored_rating ) {
				$stars_html .= '<li><i class="elementor-star-' . ( $rating - $floored_rating ) * 10 . '">' . $icon . '</i></li>';
			} else {
				$stars_html .= '<li><i class="elementor-star-empty">' . $icon . '</i></li>';
			}
		}

		return $stars_html;
	}

	protected function render( ) {
		$settings   = $this->get_settings_for_display();
		$rpt_lists  = $this->get_settings_for_display('testimonial_lists');
		$rpt_lists2 = $this->get_settings_for_display('testimonial_lists2');
		$rpt_lists3 = $this->get_settings_for_display('testimonial_st3_lists');

		if($settings['testimonial_shape_sh'] == 'yes') {
			$tm_bio_shape = ' ';
		} else {
			$tm_bio_shape = 'hide_shape';
		}

		if($settings['testimonial_layout_styles'] == 'style_1') {
			?>
            <section class="ua-testimonial-area testimonial-area2">
                <div class="ua-client-testimonial owl-carousel">
					<?php foreach ( $rpt_lists as $index => $rpt_list ) {
						$tm_rating = isset( $rpt_list['testimonial_rating'] ) ? (float) $rpt_list['testimonial_rating'] : 0;
						$tm_scale  = isset( $rpt_list['testimonial_rating_scale'] ) ? (float) $rpt_list['testimonial_rating_scale'] : 5;

						$icon              = '&#xE934;';
						$repeater_key      = $this->get_repeater_setting_key( 'tm_rating', 'test', $index );

						$this->add_render_attribute( $repeater_key, [
							'class'     => 'elementor-star-rating testi__rating',
						] );
						$stars_element = '<ul ' . $this->get_render_attribute_string( $repeater_key ) . '>' . $this->render_tm_stars( [
								$tm_rating,
								$tm_scale
							], $icon ) . '</ul>';
						?>
                        <div class="ua-testimonial-item">
                            <div class="ua-testi-desc-box <?php echo esc_attr($tm_bio_shape); ?>">
								<?php if ( ! empty( $rpt_list['testimonial_bio'] ) ) { ?>
                                    <p class="ua-testi__desc">
										<?php echo esc_html($rpt_list['testimonial_bio']); ?>
                                    </p>
								<?php }
								if ( $rpt_list['team_quote_icon_sh'] == 'yes' )
								{
									if ( !empty( $rpt_list['testimonial_quote_icon'] ) ) {
										Icons_Manager::render_icon( $rpt_list['testimonial_quote_icon'], ['class' => 'quote_icon ', 'aria-hidden' => 'true' ] );
									}
								} ?>
                            </div>
							<?php if ( ! empty( $rpt_list['testimonial_image']['url'] ) ) { ?>
                                <div class="ua-testi__img">
                                    <span class="testi__img-cercle"></span>
                                    <img src="<?php echo esc_url($rpt_list['testimonial_image']['url']); ?>" alt="<?php esc_attr_e('Testimonial Image', 'useful-addons-elementor'); ?>">
                                </div>
							<?php } ?>
                            <div class="ua-testi-title-box">
								<?php if ( ! empty( $rpt_list['testimonial_name_title'] ) ) { ?>
                                    <h4 class="ua-tesi__title">
										<?php echo esc_html($rpt_list['testimonial_name_title']); ?>
                                    </h4>
								<?php }
								if ( ! empty( $rpt_list['testimonial_cityname'] ) ) { ?>
                                    <span class="ua-testi__meta">
                                        <?php echo esc_html($rpt_list['testimonial_cityname']); ?>
                                    </span>
								<?php }
								if ( ! empty( $stars_element ) ) { ?>
                                    <div class="elementor-star-rating__wrapper">
										<?php echo $stars_element; ?>
                                    </div>
								<?php } ?>
                            </div>
                        </div>
					<?php } ?>
                </div>
            </section>

            <script>
                jQuery('.ua-client-testimonial').owlCarousel({
                    loop: <?php if($settings['testimonial_infinite_lope'] == 'yes') { ?>true <?php } else { ?>
                    false <?php } ?>,
                    autoplay: <?php if($settings['testimonial_autoplay'] == 'yes') { ?>true <?php } else { ?>
                    false <?php } ?>,
                    autoHeight: <?php if($settings['testimonial_autoheight'] == 'yes') { ?>true <?php } else { ?>
                    false <?php } ?>,
                    dots: <?php if($settings['testimonial_navigation'] == 'dots' || $settings['testimonial_navigation'] == 'arrows_dots') { ?>true <?php } else { ?>
                    false <?php } ?>,
                    nav: <?php if($settings['testimonial_navigation'] == 'arrows' || $settings['testimonial_navigation'] == 'arrows_dots') { ?>true <?php } else { ?>
                    false<?php } ?>,
                    items: <?php echo $settings['testimonial_slides_show_num']; ?>,
					<?php if($settings['testimonial_navigation'] == 'arrows' || $settings['testimonial_navigation'] == 'arrows_dots') { ?>
                    navText: ['<?php Icons_Manager::render_icon( $settings['testimonial_left_arrow_icon'], [ 'aria-hidden' => 'true' ] ); ?>', '<?php Icons_Manager::render_icon( $settings['testimonial_right_arrow_icon'], [ 'aria-hidden' => 'true' ] ); ?>'],
					<?php }
					if (!empty($settings['testimonial_animation_spd'] ) ) {
					?>
                    smartSpeed: <?php echo $settings['testimonial_animation_spd']; ?>,
					<?php
					}
					if ( !empty( $settings['testimonial_autoplay_spd'] ) ) {
					?>
                    autoplaySpeed: <?php echo $settings['testimonial_autoplay_spd']; ?>,
					<?php }
					if (!empty($settings['testimonial_slide_space_between']) ) {
					?>
                    margin: <?php echo $settings['testimonial_slide_space_between']; ?>,
					<?php } ?>
                    responsive: {
                        // breakpoint from 0 up
                        0: {
                            items: 1
                        },
                        // breakpoint from 480 up
                        480: {
                            items: 1
                        },
                        // breakpoint from 768 up
                        767: {
                            items: 2
                        },
                        // breakpoint from 1024 up
                        1024: {
                            items: <?php echo $settings['testimonial_slides_show_num']; ?>
                        }
                    }
                });
            </script>
			<?php
		}
		elseif($settings['testimonial_layout_styles'] == 'style_2') {
			if($settings['testimonial_st2_box_before_bg_sh'] == 'yes') {
				$ua_tm_st2_box_before = ' ';
			} else {
				$ua_tm_st2_box_before = ' hide_before_shape ';
			}
			?>
            <section class="ua-testimonial-area">
                <div class="ua-testimonial-wrap ua-testimonial-carousel owl-carousel">
					<?php foreach ( $rpt_lists2 as $index => $rpt_list ) {
						$tm_rating2 = isset( $rpt_list['testimonial_rating'] ) ? (float) $rpt_list['testimonial_rating'] : 0;
						$tm_scale2  = isset( $rpt_list['testimonial_rating_scale'] ) ? (float) $rpt_list['testimonial_rating_scale'] : 5;

						$icon2             = '&#xE934;';
						$repeater_key      = $this->get_repeater_setting_key( 'tm_rating', 'test', $index );

						$this->add_render_attribute( $repeater_key, [
							'class'     => 'elementor-star-rating testimonial__name-rating',
						] );
						$stars_element = '<ul ' . $this->get_render_attribute_string( $repeater_key ) . '>' . $this->render_tm_stars( [
								$tm_rating2,
								$tm_scale2
							], $icon2 ) . ' </ul>';
						?>
                        <div class="ua-testimonial-item <?php echo $ua_tm_st2_box_before; ?>">
                            <?php if($settings['testimonial_content_position_styles'] === 'after_author') { ?>
                                <div class="ua-testimonial__name">
                                    <?php if(!empty( $rpt_list['testimonial_image']['url'] )) { ?>
                                        <img src="<?php echo esc_attr($rpt_list['testimonial_image']['url']); ?>" alt="<?php esc_attr_e('Avatar', 'useful-addons-elementor'); ?>">
                                    <?php } if(!empty($rpt_list['testimonial_name_title'])) { ?>
                                        <h3 class="ua-testimonial__name-title">
                                            <?php echo $rpt_list['testimonial_name_title']; ?>
                                        </h3>
                                    <?php } if(!empty( $rpt_list['testimonial_cityname'] )) { ?>
                                        <span class="ua-testimonial__name-meta">
                                            <?php echo $rpt_list['testimonial_cityname']; ?>
                                        </span>
                                    <?php } if(!empty( $stars_element )) { ?>
                                        <?php echo $stars_element; ?>
                                    <?php } if($rpt_list['team_quote_icon_sh'] == 'yes') {
                                        if ( !empty( $rpt_list['testimonial_quote_icon'] ) ) {
                                            Icons_Manager::render_icon( $rpt_list['testimonial_quote_icon'], ['class' => 'qt_icon ', 'aria-hidden' => 'true' ] );
                                        }
                                    } ?>
                                </div><!-- end testimonial__name -->
                                <?php if(!empty( $rpt_list['testimonial_bio'] )) { ?>
                                    <div class="ua-testimonial__desc">
                                        <p class="ua-testimonial__desc-desc">
                                            <?php echo $rpt_list['testimonial_bio']; ?>
                                        </p>
                                    </div><!-- end testimonial__desc -->
                                <?php
                                }
                            } else { ?>
								<?php if(!empty( $rpt_list['testimonial_bio'] )) { ?>
                                    <div class="ua-testimonial__desc">
                                        <p class="ua-testimonial__desc-desc">
											<?php echo $rpt_list['testimonial_bio']; ?>
                                        </p>
                                    </div><!-- end testimonial__desc -->
									<?php
								} ?>
                                <div class="ua-testimonial__name">
									<?php if(!empty( $rpt_list['testimonial_image']['url'] )) { ?>
                                        <img src="<?php echo $rpt_list['testimonial_image']['url']; ?>" alt="small-avatar">
									<?php } if(!empty($rpt_list['testimonial_name_title'])) { ?>
                                        <h3 class="ua-testimonial__name-title">
											<?php echo $rpt_list['testimonial_name_title']; ?>
                                        </h3>
									<?php } if(!empty( $rpt_list['testimonial_cityname'] )) { ?>
                                        <span class="ua-testimonial__name-meta">
                                            <?php echo $rpt_list['testimonial_cityname']; ?>
                                        </span>
									<?php } if(!empty( $stars_element )) { ?>
										<?php echo $stars_element; ?>
									<?php } if($rpt_list['team_quote_icon_sh'] == 'yes') {
										if ( !empty( $rpt_list['testimonial_quote_icon'] ) ) {
											Icons_Manager::render_icon( $rpt_list['testimonial_quote_icon'], ['class' => 'qt_icon ', 'aria-hidden' => 'true' ] );
										}
									} ?>
                                </div><!-- end testimonial__name -->
							<?php }
							?>
                        </div>
					<?php } ?>
                </div>
            </section>
			<?php
			// infinite loop
			if($settings['testimonial_st2_infinite_loop'] == 'yes') {
				$infinite_loop = 'true';
			} else {
				$infinite_loop = 'false';
			}
			// autoplay
			if($settings['testimonial_st2_aplay'] == 'yes') {
				$autoplay = 'true';
			} else {
				$autoplay = 'false';
			}
			// autoheight
			if($settings['testimonial_st2_aheight'] == 'yes') {
				$autoheight = 'true';
			} else {
				$autoheight = 'false';
			}
			// navigation
			if($settings['testimonial_st2_nav'] == 'dots' || $settings['testimonial_st2_nav'] == 'arrows_dots') {
				$nav_dots = 'true';
			} else {
				$nav_dots = 'false';
			}
			if($settings['testimonial_st2_nav'] == 'arrows' || $settings['testimonial_st2_nav'] == 'arrows_dots') {
				$nav = 'true';
			} else {
				$nav = 'false';
			}
			?>
            <script>
                jQuery('.ua-testimonial-carousel').owlCarousel({
                    loop: <?php echo $infinite_loop; ?>,
                    items: <?php echo $settings['testimonial_st2_slide_to_show']; ?>,
                    nav: <?php echo $nav; ?>,
					<?php
					if($settings['testimonial_st2_nav'] == 'arrows' || $settings['testimonial_st2_nav'] == 'arrows_dots') {
					?>
                    navText: ['<?php Icons_Manager::render_icon( $settings['testimonial_st2_nav_left_icon'], [ 'aria-hidden' => 'true' ] ); ?>', '<?php Icons_Manager::render_icon( $settings['testimonial_st2_nav_right_icon'], [ 'aria-hidden' => 'true' ] ); ?>'],
					<?php } ?>
                    dots: <?php echo $nav_dots; ?>,
					<?php if ( !empty( $settings['testimonial_st2_animation_spd'] ) ) { ?>
                    smartSpeed: <?php echo $settings['testimonial_st2_animation_spd']; ?>,
					<?php
					}
					if ( !empty($settings['testimonial_st2_ap_spd'] ) ) { ?>
                    autoplaySpeed: <?php echo $settings['testimonial_st2_ap_spd']; ?>,
					<?php } ?>
                    autoplay: <?php echo $autoplay; ?>,
					<?php
					if ( !empty( $settings['testimonial_st2_spc_between'] ) ) {
					?>
                    margin: <?php echo $settings['testimonial_st2_spc_between']; ?>,
					<?php } ?>
                    autoHeight: <?php echo $autoheight; ?>,
                    responsive:{
                        320:{
                            items:1,
                        },
                        767:{
                            items:2,
                        },
                        992:{
                            items:2,
                        },
                        1025:{
                            items:<?php echo $settings['testimonial_st2_slide_to_show']; ?>,
                        },
                    }
                });
            </script>
			<?php
		}
		else {
		    ?>
            <div class="ua-testimonial3-area position-relative text-center overflow-hidden">
                <div class="swiper-container ua-testimonial3-slider">
                    <div class="swiper-wrapper">
                        <?php foreach ($rpt_lists3 as $index => $rpt_list) {
                            $tm_rating3 = isset( $rpt_list['testimonial_rating'] ) ? (float) $rpt_list['testimonial_rating'] : 0;
                            $tm_scale3  = isset( $rpt_list['testimonial_rating_scale'] ) ? (float) $rpt_list['testimonial_rating_scale'] : 5;

                            $icon2             = '&#xE934;';
                            $repeater_key      = $this->get_repeater_setting_key( 'tm_rating', 'test', $index );

                            $this->add_render_attribute( $repeater_key, [
                                'class'     => 'elementor-star-rating rating pt-1',
                            ] );
                            $stars_element = '<ul ' . $this->get_render_attribute_string( $repeater_key ) . '>' . $this->render_tm_stars( [
                                    $tm_rating3,
                                    $tm_scale3
                                ], $icon2 ) . ' </ul>';

                            ?>
                        <div class="swiper-slide">
                            <div class="ua-testimonial3-item">
                                <?php if(!empty($rpt_list['testimonial_st3_content'])) { ?>
                                    <div class="ua-testimonial3-content">
                                        <p class="ua-testimonial3__desc">
                                            <?php echo $rpt_list['testimonial_st3_content']; ?>
                                        </p>
                                    </div>
                                <?php } ?>
                                <div class="ua-testimonial3-author">
                                    <?php if(!empty($rpt_list['testimonial_st3_name']) || !empty($rpt_list['testimonial_st3_stitle'])) { ?>
                                        <h3 class="ua-testimonial3__title">
                                            <?php if(!empty($rpt_list['testimonial_st3_name'])) { ?>
                                                <span class="d-inline-block">
                                                    <?php echo $rpt_list['testimonial_st3_name']; ?>
                                                </span>
                                            <?php } if(!empty($rpt_list['testimonial_st3_stitle'])) { ?>
                                                <span class="stitle d-inline-block">
                                                    <?php echo $rpt_list['testimonial_st3_stitle']; ?>
                                                </span>
                                            <?php } ?>
                                        </h3>
                                    <?php }
                                        echo $stars_element;
                                    ?>
                                </div><!-- end ua-testimonial3-author -->
                            </div><!-- end ua-testimonial3-item -->
                        </div><!-- end swiper-slide -->
                        <?php } ?>

                    </div>
                    <?php if($settings['testimonial_st3_navigation'] == 'dots' || $settings['testimonial_st3_navigation'] == 'arrows' || $settings['testimonial_st3_navigation'] == 'arrow_dots' ) {
                            if($settings['testimonial_st3_navigation'] == 'arrow_dots' || $settings['testimonial_st3_navigation'] == 'dots') { ?>
                                <div class="swiper-pagination swiper-bullet"></div>
                        <?php }

                        if($settings['testimonial_st3_navigation'] == 'arrow_dots' || $settings['testimonial_st3_navigation'] == 'arrows') { ?>
                            <div class="swiper-navigation">
                                <?php if(!empty($settings['testimonial_st3_next_icon'])) { ?>
                                <div class="swiper-button-next">
	                                <?php Icons_Manager::render_icon( $settings['testimonial_st3_next_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </div>
                                <?php } if(!empty($settings['testimonial_st3_prev_icon'])) { ?>
                                <div class="swiper-button-prev">
	                                <?php Icons_Manager::render_icon( $settings['testimonial_st3_prev_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                </div>
                                <?php } ?>
                            </div>
                        <?php
                        }
                    } ?>
                </div>
            </div>


            <script>
                var swiper = new Swiper('.ua-testimonial3-slider', {
                    slidesPerView: <?php echo $settings['testimonial_st3_slide_to_show']; ?>,
                    spaceBetween: <?php echo $settings['testimonial_st3_spc_between']; ?>,
                    autoHeight: <?php if($settings['testimonial_st3_autoheight']) { ?> true <?php } else { ?> false <?php } ?>,
                    autoplay: <?php if($settings['testimonial_st3_autoplay'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                    <?php if($settings['testimonial_st3_autoplay'] == 'yes') { ?>
                    autoplaySpeed: <?php echo $settings['testimonial_st3_autoplay_speed']; ?>,
                    <?php } ?>
                    loop: <?php if($settings['testimonial_st3_loop'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                    speed: <?php echo $settings['testimonial_st3_speed']; ?>,
                    <?php if($settings['testimonial_st3_navigation'] == 'arrow_dots' || $settings['testimonial_st3_navigation'] == 'dots' || $settings['testimonial_st3_navigation'] == 'arrows') {
                        if($settings['testimonial_st3_navigation'] == 'arrows' || $settings['testimonial_st3_navigation'] == 'arrow_dots') {
                    ?>
                        navigation: {
                            nextEl: '.swiper-button-next',
                            prevEl: '.swiper-button-prev',
                        },
                    <?php }
                        if($settings['testimonial_st3_navigation'] == 'dots' || $settings['testimonial_st3_navigation'] == 'arrow_dots') { ?>
                            pagination: {
                                el: '.swiper-pagination',
                                clickable: true,
                            },
                        <?php
                        }
                    } ?>
                    breakpoints: {
                        640: {
                            slidesPerView: 1,
                            spaceBetween: 10,
                        },
                        768: {
                            slidesPerView: 1,
                            spaceBetween: 10,
                        },
                        1024: {
                            slidesPerView: <?php echo $settings['testimonial_st3_slide_to_show']; ?>,
                            spaceBetween: <?php echo $settings['testimonial_st3_spc_between']; ?>,
                        },
                    }
                });
            </script>
            <?php
        }

	}

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_testimonial() );