<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_page_lists extends Widget_Base {
	public function get_name() {
		return 'UA_page_list';
	}

	public function get_title() {
		return esc_html__( 'Page List', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-editor-list-ul ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* Query All Pages */
	public function UA_get_all_page_types() {
		$page_args = array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
		);
		$pages = get_posts($page_args);
		$page_list = [];
		foreach ($pages as $page) {
			$page_list[$page->ID] = $page->post_title;
		}
		return $page_list;
	}

	/* UA Page List Content Controls */
	private function get_content_page_list( ){
		$this->start_controls_section( 'UA_page_list_content',
			[
				'label' => __('Page List', 'useful-addons-elementor'),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'UA_page_list_view',
			[
				'label'   => esc_html__( 'Layout', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'default' => 'traditional',
				'options' => [
					'traditional' => [
						'title'   => esc_html__( 'Default', 'useful-addons-elementor' ),
						'icon'    => 'eicon-editor-list-ul',
					],
					'inline'    => [
						'title' => esc_html__( 'Inline', 'useful-addons-elementor' ),
						'icon'  => 'eicon-ellipsis-h',
					],
				],
				'label_block' => false,
			]
		);
		$repeater = new Repeater();
		$repeater->add_control( 'UA_page_target',
			[
				'label'   => __( 'Target', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '_self',
				'options' => [
					'_blank'  => __('Blank', 'useful-addons-elementor'),
					'_parent' => __('Parent', 'useful-addons-elementor'),
					'_self'   => __('Self', 'useful-addons-elementor'),
					'_top'    => __('Top', 'useful-addons-elementor'),
				],
			]
		);
		$repeater->add_control( 'UA_page_link_rel',
			[
				'label'        => __( 'Rel', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater->add_control( 'UA_page_list_select',
			[
				'label'    => __( 'Select Page', 'useful-addons-elementor' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => false,
				'default'  => [],
				'options'  => $this->UA_get_all_page_types(),
			]
		);
		$repeater->add_control( 'UA_page_list_icon_dependency',
			[
				'label'        => __( 'Show Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater->add_control('UA_page_list_icon',
			[
				'label'            => __( 'Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fas fa-check',
					'library' => 'solid',
				],
				'recommended'  => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'UA_page_list_icon_dependency' => 'yes',
				],
			]
		);
		$this->add_control( 'UA_page_list_repeat',
			[
				'label'  => __( 'List', 'useful-addons-elementor' ),
				'type'   => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		$this->end_controls_section();
	}
	/* UA Page List Style Controls */
	private function get_style_page_list( ){
		$this->start_controls_section( 'UA_page_list_styles',
			[
				'label' => __('List', 'useful-addons-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_page_list_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_page_list_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_page_list_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_page_list_nrml_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_page_list_nrml_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a',
			]
		);
		$this->add_responsive_control( 'UA_page_list_nrml_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_page_list_nrml_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a',
			]
		);
		$this->add_responsive_control( 'UA_page_list_nrml_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_page_list_nrml_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'UA_page_list_hv_tabs',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_page_list_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f42ec',
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_page_list_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_page_list_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover',
			]
		);
		$this->add_responsive_control( 'UA_page_list_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_page_list_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover',
			]
		);
		$this->add_responsive_control( 'UA_page_list_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_page_list_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_UA_page_list_tabs',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control( 'UA_page_list_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'UA_page_list_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_page_list_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a',
			]
		);
		$this->end_controls_section();
	}
	/* UA Page List Icon Style Controls */
	private function get_style_page_list_icon( ){
		$this->start_controls_section( 'UA_page_list_icon_styles',
			[
				'label' => __('Icon', 'useful-addons-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_page_list_icon_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_page_list_icon_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_page_list_icon_nrml_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#2e3d62',
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_page_list_icon_nrml_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(46, 61, 98, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_page_list_icon_nrml_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i',
			]
		);
		$this->add_responsive_control( 'UA_page_list_icon_nrml_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_page_list_icon_nrml_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i',
			]
		);
		$this->add_responsive_control( 'UA_page_list_icon_nrml_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_page_list_icon_nrml_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'UA_page_list_icon_hv_tabs',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_page_list_icon_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_page_list_icon_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f42ec',
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover i' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'UA_page_list_icon_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover i',
			]
		);
		$this->add_responsive_control( 'UA_page_list_icon_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_page_list_icon_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover i',
			]
		);
		$this->add_responsive_control( 'UA_page_list_icon_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_page_list_icon_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a:hover i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_UA_page_list_icon_tabs',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_control( 'UA_page_list_icon_size',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 15,
				],
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'UA_page_list_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 28,
				],
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'UA_page_list_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 28,
				],
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'UA_page_list_icon_lheight',
			[
				'label'      => __( 'Line Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 28,
				],
				'selectors' => [
					'{{WRAPPER}} .UA_page_list_section .UA_page_title ul li a i' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	protected function _register_controls() {
		$this->get_content_page_list();
		$this->get_style_page_list();
		$this->get_style_page_list_icon();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();
		if($settings['UA_page_list_view'] == 'inline') {
			$view_style = ' page_inline_style';
		} else {
			$view_style = ' ';
		}
		?>
        <div class="UA_page_list_section">
            <div class="UA_page_title <?php echo esc_attr($view_style); ?>">
                <ul>
					<?php foreach ($settings['UA_page_list_repeat'] as $index => $item) :
						$post = !empty( $item['UA_page_list_select'] ) ? get_post($item['UA_page_list_select']) : 0;
						if($post != null):
							$UA_list_title = $post->post_title;
							if($item['UA_page_link_rel'] == 'yes') {
								$item_rel = 'nofollow';
							} else {
								$item_rel = ' ';
							}
							?>
                            <li>
                                <a href="<?php echo esc_url(get_the_permalink($post->ID)); ?>" target="<?php echo esc_attr($item['UA_page_target']); ?>" rel="<?php echo esc_attr($item_rel); ?>" class="transition-all-3s UA-repeater-item-<?php echo esc_attr( $item[ '_id' ] ); ?>">
									<?php if( $item['UA_page_list_icon_dependency'] == 'yes') {
										if ( !empty( $item['UA_page_list_icon'] ) ) {
											Icons_Manager::render_icon( $item['UA_page_list_icon'], [ 'aria-hidden' => 'true' ] );
										}
									}
									echo $UA_list_title ?>
                                </a>
                            </li>
						<?php
						endif;
					endforeach;
					?>
                </ul>
            </div>
        </div>


	<?php }

	protected function _content_template() { }
}

Plugin::instance()->widgets_manager->register_widget_type( new UA_page_lists() );