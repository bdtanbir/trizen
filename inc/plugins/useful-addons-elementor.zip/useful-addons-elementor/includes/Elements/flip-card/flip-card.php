<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class ua_flip_card extends Widget_Base {
	public function get_name() {
		return 'ua_flip_card';
	}

	public function get_title() {
		return esc_html__( 'Flip Card', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-flip-box ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/*----------------------------------
	    UA Get Category Content
	------------------------------------*/
	private function flip_card_front_content() {
		$this->start_controls_section( 'flip_card_front_content',
			[
				'label' => __( 'Front', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'flip_card_front_image',
			[
				'label' => __( 'Choose Image', 'useful-addons-elementor' ),
				'type'  => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control( 'flip_card_front_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Web Development', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'flip_card_front_stitle',
			[
				'label'       => __( 'Sub Title', 'useful-addons-elementor' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '244 courses', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your sub title here', 'useful-addons-elementor' ),
			]
		);
		$this->end_controls_section();
    }
	private function flip_card_back_content() {
		$this->start_controls_section( 'flip_card_back_content',
			[
				'label' => __( 'Back', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'flip_card_back_image',
			[
				'label' => __( 'Choose Image', 'useful-addons-elementor' ),
				'type'  => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control( 'flip_card_back_btn_txt',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'label_block' => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'View Course', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'flip_card_back_btn_url',
			[
				'label'         => __( 'Button URL', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow'    => true,
				],
			]
		);
		$this->end_controls_section();
	}
	private function flip_card_title_style() {
		$this->start_controls_section( 'flip_card_title_style',
			[
				'label' => __( 'Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'flip_card_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content h3' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'flip_card_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content h3',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'flip_card_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content h3',
			]
		);
		$this->add_control( 'flip_card_title_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content h3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'flip_card_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'flip_card_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function flip_card_stitle_style() {
		$this->start_controls_section( 'flip_card_stitle_style',
			[
				'label' => __( 'Sub Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'flip_card_stitle_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'flip_card_stitle_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content p',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'flip_card_stitle_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content p',
			]
		);
		$this->add_control( 'flip_card_stitle_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content p' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'flip_card_stitle_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'flip_card_stitle_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '4',
                    'right'  => '0',
                    'bottom' => '0',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-content p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function flip_card_btn_style() {
		$this->start_controls_section( 'flip_card_btn_style',
			[
				'label' => __( 'Button', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'flip_card_btn_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn',
			]
		);
		/* ---------------------------
		    Start Tab
		-----------------------------*/
		$this->start_controls_tabs( 'flip_card_btn_tab',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'flip_card_btn_nrml',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'flip_card_btn_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'flip_card_btn_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'flip_card_btn_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#ffffff',
					],
				],
				'selector' => '{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn',
			]
		);
		$this->add_control( 'flip_card_btn_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '5',
                    'right'  => '5',
                    'bottom' => '5',
                    'left'   =>  '5',
                    'unit'   => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'flip_card_btn_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn',
			]
		);
		$this->add_responsive_control( 'flip_card_btn_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '20',
					'bottom' => '0',
					'left'   =>  '20',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'flip_card_btn_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'flip_card_btn_hv',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'flip_card_btn_clr_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'flip_card_btn_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'flip_card_btn_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn:hover',
			]
		);
		$this->add_control( 'flip_card_btn_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'flip_card_btn_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn:hover',
			]
		);
		$this->add_responsive_control( 'flip_card_btn_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'flip_card_btn_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .ua-flip-card-btn:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		/* ---------------------------
		    End Tab
		-----------------------------*/
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* ---------------------------
		    End Tab
		-----------------------------*/
		$this->end_controls_section();
	}
	private function flip_card_box_style() {
		$this->start_controls_section( 'flip_card_box_style',
			[
				'label' => __( 'Box', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control( 'flip_card_box_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-flip-card-item .front' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ua-flip-card-item .back'  => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/* ---------------------------
		    Start Tab
		-----------------------------*/
		$this->start_controls_tabs( 'flip_card_box_tab',
			[
				'separator' => 'before',
			]
		);
        // normal tab
        $this->start_controls_tab( 'flip_card_box_nrml',
            [
                'label'     => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control( 'flip_card_box_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#233d63',
                'selectors' => [
                    '{{WRAPPER}} .ua-flip-card-item .front' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .ua-flip-card-item .back'  => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control( Group_Control_Border::get_type(),
            [
                'name'     => 'flip_card_box_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-flip-card-item .front, {{WRAPPER}} .ua-flip-card-item .back',
            ]
        );
		$this->add_control( 'flip_card_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '4',
                    'right'  => '4',
                    'bottom' => '4',
                    'left'   => '4',
                    'unit'   => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .front' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-flip-card-item .back'  => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'flip_card_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.05)'
						]
					]
				],
				'selector' => '{{WRAPPER}} .ua-flip-card-item .front, {{WRAPPER}} .ua-flip-card-item .back',
			]
		);
		$this->add_responsive_control( 'flip_card_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .front' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-flip-card-item .back'  => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'flip_card_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item .front' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-flip-card-item .back'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_tab();
        // hover tab
        $this->start_controls_tab( 'flip_card_box_hv',
            [
                'label'     => __( 'Hover', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control( 'flip_card_box_bg_hv',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-flip-card-item:hover .front' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .ua-flip-card-item:hover .back'  => 'background: {{VALUE}}',
                ],
            ]
        );
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'flip_card_box_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-flip-card-item:hover .front, {{WRAPPER}} .ua-flip-card-item:hover .back',
			]
		);
		$this->add_control( 'flip_card_box_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item:hover .front' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-flip-card-item:hover .back'  => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'flip_card_box_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-flip-card-item:hover .front, {{WRAPPER}} .ua-flip-card-item:hover .back',
			]
		);
		$this->add_responsive_control( 'flip_card_box_padding_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item:hover .front' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-flip-card-item:hover .back'  => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'flip_card_box_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-flip-card-item:hover .front' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-flip-card-item:hover .back'  => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_tab();
		$this->end_controls_tabs();
		/* ---------------------------
		    End Tab
		-----------------------------*/
		$this->add_control( 'flip_card_box_overlay_hd',
			[
				'label'     => __( 'Overlay', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
		$this->add_control( 'flip_card_box_overlay_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(35, 61, 99,0.8)',
				'selectors' => [
					'{{WRAPPER}} .ua-flip-card-item .front:before' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-flip-card-item .back:before'  => 'background: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls() {
		$this->flip_card_front_content();
		$this->flip_card_back_content();
		$this->flip_card_title_style();
		$this->flip_card_stitle_style();
		$this->flip_card_btn_style();
		$this->flip_card_box_style();

	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();

		$target   = $settings['flip_card_back_btn_url']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['flip_card_back_btn_url']['nofollow'] ? ' rel="nofollow"' : '';

		?>
        <div class="ua-flip-card-item">
            <div class="front">
                <?php if(!empty($settings['flip_card_front_image'])) { ?>
                    <img src="<?php echo esc_url($settings['flip_card_front_image']['url']); ?>" alt="<?php esc_attr_e('Flip Image', 'useful-addons-elementor'); ?>">
				<?php } ?>
                <div class="ua-flip-card-content text-center position-absolute d-flex align-items-center justify-content-center flex-wrap flex-column">
                    <?php if(!empty($settings['flip_card_front_title'])) { ?>
                        <h3 class="transition-all-3s">
                            <?php echo esc_html($settings['flip_card_front_title']); ?>
                        </h3>
                    <?php } if(!empty($settings['flip_card_front_stitle'])) { ?>
                        <p class="transition-all-3s">
                            <?php echo esc_html($settings['flip_card_front_stitle']); ?>
                        </p>
                    <?php } ?>
                </div>
            </div>

            <div class="back">
                <?php if(!empty($settings['flip_card_back_image'])) { ?>
                    <img src="<?php echo esc_url($settings['flip_card_back_image']['url']); ?>" alt="<?php esc_attr_e('Flip Image', 'useful-addons-elementor'); ?>">
                <?php } ?>
                <div class="ua-flip-card-content text-center position-absolute d-flex align-items-center justify-content-center flex-wrap flex-column">
                    <?php if(!empty($settings['flip_card_back_btn_txt'])) { ?>
                        <a href="<?php echo esc_url($settings['flip_card_back_btn_url']['url']); ?>" class="ua-flip-card-btn transition-all-3s" <?php echo esc_attr($target) . esc_attr($nofollow); ?>>
                            <?php echo esc_html($settings['flip_card_back_btn_txt']); ?>
                        </a>
                    <?php } ?>
                </div>
            </div>
        </div>
		<?php
	}

	protected function _content_template() { }
}
Plugin::instance()->widgets_manager->register_widget_type( new ua_flip_card() );