<?php

namespace Elementor;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class UA_course_grid extends Widget_Base {
	public function get_name() {
		return 'UA_course_grid';
	}

	public function get_title() {
		return esc_html__( 'Course Grid', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-info-box ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/**
	 * All authors name and ID, who published at least 1 post.
	 * @return array
	 */
	public function get_authors() {
		$user_query = new \WP_User_Query(
			[
				'who' => 'authors',
				'has_published_posts' => true,
				'fields' => [
					'ID',
					'display_name',
				],
			]
		);

		$authors = [];

		foreach ($user_query->get_results() as $result) {
			$authors[$result->ID] = $result->display_name;
		}

		return $authors;
	}

	/* UA Course Grid Controls */
	private function get_query_course_grid() {
		$this->start_controls_section( 'course_grid_query_setting',
			[
				'label' => __( 'Query', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'course_authors',
			[
				'label'       => __('Author', 'useful-addons-elementor'),
				'label_block' => true,
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'default'     => [],
				'options'     => $this->get_authors(),

			]
		);
        $this->add_control('course_by_ids',
            [
                'label'       => __( 'Course By ID', 'useful-addons-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter course ids here for example: <strong>1, 2, 3</strong>', 'useful-addons-elementor' ),
            ]
        );
		$this->add_control( 'course_grid_post_per_page',
			[
				'label'   => __( 'Posts Per Page', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
				'default' => 9,
			]
		);
		$this->add_control( 'course_grid_order_by',
			[
				'label'             => __( 'Order By', 'useful-addons-elementor' ),
				'type'              => Controls_Manager::SELECT,
				'default'           => 'date',
				'options'           => [
					'ID'            => 'Post ID',
					'author'        => 'Post Author',
					'title'         => 'Title',
					'date'          => 'Date',
					'modified'      => 'Last Modified Date',
					'parent'        => 'Parent Id',
					'rand'          => 'Random',
					'comment_count' => 'Comment Count',
					'menu_order'    => 'Menu Order',
				],
			]
		);
		$this->add_control( 'course_grid_order',
			[
				'label'    => __('Order', 'useful-addons-elementor'),
				'type'     => Controls_Manager::SELECT,
				'options'  => [
					'asc'  => 'Ascending',
					'desc' => 'Descending',
				],
				'default'  => 'desc',

			]
		);
		$this->end_controls_section();
	}
	private function get_layout_course_grid() {
		$this->start_controls_section( 'course_grid_layout_setting',
			[
				'label' => __( 'Layout', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'course_grid_layout_style',
			[
				'label'        => __( 'Layout Style', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => 'grid',
				'options'      => [
					'grid'     => 'Grid',
					'carousel' => 'Carousel',
				],
			]
		);
		$this->add_control( 'course_grid_columns',
			[
				'label'   => __( 'Number of Columns', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '4',
				'options' => [
					'12'  => __( '1 Column', 'useful-addons-elementor' ),
					'6'   => __( '2 Columns', 'useful-addons-elementor' ),
					'4'   => __( '3 Columns', 'useful-addons-elementor' ),
					'3'   => __( '4 Columns', 'useful-addons-elementor' ),
					'1'   => __( '6 Columns', 'useful-addons-elementor' ),
				],
                'condition' => [
                    'course_grid_layout_style' => 'grid'
                ]
			]
		);
		$this->add_control( 'course_grid_show_image',
			[
				'label'        => __('Show Image', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_badge',
			[
				'label'        => __('Show Badge', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_badge_shp',
			[
				'label'        => __('Show Badge Shape', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
                    'course_grid_show_badge' => 'yes'
                ]
			]
		);
		$this->add_control( 'course_grid_show_level',
			[
				'label'        => __('Show Level', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_wishlist_btn',
			[
				'label'        => __('Show Wishlist Button', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_title',
			[
				'label'        => __('Show Title', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_author',
			[
				'label'        => __('Show Author', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_rating',
			[
				'label'        => __('Show Rating', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_classes',
			[
				'label'        => __('Show Classes', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_classes_icon',
			[
				'label'        => __('Show Classes Icon', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
                    'course_grid_show_classes' => 'yes',
                ]
			]
		);
		$this->add_control( 'course_grid_classes_icon',
			[
				'label'   => __( 'Icon', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'la la-play-circle',
					'library' => 'solid',
				],
                'condition' => [
					'course_grid_show_classes'      => 'yes',
                    'course_grid_show_classes_icon' => 'yes'
                ]
			]
		);
		$this->add_control( 'course_grid_show_duration',
			[
				'label'        => __('Show Course Duration', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_duration_icon',
			[
				'label'        => __('Show Duration Icon', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'course_grid_show_duration' => 'yes'
				]
			]
		);
		$this->add_control( 'course_grid_duration_icon',
			[
				'label'   => __( 'Icon', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'la la-clock',
					'library' => 'solid',
				],
				'condition' => [
					'course_grid_show_duration'      => 'yes',
					'course_grid_show_duration_icon' => 'yes'
				]
			]
		);
		$this->add_control( 'course_grid_show_price',
			[
				'label'        => __('Show Price', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_addtocart_btn',
			[
				'label'        => __('Show Add to cart Button', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_hv_pp_card',
			[
				'label'        => __('Show Hover Popup Card', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_show_pagination',
			[
				'label'        => __('Show Pagination', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->end_controls_section();
	}
	private function get_pp_course_card_grid() {
		$this->start_controls_section( 'course_grid_pp_setting',
			[
				'label'     => __( 'Card Popup Layout', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'course_grid_show_hv_pp_card' => 'yes'
                ]
			]
		);
		$this->add_control( 'course_grid_pp_show_author',
			[
				'label'        => __('Show Author', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_title',
			[
				'label'        => __('Show Title', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_badge',
			[
				'label'        => __('Show Badge', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_category',
			[
				'label'        => __('Show Category', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_ratings',
			[
				'label'        => __('Show Ratings', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_excerpt',
			[
				'label'        => __('Show Excerpt', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_materials',
			[
				'label'        => __('Show Materials', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_classes',
			[
				'label'        => __('Show Classes', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_course_duration',
			[
				'label'        => __('Show Course Duration', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_course_preview_btn',
			[
				'label'        => __('Show Course Preview Button', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_course_price',
			[
				'label'        => __('Show Course Price', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_grid_pp_show_course_addtocart_btn',
			[
				'label'        => __('Show Add to cart Button', 'useful-addons-elementor'),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->end_controls_section();
	}
	private function get_course_carouse_setting() {
		$this->start_controls_section( 'course_carousel_setting',
			[
				'label'     => __( 'Carousel Setting', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => [
					'course_grid_layout_style' => 'carousel'
				]
			]
		);
		$this->add_control( 'course_carousel_slides_show',
			[
				'label'   => __( 'Slides To Show', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 6,
				'step'    => 1,
				'default' => 3,
			]
		);
		$this->add_control( 'course_carousel_infinite_lope',
			[
				'label'        => __( 'Infinite Loop', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_carousel_autoplay',
			[
				'label'        => __( 'Autoplay', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_carousel_autop_spd',
			[
				'label'   => __( 'Autoplay Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 100,
				'max'     => 50000,
				'step'    => 50,
				'default' => 500,
				'condition' => [
					'course_carousel_autoplay' => 'yes'
				]
			]
		);
		$this->add_control( 'course_carousel_autoh',
			[
				'label'        => __( 'AutoHeight', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control( 'course_carousel_navigation',
			[
				'label'   => __( 'Navigation', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dots',
				'options' => [
					'arrows_dots' => __( 'Arrows And Dots', 'useful-addons-elementor' ),
					'arrows'      => __( 'Arrows', 'useful-addons-elementor' ),
					'dots'        => __( 'Dots', 'useful-addons-elementor' ),
					'none'        => __( 'None', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control('course_carousel_left_arrow_icon',
			[
				'label'            => __( 'Arrow Left', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'la la-angle-left',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control('course_carousel_right_arrow_icon',
			[
				'label'            => __( 'Arrow Right', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'la la-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots'],
				],
			]
		);
		$this->add_control( 'course_carousel_animation_spd',
			[
				'label'   => __( 'Animation Speed', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 100,
				'max'     => 50000,
				'step'    => 50,
				'default' => 500,
			]
		);
		$this->add_control( 'course_carousel_spc_between',
			[
				'label'   => __( 'Space Between', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 100,
				'step'    => 1,
				'default' => 30,
			]
		);
		$this->end_controls_section();
    }
	private function get_course_grid_img_style() {
		$this->start_controls_section( 'course_grid_img_style',
			[
				'label' => __( 'Image', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'course_grid_show_image' => 'yes'
                ]
			]
		);
		$this->add_responsive_control( 'course_grid_img_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-image a img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_img_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-image a img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'course_grid_img_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '4',
                    'right'    => '4',
                    'bottom'   => '0',
                    'left'     => '0',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-image a img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_img_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-image a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_grid_badge_style() {
		$this->start_controls_section( 'course_grid_badge_style',
			[
				'label' => __( 'Badge', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'course_grid_show_badge' => 'yes'
                ]
			]
		);
		$this->add_control( 'course_grid_badge_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-badge .ua-course-badge-label' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_grid_badge_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-badge .ua-course-badge-label, .ua-course-card-item .ua-course-card-badge .ua-course-badge-label:after' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_grid_badge_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-badge .ua-course-badge-label',
			]
		);
		$this->add_control( 'course_grid_badge_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '4',
                    'right'    => '4',
                    'bottom'   => '4',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-badge .ua-course-badge-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_badge_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '4',
                    'right'    => '10',
                    'bottom'   => '4',
                    'left'     => '12',
                    'unit'     => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-badge .ua-course-badge-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_badge_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_grid_level_style() {
		$this->start_controls_section( 'course_grid_level_style',
			[
				'label' => __( 'Level', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'course_grid_show_level' => 'yes'
                ]
			]
		);
		$this->add_control( 'course_grid_level_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'color: {{VALUE}}',
					'{{WRAPPER}} .tooltipster-content .ua-course-card-item .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_grid_level_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(81, 190, 120, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_grid_level_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label .ua-course-card-label-text',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_level_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label .ua-course-card-label-text',
			]
		);
		$this->add_control( 'course_grid_level_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '30',
                    'right'    => '30',
                    'bottom'   => '30',
                    'left'     => '30',
                    'unit'     => 'px',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_grid_level_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label .ua-course-card-label-text',
			]
		);
		$this->add_responsive_control( 'course_grid_level_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '1',
					'right'    => '12',
					'bottom'   => '1',
					'left'     => '12',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_level_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label .ua-course-card-label-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_grid_wishlist_style() {
		$this->start_controls_section( 'course_grid_wishlist_style',
			[
				'label'     => __( 'Wishlist', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_grid_show_wishlist_btn' => 'yes'
				]
			]
		);
		$this->add_control( 'course_grid_wishlist_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'course_grid_wishlist_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'course_grid_wishlist_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'course_grid_wishlist_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_grid_wishlist_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_grid_wishlist_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_wishlist_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a',
			]
		);
		$this->add_control( 'course_grid_wishlist_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_grid_wishlist_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a',
			]
		);
		$this->add_responsive_control( 'course_grid_wishlist_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_wishlist_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'course_grid_wishlist_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_grid_wishlist_clr_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a:hover, .ua-course-card-item .ua-course-card-collection-icon.has-wish-listed span:before' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_grid_wishlist_bg_hv',
			[
				'label'     => __( 'background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a:hover, .ua-course-card-item .ua-course-card-collection-icon.has-wish-listed span:before' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_wishlist_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a:hover, .ua-course-card-item .ua-course-card-collection-icon.has-wish-listed',
			]
		);
		$this->add_control( 'course_grid_wishlist_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a:hover, .ua-course-card-item .ua-course-card-collection-icon.has-wish-listed' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_grid_wishlist_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a:hover, .ua-course-card-item .ua-course-card-collection-icon.has-wish-listed',
			]
		);
		$this->add_responsive_control( 'course_grid_wishlist_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a:hover, .ua-course-card-item .ua-course-card-collection-icon.has-wish-listed' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_wishlist_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-label a:hover, .ua-course-card-item .ua-course-card-collection-icon.has-wish-listed' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->end_controls_section();
	}
	private function get_course_grid_title_style() {
		$this->start_controls_section( 'course_grid_title_style',
			[
				'label'     => __( 'Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_grid_show_title' => 'yes'
				]
			]
		);
		$this->add_control( 'course_grid_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-title a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_grid_title_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-title a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-title',
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_grid_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-title',
			]
		);
		$this->add_responsive_control( 'course_grid_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '10',
                    'right'    => '0',
                    'bottom'   => '9',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_grid_author_style() {
		$this->start_controls_section( 'course_grid_author_style',
			[
				'label'     => __( 'Author', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_grid_show_author' => 'yes'
				]
			]
		);
		$this->add_control( 'course_grid_author_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-author a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_grid_author_color_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-author a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_grid_author_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-author a',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_author_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-author a',
			]
		);
		$this->add_control( 'course_grid_author_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-author a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_author_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-author a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_author_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-author a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_grid_rating_style() {
		$this->start_controls_section( 'course_grid_rating_style',
			[
				'label'     => __( 'Ratings', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_grid_show_rating' => 'yes'
				]
			]
		);
		$this->add_control( 'course_grid_rating_icon_clr',
			[
				'label'     => __( 'Icon Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#F68A03',
				'selectors' => [
					'{{WRAPPER}} .ua-course-star-rating-wrap .tutor-star-rating-group i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_grid_rating_txt_clr',
			[
				'label'     => __( 'Text Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#4b5981',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-rating-wrap .ua-course-star-rating-wrap .tutor-rating-count' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_rating_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-star-rating-wrap' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'course_grid_rating_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-star-rating-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_grid_classes_style() {
		$this->start_controls_section( 'course_grid_classes_style',
			[
				'label'     => __( 'Classes', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_grid_show_classes' => 'yes'
				]
			]
		);
		$this->add_control( 'course_grid_classes_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-duration .classes' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_grid_classes_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-duration .classes',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_classes_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '0',
							'right'    => '1',
							'bottom'   => '0',
							'left'     => '0',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'rgba(127, 136, 151, 0.2)',
					],
				],
				'selector' => '{{WRAPPER}} .ua-course-card-duration .classes',
			]
		);
		$this->add_responsive_control( 'course_grid_classes_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '15',
                    'bottom' => '0',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-duration .classes' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_classes_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-duration .classes' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_grid_duration_style() {
		$this->start_controls_section( 'course_grid_duration_style',
			[
				'label'     => __( 'Duration', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_grid_show_duration' => 'yes'
				]
			]
		);
		$this->add_control( 'course_grid_duration_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-duration .duration' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_grid_duration_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-duration .duration',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_duration_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-duration .duration',
			]
		);
		$this->add_responsive_control( 'course_grid_duration_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '15',
					'unit'   => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-duration .duration' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_duration_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-duration .duration' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_grid_price_style() {
		$this->start_controls_section( 'course_grid_price_style',
			[
				'label'     => __( 'Price', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_grid_show_price' => 'yes'
				]
			]
		);
		$this->add_control( 'course_grid_price_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_grid_price_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_grid_price_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_price_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price',
			]
		);
		$this->add_control( 'course_grid_price_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_grid_price_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price',
			]
		);
		$this->add_control( 'course_grid_price_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'course_grid_price_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-content .ua-course-card-price-wrap .ua-course-card-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_grid_pagination_style() {
		$this->start_controls_section( 'course_grid_pagination_style',
			[
				'label'     => __( 'Pagination', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_grid_show_pagination' => 'yes'
				]
			]
		);
		$this->add_responsive_control( 'course_grid_pagination_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-pagination > *' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_pagination_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-pagination > *' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_pagination_spc_between',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 10,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-pagination > *' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_gird_pagination_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-pagination > *',
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'course_grid_pagination_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'course_grid_pagination_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_grid_pagination_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-pagination > *' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_grid_pagination_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-pagination > *' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_pagination_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-pagination > *',
			]
		);
		$this->add_control( 'course_grid_pagination_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '50',
                    'right'  => '50',
                    'bottom' => '50',
                    'left'   => '50',
                    'unit'   => '%',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-pagination > *' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_grid_pagination_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.2)'
						]
					]
				],
				'selector' => '{{WRAPPER}} .ua-course-pagination > *',
			]
		);
		$this->add_responsive_control( 'course_grid_pagination_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '3',
					'right'  => '3',
					'bottom' => '3',
					'left'   => '3',
					'unit'   => 'px',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-pagination > *' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_pagination_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-pagination' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'course_grid_pagination_hv',
			[
				'label' => __( 'Hover/Active', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_grid_pagination_clr_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-pagination .current' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ua-course-pagination > *:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_grid_pagination_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51BE78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-pagination .current' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-course-pagination > *:hover'  => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_pagination_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-pagination .current, {{WRAPPER}} .ua-course-pagination > *:hover'
			]
		);
		$this->add_control( 'course_grid_pagination_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-pagination .current, {{WRAPPER}} .ua-course-pagination > *:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_grid_pagination_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-pagination .current, {{WRAPPER}} .ua-course-pagination > *:hover',
			]
		);
		$this->add_responsive_control( 'course_grid_pagination_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-pagination > *:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-course-pagination .current'  => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_pagination_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-pagination ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->end_controls_section();
	}
	private function get_course_grid_card_style() {
		$this->start_controls_section( 'course_grid_card_style',
			[
				'label'     => __( 'Card', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'course_grid_card_tab',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'course_grid_card_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_grid_card_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-course-card-item .ua-course-card-image:after' => 'border-bottom: 12px solid {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'            => 'course_grid_card_border',
				'label'           => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'rgba(127, 136, 151, 0.2)',
					],
				],
				'selector'        => '{{WRAPPER}} .ua-course-card-item',
			]
		);
		$this->add_control( 'course_grid_card_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '4',
					'right'  => '4',
					'bottom' => '4',
					'left'   => '4',
					'unit'   => 'px',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_gird_card_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item',
			]
		);
		$this->add_responsive_control( 'course_grid_card_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_card_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '30',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false
				],
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'course_grid_card_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_grid_card_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-course-card-item:hover' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-course-card-item:hover .ua-course-card-image:after' => 'border-bottom: 12px solid {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_grid_card_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-card-item:hover',
			]
		);
		$this->add_control( 'course_grid_card_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_gird_card_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
				'selector' => '{{WRAPPER}} .ua-course-card-item:hover',
			]
		);
		$this->add_responsive_control( 'course_grid_card_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_grid_card_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-card-item:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->end_controls_section();
	}

	/* Course Carousel */
	private function get_course_carousel_navigation_style() {
		$this->start_controls_section( 'course_carousel_navigation_style',
			[
				'label'     => __( 'Carousel Navigation', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'dots', 'arrows_dots']
				]
			]
		);
		/*-------------------------
		    Start Arrow
		 *------------------------- */
		$this->add_control( 'carousel_nav_arrow_hd',
			[
				'label'     => __( 'Arrow', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'after',
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_arrow_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_arrow_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 40,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_arrow_size',
			[
				'label'      => __( 'Font Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_arrow_lt_translate',
			[
				'label'      => __( 'Arrow Left TranslateX', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => -50,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav .owl-prev' => 'left: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_arrow_rt_translate',
			[
				'label'      => __( 'Arrow Right TranslateX', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min'  => -500,
						'max'  => 500,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => -50,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav .owl-next' => 'right: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'carousel_nav_arrow_tab',
			[
				'separator' => 'before',
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		// normal tab
		$this->start_controls_tab( 'carousel_nav_arrow_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_control( 'carousel_nav_arrow_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *' => 'color: {{VALUE}}',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_control( 'carousel_nav_arrow_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *' => 'background: {{VALUE}}',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'carousel_nav_arrow_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#51be78',
					],
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_control( 'carousel_nav_arrow_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '50',
					'right'  => '50',
					'bottom' => '50',
					'left'   => '50',
					'unit'   => '%',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'carousel_nav_arrow_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *',
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.2)'
						]
					]
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_arrow_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'carousel_nav_arrow_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_control( 'carousel_nav_arrow_clr_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *:hover' => 'color: {{VALUE}}',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_control( 'carousel_nav_arrow_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *:hover' => 'background: {{VALUE}}',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'carousel_nav_arrow_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *:hover',
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_control( 'carousel_nav_arrow_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'carousel_nav_arrow_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *:hover',
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_arrow_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-nav > *:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['arrows', 'arrows_dots']
				]
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		/*-------------------------
		    End Arrow
		 *------------------------- */
		/*-------------------------
		    Start Dots
		 *------------------------- */
		$this->add_control( 'carousel_nav_dot_hd',
			[
				'label'     => __( 'Dots', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'carousel_nav_dot_tab',
			[
				'separator' => 'before',
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		// normal tab
		$this->start_controls_tab( 'carousel_nav_dot_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_control( 'carousel_nav_dot_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(127, 136, 151, 0.4)',
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *' => 'background: {{VALUE}}',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_dot_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_dot_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'   => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'      => 'carousel_nav_dot_border',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *',
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_control( 'carousel_nav_dot_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '50',
					'right'  => '50',
					'bottom' => '50',
					'left'   => '50',
					'unit'   => '%',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_dot_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'carousel_nav_dot_hv',
			[
				'label' => __( 'Hover/Active', 'useful-addons-elementor' ),
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_control( 'carousel_nav_dot_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *:hover' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots .active' => 'background: {{VALUE}}',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_dot_width_hv',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *:hover' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots .active' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_dot_height_hv',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *:hover' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots .active' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'      => 'carousel_nav_dot_border_hv',
				'label'     => __( 'Border', 'useful-addons-elementor' ),
				'selector'  => '{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *:hover, {{WRAPPER}} .ua-course-grid-carousel .owl-dots .active',
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_control( 'carousel_nav_dot_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots .active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->add_responsive_control( 'carousel_nav_dot_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots .active' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_responsive_control( 'carousel_nav_dot_spc_between',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'   => [
					'unit'  => 'px',
					'size'  => 2
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-grid-carousel .owl-dots > *' => 'margin: 0 {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'course_carousel_navigation' => ['dots', 'arrows_dots']
				]
			]
		);
		/*-------------------------
		    End Dots
		 *------------------------- */
		$this->end_controls_section();
	}

	protected function _register_controls() {
        $this->get_query_course_grid();
        $this->get_layout_course_grid();
        $this->get_pp_course_card_grid();
        $this->get_course_carouse_setting(); // course carousel
        $this->get_course_grid_img_style();
        $this->get_course_grid_badge_style();
        $this->get_course_grid_level_style();
        $this->get_course_grid_wishlist_style();
        $this->get_course_grid_title_style();
        $this->get_course_grid_author_style();
        $this->get_course_grid_rating_style();
        $this->get_course_grid_classes_style();
        $this->get_course_grid_duration_style();
        $this->get_course_grid_price_style();
        $this->get_course_grid_pagination_style();
        $this->get_course_grid_card_style();

        /* course carousel style */
        $this->get_course_carousel_navigation_style();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$course_ids = explode(',', $settings['course_by_ids']);


		if(!empty($settings['course_by_ids'])) {
			$default = array(
				'post_type'       => 'courses',
				'posts_per_page'  => $settings['course_grid_post_per_page'],
				'author'          => $settings['course_authors'],
				'post__in'        => $course_ids,
				'orderby'         => $settings['course_grid_order_by'],
				'order'           => $settings['course_grid_order'],
				'paged'           => get_query_var('paged') ? get_query_var('paged') : 1
			);
		} else {
			$default = array(
				'post_type'       => 'courses',
				'posts_per_page'  => $settings['course_grid_post_per_page'],
				'author'          => $settings['course_authors'],
				'orderby'         => $settings['course_grid_order_by'],
				'order'           => $settings['course_grid_order'],
				'paged'           => get_query_var('paged') ? get_query_var('paged') : 1
			);
        }
		$courses = new \WP_Query($default)

		?>
		<div class="ua-course-grid-wrap">
            <?php if($settings['course_grid_layout_style'] === 'grid') { ?>
                <div class="row align-items-startw">
                <?php
                if ( $courses->have_posts() ) :
                    while ( $courses->have_posts() ) : $courses->the_post();
                        global $authordata;
                        $tutor_course_img = get_tutor_course_thumbnail_src();
                        $badge_title      = get_post_meta( get_the_ID(), 'aduca_course_badge_title', true );
                        if ( is_user_logged_in() ) {
                            $whishlist_class = 'tutor-course-wishlist-btn';
                        } else {
                            $whishlist_class = 'cart-required-login';
                        }
                        $course_id     = get_the_ID();
                        $is_wishlisted = tutor_utils()->is_wishlisted( $course_id );
                        $has_wish_list = '';
                        if ( $is_wishlisted ) {
                            $has_wish_list = 'has-wish-listed';
                        }
                        $total_lessons     = tutor_utils()->get_lesson_count_by_course();
                        $course_duration   = get_tutor_course_duration_context();
                        $course_materials  = tutor_course_material_includes();
                        $course_categories = get_tutor_course_categories();

                        if(!$settings['course_grid_show_image'] == 'no') {
                            $card_img_shape = ' course-img-shape-none';
                        } else {
							$card_img_shape = '';
						}
                        if($settings['course_grid_show_badge_shp'] === 'yes') {
                            $badgeshape = '';
                        } else {
							$badgeshape = 'hide-shape';
						}

						if($settings['course_grid_show_hv_pp_card'] === 'yes') {
							$hovercard = '#ua_course_grid_card_tooltip_'.$course_id.'';
						} else {
							$hovercard = ' ';
						}

                        ?>
                            <div class="col-lg-<?php echo esc_attr($settings['course_grid_columns']); ?> col-md-6">
                                <div class="ua-course-grid-item">
                                    <div class="ua-course-card-item transition-all-3s ua-card-preview" data-tooltip-content="<?php echo esc_attr($hovercard); ?>">
                                        <?php if(!empty($tutor_course_img) || !empty($badge_title)) {
                                            if($settings['course_grid_show_image'] === 'yes' || $settings['course_grid_show_badge'] === 'yes') {
                                            ?>
                                            <div class="ua-course-card-image position-relative <?php echo esc_attr($card_img_shape); ?>">
                                                <?php
                                                if ( ! empty( $tutor_course_img ) && $settings['course_grid_show_image'] === 'yes' ) { ?>
                                                    <a href="<?php the_permalink(); ?>" class="ua-course-card-img d-block relative">
                                                        <img src="<?php echo esc_url( $tutor_course_img ); ?>" alt="<?php esc_attr_e('Course Image', 'useful-addons-elementor'); ?>" width="358" height="239">
                                                    </a>
                                                <?php } if(!empty($badge_title) && $settings['course_grid_show_badge'] === 'yes') { ?>
                                                    <div class="ua-course-card-badge position-absolute <?php echo esc_attr($badgeshape); ?>">
                                                        <span class="ua-course-badge-label relative d-inline-block">
                                                            <?php esc_html_e($badge_title); ?>
                                                        </span>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        <?php
                                            }
                                        } ?>
                                        <div class="ua-course-card-content">
                                            <p class="ua-course-card-label d-flex align-items-center justify-content-between">
                                                <?php if(get_tutor_course_level() && $settings['course_grid_show_level'] === 'yes') { ?>
                                                    <span class="ua-course-card-label-text d-inline-block">
                                                        <?php echo get_tutor_course_level(); ?>
                                                    </span>
                                                <?php }

                                                if($settings['course_grid_show_wishlist_btn'] === 'yes') {
													echo '
                                                    <a href="javascript:;" class="ua-course-card-collection-icon d-inline-block ' . esc_attr($whishlist_class) . ' ' . esc_attr($has_wish_list) . '" data-course-id="' . esc_attr($course_id) . '">
                                                        <span class="la la-heart"></span>
                                                    </a>';
												}
                                                ?>
                                            </p>
                                            <?php if(get_the_title() && $settings['course_grid_show_title'] === 'yes') { ?>
                                                <h3 class="ua-course-card-title">
                                                    <a class="transition-all-3s" href="<?php the_permalink(); ?>">
                                                        <?php the_title(); ?>
                                                    </a>
                                                </h3>
                                            <?php }
                                            if($settings['course_grid_show_author'] === 'yes') { ?>
                                                <p class="ua-course-card-author">
                                                    <a class="transition-all-3s" href="<?php echo tutor_utils()->profile_url($authordata->ID); ?>">
                                                        <?php echo get_the_author(); ?>
                                                    </a>
                                                </p>
                                            <?php } ?>
                                            <div class="ua-course-rating-wrap d-flex mt-2 mb-3">
                                                <?php if($settings['course_grid_show_rating'] === 'yes') { ?>
                                                    <div class="ua-course-star-rating-wrap">
                                                        <?php
                                                            $course_rating = tutor_utils()->get_course_rating();
                                                            tutor_utils()->star_rating_generator($course_rating->rating_avg);
                                                        ?>
                                                        <span class="tutor-rating-count">
                                                            <?php
                                                                if ($course_rating->rating_avg > 0) {
                                                                    echo apply_filters('tutor_course_rating_average', $course_rating->rating_avg);
                                                                    echo '<span class="star__count">' . esc_html__('(', 'useful-addons-elementor').'' . apply_filters('tutor_course_rating_count', $course_rating->rating_count) . esc_html__(')', 'useful-addons-elementor') . '</span>';
                                                                }
                                                            ?>
                                                        </span>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                            <div class="ua-course-card-action">
                                                <ul class="ua-course-card-duration d-flex align-items-center <?php if(!empty($course_duration) ) { echo 'justify-content-between'; } else { esc_attr_e('justify-content-start', 'useful-addons-elementor'); } ?>">
                                                    <?php if($settings['course_grid_show_classes'] === 'yes') { ?>
                                                        <li class="classes">
                                                            <span class="ua-course-meta-date">
                                                                <?php if($settings['course_grid_show_classes_icon'] === 'yes') { ?>
                                                                <?php Icons_Manager::render_icon( $settings['course_grid_classes_icon'], [ 'aria-hidden' => 'true' ] ); } echo esc_html($total_lessons).esc_html__(' Classes','useful-addons-elementor'); ?>
                                                            </span>
                                                        </li>
                                                    <?php } if($settings['course_grid_show_duration'] === 'yes' && !empty($course_duration)) { ?>
                                                        <li class="duration text-right">
                                                            <span class="ua-course-meta-date">
                                                                <?php if($settings['course_grid_show_duration_icon'] === 'yes') { ?>
                                                                <?php Icons_Manager::render_icon( $settings['course_grid_duration_icon'], [ 'aria-hidden' => 'true' ] ); } echo esc_html($course_duration); ?>
                                                            </span>
                                                        </li>
                                                    <?php } ?>
                                                </ul>
                                            </div>
                                            <div class="ua-course-card-price-wrap d-flex justify-content-between align-items-center">
                                                <?php
                                                if($settings['course_grid_show_price'] === 'yes') {
                                                    $is_purchasable = tutor_utils()->is_course_purchasable();
                                                    $price          = apply_filters('get_tutor_course_price', null, get_the_ID());
                                                    if ($is_purchasable && $price){
                                                        echo '<div class="ua-course-card-price">'.$price.'</div>';
                                                    } else {
                                                        ?>
                                                            <div class="ua-course-card-price free">
                                                                <?php esc_html_e('Free', 'useful-addons-elementor'); ?>
                                                            </div>
                                                        <?php
                                                    }
                                                } if($settings['course_grid_show_addtocart_btn'] === 'yes') {

													$enroll_btn = '<a class="edd-add-to-cart " href="' . get_the_permalink() . '">' . esc_html__( 'Get Enrolled', 'useful-addons-elementor' ) . '</a>';
													if ( tutor_utils()->is_course_purchasable() ) {
														$enroll_btn = tutor_course_loop_add_to_cart( false );
														$enroll_btn = '<div class="price"> ' . $enroll_btn . ' </div>';
													}
													echo ''.$enroll_btn;
												}
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ua_course_tooltip_templates d-none">
                                        <div id="ua_course_grid_card_tooltip_<?php echo esc_attr($course_id) ?>">
                                            <div class="ua-course-card-item transition-all-3s">
                                                <div class="ua-course-card-content">
                                                    <?php if($settings['course_grid_pp_show_author'] === 'yes') { ?>
                                                        <p class="ua-course-card-author">
                                                            <?php esc_html_e('By', 'useful-addons-elementor'); ?> <a class="transition-all-3s" href="<?php echo tutor_utils()->profile_url($authordata->ID); ?>">
                                                                <?php echo get_the_author(); ?>
                                                            </a>
                                                        </p>
                                                    <?php } ?>
                                                    <?php if(get_the_title() && $settings['course_grid_pp_show_title'] === 'yes') { ?>
                                                        <h3 class="ua-course-card-title">
                                                            <a class="transition-all-3s" href="<?php the_permalink(); ?>">
                                                                <?php the_title(); ?>
                                                            </a>
                                                        </h3>
                                                    <?php } ?>
                                                    <p class="ua-course-card-label">
                                                        <?php if(!empty($badge_title) && $settings['course_grid_pp_show_badge'] === 'yes') { ?>
                                                            <span class="ua-course-card-label-text mr-1">
                                                                <?php echo esc_html($badge_title); ?>
                                                            </span>
                                                        <?php } if(is_array($course_categories) && count($course_categories) && $settings['course_grid_pp_show_category'] === 'yes') { ?>
                                                            <span class="mr-1">
                                                                <?php esc_html_e('in', 'useful-addons-elementor'); ?>
                                                            </span>
                                                            <?php
                                                            foreach ($course_categories as $course_category){
                                                                $category_name = $course_category->name;
                                                                $category_link = get_term_link($course_category->term_id);
                                                                echo "<a href=".esc_url($category_link)." class='mr-1'>" . esc_html($category_name) . "</a> <span class='cat-bar'>". esc_html__('|', 'useful-addons-elementor') ." </span> ";
                                                            }
                                                            ?>
                                                        <?php } ?>
                                                    </p>
                                                    <div class="ua-course-rating-wrap d-flex mt-2 mb-3">
                                                        <?php if($settings['course_grid_pp_show_ratings'] === 'yes') { ?>
                                                            <div class="ua-course-star-rating-wrap">
                                                                <?php
                                                                $course_rating = tutor_utils()->get_course_rating();
                                                                tutor_utils()->star_rating_generator($course_rating->rating_avg);
                                                                ?>
                                                                <span class="tutor-rating-count">
                                                                    <?php
                                                                    if ($course_rating->rating_avg > 0) {
                                                                        echo apply_filters('tutor_course_rating_average', $course_rating->rating_avg);
                                                                        echo '<span class="star__count">'.esc_html__('(', 'useful-addons-elementor').'' . apply_filters('tutor_course_rating_count', $course_rating->rating_count) . esc_html__(')', 'useful-addons-elementor') .'</span>';
                                                                    }
                                                                    ?>
                                                                </span>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                    <?php if(get_the_excerpt() && $settings['course_grid_pp_show_excerpt'] === 'yes') { ?>
                                                        <div class="ua-course-card-para mb-3">
                                                            <p class="font-size-14 line-height-24">
                                                                <?php
                                                                    echo wp_trim_words(get_the_excerpt(), '21', ' ');
                                                                ?>
                                                            </p>
                                                        </div>
                                                    <?php }
                                                    if(!empty($course_materials) && is_array($course_materials) && count($course_materials) && $settings['course_grid_pp_show_materials'] === 'yes') { ?>
                                                        <ul class="ua-course-list-items mb-3 font-size-14">
                                                            <?php foreach ($course_materials as $course_material) {
                                                                echo '<li class="position-relative">' . $course_material . '</li>';
                                                            } ?>
                                                        </ul>
                                                    <?php } ?>
                                                    <div class="ua-course-card-action">
                                                        <ul class="ua-course-card-duration d-flex justify-content-between align-items-center">
                                                            <?php if($settings['course_grid_pp_show_classes'] === 'yes') { ?>
                                                                <li class="classes">
                                                                    <span class="ua-course-meta-date">
                                                                        <i class="la la-play-circle"></i> <?php echo esc_html($total_lessons).esc_html__( ' Classes', 'useful-addons-elementor'); ?>
                                                                    </span>
                                                                </li>
                                                            <?php } if($settings['course_grid_pp_show_course_duration'] === 'yes') { ?>
                                                                <li class="duration">
                                                                    <?php if(!empty($course_duration)) { ?>
                                                                        <span class="ua-course-meta-date">
                                                                            <i class="la la-clock-o"></i> <?php echo esc_html($course_duration); ?>
                                                                        </span>
                                                                    <?php } ?>
                                                                </li>
                                                            <?php } ?>
                                                        </ul>
                                                    </div>
                                                    <?php if($settings['course_grid_pp_show_course_preview_btn'] === 'yes') { ?>
                                                        <div class="ua-course-btn-box w-100 text-center mb-3">
                                                            <a href="<?php the_permalink(); ?>" class="theme-btn d-block">
                                                                <?php esc_html_e('Preview this course', 'useful-addons-elementor'); ?>
                                                            </a>
                                                        </div>
                                                    <?php } ?>
                                                    <div class="ua-course-card-price-wrap d-flex justify-content-between align-items-center">
                                                        <?php
                                                        if($settings['course_grid_pp_show_course_price'] === 'yes') {
                                                            $is_purchasable = tutor_utils()->is_course_purchasable();
                                                            $price          = apply_filters('get_tutor_course_price', null, get_the_ID());
                                                            if ($is_purchasable && $price){
                                                                echo '<div class="ua-course-card-price">' . $price . '</div>';
                                                            } else {
                                                                ?>
                                                                <div class="ua-course-card-price free">
                                                                    <?php esc_html_e('Free', 'useful-addons-elementor'); ?>
                                                                </div>
                                                                <?php
                                                            }
                                                        } if($settings['course_grid_pp_show_course_addtocart_btn'] === 'yes') {

															$enroll_btn = '<div  class="tutor-loop-cart-btn-wrap"><a href="' . get_the_permalink() . '">' . esc_html__( 'Get Enrolled', 'useful-addons-elementor' ) . '</a></div>';
															if ( tutor_utils()->is_course_purchasable() ) {
																$enroll_btn = tutor_course_loop_add_to_cart( false );
																$enroll_btn = '<div class="price"> ' . $enroll_btn . ' </div>';
															}
															echo ''.$enroll_btn;
														}
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        endwhile;
                    else :
                        ?>
                        <h1>
                            <?php esc_html_e('No Course Found!', 'useful-addons-elementor'); ?>
                        </h1>
                    <?php
                    endif;
                    if($settings['course_grid_show_pagination']) {
                    ?>
                        <div class="col-lg-12">
                            <div class="ua-course-pagination">
                                <?php
                                $total_pages = $courses->max_num_pages;
                                echo paginate_links( [
                                    'format'    => '?paged=%#%',
                                    'current'   => max(1, get_query_var('paged')),
                                    'prev_text' => __('<i class="la la-arrow-left"></i>', 'useful-addons-elementor'),
                                    'next_text' => __('<i class="la la-arrow-right"></i>', 'useful-addons-elementor'),
                                    'total'     => $total_pages,
                                ] );
                                ?>
                            </div>
                        </div>
                    <?php
                    }
                    do_action('tutor_course/archive/after_loop');
                ?>
                </div>
            <?php } else { ?>

                <?php
                $slidetoshow  = $settings['course_carousel_slides_show'];
                $autoplayspd  = $settings['course_carousel_autop_spd'];
                $larrow       = $settings['course_carousel_left_arrow_icon'];
                $rarrow       = $settings['course_carousel_right_arrow_icon'];
                $animationspd = $settings['course_carousel_animation_spd'];
                $spc_between  = $settings['course_carousel_spc_between'];

                if($settings['course_carousel_infinite_lope'] === 'yes' ){
					$infiniteloop = 'true';
				} else {
					$infiniteloop = 'false';
				}
                if($settings['course_carousel_autoplay'] === 'yes' ){
					$autoplay = 'true';
				} else {
					$autoplay = 'false';
				}
                if($settings['course_carousel_autoh'] === 'yes' ){
					$autoheight = 'true';
				} else {
					$autoheight = 'false';
				}
                if($settings['course_carousel_navigation'] === 'arrows' || $settings['course_carousel_navigation'] === 'arrows_dots' ){
					$navigation = 'true';
				} else {
					$navigation = 'false';
				}
                if($settings['course_carousel_navigation'] === 'dots' || $settings['course_carousel_navigation'] === 'arrows_dots' ){
					$navigation_dot = 'true';
				} else {
					$navigation_dot = 'false';
				}

                if ( $courses->have_posts() ) :
                ?>
                <div class="ua-course-grid-carousel position-relative">
                    <?php
                        while ( $courses->have_posts() ) : $courses->the_post();
                            global $authordata;
                            $tutor_course_img = get_tutor_course_thumbnail_src();
                            $badge_title      = get_post_meta( get_the_ID(), 'aduca_course_badge_title', true );
                            if ( is_user_logged_in() ) {
                                $whishlist_class = 'tutor-course-wishlist-btn';
                            } else {
                                $whishlist_class = 'cart-required-login';
                            }
                            $course_id     = get_the_ID();
                            $is_wishlisted = tutor_utils()->is_wishlisted( $course_id );
                            $has_wish_list = '';
                            if ( $is_wishlisted ) {
                                $has_wish_list = 'has-wish-listed';
                            }
                            $total_lessons     = tutor_utils()->get_lesson_count_by_course();
                            $course_duration   = get_tutor_course_duration_context();
                            $course_materials  = tutor_course_material_includes();
                            $course_categories = get_tutor_course_categories();
							if(!$settings['course_grid_show_image'] == 'no') {
								$card_img_shape = ' course-img-shape-none';
							} else {
								$card_img_shape = '';
							}
							if($settings['course_grid_show_badge_shp'] === 'yes') {
								$badgeshape = '';
							} else {
								$badgeshape = 'hide-shape';
							}
							if($settings['course_grid_show_hv_pp_card'] === 'yes') {
								$hovercard = '#ua_course_sld_card_tooltip_'.$course_id.'';
							} else {
								$hovercard = ' ';
							}
                            ?>
                            <div class="ua-course-grid-item">
                                <div class="ua-course-card-item transition-all-3s ua-card-preview" data-tooltip-content="<?php echo esc_attr($hovercard); ?>">
									<?php if(!empty($tutor_course_img) || !empty($badge_title)) {
										if($settings['course_grid_show_image'] === 'yes' || $settings['course_grid_show_badge'] === 'yes') {
											?>
                                            <div class="ua-course-card-image position-relative <?php echo esc_attr($card_img_shape); ?>">
												<?php
												if ( ! empty( $tutor_course_img ) && $settings['course_grid_show_image'] === 'yes' ) { ?>
                                                    <a href="<?php the_permalink(); ?>" class="ua-course-card-img d-block relative">
                                                        <img src="<?php echo esc_url( $tutor_course_img ); ?>" alt="<?php esc_attr_e('Course', 'useful-addons-elementor'); ?>" width="358" height="239">
                                                    </a>
												<?php } if(!empty($badge_title) && $settings['course_grid_show_badge'] === 'yes') { ?>
                                                    <div class="ua-course-card-badge position-absolute <?php echo esc_attr($badgeshape); ?>">
                                                        <span class="ua-course-badge-label relative d-inline-block">
                                                            <?php esc_html_e($badge_title); ?>
                                                        </span>
                                                    </div>
												<?php } ?>
                                            </div>
											<?php
										}
									} ?>
                                    <div class="ua-course-card-content">
                                        <p class="ua-course-card-label d-flex align-items-center justify-content-between">
											<?php if(get_tutor_course_level() && $settings['course_grid_show_level'] === 'yes') { ?>
                                                <span class="ua-course-card-label-text d-inline-block">
                                                    <?php echo get_tutor_course_level(); ?>
                                                </span>
											<?php }

											if($settings['course_grid_show_wishlist_btn'] === 'yes') {
												echo '
                                                    <a href="javascript:;" class="ua-course-card-collection-icon d-inline-block ' . esc_attr($whishlist_class) . ' ' . esc_attr($has_wish_list) . '" data-course-id="' . esc_attr($course_id) . '">
                                                        <span class="la la-heart"></span>
                                                    </a>';
											}
											?>
                                        </p>
										<?php if(get_the_title() && $settings['course_grid_show_title'] === 'yes') { ?>
                                            <h3 class="ua-course-card-title">
                                                <a class="transition-all-3s" href="<?php the_permalink(); ?>">
													<?php the_title(); ?>
                                                </a>
                                            </h3>
										<?php }
										if($settings['course_grid_show_author'] === 'yes') { ?>
                                            <p class="ua-course-card-author">
                                                <a class="transition-all-3s" href="<?php echo tutor_utils()->profile_url($authordata->ID); ?>">
													<?php echo get_the_author(); ?>
                                                </a>
                                            </p>
										<?php } ?>
                                        <div class="ua-course-rating-wrap d-flex mt-2 mb-3">
											<?php if($settings['course_grid_show_rating'] === 'yes') { ?>
                                                <div class="ua-course-star-rating-wrap">
                                                    <?php
                                                    $course_rating = tutor_utils()->get_course_rating();
                                                    tutor_utils()->star_rating_generator($course_rating->rating_avg);
                                                    ?>
                                                    <span class="tutor-rating-count">
                                                        <?php
                                                        if ($course_rating->rating_avg > 0) {
                                                            echo apply_filters('tutor_course_rating_average', $course_rating->rating_avg);
                                                            echo '<span class="star__count">'.esc_html__('(', 'useful-addons-elementor').'' . apply_filters('tutor_course_rating_count', $course_rating->rating_count) . esc_html__(')', 'useful-addons-elementor') .'</span>';
                                                        }
                                                        ?>
                                                    </span>
                                                </div>
											<?php } ?>
                                        </div>
                                        <div class="ua-course-card-action">
                                            <ul class="ua-course-card-duration d-flex align-items-center <?php if(!empty($course_duration) ) { esc_attr_e('justify-content-between', 'useful-addons-elementor'); } else { esc_attr_e('justify-content-start', 'useful-addons-elementor'); } ?>">
												<?php if($settings['course_grid_show_classes'] === 'yes') { ?>
                                                    <li class="classes">
                                                        <span class="ua-course-meta-date">
                                                            <?php if($settings['course_grid_show_classes_icon'] === 'yes') {
                                                                Icons_Manager::render_icon( $settings['course_grid_classes_icon'], [ 'aria-hidden' => 'true' ] ); } echo esc_html($total_lessons) . esc_html__(' Classes', 'useful-addons-elementor'); ?>
                                                        </span>
                                                    </li>
												<?php } if($settings['course_grid_show_duration'] === 'yes' && !empty($course_duration)) { ?>
                                                    <li class="duration text-right">
                                                        <span class="ua-course-meta-date">
                                                            <?php if($settings['course_grid_show_duration_icon'] === 'yes') {
                                                                Icons_Manager::render_icon( $settings['course_grid_duration_icon'], [ 'aria-hidden' => 'true' ] ); } echo esc_html($course_duration); ?>
                                                        </span>
                                                    </li>
												<?php } ?>
                                            </ul>
                                        </div>
                                        <div class="ua-course-card-price-wrap d-flex justify-content-between align-items-center">
											<?php
											if($settings['course_grid_show_price'] === 'yes') {
												$is_purchasable = tutor_utils()->is_course_purchasable();
												$price          = apply_filters('get_tutor_course_price', null, get_the_ID());
												if ($is_purchasable && $price){
													echo '<div class="ua-course-card-price">' . $price . '</div>';
												} else {
													?>
                                                    <div class="ua-course-card-price free">
														<?php esc_html_e('Free', 'useful-addons-elementor'); ?>
                                                    </div>
													<?php
												}
											} if($settings['course_grid_show_addtocart_btn'] === 'yes') {

												$enroll_btn = '<a class="edd-add-to-cart " href="' . get_the_permalink() . '">' . esc_html__( 'Get Enrolled', 'useful-addons-elementor' ) . '</a>';
												if ( tutor_utils()->is_course_purchasable() ) {
													$enroll_btn = tutor_course_loop_add_to_cart( false );
													$enroll_btn = '<div class="price"> ' . $enroll_btn . ' </div>';
												}
												echo ''.$enroll_btn;
											}
											?>
                                        </div>
                                    </div>
                                </div>
                                <div class="ua_course_tooltip_templates d-none">
                                    <div id="ua_course_sld_card_tooltip_<?php echo esc_attr($course_id); ?>">
                                        <div class="ua-course-card-item transition-all-3s">
                                            <div class="ua-course-card-content">
												<?php if($settings['course_grid_pp_show_author'] === 'yes') { ?>
                                                    <p class="ua-course-card-author">
														<?php esc_html_e('By', 'useful-addons-elementor'); ?> <a class="transition-all-3s" href="<?php echo tutor_utils()->profile_url($authordata->ID); ?>">
															<?php echo get_the_author(); ?>
                                                        </a>
                                                    </p>
												<?php } ?>
												<?php if(get_the_title() && $settings['course_grid_pp_show_title'] === 'yes') { ?>
                                                    <h3 class="ua-course-card-title">
                                                        <a class="transition-all-3s" href="<?php the_permalink(); ?>">
															<?php the_title(); ?>
                                                        </a>
                                                    </h3>
												<?php } ?>
                                                <p class="ua-course-card-label">
													<?php if(!empty($badge_title) && $settings['course_grid_pp_show_badge'] === 'yes') { ?>
                                                        <span class="ua-course-card-label-text mr-1">
                                                            <?php echo esc_html($badge_title); ?>
                                                        </span>
													<?php } if(is_array($course_categories) && count($course_categories) && $settings['course_grid_pp_show_category'] === 'yes') { ?>
                                                        <span class="mr-1">
                                                            <?php esc_html_e('in', 'useful-addons-elementor'); ?>
                                                        </span>
														<?php
														foreach ($course_categories as $course_category){
															$category_name = $course_category->name;
															$category_link = get_term_link($course_category->term_id);
															echo "<a href=".esc_url($category_link)." class='mr-1'>" . esc_html($category_name) . "</a> <span class='cat-bar'>".esc_html__('|', 'useful-addons-elementor')." </span> ";
														}
														?>
													<?php } ?>
                                                </p>
                                                <div class="ua-course-rating-wrap d-flex mt-2 mb-3">
													<?php if($settings['course_grid_pp_show_ratings'] === 'yes') { ?>
                                                        <div class="ua-course-star-rating-wrap">
                                                            <?php
                                                            $course_rating = tutor_utils()->get_course_rating();
                                                            tutor_utils()->star_rating_generator($course_rating->rating_avg);
                                                            ?>
                                                            <span class="tutor-rating-count">
                                                                <?php
                                                                if ($course_rating->rating_avg > 0) {
                                                                    echo apply_filters('tutor_course_rating_average', $course_rating->rating_avg);
                                                                    echo '<span class="star__count">'.esc_html__('(', 'useful-addons-elementor').'' . apply_filters('tutor_course_rating_count', $course_rating->rating_count) . esc_html__(')', 'useful-addons-elementor') .'</span>';
                                                                }
                                                                ?>
                                                            </span>
                                                        </div>
													<?php } ?>
                                                </div>
												<?php if(get_the_excerpt() && $settings['course_grid_pp_show_excerpt'] === 'yes') { ?>
                                                    <div class="ua-course-card-para mb-3">
                                                        <p class="font-size-14 line-height-24">
															<?php
															echo wp_trim_words(get_the_excerpt(), '21', ' ');
															?>
                                                        </p>
                                                    </div>
												<?php }
												if(!empty($course_materials) && is_array($course_materials) && count($course_materials) && $settings['course_grid_pp_show_materials'] === 'yes') { ?>
                                                    <ul class="ua-course-list-items mb-3 font-size-14">
														<?php foreach ($course_materials as $course_material) {
															echo '<li class="position-relative">' . $course_material . '</li>';
														} ?>
                                                    </ul>
												<?php } ?>
                                                <div class="ua-course-card-action">
                                                    <ul class="ua-course-card-duration d-flex justify-content-between align-items-center">
														<?php if($settings['course_grid_pp_show_classes'] === 'yes') { ?>
                                                            <li class="classes">
                                                                <span class="ua-course-meta-date">
                                                                    <i class="la la-play-circle"></i> <?php echo esc_html($total_lessons) . esc_html__(' Classes', 'useful-addons-elementor'); ?>
                                                                </span>
                                                            </li>
														<?php } if($settings['course_grid_pp_show_course_duration'] === 'yes') { ?>
                                                            <li class="duration">
																<?php if(!empty($course_duration)) { ?>
                                                                    <span class="ua-course-meta-date">
                                                                        <i class="la la-clock-o"></i> <?php echo esc_html($course_duration); ?>
                                                                    </span>
																<?php } ?>
                                                            </li>
														<?php } ?>
                                                    </ul>
                                                </div>
												<?php if($settings['course_grid_pp_show_course_preview_btn'] === 'yes') { ?>
                                                    <div class="ua-course-btn-box w-100 text-center mb-3">
                                                        <a href="<?php the_permalink(); ?>" class="theme-btn d-block">
															<?php esc_html_e('Preview this course', 'useful-addons-elementor'); ?>
                                                        </a>
                                                    </div>
												<?php } ?>
                                                <div class="ua-course-card-price-wrap d-flex justify-content-between align-items-center">
													<?php
													if($settings['course_grid_pp_show_course_price'] === 'yes') {
														$is_purchasable = tutor_utils()->is_course_purchasable();
														$price          = apply_filters('get_tutor_course_price', null, get_the_ID());
														if ($is_purchasable && $price){
															echo '<div class="ua-course-card-price">' . $price . '</div>';
														} else {
															?>
                                                            <div class="ua-course-card-price free">
																<?php esc_html_e('Free', 'useful-addons-elementor'); ?>
                                                            </div>
															<?php
														}
													} if($settings['course_grid_pp_show_course_addtocart_btn'] === 'yes') {

														$enroll_btn = '<div  class="tutor-loop-cart-btn-wrap"><a href="' . get_the_permalink() . '">' . esc_html__( 'Get Enrolled', 'useful-addons-elementor' ) . '</a></div>';
														if ( tutor_utils()->is_course_purchasable() ) {
															$enroll_btn = tutor_course_loop_add_to_cart( false );
															$enroll_btn = '<div class="price"> ' . $enroll_btn . ' </div>';
														}
														echo ''.$enroll_btn;
													}
													?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php
                        endwhile;
                    ?>
                </div>
                <?php
                else :
					?>
                    <h1>
						<?php esc_html_e('No Course Found!', 'useful-addons-elementor'); ?>
                    </h1>
				<?php
                endif;
                tutor_course_archive_pagination();
                do_action('tutor_course/archive/after_loop');
                ?>
        </div>


        <script>
            if(jQuery(".ua-course-grid-carousel").length) {
                jQuery('.ua-course-grid-carousel').owlCarousel({
                    loop: <?php echo esc_attr($infiniteloop); ?>,
                    items: <?php echo esc_attr($slidetoshow); ?>,
                    nav: <?php echo esc_attr($navigation); ?>,
                    <?php if($settings['course_carousel_navigation'] === 'arrows' || $settings['course_carousel_navigation'] === 'arrows_dots') { ?>
                    navText: ['<?php if ( !empty( $larrow ) ) { Icons_Manager::render_icon( $larrow, [ 'aria-hidden' => 'true' ] ); } ?>', '<?php if ( !empty( $rarrow ) ) { Icons_Manager::render_icon( $rarrow, [ 'aria-hidden' => 'true' ] ); } ?>'],
                    <?php } ?>
                    dots: <?php echo esc_attr($navigation_dot); ?>,
                    smartSpeed: <?php echo esc_attr($animationspd); ?>,
                    <?php if($settings['course_carousel_autoplay'] === 'yes') { ?>
                    autoplaySpeed: <?php echo esc_attr($autoplayspd); ?>,
                    <?php } ?>
                    autoplay: <?php echo esc_attr($autoplay); ?>,
                    autoHeight: <?php echo esc_attr($autoheight); ?>,
                    margin: <?php echo esc_attr($spc_between); ?>,
                    responsive: {
                        320: {
                            items: 1,
                        },
                        768: {
                            items: 2,
                        },
                        992: {
                            items: <?php echo esc_attr($slidetoshow); ?>,
                        }
                    }
                });
            }
        </script>
    <?php }
	}

	protected function _content_template() {
	}
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_course_grid() );