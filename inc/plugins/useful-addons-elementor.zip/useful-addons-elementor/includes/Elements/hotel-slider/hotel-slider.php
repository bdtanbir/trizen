<?php
// namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_hotel_slider extends \Elementor\Widget_Base {
	public function get_name() {
		return 'UA_hotel_slider';
	}

	public function get_title() {
		return esc_html__( 'Hotel Slider', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-posts-carousel ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}


	private function get_hotel_slider_layout_setting() {
        $this->start_controls_section( 'hotel_slider_layout',
            [
                'label' => __( 'Layout', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('hs_show_btn_icon',
			[
				'label'        => __( 'Show Button Icon', 'useful-addons-elementor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
        $this->add_control('hs_btn_icon',
			[
				'label'   => __( 'Icon', 'useful-addons-elementor' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value'   => 'la la-angle-right',
				],
                'condition' => [
                    'hs_show_btn_icon' => 'yes'
                ]
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_control_setting() {
        $this->start_controls_section( 'hotel_slider_control',
            [
                'label' => __( 'Control', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control('hs_hotel_by_ids',
            [
                'label'       => __( 'Hotel By ID(s)', 'useful-addons-elementor' ),
                'type'        => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'description' => __( 'Enter hotel\'s id(s) here for example: <strong>1, 2, 3</strong>', 'useful-addons-elementor' ),
            ]
        );
		$this->add_control( 'hs_posts_per_page',
			[
				'label'   => __( 'Posts Per Page', 'useful-addons-elementor' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 20,
				'step'    => 1,
				'default' => 10,
			]
		);
        $this->add_control('hs_slide_to_show',
			[
				'label'   => __( 'Slide To Show', 'useful-addons-elementor' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 6,
				'step'    => 1,
				'default' => 4,
			]
		);
        $this->add_control('hs_show_infinite_loop',
			[
				'label'        => __( 'Infinite Loop', 'useful-addons-elementor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'false', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
        $this->add_control('hs_autoplay',
			[
				'label'        => __( 'Autoplay', 'useful-addons-elementor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'false', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
        $this->add_control('hs_autoplay_speed',
			[
				'label'   => __( 'Autoplay Speed', 'useful-addons-elementor' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'min'     => 100,
				'max'     => 50000,
				'step'    => 50,
				'default' => 500,
                'condition' => [
                    'hs_autoplay' => 'yes'
                ],
			]
		);
        $this->add_control('hs_autoheight',
			[
				'label'        => __( 'Autoheight', 'useful-addons-elementor' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'false', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control('hs_navigation',
			[
				'label'   => __( 'Navigation', 'useful-addons-elementor' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'arrow_dots',
				'options' => [
					'arrow_dots'  => __( 'Arrow and Dots', 'useful-addons-elementor' ),
					'arrow'       => __( 'Arrow', 'useful-addons-elementor' ),
					'dots'        => __( 'Dots', 'useful-addons-elementor' ),
					'none'        => __( 'None', 'useful-addons-elementor' ),
				],
			]
		);
        $this->add_control('hs_nav_prev_icon',
			[
				'label'   => __( 'Prev Icon', 'useful-addons-elementor' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value'   => 'la la-angle-left',
				],
                'condition' => [
                    'hs_navigation' => ['arrow', 'arrow_dots']
                ]
			]
		);
        $this->add_control('hs_nav_next_icon',
			[
				'label'   => __( 'Next Icon', 'useful-addons-elementor' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value'   => 'la la-angle-right',
				],
                'condition' => [
                    'hs_navigation' => ['arrow', 'arrow_dots']
                ]
			]
		);
        $this->add_control('hs_animation_speed',
			[
				'label'   => __( 'Animation Speed', 'useful-addons-elementor' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'min'     => 100,
				'max'     => 50000,
				'step'    => 50,
				'default' => 700,
			]
		);
        $this->add_control('hs_space_between',
			[
				'label'   => __( 'Space Between', 'useful-addons-elementor' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 100,
				'step'    => 1,
				'default' => 30,
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_badge_style() {
        $this->start_controls_section( 'hs_badge_style',
            [
                'label' => __( 'Badge', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('hs_badge_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-badge' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control('hs_badge_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#40cc6f',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-badge' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'hs_badge_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-badge',
			]
		);
        $this->add_responsive_control('hs_badge_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '30',
                    'right'    => '30',
                    'bottom'   => '30',
                    'left'     => '30',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_badge_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '6',
                    'right'    => '11',
                    'bottom'   => '6',
                    'left'     => '11',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_badge_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-badge' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_title_style() {
        $this->start_controls_section( 'hs_title_style',
            [
                'label' => __( 'Title', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('hs_title_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#0d233e',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-title a' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control('hs_title_color_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#287dfa',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-title a:hover' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'hs_title_typography',
				'label' => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-title',
			]
		);
        $this->add_responsive_control('hs_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '2',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_title_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_address_style() {
        $this->start_controls_section( 'hs_address_style',
            [
                'label' => __( 'Address', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('hs_address_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#5d646d',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-meta' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'hs_address_typography',
				'label' => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-meta',
			]
		);
        $this->add_responsive_control('hs_address_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '0',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_address_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_review_rate_style() {
        $this->start_controls_section( 'hs_review_rate_style',
            [
                'label' => __( 'Review Rate', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('hs_review_rate_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-rate' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control('hs_review_rate_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#f9b851',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-rate' => 'background: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'hs_review_rate_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-rate',
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'hs_review_rate_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-rate',
			]
		);
        $this->add_responsive_control('hs_review_rate_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-rate' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_review_rate_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-rate' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_review_rate_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-rate' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_review_text_style() {
        $this->start_controls_section( 'hs_review_text_style',
            [
                'label' => __( 'Review Text', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('hs_review_text_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#f9b851',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-text' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'hs_review_text_typography',
				'label' => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-text',
			]
		);
        $this->add_responsive_control('hs_review_text_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '0',
                    'right'    => '4',
                    'bottom'   => '0',
                    'left'     => '4',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_review_text_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_review_number_style() {
        $this->start_controls_section( 'hs_review_number_style',
            [
                'label' => __( 'Review Number', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('hs_review_number_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#5d646d',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-num' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'hs_review_number_typography',
				'label' => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-num',
			]
		);
        $this->add_responsive_control('hs_review_number_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-num' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_review_number_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-rating .ua-hotel-slider-review-num' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_price_before_style() {
        $this->start_controls_section( 'hs_price_before_style',
            [
                'label' => __( 'Price Before Text', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('hs_price_before_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#5d646d',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-from' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'hs_price_before_typography',
				'label' => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-from',
			]
		);
        $this->add_responsive_control('hs_price_before_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-from' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_price_before_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-from' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_price_style() {
        $this->start_controls_section( 'hs_price_style',
            [
                'label' => __( 'Price', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('hs_price_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#0d233e',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-num' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'hs_price_typography',
				'label' => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-num',
			]
		);
        $this->add_responsive_control('hs_price_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-num' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_price_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-num' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_price_after_style() {
        $this->start_controls_section( 'hs_price_after_style',
            [
                'label' => __( 'Price After Text', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('hs_price_after_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#5d646d',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-text' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'hs_price_after_typography',
				'label' => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-text',
			]
		);
        $this->add_responsive_control('hs_price_after_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_price_after_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-price-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_button_style() {
        $this->start_controls_section( 'hs_button_style',
            [
                'label' => __( 'Button', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        /* Start Tab */
		$this->start_controls_tabs( 'hs_btn_tab',
            [
                'separator' => 'before'
            ]
        );
        // normal tab
        $this->start_controls_tab( 'hs_btn_nrml_tab',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('hs_button_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#0d233e',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control('hs_button_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button' => 'background: {{VALUE}}',
				],
			]
		);
        $this->end_controls_tab();
        // hover tab how to change editor tree line color in phpstorm
        $this->start_controls_tab( 'hs_btn_hv_tab',
            [
                'label' => __( 'Hover', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('hs_button_color_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#287dfa',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button:hover' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control('hs_button_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button:hover' => 'background: {{VALUE}}',
				],
			]
		);
        $this->end_controls_tab();
        $this->end_controls_tabs();
        /* End Tab */
        $this->add_control('hs_btn_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'hs_button_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button',
			]
		);
        $this->add_responsive_control('hs_button_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_button_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_button_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_button_icon_style() {
        $this->start_controls_section( 'hs_button_icon_style',
            [
                'label' => __( 'Button Icon', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'hs_show_btn_icon' => 'yes'
                ]
            ]
        );
        $this->add_control('hs_button_icon_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button i' => 'Color: {{VALUE}}',
				],
			]
		);
        $this->add_control('hs_button_icon_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button:hover i' => 'Color: {{VALUE}}',
				],
			]
		);
        $this->add_responsive_control('hs_button_icon_size',
			[
				'label' => __( 'Font size', 'useful-addons-elementor' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 13,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_button_icon_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-price .ua-hotel-slider-button i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_nav_arrow_style() {
        $this->start_controls_section( 'hs_nav_arrow_style',
            [
                'label' => __( 'Navigation (Arrow)', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'hs_navigation' => ['arrow', 'arrow_dots']
                ],
            ]
        );
        /* Start Tab */
		$this->start_controls_tabs( 'hs_nav_arrow_tab',
            [
                'separator' => 'before'
            ]
        );
        // normal tab
        $this->start_controls_tab( 'hs_nav_arrow_nrml_tab',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('hs_nav_arrow_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#0d233e',
                'selectors' => [
                    '{{WRAPPER}} .ua-hotel-slides .owl-nav > *' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_control('hs_nav_arrow_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-hotel-slides .owl-nav > *' => 'background: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_group_control(\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'hs_nav_arrow_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slides .owl-nav > *',
			]
		);
        $this->add_responsive_control('hs_nav_arrow_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'    => '50',
                    'right'  => '50',
                    'bottom' => '50',
                    'left'   => '50',
                    'unit'   => '%',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slides .owl-nav > *' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'hs_nav_arrow_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
				'selector' => '{{WRAPPER}} .ua-hotel-slides .owl-nav > *',
			]
		);
        $this->end_controls_tab();
        // hover tab how to change editor tree line color in phpstorm
        $this->start_controls_tab( 'hs_nav_arrow_hv_tab',
            [
                'label' => __( 'Hover', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('hs_nav_arrow_color_hv',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-hotel-slides .owl-nav > *:hover' => 'color: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_control('hs_nav_arrow_bg_hv',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#287dfa',
                'selectors' => [
                    '{{WRAPPER}} .ua-hotel-slides .owl-nav > *:hover' => 'background: {{VALUE}} !important',
                ],
            ]
        );
        $this->add_group_control(\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'hs_nav_arrow_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slides .owl-nav > *:hover',
			]
		);
        $this->add_responsive_control('hs_nav_arrow_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slides .owl-nav > *:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'hs_nav_arrow_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slides .owl-nav > *:hover',
			]
		);
        $this->end_controls_tab();
        $this->end_controls_tabs();
        /* End Tab */
        $this->add_control('hs_nav_arrow_hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		$this->add_responsive_control('hs_nav_arrow_size',
			[
				'label' => __( 'Font Size', 'useful-addons-elementor' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slides .owl-nav > *' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('hs_nav_arrow_width',
			[
				'label' => __( 'Width', 'useful-addons-elementor' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 45,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slides .owl-nav > *' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('hs_nav_arrow_height',
			[
				'label' => __( 'Height', 'useful-addons-elementor' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 45,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slides .owl-nav > *' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('hs_nav_arrow_line_height',
			[
				'label' => __( 'Line Height', 'useful-addons-elementor' ),
				'type'  => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 45,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slides .owl-nav > *' => 'line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_nav_arrow_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slides .owl-nav > *' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_nav_dots_style() {
        $this->start_controls_section( 'hs_nav_dots_style',
            [
                'label' => __( 'Navigation (Dots)', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'hs_navigation' => ['dots', 'arrow_dots']
                ],
            ]
        );
        /* Start Tab */
		$this->start_controls_tabs( 'hs_nav_dots_tab',
            [
                'separator' => 'before'
            ]
        );
        // normal tab
        $this->start_controls_tab( 'hs_nav_dots_nrml_tab',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('hs_nav_dots_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-hotel-slides .owl-dots .owl-dot' => 'background: {{VALUE}}',
                ],
            ]
        );
		$this->add_group_control(\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'hs_nav_dots_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'rgba(19, 41, 104, 0.1)',
					],
				],
				'selector' => '{{WRAPPER}} .ua-hotel-slides .owl-dots .owl-dot',
			]
		);
        $this->add_responsive_control('hs_nav_dots_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'    => '50',
                    'right'  => '50',
                    'bottom' => '50',
                    'left'   => '50',
                    'unit'   => '%',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slides .owl-dots .owl-dot' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_tab();
        // hover tab how to change editor tree line color in phpstorm
        $this->start_controls_tab( 'hs_nav_dots_act_tab',
            [
                'label' => __( 'Active', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('hs_nav_dots_bg_act',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#287dfa',
                'selectors' => [
                    '{{WRAPPER}} .ua-hotel-slides .owl-dots .owl-dot.active' => 'background: {{VALUE}}',
                ],
            ]
        );
		$this->add_group_control(\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'hs_nav_dots_border_act',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '2',
							'right'    => '2',
							'bottom'   => '2',
							'left'     => '2',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#287dfa',
					],
				],
				'selector' => '{{WRAPPER}} .ua-hotel-slides .owl-dots .owl-dot.active',
			]
		);
        $this->add_responsive_control('hs_nav_dots_radius_act',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slides .owl-dots .owl-dot.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_tab();
        $this->end_controls_tabs();
        /* End Tab */
        $this->add_control('hs_nav_dots_hr',
            [
                'type' => \Elementor\Controls_Manager::DIVIDER,
            ]
        );
        $this->add_responsive_control('hs_nav_dots_width',
            [
                'label' => __( 'Width', 'useful-addons-elementor' ),
                'type'  => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 12,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-hotel-slides .owl-dots .owl-dot' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('hs_nav_dots_height',
            [
                'label' => __( 'Height', 'useful-addons-elementor' ),
                'type'  => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 12,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-hotel-slides .owl-dots .owl-dot' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('hs_nav_dots_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'     => '0',
                    'right'   => '2',
                    'bottom'  => '0',
                    'left'    => '2',
                    'unit'    => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slides .owl-dots .owl-dot' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
	private function get_hotel_slider_card_style() {
        $this->start_controls_section( 'hs_card_style',
            [
                'label' => __( 'Card', 'useful-addons-elementor' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control('hs_card_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
                'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-hotel-slider-item' => 'background: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'hs_card_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item',
			]
		);
        $this->add_responsive_control('hs_card_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '5',
                    'right'    => '5',
                    'bottom'   => '5',
                    'left'     => '5',
                    'unit'     => 'px',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( \Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'hs_card_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82,85,90,.1)'
						]
					]
				],
				'selector' => '{{WRAPPER}} .ua-hotel-slider-item',
			]
		);
        $this->add_responsive_control('hs_card_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_responsive_control('hs_card_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->add_control('hs_card_body_hd',
			[
				'label'     => __( 'Card Body', 'useful-addons-elementor' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_responsive_control('hs_card_body_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '25',
                    'right'    => '30',
                    'bottom'   => '25',
                    'left'     => '30',
                    'unit'     => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-hotel-slider-item .ua-hotel-slider-body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }

	protected function _register_controls() {
        $this->get_hotel_slider_layout_setting();
		$this->get_hotel_slider_control_setting();
        $this->get_hotel_slider_badge_style();
        $this->get_hotel_slider_title_style();
        $this->get_hotel_slider_address_style();
        $this->get_hotel_slider_review_rate_style();
        $this->get_hotel_slider_review_text_style();
        $this->get_hotel_slider_review_number_style();
        $this->get_hotel_slider_price_before_style();
        $this->get_hotel_slider_price_style();
        $this->get_hotel_slider_price_after_style();
        $this->get_hotel_slider_button_style();
        $this->get_hotel_slider_button_icon_style();
        $this->get_hotel_slider_nav_arrow_style();
        $this->get_hotel_slider_nav_dots_style();
        $this->get_hotel_slider_card_style();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();
        $by_id   = explode(',', $settings['hs_hotel_by_ids']);
        if(!empty($settings['hs_hotel_by_ids'])) {
            $args = [
                'post_type'      => 'ts_hotel',
                'posts_per_page' => $settings['hs_posts_per_page'],
                'post__in'       => $by_id
            ];
        } else {
            $args = [
                'post_type'      => 'ts_hotel',
                'posts_per_page' => $settings['hs_posts_per_page'],
            ];
        }
        $query_hotel = new \WP_Query($args);
		?>
        <div class="ua-hotel-slides owl-carousel">

            <?php while($query_hotel->have_posts(  )) { $query_hotel->the_post();
                
                $badge_title   = get_post_meta(get_the_ID(), 'trizen_hotel_badge_title', true);
                $address_title = get_post_meta(get_the_ID(), 'address', true);
                $price         = get_price();
                $count_review  = get_comment_count(get_the_ID())['approved'];
            
                if(get_the_post_thumbnail()) {
                    $empty_img = '';
                } else {
                    $empty_img = ' empty-hotel-img';
                }
                $avg = TSReview::get_avg_rate();
        
                ?>
                <div class="ua-hotel-slider-item">
                    <div class="ua-hotel-slider-img<?php echo esc_attr( $empty_img ); ?>">
                        <?php if(get_the_post_thumbnail(  )) { ?>
                            <a href="<?php the_permalink(  ); ?>" class="d-block">
                                <?php the_post_thumbnail(); ?>
                            </a>
                        <?php } if(!empty($badge_title)) { ?>
                            <span class="ua-hotel-slider-badge badge">
                                <?php echo esc_html($badge_title); ?>
                            </span>
                        <?php } ?>
                        <!-- <div class="ua-hotel-slider-wishlist icon-element" data-toggle="tooltip" data-placement="top" title="Bookmark">
                            <i class="la la-heart-o"></i>
                        </div> -->
                    </div>
                    <div class="ua-hotel-slider-body">
                        <?php if(get_the_title()) { ?>
                            <h3 class="ua-hotel-slider-title">
                                <a href="<?php the_permalink(  ); ?>">
                                    <?php the_title(); ?>
                                </a>
                            </h3>
                        <?php } if(!empty($address_title)) { ?>
                            <p class="ua-hotel-slider-meta">
                                <?php echo esc_html( $address_title ); ?>
                            </p>
                        <?php } ?>
                        <div class="ua-hotel-slider-rating">
                            <span class="ua-hotel-slider-review-rate badge">
                                <?php echo esc_html($avg); ?>
                            </span>
                            <span class="ua-hotel-slider-review-text">
                                <?php echo TSReview::get_rate_review_text($avg, $count_review); ?>
                            </span>
                            <span class="ua-hotel-slider-review-num">
                                <?php comments_number(__('(0 Review)', 'useful-addons-elementor'), __('(1 Review)', 'useful-addons-elementor'), __('(% Reviews)', 'useful-addons-elementor')); ?>
                            </span>
                        </div>
                        <div class="ua-hotel-slider-price d-flex align-items-center justify-content-between">
                            <p>
                                <span class="ua-hotel-slider-price-from">
                                    <?php esc_html_e( 'From', 'useful-addons-elementor' ); ?>
                                </span>
                                <span class="ua-hotel-slider-price-num">
                                    <?php echo TravelHelper::format_money($price); ?>
                                </span>
                                <span class="ua-hotel-slider-price-text">
                                    <?php esc_html_e( 'Per night', 'useful-addons-elementor' ); ?>
                                </span>
                            </p>
                            <a href="<?php the_permalink(  ); ?>" class="ua-hotel-slider-button btn-text">
                                <?php esc_html_e( 'See details', 'useful-addons-elementor' ); 
                                    \Elementor\Icons_Manager::render_icon( $settings['hs_btn_icon'], [ 'aria-hidden' => 'true' ] );
                                ?>
                            </a>
                        </div>
                    </div>
                </div>
            <?php } ?>

        </div>

        <script>
            jQuery(".ua-hotel-slides").owlCarousel({
                loop: <?php if($settings['hs_show_infinite_loop'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                items: <?php echo $settings['hs_slide_to_show']; ?>,
                nav: <?php if($settings['hs_navigation'] == 'arrow_dots' || $settings['hs_navigation'] == 'arrow') { ?> true <?php } else { ?> false <?php } ?>,
                dots: <?php if($settings['hs_navigation'] == 'arrow_dots' || $settings['hs_navigation'] == 'dots') { ?> true <?php } else { ?> false <?php } ?>,
                smartSpeed: <?php echo $settings['hs_animation_speed']; ?>,
                autoplay: <?php if($settings['hs_autoplay'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                <?php if($settings['hs_autoplay'] == 'yes') { ?>
                autoplaySpeed: <?php echo $settings['hs_autoplay_speed']; ?>,
                <?php } ?>
                autoHeight: <?php if($settings['hs_autoheight'] == 'yes') { ?> true <?php } else { ?> false <?php } ?>,
                active: true,
                margin: <?php echo $settings['hs_space_between']; ?>,
                // navigation : true
                navText: ['<?php \Elementor\Icons_Manager::render_icon( $settings['hs_nav_prev_icon'], [ 'aria-hidden' => 'true' ] ); ?>', '<?php \Elementor\Icons_Manager::render_icon( $settings['hs_nav_next_icon'], [ 'aria-hidden' => 'true' ] ); ?>'],
                responsive: {
                    // breakpoint from 0 up
                    0: {
                        items: 1
                    },
                    // breakpoint from 991 up
                    768: {
                        items: 2
                    },
                    // breakpoint from 992 up
                    992: {
                        items: 3
                    },
                    // breakpoint from 1441 up
                    1441: {
                        items: <?php echo $settings['hs_slide_to_show']; ?>
                    }
                }
            });
        </script>
        <?php

	}

	protected function _content_template() { }
}


\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new UA_hotel_slider() );