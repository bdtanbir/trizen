<?php
namespace Elementor;
// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}


class ua_corona_live_map extends Widget_Base {
	public function get_name() {
		return 'Ua_corona_live_map';
	}

	public function get_title() {
		return esc_html__( 'Corona Live Map', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-google-maps ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Corona Live Map content */
	private function get_corona_live_map_content() {
		$this->start_controls_section( 'corona_live_map_content',
			[
				'label' => __( 'Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control( 'corona_live_map_url',
			[
				'label'       => __( 'Live Map Embed URL', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 6,
				'default'     => __( 'https://coronavirus.app/map?embed=true', 'useful-addons-elementor' ),
				'placeholder' => __( 'https://coronavirus.app/map?embed=true', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'corona_live_map_cap',
			[
				'label'       => __( 'Caption', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => __( 'Note: If you want to see the data you hover on the red circle bubble', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
			]
		);
		$this->end_controls_section();
    }
	/* UA Corona Live Map content */
	private function get_corona_live_map_style() {
		$this->start_controls_section( 'corona_live_map_style',
			[
				'label' => __( 'Map', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control( 'corona_live_map_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1920,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-corona-live-map .maps' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'corona_live_map_height',
			[
				'label'      => __( 'height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1024,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 500,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-corona-live-map .maps' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'corona_live_map_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'   => [
                    'top'   => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-corona-live-map .maps' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'corona_live_map_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-corona-live-map .maps' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Corona Live Map Caption content */
	private function get_corona_live_map_cap_style() {
		$this->start_controls_section( 'corona_live_map_cap_style',
			[
				'label' => __( 'Caption', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'corona_live_map_cap_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0A1B4F',
				'selectors' => [
					'{{WRAPPER}} .ua-corona-live-map .widget-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'corona_live_map_cap_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-corona-live-map .widget-title',
			]
		);
		$this->add_responsive_control( 'corona_live_map_cap_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'   => [
                    'top' => '16',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-corona-live-map .widget-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'corona_live_map_cap_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-corona-live-map .widget-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls() {
		$this->get_corona_live_map_content();
		$this->get_corona_live_map_style();
		$this->get_corona_live_map_cap_style();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();

		if(!empty($settings['corona_live_map_url']) || !empty($settings['corona_live_map_cap'])) {
			?>
            <div class="ua-corona-live-map">
				<?php if ( ! empty( $settings['corona_live_map_url'] ) ) { ?>
                    <iframe class="maps" src="<?php echo esc_url($settings['corona_live_map_url']); ?>"
                            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen></iframe>
					<?php
				}
				if ( ! empty( $settings['corona_live_map_cap'] ) ) { ?>
                    <h3 class="widget-title">
						<?php echo esc_html($settings['corona_live_map_cap']); ?>
                    </h3>
				<?php } ?>
            </div>
			<?php
		}
	}

	protected function _content_template() {}
}

Plugin::instance()->widgets_manager->register_widget_type( new ua_corona_live_map() );