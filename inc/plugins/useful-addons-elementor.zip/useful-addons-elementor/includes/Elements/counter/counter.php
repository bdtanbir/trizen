<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_counter extends Widget_Base {
	public function get_name() {
		return 'UA_counter';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @since 2.1.0
	 * @access public
	 *
	 * @return array Widget keywords.
	 */
	public function get_keywords() {
		return [ 'counter', 'count', 'counterup' ];
	}

	public function get_title() {
		return esc_html__( 'Counter', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-number-field ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Counter Content Controls */
	private function get_content_counter( ){
		$this->start_controls_section( 'counter_content',
			[
				'label' => __( 'Counter', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'counter_layout',
			[
				'label'   => __( 'Layout', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style_1',
				'options' => [
					'style_1'  => __( 'Style 1', 'useful-addons-elementor' ),
					'style_2'  => __( 'Style 2', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control( 'counter_box_alignment',
			[
				'label'   => __( 'Alignment', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0' => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'   => '1',
			]
		);
		$this->add_control( 'counter_number',
			[
				'label'       => __('Counter Number', 'useful-addons-elementor'),
				'type'        => Controls_Manager::TEXT,
				'default'     => __('100', 'useful-addons-elementor'),
				'placeholder' => __('Type your counter number', 'useful-addons-elementor'),
			]
		);
		$this->add_control( 'counter_number_suffix',
			[
				'label'       => __('Number Suffix', 'useful-addons-elementor'),
				'type'        => Controls_Manager::TEXT,
				'default'     => __('+', 'useful-addons-elementor'),
				'placeholder' => __('plus', 'useful-addons-elementor'),
                'condition'   => [
                    'counter_layout' => 'style_1'
                ]
			]
		);
		$this->add_control( 'counter_title',
			[
				'label'       => __('Title', 'useful-addons-elementor'),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => __('Project', 'useful-addons-elementor'),
				'placeholder' => __('Enter counter title', 'useful-addons-elementor'),
			]
		);
		$this->add_control( 'counter_icon_showhide',
			[
				'label'        => __( 'Show Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control('counter_icon',
			[
				'label'            => __( 'Icons', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fas fa-user',
					'library' => 'solid',
				],
				'condition' => [
					'counter_icon_showhide' => 'yes'
				]
			]
		);
		$this->add_control( 'counter_icon_shape',
			[
				'label'        => __( 'Show Icon\'s Shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition' => [
					'counter_icon_showhide' => 'yes',
					'counter_layout' => 'style_1'
				]
			]
		);
		$this->add_control( 'counter_icon_bg_animation',
			[
				'label'        => __( 'Show Icon\'s BG Animation', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'True', 'useful-addons-elementor' ),
				'label_off'    => __( 'False', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition' => [
					'counter_icon_showhide' => 'yes',
					'counter_layout' => 'style_1'
				]
			]
		);
		$this->end_controls_section();
	}
	/* UA Counter Number and suffix Style Controls */
	private function get_style_counter_number_and_suffix( ){
		// number
		$this->start_controls_section( 'counter_number_styles',
			[
				'label' => __( 'Number', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'counter_layout' => 'style_1'
                ]
			]
		);
		$this->add_control( 'counter_number_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact__number' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'counter_number_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-funfact-item .ua-funfact__number',
				'default'  => [
					'font-size'   => '65px',
					'font-weight' => '600',
				]
			]
		);
		$this->add_responsive_control(
			'counter_number_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact__number' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'counter_number_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '45',
					'right'    => '0',
					'bottom'   => '32',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact__number' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		// number suffix
		$this->start_controls_section( 'counter_number_suffix_styles',
			[
				'label'     => __( 'Number Suffix', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'counter_layout' => 'style_1'
				]
			]
		);
		$this->add_control( 'counter_number_suffix_clr',
			[
				'label'     => __('Color', 'useful-addons-elementor'),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funtact__plus' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'counter_number_suffix_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-funfact-item .ua-funtact__plus',
				'default'  => [
					'font-size' => '54px',
				]
			]
		);
		$this->add_responsive_control('counter_number_suffix_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-item .ua-funtact__plus' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('counter_number_suffix_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-item .ua-funtact__plus' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Counter Title Style Controls */
	private function get_style_counter_title( ){
		$this->start_controls_section( 'counter_title_styles',
			[
				'label' => __( 'Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'counter_layout' => 'style_1'
                ]
			]
		);
		$this->add_control( 'counter_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#00000',
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact__meta' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'counter_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-funfact-item .ua-funfact__meta',
				'default'  => [
					'font-size'   => '18px',
					'font-weight' => '600',
				]
			]
		);
		$this->add_responsive_control('counter_title_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact__meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('counter_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact__meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Counter Icon Style Controls */
	private function get_style_counter_icon( ){
		$this->start_controls_section( 'counter_icon_styles',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'counter_icon_showhide' => 'yes',
                    'counter_layout' => 'style_1'
				]
			]
		);
		$this->add_control( 'counter_icon_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon .ua-funfact__icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'counter_icon_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-funfact-item .ua-funfact-icon',
			]
		);
		$this->add_control('counter_icon_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 65,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon .ua-funfact__icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'counter_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'counter_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 80,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon' => 'height: {{SIZE}}{{UNIT}};line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'counter_icon_border',
				'label'    => esc_html__( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-funfact-item .ua-funfact-icon'
			]
		);
		$this->add_responsive_control( 'counter_icon_radius',
			[
				'label'      => __( 'Border radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'counter_icon_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-funfact-item .ua-funfact-icon',
			]
		);
		$this->add_responsive_control( 'counter_icon_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'counter_icon_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => 'auto',
					'bottom'   => '0',
					'left'     => 'auto',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		/* Icons shape*/
		$this->add_control( 'counter_icon_shape_title',
			[
				'label'     => __( 'Icon\'s Shape', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
                'condition' => [
                    'counter_icon_shape' => 'yes'
                ]
			]
		);
		$this->add_control('counter_icon_shape_bg',
			[
				'label'     => __( 'Shape Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(0,0,0,0.1)',
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon:before' => 'background: {{VALUE}}',
				],
				'condition' => [
					'counter_icon_shape' => 'yes'
				]
			]
		);
		$this->add_responsive_control('counter_icon_shape_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'  => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon:before' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'counter_icon_shape' => 'yes'
				]
			]
		);
		$this->add_responsive_control('counter_icon_shape_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 18,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon:before' => 'height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'counter_icon_shape' => 'yes'
				]
			]
		);
		$this->add_responsive_control('counter_icon_shape_radius',
			[
				'label'      => __( 'Border radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '4',
					'right'     => '4',
					'bottom'    => '4',
					'left'      => '4',
					'unit'      => 'px',
					'is_Linked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'counter_icon_shape' => 'yes'
				]
			]
		);
		$this->add_responsive_control('counter_icon_shape_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-item .ua-funfact-icon:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => [
					'counter_icon_shape' => 'yes'
				]
			]
		);
		$this->end_controls_section();
	}


	/* UA Counter Style 2 */
    private function get_style_counter_st2_icon() {
		$this->start_controls_section( 'counter_st2_icon',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'counter_layout' => 'style_2'
				]
			]
		);
		$this->add_control( 'counter_st2_icon_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(127, 136, 151, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'counter_st2_icon_size',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 70,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'counter_st2_icon_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
    }
	private function get_style_counter_st2_num() {
		$this->start_controls_section( 'counter_st2_num',
			[
				'label'     => __( 'Number', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'counter_layout' => 'style_2'
				]
			]
		);
		$this->add_control( 'counter_st2_num_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7E3CF9',
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-number' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'counter_st2_num_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-number',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'counter_st2_num_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-number',
			]
		);
		$this->add_responsive_control( 'counter_st2_num_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-number' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'counter_st2_num_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '0',
                    'bottom' => '10',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-number' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_counter_st2_title() {
		$this->start_controls_section( 'counter_st2_title_style',
			[
				'label'     => __( 'Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'counter_layout' => 'style_2'
				]
			]
		);
		$this->add_control( 'counter_st2_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'counter_st2_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-title',
			]
		);
		$this->add_responsive_control( 'counter_st2_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-funfact-2-item .ua-funfact-2-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls() {
		$this->get_content_counter();
		$this->get_style_counter_number_and_suffix();
		$this->get_style_counter_title();
		$this->get_style_counter_icon();

		/* UA Counter Style 2 */
		$this->get_style_counter_st2_icon();
		$this->get_style_counter_st2_num();
		$this->get_style_counter_st2_title();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'counter_number', 'none' );
		$this->add_render_attribute( 'counter_number', 'class' , 'ua-funfact__number ua-counter');
		$this->add_inline_editing_attributes( 'counter_number_suffix', 'none' );
		$this->add_render_attribute( 'counter_number_suffix', 'class' , 'ua-funtact__plus');
		$this->add_inline_editing_attributes( 'counter_title', 'none' );
		$this->add_render_attribute( 'counter_title', 'class' , 'ua-funfact__meta');


		// Content Alignments
		if($settings['counter_box_alignment'] == 0) {
			$counter_alignment = 'text-left justify-content-left';
			$icon_position     = 'left';
		} elseif ( $settings['counter_box_alignment'] == 1 ) {
			$counter_alignment = 'text-center justify-content-center';
			$icon_position     = 'center';
		} elseif ( $settings['counter_box_alignment'] == 2 ) {
			$counter_alignment = 'text-right justify-content-right';
			$icon_position     = 'right';
		} else {
			$counter_alignment = 'text-center justify-content-center';
			$icon_position     = 'center';
		}


		if($settings['counter_layout'] === 'style_1' ) {
		?>
        <div class="ua-funfact-item <?php echo esc_attr($counter_alignment); ?>">
            <div class="ua-funfact-shared">
				<?php if( $settings['counter_icon_showhide'] == 'yes' ) {
					if ( !empty( $settings['counter_icon'] ) ) {
						?>
                        <div class="ua-funfact-icon <?php if($settings['counter_icon_shape'] !== 'yes') { echo esc_attr__(' hide-shape ', 'useful-addons-elementor'); } if($settings['counter_icon_bg_animation'] === 'yes') { echo esc_attr__(' morph ', 'useful-addons-elementor'); } echo esc_attr($icon_position); ?>">
							<?php
							Icons_Manager::render_icon( $settings['counter_icon'], ['class' => 'ua-funfact__icon ', ' aria-hidden' => 'true' ] );
							?>
                        </div>
						<?php
					}
				}
				if( !empty( $settings['counter_number'] ) ) { ?>
                    <span <?php $this->print_render_attribute_string( 'counter_number'); ?>>
                        <?php echo esc_html($settings['counter_number']); ?>
                    </span>
				<?php } if( !empty( $settings['counter_number_suffix'] ) ) { ?>
                    <span <?php $this->print_render_attribute_string( 'counter_number_suffix'); ?>>
                    <?php echo esc_html($settings['counter_number_suffix']); ?>
                </span>
				<?php } if( !empty( $settings['counter_title'] ) ) { ?>
                    <p <?php $this->print_render_attribute_string( 'counter_title'); ?>>
						<?php echo esc_html($settings['counter_title']); ?>
                    </p>
				<?php } ?>
            </div>
        </div>

	<?php
        } else { ?>
            <div class="ua-funfact-2-item position-relative <?php echo esc_attr($counter_alignment); ?>">
                <?php if($settings['counter_icon_showhide'] === 'yes') {
					Icons_Manager::render_icon( $settings['counter_icon'], [ 'class'        => 'ua-funfact-2-icon ', ' aria-hidden' => 'true' ] );
				} if(!empty($settings['counter_number'])) { ?>
                <h4 class="ua-funfact-2-number ua-counter">
                    <?php echo esc_html($settings['counter_number']); ?>
                </h4>
                <?php } if(!empty($settings['counter_title'])) { ?>
                    <p class="ua-funfact-2-title">
                        <?php echo esc_html($settings['counter_title']); ?>
                    </p>
                <?php } ?>
            </div>
            <?php
        }
    }

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_counter() );