<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_progressbar extends Widget_Base {
	public function get_name() {
		return 'UA_progressbar';
	}

	public function get_title() {
		return esc_html__( 'Progressbar', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-skill-bar ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA ProgressBar Content Controls */
	private function get_content_progressbar_controls( ){
		$this->start_controls_section( 'UA_progressbar_content',
			[
				'label' => __( 'Progressbar', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'UA_progressbar_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'My Progressbar', 'useful-addons-elementor' ),
				'placeholder' => __( 'Progressbar title here', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_progressbar_percentage',
			[
				'label'   => __( 'Percentage', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 90,
					'unit' => '%',
				],
				'label_block' => true,
			]
		);
		$this->add_control( 'UA_progressbar_percent_show',
			[
				'label'        => __( 'Show Percentage', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->end_controls_section();
	}
	/* UA ProgressBar Title Style Controls */
	private function get_style_progressbar_title( ){
		$this->start_controls_section( 'UA_progressbar_title_style',
			[
				'label' => __( 'Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'UA_progressbar_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progress-bar-content .skillbar .skillbar-title' => 'color: {{VALUE}}',
				],
				'default' => '#233d63',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_progressbar_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .progress-bar-content .skillbar .skillbar-title',
			]
		);
		$this->add_responsive_control( 'UA_progressbar_title_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .progress-bar-content .skillbar .skillbar-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_progressbar_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .progress-bar-content .skillbar .skillbar-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA ProgressBar Percentage Style Controls */
	private function get_style_progressbar_percentage( ){
		$this->start_controls_section( 'UA_progressbar_percentage_style',
			[
				'label' => __( 'Percent', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'UA_progressbar_percentage_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progress-bar-content .skillbar .skill-bar-percent' => 'color: {{VALUE}}',
				],
				'default' => '#233d63',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_progressbar_percentage_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .progress-bar-content .skillbar .skill-bar-percent',
			]
		);
		$this->add_responsive_control( 'UA_progressbar_percentage_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .progress-bar-content .skillbar .skill-bar-percent' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_progressbar_percentage_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .progress-bar-content .skillbar .skill-bar-percent' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA ProgressBar Box Style*/
	private function get_style_progressbar_box( ){
		$this->start_controls_section( 'UA_progressbar_style',
			[
				'label' => __( 'Progress Bar', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'UA_progressbar_animation_box',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .progress-bar-content .skillbar .skillbar-bar' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_progressbar_static_box',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#eeeeee',
				'selectors' => [
					'{{WRAPPER}} .progress-bar-content .skillbar' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_progressbar_box_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					]
				],
				'default'  => [
					'unit' => 'px',
					'size' => 8,
				],
				'selectors' => [
					'{{WRAPPER}} .progress-bar-content .skillbar .skillbar-bar, {{WRAPPER}} .progress-bar-content .skillbar' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_progressbar_box_radius',
			[
				'label'      => __( 'Border radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '4',
					'right'     => '4',
					'bottom'    => '4',
					'left'      => '4',
					'unit'      => 'px',
					'is_Linked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .progress-bar-content .skillbar, {{WRAPPER}} .progress-bar-content .skillbar .skillbar-bar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_progressbar_box_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .progress-bar-content .skillbar' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	protected function _register_controls() {
	    $this->get_content_progressbar_controls();
	    $this->get_style_progressbar_title();
	    $this->get_style_progressbar_percentage();
	    $this->get_style_progressbar_box();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();
		$this->add_inline_editing_attributes( 'UA_progressbar_title', 'none' );
		$this->add_render_attribute( 'UA_progressbar_title', 'class' , 'skillbar-title');



		$this->add_render_attribute( 'UA_progressbar_percentage', [
			'class' => 'skillbar clearfix',
		] );

    ?>

		<div class="progress-bar-content">
			<div <?php $this->print_render_attribute_string( 'UA_progressbar_percentage' ); ?> data-percent="<?php echo esc_attr($settings['UA_progressbar_percentage']['size']); ?>%">
				<div <?php $this->print_render_attribute_string( 'UA_progressbar_title'); ?>>
				    <span><?php echo esc_html($settings['UA_progressbar_title']); ?></span>
				</div>
				<div class="skillbar-bar"></div>
				<?php if(!empty( $settings['UA_progressbar_percentage']['size']) && $settings['UA_progressbar_percent_show'] == 'yes') { ?>
				<div class="skill-bar-percent">
				    <?php echo esc_html($settings['UA_progressbar_percentage']['size']); echo esc_html__('%', 'useful-addons-elementor'); ?>
                </div>
                <?php } ?>
			</div>
		</div>

	<?php }

	protected function _content_template() {}
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_progressbar() );