<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class ua_login_register extends Widget_Base {
	public function get_name() {
		return 'ua_login_register';
	}

	public function get_title() {
		return esc_html__( 'Login_Register', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-lock-user ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Course Filter */
	private function get_login_register_content() {
		$this->start_controls_section( 'log_reg_content_setting',
			[
				'label' => __( 'Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'log_reg_form_type',
			[
				'label'   => __( 'Form Layout', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'login_form',
				'options' => [
					'login_form'    => __( 'Login Form', 'useful-addons-elementor' ),
					'register_form' => __( 'Register Form', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control( 'log_reg_email_uname_title',
			[
				'label'       => __( 'Email or Username', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Email or Username', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type Email/Username title here', 'useful-addons-elementor' ),
                'condition'   => [
                    'log_reg_form_type' => 'login_form'
                ]
			]
		);
		$this->add_control( 'log_reg_email_pass_title',
			[
				'label'       => __( 'Password Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Password', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type Password title here', 'useful-addons-elementor' ),
                'condition'   => [
                    'log_reg_form_type' => 'login_form'
                ]
			]
		);
		$this->add_control( 'log_reg_show_required_icon',
			[
				'label'        => __( 'Show Required Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'log_reg_form_type' => 'login_form'
				]
			]
		);
		$this->add_control( 'log_reg_show_rememberme',
			[
				'label'        => __( 'Show Remember Me', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'log_reg_form_type' => 'login_form'
				]
			]
		);
		$this->add_control( 'log_reg_rememberme_title',
			[
				'label'       => __( 'Remember Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Remember Me', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type remember me title here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type'       => 'login_form',
                    'log_reg_show_rememberme' => 'yes'
				]
			]
		);
		$this->add_control( 'log_reg_show_forgot_pass',
			[
				'label'        => __( 'Show Forgot Password', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'log_reg_form_type' => 'login_form'
				]
			]
		);
		$this->add_control( 'log_reg_forgot_pass_title',
			[
				'label'       => __( 'Forgot Password Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Forgot my password?', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type forgot my password title here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type'       => 'login_form',
					'log_reg_show_forgot_pass' => 'yes'
				]
			]
		);
		$this->add_control( 'log_reg_login_btn',
			[
				'label'       => __( 'Login Button', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Login Account', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type forgot my password title here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type'       => 'login_form',
				]
			]
		);
		$this->add_control( 'log_reg_show_dont_have_acnt',
			[
				'label'        => __( 'Show Don\'t have account', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'log_reg_form_type' => 'login_form'
				]
			]
		);
		$this->add_control( 'log_reg_dont_have_acnt_title',
			[
				'label'       => __( 'Don\'t have account title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Don\'t have an account?', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type Don\'t have an account? title here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type'           => 'login_form',
					'log_reg_show_dont_have_acnt' => 'yes',
				]
			]
		);
		$this->add_control( 'log_reg_register_title',
			[
				'label'       => __( 'Register Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Register', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type Register title here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type'           => 'login_form',
					'log_reg_show_dont_have_acnt' => 'yes',
				]
			]
		);
		$this->add_control( 'log_reg_register_link',
			[
				'label'         => __( 'Register Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition'   => [
					'log_reg_form_type'           => 'login_form',
					'log_reg_show_dont_have_acnt' => 'yes',
				]
			]
		);

		/* Register Form */
		$this->add_control( 'log_reg_fname',
			[
				'label'       => __( 'First Name', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'First Name', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type first name title here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type' => 'register_form',
				]
			]
		);
		$this->add_control( 'log_reg_lname',
			[
				'label'       => __( 'Last Name', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Last Name', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type last name title here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type' => 'register_form',
				]
			]
		);
		$this->add_control( 'log_reg_uname',
			[
				'label'       => __( 'User Name', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'User Name', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type username here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type' => 'register_form',
				]
			]
		);
		$this->add_control( 'log_reg_email',
			[
				'label'       => __( 'Email', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Email', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type username here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type' => 'register_form',
				]
			]
		);
		$this->add_control( 'log_reg_password',
			[
				'label'       => __( 'Password', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Password', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type Password here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type' => 'register_form',
				]
			]
		);
		$this->add_control( 'log_reg_confirm_password',
			[
				'label'       => __( 'Confirm Password', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Confirm Password', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type Password here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type' => 'register_form',
				]
			]
		);
		$this->add_control( 'log_reg_button',
			[
				'label'       => __( 'Button', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Register Account', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type button text here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type' => 'register_form',
				]
			]
		);
		$this->add_control( 'log_reg_show_have_an_acnt',
			[
				'label'        => __( 'Show Have an account title', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'   => [
					'log_reg_form_type' => 'register_form',
				]
			]
		);
		$this->add_control( 'log_reg_have_an_acnt',
			[
				'label'       => __( 'Have an account', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Already have an account?', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type button text here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type'         => 'register_form',
					'log_reg_show_have_an_acnt' => 'yes',
				]
			]
		);
		$this->add_control( 'log_reg_login_title',
			[
				'label'       => __( 'Login Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Log in', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type login text here', 'useful-addons-elementor' ),
				'condition'   => [
					'log_reg_form_type'         => 'register_form',
					'log_reg_show_have_an_acnt' => 'yes',
				]
			]
		);
		$this->add_control( 'log_reg_login_link',
			[
				'label'         => __( 'Login Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default' => [
					'url' => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
				'condition'   => [
					'log_reg_form_type'           => 'register_form',
					'log_reg_show_dont_have_acnt' => 'yes',
				]
			]
		);
		$this->end_controls_section();
    }
	private function get_style_log_reg_label() {
		$this->start_controls_section( 'log_reg_label_style',
			[
				'label' => __( 'Label', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'log_reg_label_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233D63',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .label-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'log_reg_label_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-login-register-form .label-text',
			]
		);
		$this->add_responsive_control( 'log_reg_label_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'     => '0',
                    'right'   => '0',
                    'bottom'  => '8',
                    'left'    => '0',
                    'unit'    => 'px',
                    'isLinked'=> false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .label-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'log_reg_label_required',
			[
				'label'     => __( 'Required Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
                'condition' => [
                    'log_reg_show_required_icon' => 'yes'
                ],
			]
		);
		$this->add_control( 'log_reg_label_required_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .label-text span' => 'color: {{VALUE}}',
				],
				'condition' => [
					'log_reg_show_required_icon' => 'yes'
				],
			]
		);
		$this->add_responsive_control( 'log_reg_label_required_size',
			[
				'label'      => __( 'Font Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .label-text span' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'log_reg_show_required_icon' => 'yes'
				],
			]
		);
		$this->add_responsive_control( 'log_reg_label_required_translatey',
			[
				'label'      => __( 'TranslateY', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range'      => [
					'px'     => [
						'min'  => -50,
						'max'  => 50,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .label-text span' => 'transform: translateY({{SIZE}}{{UNIT}});',
				],
				'condition' => [
					'log_reg_show_required_icon' => 'yes'
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_log_reg_input() {
		$this->start_controls_section( 'log_reg_input_style',
			[
				'label' => __( 'Input', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'log_reg_input_clr',
			[
				'label'     => __( 'Input Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233D63',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .form-group > input' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'log_reg_input_plc_clr',
			[
				'label'     => __( 'Placeholder Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8e959b',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .form-group > input::placeholder' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'log_reg_input_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-login-register-form .form-group > input',
			]
		);
		$this->add_responsive_control( 'log_reg_input_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 800,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .form-group > input' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'log_reg_input_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 80,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .form-group > input' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/* Start Tab */
		$this->start_controls_tabs(
		        'log_reg_input_tab'
		);
		$this->start_controls_tab( 'log_reg_input_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'log_reg_input_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .form-group > input' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'            => 'log_reg_input_border',
				'label'           => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => 'rgba(127, 136, 151, 0.2)',
					],
				],
				'selector'        => '{{WRAPPER}} .ua-login-register-form .form-group > input',
			]
		);
		$this->add_control( 'log_reg_input_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '5',
                    'right'    => '5',
                    'bottom'   => '5',
                    'left'     => '5',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .form-group > input' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'log_reg_input_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-login-register-form .form-group > input',
			]
		);
		$this->end_controls_tab();
		// hover
		$this->start_controls_tab( 'log_reg_input_hv',
			[
				'label' => __( 'Hover/Focus', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'log_reg_input_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .form-group > input:hover' => 'background: {{VALUE}}',
					'{{WRAPPER}} .ua-login-register-form .form-group > input:focus' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'            => 'log_reg_input_border_hv',
				'label'           => __( 'Border', 'useful-addons-elementor' ),
				'selector'        => '{{WRAPPER}} .ua-login-register-form .form-group > input:hover, {{WRAPPER}} .ua-login-register-form .form-group > input:focus',
			]
		);
		$this->add_control( 'log_reg_input_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .form-group > input:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .ua-login-register-form .form-group > input:focus' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'log_reg_input_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-login-register-form .form-group > input:hover, {{WRAPPER}} .ua-login-register-form .form-group > input:focus',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End tab */
		$this->add_responsive_control( 'log_reg_input_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '10',
					'right'    => '20',
					'bottom'   => '10',
					'left'     => '45',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .form-group > input' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'log_reg_input_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '20',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .form-group' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'log_reg_input_icon_hd',
			[
				'label'     => __( 'Input Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'log_reg_input_icon_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .form-group .input-icon' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'log_reg_input_icon_size',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 18,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .form-group .input-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'log_reg_input_icon_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '15',
                    'right'    => '0',
                    'bottom'   => '0',
                    'left'     => '20',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .form-group .input-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_log_reg_remember() {
		$this->start_controls_section( 'log_reg_rememberme_style',
			[
				'label'     => __( 'Remember Me', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'log_reg_show_rememberme' => 'yes'
                ]
			]
		);
		$this->add_control( 'log_reg_remember_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .ua-remember-checkbox label' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'log_reg_remember_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-login-register-form .ua-remember-checkbox label',
			]
		);
		$this->add_responsive_control( 'log_reg_remember_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .ua-remember-checkbox label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_log_reg_forgot_pass() {
		$this->start_controls_section( 'log_reg_forgot_pass_style',
			[
				'label'     => __( 'Forgot Password', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'log_reg_show_forgot_pass' => 'yes'
				]
			]
		);
		$this->add_control( 'log_reg_forgot_pass_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .ua-remember-checkbox .forgot-password' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'log_reg_forgot_pass_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .ua-remember-checkbox .forgot-password:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'log_reg_forgot_pass_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-login-register-form .ua-remember-checkbox .forgot-password',
			]
		);
		$this->add_responsive_control( 'log_reg_forgot_pass_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .ua-remember-checkbox .forgot-password:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_log_reg_button() {
		$this->start_controls_section( 'log_reg_button_style',
			[
				'label' => __( 'Button', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'log_reg_button_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-login-register-form .ua-login-btn',
			]
		);
		$this->add_responsive_control( 'log_reg_btn_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'log_reg_btn_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/* Start tab */
		$this->start_controls_tabs(
			'log_reg_button_tab'
		);
		$this->start_controls_tab( 'log_reg_button_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'log_reg_btn_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'log_reg_btn_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51BE78',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'            => 'log_reg_btn_border',
				'label'           => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#51BE78',
					],
				],
				'selector'        => '{{WRAPPER}} .ua-login-register-form .ua-login-btn',
			]
		);
		$this->add_control( 'log_reg_btn_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '5',
                    'right'    => '5',
                    'bottom'   => '5',
                    'left'     => '5',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'log_reg_btn_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-login-register-form .ua-login-btn',
			]
		);
		$this->add_responsive_control( 'log_reg_btn_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '0',
                    'right'    => '30',
                    'bottom'   => '0',
                    'left'     => '30',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'log_reg_btn_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover
		$this->start_controls_tab( 'log_reg_button_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'log_reg_btn_color_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51BE78',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'log_reg_btn_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'            => 'log_reg_btn_border_hv',
				'label'           => __( 'Border', 'useful-addons-elementor' ),
				'selector'        => '{{WRAPPER}} .ua-login-register-form .ua-login-btn:hover',
			]
		);
		$this->add_control( 'log_reg_btn_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'log_reg_btn_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-login-register-form .ua-login-btn:hover',
			]
		);
		$this->add_responsive_control( 'log_reg_btn_pd_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'log_reg_btn_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .ua-login-btn:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End tab */
		$this->end_controls_section();
	}
	private function get_style_log_reg_dont_have_acnt() {
		$this->start_controls_section( 'dont_have_acnt_style',
			[
				'label'     => __( 'Don\'t have account', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'log_reg_show_dont_have_acnt' => 'yes'
                ]
			]
		);
		$this->add_control( 'log_reg_dont_have_acnt_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .dont-have-account' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'log_reg_dont_have_acnt_link_clr',
			[
				'label'     => __( 'Link Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .dont-have-account a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'log_reg_dont_have_acnt_link_clr_hv',
			[
				'label'     => __( 'Link hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-login-register-form .dont-have-account a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'log_reg_dont_have_acnt_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-login-register-form .dont-have-account',
			]
		);
		$this->add_responsive_control( 'log_reg_dont_have-acnt_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '24',
                    'right'    => '0',
                    'bottom'   => '0',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-login-register-form .dont-have-account' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}



	protected function _register_controls() {
        $this->get_login_register_content();
        $this->get_style_log_reg_label();
        $this->get_style_log_reg_input();
        $this->get_style_log_reg_remember();
        $this->get_style_log_reg_forgot_pass();
        $this->get_style_log_reg_button();
        $this->get_style_log_reg_dont_have_acnt();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();

		$target   = $settings['log_reg_register_link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['log_reg_register_link']['nofollow'] ? ' rel="nofollow"' : '';

		$lg_target   = $settings['log_reg_login_link']['is_external'] ? ' target="_blank"' : '';
		$lg_nofollow = $settings['log_reg_login_link']['nofollow'] ? ' rel="nofollow"' : '';

		?>
        <div class="ua-login-register-form">
            <?php
            if(!is_user_logged_in()) {
                if($settings['log_reg_form_type'] == 'login_form') { ?>
                    <form id="ua-login-register">
                        <p class="ua-login-register-msg-status"></p>
                        <?php wp_nonce_field( 'ajax-login-nonce', 'security' ); ?>
                        <div class="input-box">
                            <?php if(!empty($settings['log_reg_email_uname_title'])) { ?>
                                <label class="label-text" for="username">
                                    <?php
                                        esc_html_e($settings['log_reg_email_uname_title']);
                                        if($settings['log_reg_show_required_icon'] == 'yes') {
                                    ?>
                                        <span class="d-inline-block">
                                            <?php esc_html_e( '*', 'useful-addons-elementor' ); ?>
                                        </span>
                                    <?php } ?>
                                </label>
                            <?php } ?>
                            <div class="form-group">
                                <input
                                        class="form-control"
                                        id="username"
                                        type="text"
                                        name="name"
                                        placeholder="<?php echo esc_attr($settings['log_reg_email_uname_title']); ?>"
                                    <?php if($settings['log_reg_show_required_icon'] == 'yes') { esc_attr_e('required', 'useful-addons-elementor'); } ?>>
                                <span class="la la-envelope input-icon"></span>
                            </div>
                        </div>
                        <div class="input-box">
                            <?php if(!empty($settings['log_reg_email_pass_title'])) { ?>
                                <label class="label-text" for="password">
                                    <?php
                                        echo esc_html($settings['log_reg_email_pass_title']);
                                        if($settings['log_reg_show_required_icon'] == 'yes') {
                                    ?>
                                        <span class="d-inline-block">
                                            <?php esc_html_e( '*', 'useful-addons-elementor' ); ?>
                                        </span>
                                    <?php } ?>
                                </label>
                            <?php } ?>
                            <div class="form-group">
                                <input
                                    class="form-control"
                                    id="password"
                                    type="password"
                                    placeholder="<?php echo esc_attr($settings['log_reg_email_pass_title'] ); ?>"
                                <?php if($settings['log_reg_show_required_icon'] == 'yes') { esc_attr_e('required', 'useful-addons-elementor'); } ?>>
                                <span class="la la-lock input-icon"></span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="ua-remember-checkbox d-flex justify-content-between">
                                <?php if($settings['log_reg_show_rememberme'] == 'yes' && !empty($settings['log_reg_rememberme_title'])) { ?>
                                    <label for="rememberme" class="inline">
                                        <input
                                            name="rememberme"
                                            type="checkbox"
                                            id="rememberme"
                                            value="forever"/> <?php echo esc_html($settings['log_reg_rememberme_title']); ?>
                                    </label>
                                <?php } if($settings['log_reg_show_forgot_pass'] == 'yes' && !empty($settings['log_reg_forgot_pass_title'])) { ?>
                                    <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>" class="forgot-password d-inline-block">
                                        <?php echo esc_html($settings['log_reg_forgot_pass_title']); ?>
                                    </a>
                                <?php } ?>
                            </div>
                        </div>
                        <?php if(!empty($settings['log_reg_login_btn'])) { ?>
                            <button id="aduca-pop-login-submit" type="submit" class="btn ua-login-btn">
                                <?php echo esc_html($settings['log_reg_login_btn']); ?>
                            </button>
                        <?php } if($settings['log_reg_show_dont_have_acnt'] == 'yes') {
                            if(!empty($settings['log_reg_register_title']) || !empty($settings['log_reg_dont_have_acnt_title'])) {
                                ?>
                                <p class="dont-have-account">
                                    <?php
                                        echo esc_html($settings['log_reg_dont_have_acnt_title']);
                                        if(!empty($settings['log_reg_register_title'])) {
                                    ?>
                                        <a href="<?php echo esc_url($settings['log_reg_register_link']['url']); ?>" <?php echo esc_attr($target). ' ' . esc_attr($nofollow); ?>>
                                            <?php echo esc_html($settings['log_reg_register_title']); ?>
                                        </a>
                                    <?php } ?>
                                </p>
                            <?php
                            }
                        } ?>
                    </form>
                <?php } else { ?>
                    <form id="ua-register-form">
                        <p class="ua-login-register-msg-status"></p>
                        <?php wp_nonce_field( 'ajax-register-nonce', 'signonsecurity' ); ?>
                        <div class="input-box">
                            <?php if(!empty($settings['log_reg_fname'])) { ?>
                                <label class="label-text" for="reg-fname">
                                    <?php echo esc_html($settings['log_reg_fname']); ?>
                                    <span class="primary-color-2 ml-1">
                                        <?php esc_html_e( '*', 'useful-addons-elementor' ); ?>
                                    </span>
                                </label>
                            <?php } ?>
                            <div class="form-group">
                                <input
                                   class="form-control"
                                   type="text"
                                   name="reg-fname"
                                   id="reg-fname"
                                   placeholder="<?php echo esc_attr($settings['log_reg_fname']); ?>" required>
                                <span class="la la-user input-icon"></span>
                            </div>
                        </div>

                        <div class="input-box">
                            <?php if(!empty($settings['log_reg_lname'])) { ?>
                                <label class="label-text" for="reg-lname"><?php echo esc_html($settings['log_reg_lname']); ?>
                                    <span class="primary-color-2 ml-1">
                                        <?php esc_html_e( '*', 'useful-addons-elementor' ); ?>
                                    </span>
                                </label>
                            <?php } ?>
                            <div class="form-group">
                                <input
                                   class="form-control"
                                   type="text"
                                   name="reg-lname"
                                   id="reg-lname"
                                   placeholder="<?php echo esc_attr($settings['log_reg_lname']); ?>" required>
                                <span class="la la-user input-icon"></span>
                            </div>
                        </div>

                        <div class="input-box">
                            <?php if(!empty($settings['log_reg_uname'])) { ?>
                                <label class="label-text" for="reg-username"><?php echo esc_html($settings['log_reg_uname']); ?>
                                    <span class="primary-color-2 ml-1">
                                        <?php esc_html_e( '*', 'useful-addons-elementor' ); ?>
                                    </span>
                                </label>
                            <?php } ?>
                            <div class="form-group">
                                <input
                                   class="form-control"
                                   type="text"
                                   name="reg-username"
                                   id="reg-username"
                                   placeholder="<?php echo esc_attr($settings['log_reg_uname']); ?>" required>
                                <span class="la la-user input-icon"></span>
                            </div>
                        </div>

                        <div class="input-box">
                            <?php if(!empty($settings['log_reg_email'])) { ?>
                                <label class="label-text" for="reg-email"><?php echo esc_html($settings['log_reg_email']); ?>
                                    <span class="primary-color-2 ml-1">
                                        <?php esc_html_e( '*', 'useful-addons-elementor' ); ?>
                                    </span>
                                </label>
                            <?php } ?>
                            <div class="form-group">
                                <input
                                   class="form-control"
                                   type="text"
                                   name="email"
                                   id="reg-email"
                                   placeholder="<?php echo esc_attr($settings['log_reg_email']); ?>" required>
                                <span class="la la-envelope input-icon"></span>
                            </div>
                        </div>

                        <div class="input-box">
                            <?php if(!empty($settings['log_reg_password'])) { ?>
                                <label class="label-text" for="reg-password">
                                    <?php echo esc_html($settings['log_reg_password']); ?>
                                    <span class="primary-color-2 ml-1">
                                        <?php esc_html_e( '*', 'useful-addons-elementor' ); ?>
                                    </span>
                                </label>
                            <?php } ?>
                            <div class="form-group">
                                <input
                                   class="form-control"
                                   type="password"
                                   name="password"
                                   id="reg-password"
                                   placeholder="<?php echo esc_attr($settings['log_reg_password']); ?>" required>
                                <span class="la la-lock input-icon"></span>
                            </div>
                        </div>

                        <div class="input-box">
                            <?php if(!empty($settings['log_reg_confirm_password'])) { ?>
                                <label class="label-text" for="reg-password2"><?php echo esc_html($settings['log_reg_confirm_password']); ?>
                                    <span class="primary-color-2 ml-1">
                                        <?php esc_html_e( '*', 'useful-addons-elementor' ); ?>
                                    </span>
                                </label>
                            <?php } ?>
                            <div class="form-group">
                                <input
                                   class="form-control"
                                   type="password"
                                   name="password2"
                                   id="reg-password2"
                                   placeholder="<?php echo esc_attr($settings['log_reg_confirm_password']); ?>" required>
                                <span class="la la-lock input-icon"></span>
                            </div>
                        </div>

                        <?php if(!empty($settings['log_reg_button'])) { ?>
                            <div class="btn-box">
                                <button class="ua-login-btn" type="submit" id="aduca-pop-register-submit">
                                    <?php echo esc_html($settings['log_reg_button']); ?>
                                </button>
                            </div>
                        <?php } if($settings['log_reg_show_have_an_acnt'] == 'yes') { ?>
                            <p class="mt-4 already-have-account">
                                <?php echo esc_html($settings['log_reg_have_an_acnt']); ?>
                                <a href="<?php echo esc_url($settings['log_reg_login_link']['url']); ?>" <?php echo esc_attr($lg_target) . ' ' . esc_attr($lg_nofollow); ?> class="primary-color-2">
                                    <?php echo esc_html($settings['log_reg_login_title']); ?>
                                </a>
                            </p>
                        <?php } ?>
                    </form>
                <?php }
            } else { ?>
                <h3>
                    <?php esc_html_e('Already you are login!', 'useful-addons-elementor'); ?>
                    <a href="<?php echo wp_logout_url( apply_filters( 'the_permalink', get_permalink( get_the_ID() ), get_the_ID() ) ); ?>" class="logout-button">
                        <?php esc_html_e('Logout', 'useful-addons-elementor'); ?>
                    </a>
                </h3>
            <?php
            }

            ?>
        </div>
        <?php

	}

	protected function _content_template() { }
}

Plugin::instance()->widgets_manager->register_widget_type( new ua_login_register() );