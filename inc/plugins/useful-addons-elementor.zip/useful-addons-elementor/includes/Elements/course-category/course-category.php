<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class ua_course_category extends Widget_Base {
	public function get_name() {
		return 'ua_course_category';
	}

	public function get_title() {
		return esc_html__( 'Course Category', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-archive-posts ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/*----------------------------------
	    UA Course Category Content
	------------------------------------*/
	private function get_course_cat_content() {
		$this->start_controls_section( 'course_category_content',
			[
				'label' => __( 'Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
        $this->add_control( 'course_cat_num_of_col',
            [
                'label'   => __( 'Number Of Column(s)', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '4',
                'options' => [
                    '12' => __( '1 Column', 'useful-addons-elementor' ),
                    '6'  => __( '2 Columns', 'useful-addons-elementor' ),
                    '4'  => __( '3 Columns', 'useful-addons-elementor' ),
                    '3'  => __( '4 Columns', 'useful-addons-elementor' ),
                    '2'  => __( '6 Columns', 'useful-addons-elementor' ),
                    '1'  => __( '12 Columns', 'useful-addons-elementor' ),
                ],
            ]
        );
		$this->add_control( 'course_category_btn_text',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Explore Now', 'useful-addons-elementor' ),
			]
		);
        $this->add_control('course_category_show_num',
            [
                'label'   => __( 'Number Of Categories', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 20,
                'step'    => 1,
                'default' => 6,
            ]
        );
		$this->end_controls_section();
    }
	private function get_course_cat_title_style() {
		$this->start_controls_section( 'course_cat_title_style',
			[
				'label' => __( 'Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'course_cat_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-category h3 a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_cat_title_clr_hv',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-course-category h3 a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_cat_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category h3',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_cat_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category h3',
			]
		);
		$this->add_control( 'course_cat_title_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category h3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_cat_stitle_style() {
		$this->start_controls_section( 'course_cat_stitle_style',
			[
				'label' => __( 'Sub Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'course_cat_stitle_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-category p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(Group_Control_Typography::get_type(),
			[
				'name'     => 'course_cat_stitle_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category p',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_cat_stitle_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category p',
			]
		);
		$this->add_control( 'course_cat_stitle_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category p' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_stitle_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_stitle_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '4',
                    'right'  => '0',
                    'bottom' => '0',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_course_cat_btn_style() {
		$this->start_controls_section( 'course_cat_btn_style',
			[
				'label' => __( 'Button', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'course_cat_btn_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category .ua-course-category-btn',
			]
		);
		/* ---------------------------
		    Start Tab
		-----------------------------*/
		$this->start_controls_tabs( 'course_cat_btn_tab',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'course_cat_btn_nrml',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_cat_btn_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-course-category .ua-course-category-btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_cat_btn_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-category .ua-course-category-btn' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'course_cat_btn_border',
				'label'    => esc_html__( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category .ua-course-category-btn',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#ffffff',
					],
				],
			]
		);
		$this->add_control( 'course_cat_btn_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '5',
                    'right'  => '5',
                    'bottom' => '5',
                    'left'   => '5',
                    'unit'   => 'px',
                    'isLinked' => true
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category .ua-course-category-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_btn_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '20',
                    'bottom' => '0',
                    'left'   => '20',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category .ua-course-category-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_btn_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category .ua-course-category-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'course_cat_btn_hv',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'course_cat_btn_clr_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-course-category .ua-course-category-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'course_cat_btn_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-course-category .ua-course-category-btn:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'course_cat_btn_border_hv',
				'label'    => esc_html__( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category .ua-course-category-btn:hover',
			]
		);
		$this->add_control( 'course_cat_btn_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category .ua-course-category-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_btn_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category .ua-course-category-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_btn_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category .ua-course-category-btn:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* ---------------------------
		    End Tab
		-----------------------------*/
		$this->end_controls_section();
	}
	private function get_course_cat_box_style() {
		$this->start_controls_section( 'course_cat_box_style',
			[
				'label' => __( 'Box', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		/* ---------------------------
		    Start Tab
		-----------------------------*/
		$this->start_controls_tabs( 'course_cat_box_tab',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'course_cat_box_nrml',
			[
				'label'     => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_cat_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category',
			]
		);
		$this->add_control( 'course_cat_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '4',
					'right'  => '4',
					'bottom' => '4',
					'left'   => '4',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_cat_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category',
			]
		);
		$this->add_responsive_control( 'course_cat_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '0',
					'bottom' => '30',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'course_cat_box_hv',
			[
				'label'     => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_cat_box_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category:hover',
			]
		);
		$this->add_control( 'course_cat_box_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'course_cat_box_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category:hover',
			]
		);
		$this->add_responsive_control( 'course_cat_box_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_box_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* ---------------------------
		    End Tab
		-----------------------------*/
		$this->add_control( 'course_cat_box_overlay',
			[
				'label'     => __( 'Overlay', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'course_cat_box_overlay_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(35, 61, 99,0.8)',
				'selectors' => [
					'{{WRAPPER}} .ua-course-category:after' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'course_cat_box_overlay_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-course-category:after',
			]
		);
		$this->add_control( 'course_cat_box_overlay_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-course-category:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_box_overlay_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-category:after' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'course_cat_box_overlay_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-course-category:after' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls() {
		$this->get_course_cat_content();
		$this->get_course_cat_title_style();
		$this->get_course_cat_stitle_style();
		$this->get_course_cat_btn_style();
		$this->get_course_cat_box_style();

	}


	protected function render( ) {
		$settings   = $this->get_settings_for_display();
		$cat_number = $settings['course_category_show_num'];

		if(function_exists('tutor')) {
		?>
        <div class="row">
            <?php

                $args = array(
                    'orderby'    => 'name',
                    'order'      => 'ASC',
                    'parent'     => 0,
                    'hide_empty' => 0,
                    'taxonomy'   => 'course-category',
                    'number'     => $cat_number
                );
                $terms = get_categories($args);
                $count = count( $terms );

                if ( $count > 0 ) {
                    foreach ( $terms as $term ) {
                        $termname = get_term_link( $term->term_id );
                        $termname = str_replace( ' ', '-', $termname );

						$thumbnail_id = absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) );
						if ( $thumbnail_id ) {
							$image = wp_get_attachment_thumb_url( $thumbnail_id );
							$image = str_replace('-150x150.', '.', $image);
						} else {
							$image = tutor_placeholder_img_src();
						}
                        ?>
                        <div class="col-lg-<?php echo esc_attr($settings['course_cat_num_of_col']); ?> col-sm-6">
                            <div class="ua-course-category transition-all-3s">
                                <img class="transition-all-3s" src="<?php echo esc_url( $image ); ?>" width="370" height="246" alt="">
                                <div class="ua-course-category-content transition-all-3s">
                                    <div class="ua-course-category-inner">
                                        <?php if (!empty($term->name)) { ?>
                                            <h3 class="ua-course-category-title transition-all-3s">
                                                <a href="<?php echo esc_url($termname); ?>">
                                                    <?php echo esc_html($term->name); ?>
                                                </a>
                                            </h3>
                                        <?php } ?>
                                        <p class="ua-course-category-meta transition-all-3s">
                                            <?php echo esc_html($term->count); esc_html_e(' courses', 'useful-addons-elementor'); ?>
                                        </p>
                                        <?php if(!empty($settings['course_category_btn_text'])) { ?>
                                            <a href="<?php echo esc_url($termname); ?>" class="ua-course-category-btn transition-all-3s">
                                                <?php echo esc_html($settings['course_category_btn_text']); ?>
                                            </a>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
            ?>
        </div>
		<?php
        }
	}

	protected function _content_template() { }
}
Plugin::instance()->widgets_manager->register_widget_type( new ua_course_category() );