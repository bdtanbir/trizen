
<?php 
    $social_fb =               get_post_meta( get_the_ID(), 'ua_team_social_fb', true );
     $social_tw  =             get_post_meta( get_the_ID(), 'ua_team_social_tw', true );
      $social_ln   =           get_post_meta( get_the_ID(), 'ua_team_social_ln', true );
       $social_yt    =         get_post_meta( get_the_ID(), 'ua_team_social_yt', true );
        $social_gg     =       get_post_meta( get_the_ID(), 'ua_team_social_gg', true );
         $social_pt      =     get_post_meta( get_the_ID(), 'ua_team_social_pt', true );
          $social_gt       =   get_post_meta( get_the_ID(), 'ua_team_social_gt', true );
           $social_dd        = get_post_meta( get_the_ID(), 'ua_team_social_dd', true );

    if(
        !empty( $social_fb ) ||
        !empty( $social_tw ) ||
        !empty( $social_ln ) ||
        !empty( $social_yt ) ||
        !empty( $social_gg ) ||
        !empty( $social_pt ) ||
        !empty( $social_gt ) ||
        !empty( $social_dd )
    ) {
?>


<ul class="ua-team3-social-profile d-flex align-items-center flex-wrap">
    <?php if ( !empty( $social_fb ) ) { ?>
        <li>
            <a href="<?php echo esc_url($social_fb); ?>">
                <i class="fab fa-facebook-f"></i>
            </a>
        </li>
    <?php } 
    
    if ( !empty( $social_tw ) ) { ?>
        <li>
            <a href="<?php echo esc_url($social_tw); ?>">
                <i class="fab fa-twitter"></i>
            </a>
        </li>
    <?php } 
    
    if ( !empty( $social_ln ) ) { ?>
        <li>
            <a href="<?php echo esc_url($social_ln); ?>">
                <i class="fab fa-linkedin-in"></i>
            </a>
        </li>
    <?php } 
    
    if ( !empty( $social_yt ) ) { ?>
        <li>
            <a href="<?php echo esc_url($social_yt); ?>">
                <i class="fab fa-youtube"></i>
            </a>
        </li>
    <?php } 
    
    if ( !empty( $social_gg ) ) { ?>
        <li>
            <a href="<?php echo esc_url($social_gg); ?>">
                <i class="fab fa-google"></i>
            </a>
        </li>
    <?php }  
    
    if ( !empty( $social_pt ) ) { ?>
        <li>
            <a href="<?php echo esc_url($social_pt); ?>">
                <i class="fab fa-pinterest-p"></i>
            </a>
        </li>
    <?php }  
    
    if ( !empty( $social_gt ) ) { ?>
        <li>
            <a href="<?php echo esc_url($social_gt); ?>">
                <i class="fab fa-github"></i>
            </a>
        </li>
    <?php }  
    
    if ( !empty( $social_dd ) ) { ?>
        <li>
            <a href="<?php echo esc_url($social_dd); ?>">
                <i class="fab fa-dribbble"></i>
            </a>
        </li>
    <?php } ?>
</ul>

<?php 
}
 ?>