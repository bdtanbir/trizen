<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_teams extends Widget_Base {
	public function get_name() {
		return 'UA_teams';
	}

	public function get_title() {
		return esc_html__( 'Team Members', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-person ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Team Content setting */
	private function get_content_team( ){
		$this->start_controls_section( 'UA_team_content_setting',
			[
				'label' => __( 'Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
                'condition' => [
                    'ua_team_layout_style' => ['style_1','style_2']
                ]
			]
		);
		$this->add_control( 'ua_team_post_per_page',
			[
				'label'   => __( 'Posts Per Page', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
				'default' => 9,
			]
		);
		$this->add_control( 'ua_team_order_by',
			[
				'label'             => __( 'Order By', 'useful-addons-elementor' ),
				'type'              => Controls_Manager::SELECT,
				'default'           => 'date',
				'options'           => [
					'ID'            => 'Post ID',
					'author'        => 'Post Author',
					'title'         => 'Title',
					'date'          => 'Date',
					'modified'      => 'Last Modified Date',
					'parent'        => 'Parent Id',
					'rand'          => 'Random',
					'comment_count' => 'Comment Count',
					'menu_order'    => 'Menu Order',
				],
			]
		);
		$this->add_control( 'ua_team_order',
			[
				'label'    => __('Order', 'useful-addons-elementor'),
				'type'     => Controls_Manager::SELECT,
				'options'  => [
					'asc'  => 'Ascending',
					'desc' => 'Descending',
				],
				'default'  => 'desc',

			]
		);
        $this->add_control('ua_team_by_ids',
            [
                'label'       => __( 'Team By IDs', 'useful-addons-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'placeholder' => __( 'Enter course ids here for example: <strong>1, 2, 3</strong>', 'useful-addons-elementor' ),
            ]
        );
		$this->end_controls_section();
	}
	private function get_layout_team()
	{
		$this->start_controls_section( 'UA_team_layout_setting',
			[
				'label' => __( 'Layout', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control('ua_team_layout_style',
			[
				'label'   => __( 'Layout Style', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'style_1',
				'options' => [
					'style_1' => __( 'Style 1', 'useful-addons-elementor' ),
					'style_2' => __( 'Style 2', 'useful-addons-elementor' ),
					'style_3' => __( 'Style 3', 'useful-addons-elementor' ),
				],
			]
		);
		$this->add_control('ua_team_columns_width',
			[
				'label'   => __( 'Columns Width', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '4',
				'options' => [
					'12'=> __( 'Column 1', 'useful-addons-elementor' ),
					'6' => __( 'Column 2', 'useful-addons-elementor' ),
					'4' => __( 'Column 3', 'useful-addons-elementor' ),
					'3' => __( 'Column 4', 'useful-addons-elementor' ),
					'2' => __( 'Column 6', 'useful-addons-elementor' ),
				],
                'condition' => [
                    'ua_team_layout_style' => ['style_1', 'style_2']
                ]
			]
		);
		$this->add_control( 'UA_team_alignment',
			[
				'label'   => __('Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0' => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default' => '1',
			]
		);
		$this->add_control( 'UA_team_button_show',
			[
				'label'        => __('Show ReadMore Button', 'useful-addons-elementor'),
				'type'	       => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
                    'ua_team_layout_style' => ['style_1', 'style_2']
                ]
			]
		);
		$this->add_control( 'UA_team_button_text',
			[
				'label' 	  => __( 'Button Text', 'useful-addons-elementor' ),
				'type' 		  => Controls_Manager::TEXT,
				'default' 	  => __( 'Read His Story', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type button text here', 'useful-addons-elementor' ),
				'condition'   => [
					'UA_team_button_show' => 'yes',
                    'ua_team_layout_style' => ['style_1', 'style_2']
				],
			]
		);
		$this->add_control( 'UA_team_button_icon_condition',
			[
				'label'        => __( 'Show Button Icon', 'useful-addons-elementor' ),
				'type' 		   => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'UA_team_button_show'  => 'yes',
                    'ua_team_layout_style' => 'style_1'
				],
			]
		);
		$this->add_control('UA_team_button_icon',
			[
				'label'            => __( 'Button Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition'   => [
					'UA_team_button_icon_condition' => 'yes',
					'UA_team_button_show' 			=> 'yes',
					'ua_team_layout_style' 			=> 'style_1',
				],
			]
		);
		$this->add_control( 'UA_team_box_shape_condition',
			[
				'label' 	   => __( 'Show Box Shape', 'useful-addons-elementor' ),
				'type' 		   => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
                    'ua_team_layout_style' => ['style_1', 'style_2']
                ]
			]
		);


		/* UA Team3 */
        $this->add_control('ua_team4_image',
            [
                'label'   => __( 'Image', 'useful-addons-elementor' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'ua_team_layout_style' => 'style_3',
                ]
            ]
        );
        $this->add_control('ua_team4_name',
            [
                'label'       => __( 'Name', 'useful-addons-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Alex Smith', 'useful-addons-elementor' ),
                'placeholder' => __( 'Type name here', 'useful-addons-elementor' ),
                'condition'   => [
                    'ua_team_layout_style' => 'style_3',
                ]
            ]
        );
        $this->add_control('ua_team4_enable_name_link',
            [
                'label'        => __( 'Enable Link on Name', 'useful-addons-elementor' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => __( 'Tue', 'useful-addons-elementor' ),
                'label_off'    => __( 'False', 'useful-addons-elementor' ),
                'return_value' => 'yes',
                'default'      => 'yes',
                'condition'   => [
                    'ua_team_layout_style' => ['style_1','style_3'],
                ]
            ]
        );
        $this->add_control('ua_team4_designation',
            [
                'label'       => __( 'Designation', 'useful-addons-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Teacher', 'useful-addons-elementor' ),
                'placeholder' => __( 'Type Designation here', 'useful-addons-elementor' ),
                'condition'   => [
                    'ua_team_layout_style' => 'style_3',
                ]
            ]
        );
        $this->add_control('ua_team3_content',
            [
                'label'       => __( 'Content', 'useful-addons-elementor' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 8,
                'default'     => __( 'Pellentesque tellus arcu, laoreet volutpavenenatis molest commodo lorem lectus pretium vehicula.', 'useful-addons-elementor' ),
                'placeholder' => __( 'Type your Content here', 'useful-addons-elementor' ),
                'condition'   => [
                    'ua_team_layout_style' => ['style_1','style_3'],
                ]
            ]
        );
        $this->add_control('ua_team4_btn_tx',
            [
                'label'       => __( 'Button Text', 'useful-addons-elementor' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'view profile', 'useful-addons-elementor' ),
                'placeholder' => __( 'Type button text here', 'useful-addons-elementor' ),
                'condition'   => [
                    'ua_team_layout_style' => ['style_1','style_3'],
                ]
            ]
        );
        $this->add_control('ua_team4_link',
            [
                'label'         => __( 'Read More Link', 'useful-addons-elementor' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
                'condition'   => [
                    'ua_team_layout_style' => ['style_1','style_3'],
                ]
            ]
        );

        /* social links */
        $this->add_control('ua_team4_socials',
            [
                'label'  => __( 'Social Links', 'useful-addons-elementor' ),
                'type'   => Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name'    => 'ua_team4_social_icon',
                        'label'   => __( 'Icon', 'useful-addons-elementor' ),
                        'type'    => Controls_Manager::ICONS,
                        'default' => [
                            'value'   => 'fab fa-facebook-f',
                            'library' => 'solid',
                        ],
                    ],
                    [
                        'name'    => 'ua_team4_social_link',
                        'label'         => __( 'Link', 'useful-addons-elementor' ),
                        'type'          => Controls_Manager::URL,
                        'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
                        'show_external' => true,
                        'default' => [
                            'url' => 'https://facebook.com',
                            'is_external' => false,
                            'nofollow'    => false,
                        ],
                    ]
                ],
                'default' => [
                    [
                        'ua_team4_social_icon' => 'fab fa-facebook-f',
                        'ua_team4_social_link' => 'https://facebook.com',
                    ]
                ],
                'title_field' => 'Social Icon',
                'condition'   => [
                    'ua_team_layout_style' => ['style_1','style_3'],
                ]
            ]
        );
		$this->end_controls_section();
	}


	/* UA Team title Style controls */
	private function get_style_team_title( ){
		$this->start_controls_section( 'team_title_style',
			[
				'label' => __( 'Title', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_1'
                ]
			]
		);
		$this->add_control( 'team_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team__title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 	   => 'team_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item .team-content .team__title',
			]
		);
		$this->add_responsive_control( 'team_title_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content .team__title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'team_title_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '5',
					'right'    => '0',
					'bottom'   => '3',
					'left'     => '0',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Team Skills Style Controls */
	private function get_style_team_skills() {
		$this->start_controls_section( 'UA_team_skills_style',
			[
				'label' => __( 'Designation', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_1'
                ]
			]
		);
		$this->add_control( 'UA_team_skills_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'	    => Controls_Manager::COLOR,
				'default'   => '#677286',
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team__meta' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_team_skills_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item .team-content .team__meta',
			]
		);
		$this->add_responsive_control( 'UA_team_skills_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content .team__meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_team_skills_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content .team__meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Team Image style Controls*/
	private function get_style_team_image( ){
		$this->start_controls_section( 'UA_team_image_style',
			[
				'label' => __( 'Image', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_1'
                ]
			]
		);
		$this->add_responsive_control( 'UA_team_image_width',
			[
				'label' 	 => __( 'Width', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' 	 => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => '%',
					'size' => 100,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-img-box img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_team_image_height',
			[
				'label' 	 => __( 'Height', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' 	 => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-img-box img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_team_image_radius',
			[
				'label' 	 => __( 'Border Radius', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top' 	   => '4',
					'right'    => '4',
					'bottom'   => '0',
					'left' 	   => '0',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-img-box img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 	   => 'UA_team_image_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item .team-img-box img',
			]
		);
		$this->add_responsive_control( 'UA_team_image_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-img-box img' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_team_image_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-img-box img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Team Button Style Controls */
	private function get_style_team_button( ){
		$this->start_controls_section( 'UA_team_button_style',
			[
				'label' 	=> __( 'Read More Button', 'useful-addons-elementor' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'UA_team_button_show' => 'yes',
                    'ua_team_layout_style' => 'style_1'
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_team_button_tabs_control',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_team_button_normal_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_team_button_normal_clr',
			[
				'label' 	=> __( 'Color', 'useful-addons-elementor' ),
				'type' 		=> Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' 	   => 'UA_team_button_normal_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_team_button_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button',
			]
		);
		$this->add_responsive_control( 'UA_team_button_normal_radius',
			[
				'label' 	 => __( 'Border Radius', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' 	 => [
					'top' 	   => '30',
					'right'    => '30',
					'bottom'   => '30',
					'left' 	   => '30',
					'unit' 	   => 'px',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_team_button_normal_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' 	 => [
					'top' 	   => '10',
					'right'    => '40',
					'bottom'   => '10',
					'left'     => '25',
					'unit' 	   => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_team_button_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top' 	   => '28',
					'right'    => '0',
					'bottom'   => '0',
					'left' 	   => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'UA_team_button_hover_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_team_button_hover_clr',
			[
				'label' 	=> __( 'Color', 'useful-addons-elementor' ),
				'type' 	    => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'UA_team_button_hover_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'UA_team_button_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button:hover',
			]
		);
		$this->add_responsive_control( 'UA_team_button_hover_radius',
			[
				'label' 	 => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_team_button_hover_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'UA_team_button_hover_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control(
			'team_end_button_divider',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'UA_team_button_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button',
			]
		);

		// Icon
		$this->add_control( 'UA_team_button_icon_heading',
			[
				'label' 	=> __( 'Icon', 'useful-addons-elementor' ),
				'type' 		=> Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control('ua_team_button_icon_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button .fa__arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_team_button_icon_tabs_control',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_team_button_icon_normal_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_team_button_icon_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button .fa__arrow' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_team_button_icon_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button .fa__arrow' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'UA_team_button_icon_normal_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'UA_team_button_icon_hover_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'UA_team_button_icon_hover_clr',
			[
				'label' 	=> __( 'Color', 'useful-addons-elementor' ),
				'type' 		=> Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button:hover .fa__arrow' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'UA_team_button_icon_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button:hover .fa__arrow' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'UA_team_button_icon_hover_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content .team-read-btn .theme-button:hover .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* UA Team social media style controls */
	private function get_style_team_social_media( ){
		$this->start_controls_section( 'team_social_style',
			[
				'label' => __( 'Social Profile', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_1'
                ]
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'team_social_background',
				'label'    => __( 'Social Box Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-team-item .team-content .team__social',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 	   => 'team_social_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item .team-content .team__social',
			]
		);
		$this->add_responsive_control( 'team_social_radius',
			[
				'label' 	 => __( 'Border Radius', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content .team__social' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'team_social_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' 	 => [
					'top' 	   => '10',
					'right'    => '35',
					'bottom'   => '10',
					'left' 	   => '35',
					'unit' 	   => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team__social' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// icon
		$this->add_control( 'team_social_icon_setting',
			[
				'label' 	=> __( 'Icon', 'useful-addons-elementor' ),
				'type' 		=> Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'team_social_icon_normal_color',
			[
				'label' 	=> __( 'Color', 'useful-addons-elementor' ),
				'type' 		=> Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team__social li a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'team_social_icon_hover_color',
			[
				'label' 	=> __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team__social li a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'team_social_icon_size',
			[
				'label' 	 => __( 'Font Size', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' 	 => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 20,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content .team__social li a' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'team_social_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content .team__social li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Team box Style Controls */
	private function get_style_team_box( ){
		$this->start_controls_section( 'team_box_style',
			[
				'label' => __( 'Box', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_1'
                ]
			]
		);
		// start tab
		$this->start_controls_tabs( 'team_box_tabs_control',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'team_box_normal_tabs',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'team_box_normal_background',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-team-item',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'team_box_normal_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'team_box_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item',
			]
		);
		$this->add_responsive_control( 'team_box_normal_radius',
			[
				'label' 	 => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'team_box_normal_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'team_box_normal_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' 	 => [
					'top' 	   => '0',
					'right'    => '0',
					'bottom'   => '30',
					'left'     => '0',
					'unit' 	   => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'team_box_hover_tabs',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'team_box_hover_background',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-team-item:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'team_box_hover_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'team_box_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item:hover',
			]
		);
		$this->add_responsive_control( 'team_box_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'team_box_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'team_box_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'team_content_box',
			[
				'label'     => __( 'Content Box', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'team_content_box_background',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-team-item .team-content',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'team_content_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-team-item .team-content',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#eeeeee',
					],
				],
			]
		);
		$this->add_responsive_control( 'team_content_box_radius',
			[
				'label' 	 => __( 'Border Radius', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' 	 => [
					'top' 	   => '0',
					'right'    => '0',
					'bottom'   => '4',
					'left'     => '4',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'team_content_box_padding',
			[
				'label' 	 => __( 'Padding', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' 	 => [
					'top'      => '30',
					'right'    => '20',
					'bottom'   => '35',
					'left' 	   => '20',
					'unit' 	   => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'team_content_box_margin',
			[
				'label' 	 => __( 'Margin', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-team-item .team-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Team box Shape Style Controls */
	private function get_style_team_box_shape( ){
		$this->start_controls_section( 'UA_team_box_shape_style',
			[
				'label' 	=> __( 'Box Shape', 'useful-addons-elementor' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'UA_team_box_shape_condition' => 'yes',
                    'ua_team_layout_style' => 'style_1'
				]
			]
		);
		// start tab
		$this->start_controls_tabs( 'UA_team_box_shape_tabs_control',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'UA_team_box_shape_normal_tabs',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_team_box_shape_normal_color',
			[
				'label' 	=> __( 'Color', 'useful-addons-elementor' ),
				'type' 		=> Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-img-box:after' => 'border-bottom-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'UA_team_box_shape_hover_tabs',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('UA_team_box_shape_hv_color',
			[
				'label' 	=> __( 'Color', 'useful-addons-elementor' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-team-item:hover .team-img-box:after' => 'border-bottom-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_responsive_control('UA_team_box_shape_size',
			[
				'label' 	 => __( 'Size', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' 	 => [
					'px' => [
						'min'  => 0,
						'max'  => 500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 12,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-team-item .team-img-box:after' => 'border-bottom-width: {{SIZE}}{{UNIT}}; border-right-width: {{SIZE}}{{UNIT}};border-left-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


    /* UA Team2 Style controls */
    private function get_style_team2_image( ) {
        $this->start_controls_section('team2_image_style',
            [
                'label'     => __('Image', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_2'
                ]
            ]
        );
        $this->add_responsive_control('team2_image_width',
            [
                'label' => __( 'Width', 'useful-addons-elementor' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 300,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-img-box' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team2_image_height',
            [
                'label' => __( 'Height', 'useful-addons-elementor' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 300,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-img-box' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team2_image_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item .ua-team2-img-box',
            ]
        );
        $this->add_responsive_control('team2_image_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'    => '50',
                    'right'  => '50',
                    'bottom' => '50',
                    'left'   => '50',
                    'unit'   => '%',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-img-box'     => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .ua-team2-item .ua-team2-img-box img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team2_image_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item .ua-team2-img-box',
            ]
        );
        $this->add_responsive_control('team2_image_margin',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'rem' ],
                'allowed_dimensions' => 'vertical',
                'placeholder' => [
                    'top'    => '',
                    'right'  => 'auto',
                    'bottom' => '',
                    'left'   => 'auto',
                ],
                'default'   => [
                    'top'      => '0',
                    'right'    => 'auto',
                    'bottom'   => '20',
                    'left'     => 'auto',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-img-box' => 'margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_team2_name( ) {
        $this->start_controls_section('team2_name_style',
            [
                'label'     => __('Name', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_2'
                ]
            ]
        );
        $this->add_control('team2_name_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#233d63',
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-title' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Typography::get_type(),
            [
                'name'     => 'team2_name_typography',
                'label'    => __( 'Typography', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-title',
            ]
        );
        $this->add_responsive_control('team2_name_margin',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '3',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_team2_designation( ) {
        $this->start_controls_section('team2_designation_style',
            [
                'label'     => __('Designation', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_2'
                ]
            ]
        );
        $this->add_control('team2_designation_color',
            [
                'label'     => __('Color', 'useful-addons-elementor'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#7f8897',
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-meta' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Typography::get_type(),
            [
                'name'     => 'team2_designation_typography',
                'label'    => __( 'Typography', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-meta',
            ]
        );
        $this->add_responsive_control('team2_designation_margin',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '20',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_team2_btn( ) {
        $this->start_controls_section('team2_btn_style',
            [
                'label'     => __('Button', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_2'
                ]
            ]
        );
        /*
         * Start Tab
        */
        $this->start_controls_tabs( 'team2_btn_tabs',
            [
                'separator' => 'before'
            ]
        );
        // Normal Tab
        $this->start_controls_tab( 'team2_btn_nrml_tab',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('team2_btn_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#7f8897',
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('team2_btn_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(127, 136, 151, 0.1)',
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team2_btn_border',
                'label'    => esc_html__( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn',
                'fields_options'  => [
                    'border'      => [
                        'default' => 'solid',
                    ],
                    'width'       => [
                        'default' => [
                            'top'      => '1',
                            'right'    => '1',
                            'bottom'   => '1',
                            'left'     => '1',
                            'isLinked' => true,
                        ],
                    ],
                    'color' => [
                        'default' => 'rgba(127, 136, 151, 0.2)',
                    ],
                ],
            ]
        );
        $this->add_responsive_control('team2_btn_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '30',
                    'right'    => '30',
                    'bottom'   => '30',
                    'left'     => '30',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team2_btn_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn',
            ]
        );
        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab( 'team2_btn_hv_tab',
            [
                'label' => __( 'Hover', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('team2_btn_color_hv',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('team2_btn_bg_hv',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#51be78',
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn:hover' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team2_btn_border_hv',
                'label'    => esc_html__( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn:hover'
            ]
        );
        $this->add_responsive_control('team2_btn_radius_hv',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team2_btn_shadow_hv',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn:hover',
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        /*
         * End Tab
         */
        $this->add_control('team2_hr',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );
        $this->add_responsive_control('team2_btn_margin',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team2_btn_padding',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '0',
                    'right'    => '20',
                    'bottom'   => '0',
                    'left'     => '20',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Typography::get_type(),
            [
                'name'     => 'team2_btn_typography',
                'label'    => __( 'Typography', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item .ua-team2-content .ua-team2-btn',
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_team2_box( ) {
        $this->start_controls_section('team2_box_style',
            [
                'label'     => __('Box', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_2'
                ]
            ]
        );
        /*
         * Start Tab
        */
        $this->start_controls_tabs( 'team2_box_tabs',
            [
                'separator' => 'before'
            ]
        );
        // Normal Tab
        $this->start_controls_tab( 'team2_box_nrml_tab',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('team2_box_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team2_box_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item',
            ]
        );
        $this->add_responsive_control('team2_box_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '8',
                    'right'    => '8',
                    'bottom'   => '8',
                    'left'     => '8',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team2-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control( Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team2_box_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'fields_options' => [
                    'box_shadow_type' => [
                        'default'     =>'yes'
                    ],
                    'box_shadow'  => [
                        'default' => [
                            'horizontal' => 0,
                            'vertical'   => 0,
                            'blur'       => 30,
                            'spread'     => 0,
                            'color'      => 'rgba(46, 61, 73, 0.1)'
                        ]
                    ]
                ],
                'selector' => '{{WRAPPER}} .ua-team2-item',
            ]
        );
        $this->add_responsive_control('team2_box_pd',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '40',
                    'right'    => '10',
                    'bottom'   => '40',
                    'left'     => '10',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team2-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team2_box_mg',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '30',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team2-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab( 'team2_box_hv_tab',
            [
                'label' => __( 'Hover', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('team2_box_bg_hv',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item:hover' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team2_box_border_hv',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item:hover',
            ]
        );
        $this->add_responsive_control('team2_box_radius_hv',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team2-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control( Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team2_box_shadow_hv',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team2-item:hover',
            ]
        );
        $this->add_responsive_control('team2_box_pd_hv',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team2-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team2_box_mg_hv',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team2-item:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        /*
         * End Tab
         */
        /* Box Shape */
        $this->add_control('team2_box_shape_hd',
            [
                'label'     => __( 'Box\'s Shape', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        $this->add_control('team2_box_shape_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'rgba(127, 136, 151, 0.2)',
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item:after' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('team2_box_shape_bg_hv',
            [
                'label'     => __( 'Hover Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#51be78',
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item:hover:after' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control('team2_box_shape_width',
            [
                'label'      => __( 'Width', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 500,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 60,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item:after' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team2_box_shape_height',
            [
                'label'      => __( 'Height', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 20,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 4,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team2-item:after' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team2_box_shape_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '5',
                    'left'     => '5',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team2-item:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }


    /* UA Team4 Style controls */
    private function get_style_team4_image( ){
        $this->start_controls_section('team4_image_style',
            [
                'label'     => __('Image', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_3'
                ]
            ]
        );
        $this->add_responsive_control('team4_image_width',
            [
                'label'      => __( 'Width', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 200,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team4_image_height',
            [
                'label'      => __( 'Height', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range'  => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 200,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team4_image_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'     => '50',
                    'right'   => '50',
                    'bottom'  => '50',
                    'left'    => '50',
                    'unit'    => '%',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box'     => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team4_image_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-img-box',
            ]
        );
        $this->add_responsive_control('team4_image_margin',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'rem' ],
                'allowed_dimensions' => 'vertical',
                'placeholder' => [
                    'top'    => '',
                    'right'  => 'auto',
                    'bottom' => '',
                    'left'   => 'auto',
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box' => 'margin-top: {{TOP}}{{UNIT}}; margin-bottom: {{BOTTOM}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_team4_name() {
        $this->start_controls_section('team4_name_style',
            [
                'label'     => __('Name', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_3'
                ]
            ]
        );
        $this->add_control('team4_name_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#233d63',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail h3'   => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail h3 a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('team4_name_color_hv',
            [
                'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#51be78',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail h3:hover'   => 'color: {{VALUE}}',
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail h3:hover a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Typography::get_type(),
            [
                'name'     => 'team4_name_typography',
                'label'    => __( 'Typography', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-detail h3',
            ]
        );
        $this->add_responsive_control('team4_name_margin',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'rem' ],
                'default' => [
                    'top'    => '24',
                    'right'  => '0',
                    'bottom' => '3',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_team4_designation() {
        $this->start_controls_section('team4_designation_style',
            [
                'label'     => __('Designation', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_3'
                ]
            ]
        );
        $this->add_control('team4_designation_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#7f8897',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-meta'   => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Typography::get_type(),
            [
                'name'     => 'team4_designation_typography',
                'label'    => __( 'Typography', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-meta',
            ]
        );
        $this->add_responsive_control('team4_designation_margin',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%', 'rem' ],
                'default' => [
                    'top'    => '0',
                    'right'  => '0',
                    'bottom' => '15',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_team4_content() {
        $this->start_controls_section('team4_content_style',
            [
                'label'     => __('Content', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_3'
                ]
            ]
        );
        $this->add_control('team4_content_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#7f8897',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-content' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Typography::get_type(),
            [
                'name'     => 'team4_content_typography',
                'label'    => __( 'Typography', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-content',
            ]
        );
        $this->add_responsive_control('team4_content_margin',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '30',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_team4_btn() {
        $this->start_controls_section('team4_btn_style',
            [
                'label'     => __('Button', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_3'
                ]
            ]
        );
        $this->add_group_control(Group_Control_Typography::get_type(),
            [
                'name'     => 'team4_btn_typography',
                'label'    => __( 'Typography', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn',
            ]
        );
        /*
         * Start Tab
        */
        $this->start_controls_tabs( 'team4_btn_tabs',
            [
                'separator' => 'before'
            ]
        );
        // Normal Tab
        $this->start_controls_tab( 'team4_btn_nrml_tab',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('team4_btn_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('team4_btn_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#51be78',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team4_btn_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'fields_options'  => [
                    'border'      => [
                        'default' => 'solid',
                    ],
                    'width'       => [
                        'default' => [
                            'top'      => '1',
                            'right'    => '1',
                            'bottom'   => '1',
                            'left'     => '1',
                            'isLinked' => true,
                        ],
                    ],
                    'color' => [
                        'default' => '#51be78',
                    ],
                ],
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn',
            ]
        );
        $this->add_responsive_control('team4_btn_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'      => '30',
                    'right'    => '30',
                    'bottom'   => '30',
                    'left'     => '30',
                    'unit'     => 'px',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team4_btn_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn',
            ]
        );
        $this->add_responsive_control('team4_btn_padding',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'   => [
                    'top'      => '0',
                    'right'    => '30',
                    'bottom'   => '0',
                    'left'     => '30',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab( 'team4_btn_hv_tab',
            [
                'label' => __( 'Hover', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('team4_btn_color_hv',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#51be78',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('team4_btn_bg_hv',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn:hover' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team4_btn_border_hv',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn:hover',
            ]
        );
        $this->add_responsive_control('team4_btn_radius_hv',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team4_btn_shadow_hv',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn:hover',
            ]
        );
        $this->add_responsive_control('team4_btn_padding_hv',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        /*
         * End Tab
         */
        $this->add_control('team4_btn_hr',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );
        $this->add_responsive_control('team4_btn_margin_hv',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-detail .ua-team4-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_team4_socials() {
        $this->start_controls_section('team4_social_style',
            [
                'label'     => __('Social', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_3'
                ]
            ]
        );
        $this->add_responsive_control('team4_social_width',
            [
                'label'      => __( 'Width', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 34,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team4_social_height',
            [
                'label'      => __( 'Height', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 34,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team4_social_size',
            [
                'label'      => __( 'Font Size', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range'  => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 14,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li' => 'font-size: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team4_social_spc_between',
            [
                'label'      => __( 'Space between the social link', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 5,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 5,
                ],
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        /*
         * Start Tab
        */
        $this->start_controls_tabs( 'team4_social_tabs',
            [
                'separator' => 'before'
            ]
        );
        // Normal Tab
        $this->start_controls_tab( 'team4_social_nrml_tab',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('team4_social_color',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#233d63',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('team4_social_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team4_social_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a',
            ]
        );
        $this->add_responsive_control('team4_social_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'     => '50',
                    'right'    => '50',
                    'bottom'   => '50',
                    'left'     => '50',
                    'unit'     => '%',
                    'isLinked' => true,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team4_social_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a',
            ]
        );
        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab( 'team4_social_hv_tab',
            [
                'label' => __( 'Hover', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('team4_social_color_hv',
            [
                'label'     => __( 'Color', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control('team4_social_bg_hv',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#51be78',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a:hover' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team4_social_border_hv',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a:hover',
            ]
        );
        $this->add_responsive_control('team4_social_radius_h',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team4_social_shadow_hv',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a:hover',
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        /*
         * End Tab
         */
        $this->add_control('team4_social_hr',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );
        $this->add_responsive_control('team4_social_padding',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item .ua-team4-img-box .ua-team4-social-profile li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    private function get_style_team4_box() {
        $this->start_controls_section('team4_box_style',
            [
                'label'     => __('Box', 'useful-addons-elementor'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'ua_team_layout_style' => 'style_3'
                ]
            ]
        );
        /*
         * Start Tab
        */
        $this->start_controls_tabs( 'team4_box_tabs',
            [
                'separator' => 'before'
            ]
        );
        // Normal Tab
        $this->start_controls_tab( 'team4_box_nrml_tab',
            [
                'label' => __( 'Normal', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('team4_box_bg',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team4_box_border',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item',
            ]
        );
        $this->add_responsive_control('team4_box_radius',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team4_box_shadow',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item',
            ]
        );
        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab( 'team4_box_hv_tab',
            [
                'label' => __( 'Hover', 'useful-addons-elementor' ),
            ]
        );
        $this->add_control('team4_box_bg_hv',
            [
                'label'     => __( 'Background', 'useful-addons-elementor' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .ua-team4-item:hover' => 'background: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Border::get_type(),
            [
                'name'     => 'team4_box_border_hv',
                'label'    => __( 'Border', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item:hover',
            ]
        );
        $this->add_responsive_control('team4_box_radius_hv',
            [
                'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_group_control(Group_Control_Box_Shadow::get_type(),
            [
                'name'     => 'team4_box_shadow_hv',
                'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
                'selector' => '{{WRAPPER}} .ua-team4-item:hover',
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();
        /*
         * End Tab
         */
        $this->add_control('team4_box_hr',
            [
                'type' => Controls_Manager::DIVIDER,
            ]
        );
        $this->add_responsive_control('team4_box_padding',
            [
                'label'      => __( 'Padding', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'default'    => [
                    'top'     => '0',
                    'right'   => '40',
                    'bottom'  => '30',
                    'left'    => '40',
                    'unit'    => 'px',
                    'isLinked'=> false
                ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control('team4_box_margin',
            [
                'label'      => __( 'Margin', 'useful-addons-elementor' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .ua-team4-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
    }


	protected function _register_controls() {
		$this->get_content_team();
		$this->get_layout_team();
		$this->get_style_team_image();
		$this->get_style_team_title();
		$this->get_style_team_skills();
		$this->get_style_team_social_media();
		$this->get_style_team_button();
		$this->get_style_team_box();
		$this->get_style_team_box_shape();

		$this->get_style_team2_image();
		$this->get_style_team2_name();
		$this->get_style_team2_designation();
		$this->get_style_team2_btn();
		$this->get_style_team2_box();

		$this->get_style_team4_image();
		$this->get_style_team4_name();
		$this->get_style_team4_designation();
		$this->get_style_team4_content();
		$this->get_style_team4_btn();
		$this->get_style_team4_socials();
		$this->get_style_team4_box();
	}



	protected function render( ) {
		$settings = $this->get_settings_for_display();
        $team_ids = explode(',', $settings['ua_team_by_ids']);

		if( $settings['UA_team_alignment'] == '0' ) {
			$team_alignments = 'text-left justify-content-start';
		} elseif( $settings['UA_team_alignment'] == '1' ) {
			$team_alignments = 'text-center justify-content-center';
		} elseif( $settings['UA_team_alignment'] == '2' ) {
			$team_alignments = 'text-right justify-content-end';
		} else {
			$team_alignments = 'text-center justify-content-center';
		}
		if ( $settings['UA_team_box_shape_condition'] == 'yes' ) {
			$team_img_box_shape_class =  '';
		} else {
			$team_img_box_shape_class =  'hide_team_img_box_shape';
		}



		$tm_columns    = $settings['ua_team_columns_width'];
		$post_per_page = $settings['ua_team_post_per_page'];
		$orderby 	   = $settings['ua_team_order_by'];
		$order   	   = $settings['ua_team_order'];

		if(!empty($settings['ua_team_by_ids'])) {
            $default = [
                'posts_per_page' => $post_per_page,
                'orderby'        => $orderby,
                'order'          => $order,
                'post__in'       => $team_ids,
                'post_type'      => 'team'
            ];
        } else {
            $default = [
                'posts_per_page' => $post_per_page,
                'orderby'        => $orderby,
                'order'          => $order,
                'post_type'      => 'team'
            ];
        }

		/**
		 * Setup the post arguments.
		 */
		// Team Query
		$team_query = new \WP_Query( $default );


		if ($settings['ua_team_layout_style'] == 'style_1') {
            if( $team_query->have_posts() ) {
                ?>
                <div class="ua-team-wrapper">
                    <div class="row">
                        <?php
                        while($team_query->have_posts()) {
                            $team_query->the_post();
                            $tm_skill    = get_post_meta( get_the_ID(), 'tm_cnt_skill', true );
                            ?>
                            <div class="col-md-<?php echo esc_attr($tm_columns); ?> col-sm-6">
                                <div class="ua-team-item <?php echo esc_attr($team_alignments) . ' ' . esc_attr($team_img_box_shape_class); ?>">
                                    <?php if(!empty( get_the_post_thumbnail() )) { ?>
                                        <div class="team-img-box">
                                            <?php the_post_thumbnail(); ?>
                                        </div>
                                    <?php } ?>

                                    <div class="team-content">
                                        <?php if(!empty( get_the_title() )) { ?>
                                            <h3 class="team__title">
                                                <?php the_title(); ?>
                                            </h3>
                                        <?php }

                                        if( !empty( $tm_skill ) ) { ?>
                                            <span class="team__meta">
                                                <?php echo esc_html($tm_skill); ?>
                                            </span>
                                        <?php }
                                        require UA_ELEMENTOR_PATH.'./includes/Elements/team/team-social.php';

                                        if( !empty( $settings['UA_team_button_text'] ) && $settings['UA_team_button_show'] == 'yes' ) { ?>
                                            <div class="team-read-btn">
                                                <a href="<?php the_permalink(); ?>" class="theme-button">
                                                    <?php echo esc_html($settings['UA_team_button_text']); ?> <?php
                                                    if( $settings['UA_team_button_icon_condition'] == 'yes' ) {
                                                        if ( !empty( $settings['UA_team_button_icon'] ) ) {
                                                            Icons_Manager::render_icon( $settings['UA_team_button_icon'], ['class' => 'fa__arrow ', ' aria-hidden' => 'true' ] );
                                                        }
                                                    }
                                                    ?>
                                                </a>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>

                <?php
            } else { ?>
            <h2>
                <?php esc_html_e('Empty Team Member!', 'useful-addons-elementor'); ?>
            </h2>
            <?php }
            wp_reset_query();
        }
		elseif($settings['ua_team_layout_style'] == 'style_2') {
		    if( $team_query->have_posts() ) { ?>
            <div class="ua-team2-wrapper">
                <div class="row">
                <?php
                $i=0;
                while($team_query->have_posts()) {
                    $team_query->the_post();
                    $i++;
                    $team_designation    = get_post_meta( get_the_ID(), 'tm_cnt_designation', true );
                    ?>

                        <div class="col-lg-<?php echo esc_attr($settings['ua_team_columns_width']); ?> column-td-half">
                            <div class="ua-team2-item <?php echo esc_attr($team_alignments); echo ' '. esc_attr($team_img_box_shape_class); ?>">
                                <div class="ua-team2-img-box">
                                    <?php the_post_thumbnail(); ?>
                                </div>
                                <div class="ua-team2-content">
                                    <?php if(!empty(get_the_title())) { ?>
                                        <h3 class="ua-team2-title">
                                            <?php the_title(); ?>
                                        </h3>
                                    <?php } if(!empty($team_designation)) { ?>
                                        <p class="ua-team2-meta">
                                            <?php echo esc_html($team_designation); ?>
                                        </p>
                                    <?php } if($settings['UA_team_button_show'] == 'yes' && !empty($settings['UA_team_button_text'])) { ?>
                                        <a href="#" class="ua-team2-btn" data-toggle="modal" data-target=".ua-team2-modal-form-<?php echo esc_attr($i); ?>" data-whatever="<?php the_title(); ?>">
                                            <?php echo esc_html($settings['UA_team_button_text']); ?>
                                        </a>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>

                        <div class="ua-team2-modal-form">
                            <div class="modal fade ua-team2-modal-form-<?php echo esc_attr($i); ?> show" tabindex="-1" role="dialog" aria-modal="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-top mb-0">
                                            <?php if(!empty(get_the_title())) { ?>
                                                <h3 class="modal-title widget-title font-size-20">
                                                    <?php the_title(); esc_html_e("'s Bio","useful-addons-elementor"); ?>
                                                </h3>
                                            <?php } ?>
                                            <button type="button" class="close close-arrow" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true" class="la la-close mb-0"></span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <?php if(!empty(get_the_content())) { ?>
                                                <div class="modal-text">
                                                    <?php the_content(); ?>
                                                </div>
                                                <div class="section-block"></div>
                                            <?php } ?>
                                            <h3 class="widget-title pt-3">
                                                <?php esc_html_e('Connect me on', 'useful-addons-elementor'); ?>
                                            </h3>
                                            <?php
                                            require UA_ELEMENTOR_PATH.'./includes/Elements/team/team-social3.php';
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>

                </div><!-- end row -->
            </div>
            <?php } else { ?>
                <h2>
                    <?php esc_html_e('Empty Team Member!', 'useful-addons-elementor'); ?>
                </h2>
            <?php }
            wp_reset_query();
		}
		else {
            $team3_link_target   = $settings['ua_team4_link']['is_external'] ? ' target="_blank"' : '';
            $team3_link_nofollow = $settings['ua_team4_link']['nofollow'] ? ' rel="nofollow"' : '';
		    ?>
            <div class="ua-team4-item <?php echo esc_attr($team_alignments); ?>">
                <div class="ua-team4-img-box">
                    <?php if (!empty($settings['ua_team4_image']['url'])) { ?>
                        <img src="<?php echo esc_url($settings['ua_team4_image']['url']); ?>" alt="" width="200" height="200">
                    <?php } if(!empty($settings['ua_team4_socials'])) { ?>
                        <ul class="ua-team4-social-profile">
                            <?php foreach ($settings['ua_team4_socials'] as $ua_team_social) {
                                $team3_link_target   = $ua_team_social['ua_team4_social_link']['is_external'] ? ' target="_blank"' : '';
                                $team3_link_nofollow = $ua_team_social['ua_team4_social_link']['nofollow'] ? ' rel="nofollow"' : '';
                                ?>
                                <li>
                                    <a href="<?php echo esc_url($ua_team_social['ua_team4_social_link']['url']);  ?>" <?php echo esc_attr($team3_link_target); echo esc_attr($team3_link_nofollow); ?>>
                                        <?php Icons_Manager::render_icon( $ua_team_social['ua_team4_social_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    </a>
                                </li>
                            <?php } ?>
                        </ul>
                    <?php } ?>
                </div>
                <div class="ua-team4-detail">
                    <?php if (!empty($settings['ua_team4_name'])) { ?>
                        <h3 class="ua-team4-title">
                        <?php if ($settings['ua_team4_enable_name_link'] == 'yes') { ?>
                            <a href="<?php echo esc_url($settings['ua_team4_link']['url']); ?>" <?php echo esc_attr($team3_link_target); echo esc_attr($team3_link_nofollow); ?>>
                                <?php echo esc_html($settings['ua_team4_name']); ?>
                            </a>
                        <?php } else {
                            echo esc_html($settings['ua_team4_name']);
                        } ?>
                        </h3>
                    <?php } if (!empty($settings['ua_team4_designation'])) { ?>
                        <p class="ua-team4-meta">
                            <?php echo esc_html($settings['ua_team4_designation']); ?>
                        </p>
                    <?php } if (!empty($settings['ua_team3_content'])) { ?>
                        <p class="ua-team4-content">
                            <?php echo esc_html($settings['ua_team3_content']); ?>
                        </p>
                    <?php } if (!empty($settings['ua_team4_btn_tx'])) { ?>
                        <a href="<?php echo esc_url($settings['ua_team4_link']['url']); ?>" class="ua-team4-btn" <?php echo esc_attr($team3_link_target); echo esc_attr($team3_link_nofollow); ?>>
                            <?php echo esc_html($settings['ua_team4_btn_tx']); ?>
                        </a>
                    <?php } ?>
                </div>
            </div>
        <?php
		}
	}

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new UA_teams() );