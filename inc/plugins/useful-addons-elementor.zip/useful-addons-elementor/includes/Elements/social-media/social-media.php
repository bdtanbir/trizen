<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class ua_social_media extends Widget_Base {
	public function get_name() {
		return 'ua_social_media';
	}

	public function get_title() {
		return esc_html__( 'Social Media', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-social-icons ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}


	/* UA Social Media Lists Content */
	private function get_setting_social_media_list()
	{
		$this->start_controls_section('ua_social_media_setting',
			[
				'label' => __('Social Media Content', 'useful-addons-elementor'),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control('ua_social_media_icon_shape',
			[
				'label'        => __( 'Show Icon\'s Shape', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater = new Repeater();

		$repeater->add_control( 'ua_social_icon',
			[
				'label'            => __( 'Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fab fa-facebook-f',
					'library' => 'brands',
				],
				'recommended'   => [
					'fa-brands' => [
						'facebook',
						'facebook-f',
						'facebook-messenger',
						'facebook-square',
						'twitch',
						'twitter',
						'twitter-square',
						'linkedin',
						'linkedin-in',
						'yoast',
						'youtube',
						'youtube-square',
						'gofore',
						'goodreads',
						'goodreads-g',
						'google',
						'google-drive',
						'google-play',
						'google-plus',
						'google-plus-g',
						'google-plus-square',
						'google-wallet',
						'instagram',
						'pinterest',
						'pinterest-p',
						'pinterest-square',
						'dribbble',
						'github',
						'github-alt',
						'github-square',
						'foursquare',
						'apple',
						'android',
						'map',
						'map',
						'map-marked',
						'map-marked-alt',
						'map-marker',
						'map-marker-alt',
						'map-pin',
						'map-signs',
						'sitemap',
						'blender-phone',
						'headphones',
						'headphones-alt',
						'microphone',
						'microphone-alt',
						'microphone-alt-slash',
						'microphone-slash',
						'phone',
						'phone-alt',
						'phone-slash',
						'phone-square',
						'phone-square-alt',
						'phone-volume',
						'envelope',
						'envelope-open',
						'envelope',
						'envelope-open',
						'envelope-open-text',
						'envelope-square',
					],
				],
			]
		);
		$repeater->add_control('ua_social_icon_url',
			[
				'label'         => __( 'Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => true,
					'nofollow'    => true,
				],
			]
		);
		$this->add_control( 'ua_social_media_lists',
			[
				'label'  	=> __( 'Social Media List', 'useful-addons-elementor' ),
				'type'   	=> Controls_Manager::REPEATER,
				'fields' 	=> $repeater->get_controls(),
				'default' => [
					[
						'ua_social_icon'     => __( 'fab fa-facebook-f', 'useful-addons-elementor' ),
						'ua_social_icon_url' => __( 'https://facebook.com/', 'useful-addons-elementor' )
					],
					[
						'ua_social_icon'     => __( 'fab fa-twitter', 'useful-addons-elementor' ),
						'ua_social_icon_url' => __( 'https://twitter.com/', 'useful-addons-elementor' )
					],
					[
						'ua_social_icon'     => __( 'fab fa-linkedin', 'useful-addons-elementor' ),
						'ua_social_icon_url' => __( 'https://linkedin.net/', 'useful-addons-elementor' )
					],
				],
				'title_field' => 'Social list',
			]
		);
		$this->end_controls_section();
	}
	/* UA Social Media Icon Style */
	private function get_style_social_icon()
	{
		// Icon
		$this->start_controls_section( 'ua_social_icon_style',
			[
				'label' => __( 'Icon', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control('ua_social_icon_size',
			[
				'label'      => __( 'Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'     => [
						'min'  => 1,
						'max'  => 100,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 16,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control('ua_social_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 1,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 38,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control('ua_social_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 1,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 38,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'ua_social_icon_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'ua_social_icon_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('ua_social_icon_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#677286',
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('ua_social_icon_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(35, 61, 99, 0.1)',
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_social_icon_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-social-media-list li a',
			]
		);
		$this->add_responsive_control('ua_social_icon_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => '%',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_social_icon_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-social-media-list li a',
			]
		);
		$this->add_responsive_control('ua_social_icon_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_social_icon_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'      => [
					'top'      => '0',
					'right'    => '5',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'ua_social_icon_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('ua_social_icon_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('ua_social_icon_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#F66B5D',
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_social_icon_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-social-media-list li a:hover',
			]
		);
		$this->add_responsive_control('ua_social_icon_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list li a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_social_icon_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-social-media-list li a:hover',
			]
		);
		$this->add_responsive_control('ua_social_icon_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list li a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_social_icon_hv_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list li a:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tabs();
		$this->end_controls_tab();
		//end tabs
		$this->end_controls_section();
	}
	/* UA Social Media Icon's Shape Style */
	private function get_style_social_icon_shp()
	{
		$this->start_controls_section( 'ua_social_icon_shp',
			[
				'label'     => __( 'Shape', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'ua_social_media_icon_shape' => 'yes'
				],
			]
		);
		$this->add_control('ua_social_icon_shp_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a:before' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control('ua_social_icon_shp_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 22,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a:before' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control('ua_social_icon_shp_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'       => [
						'min'  => 0,
						'max'  => 200,
						'step' => 1,
					],
					'%'       => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 9,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a:before' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control('ua_social_icon_shp_rotate',
			[
				'label' 	 => __( 'Rotate', 'useful-addons-elementor' ),
				'type' 		 => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' 	 => [
					'px' 	 => [
						'min'  => 0,
						'max'  => 360,
						'step' => 1,
					]
				],
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list li a:before' => 'transform: rotate({{SIZE}}deg) translateX(-50%);',
				],
			]
		);
		$this->add_responsive_control('ua_social_icon_shp_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top' 	   => '50',
					'right'    => '50',
					'bottom'   => '50',
					'left'     => '50',
					'unit'     => '%',
					'isLinked' => true
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list li a:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_social_icon_shp_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list li a:before' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Social Media box style */
	private function get_style_social_box()
	{
		$this->start_controls_section( 'ua_social_box',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control('ua_social_box_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-social-media-list' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'ua_social_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-social-media-list',
			]
		);
		$this->add_responsive_control('ua_social_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'ua_social_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-social-media-list',
			]
		);
		$this->add_responsive_control('ua_social_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('ua_social_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	 => [
					'top'      => '10',
					'right'	   => '0',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-social-media-list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	protected function _register_controls() {
		$this->get_setting_social_media_list();
		$this->get_style_social_icon();
		$this->get_style_social_icon_shp();
		$this->get_style_social_box();
	}


	protected function render( ) {
		$settings     = $this->get_settings_for_display();
		$social_lists = $settings['ua_social_media_lists'];

		if($settings['ua_social_media_icon_shape'] == 'yes') {
			$ua_social_shp_hide = '';
		} else {
			$ua_social_shp_hide = 'ua-hide-icon-shape';
		}


		if(!empty($social_lists)) {
			?>
            <ul class="ua-social-media-list <?php echo esc_attr($ua_social_shp_hide); ?>">
				<?php foreach ($social_lists as $social_list) {
					$target   = $social_list['ua_social_icon_url']['is_external'] ? ' target="_blank"' : '';
					$nofollow = $social_list['ua_social_icon_url']['nofollow'] ? ' rel="nofollow"' : '';
					?>
                    <li>
                        <a href="<?php echo esc_url($social_list['ua_social_icon_url']['url']); ?>" <?php echo esc_attr($target) .' '. esc_attr($nofollow); ?>>
						<?php
						Icons_Manager::render_icon( $social_list['ua_social_icon'], [ 'aria-hidden' => 'true' ] );
						?>
                        </a>
                    </li>
				<?php } ?>
            </ul>
			<?php
		}

	}

	protected function _content_template() { }
}


Plugin::instance()->widgets_manager->register_widget_type( new ua_social_media() );