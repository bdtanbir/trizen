<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class ua_category_box extends Widget_Base {
	public function get_name() {
		return 'ua_category_box';
	}

	public function get_title() {
		return esc_html__( 'Category Box', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-info-box ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/*----------------------------------
	    UA Get Category Content
	------------------------------------*/
	private function ua_get_content() {
		$this->start_controls_section( 'category_content',
			[
				'label' => __( 'Content', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control('category_img',
			[
				'label'   => __( 'Choose Image', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control('category_img_url',
			[
				'label'         => __( 'Image Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'dynamic'       => [
					'active' => true,
				],
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				],
			]
		);
		$this->add_control('category_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Product Collection', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your category title here', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('category_title_url_dpnd',
			[
				'label'        => __( 'Show Title Link', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control('category_title_url',
			[
				'label'         => __( 'Title Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'dynamic'       => [
					'active' => true,
				],
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition'      => [
					'category_title_url_dpnd' => 'yes'
				]
			]
		);
		$this->add_control('category_show_btn',
			[
				'label'        => __( 'Show Button', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$this->add_control('category_btn_tx',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Shop Now', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your button text here', 'useful-addons-elementor' ),
				'condition'   => [
					'category_show_btn' => 'yes'
				]
			]
		);
		$this->add_control('category_button_url',
			[
				'label'         => __( 'Button Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'dynamic'       => [
					'active' => true,
				],
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition'   => [
					'category_show_btn' => 'yes'
				]
			]
		);
		$this->add_control('category_show_btn_icon',
			[
				'label'        => __( 'Show Button Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'category_show_btn' => 'yes'
				]
			]
		);
		$this->add_control('category_btn_icon',
			[
				'label'   => __( 'Icon', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'fa fa-angle-right',
					'library' => 'solid',
				],
				'recommended'  => [
					'fa-solid' => [
						'angle-right',
						'angle-left',
						'arrow-alt-circle-down',
						'arrow-alt-circle-up',
						'arrow-alt-circle-left',
						'arrow-alt-circle-right',
						'arrow-circle-down',
						'arrow-circle-up',
						'arrow-circle-left',
						'arrow-circle-right',
						'arrow-down',
						'arrow-up',
						'arrow-left',
						'arrow-right',
						'arrows-alt',
						'arrows-alt-h',
						'arrows-alt-v',
						'cart-arrow-down',
						'compress-arrows-alt',
						'expand-rows-alt',
						'location-arrow',
						'long-arrow-alt-down',
						'long-arrow-alt-up',
						'long-arrow-alt-left',
						'long-arrow-alt-right',
					],
				],
				'condition' => [
					'category_show_btn_icon' => 'yes',
					'category_show_btn'      => 'yes',
				]
			]
		);

		$this->end_controls_section();
	}
	/*----------------------------------
		UA Get Image Style
	------------------------------------*/
	private function ua_get_img_style()
	{
		$this->start_controls_section('category_img_style',
			[
				'label' => __('Image', 'useful-addons-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control( 'category_img_alignment',
			[
				'label'   => __('Alignment', 'useful-addons-elementor'),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'0' => [
						'title' => __('Left', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-left',
					],
					'1' => [
						'title' => __('Center', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-center',
					],
					'2' => [
						'title' => __('Right', 'useful-addons-elementor'),
						'icon'  => 'fa fa-align-right',
					],
				],
			]
		);
		$this->add_control('category_img_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-img a img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control('category_img_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-img a img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'category_img_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'category_img_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_responsive_control('category_img_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-img a img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'category_img_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-img a img',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'category_img_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-img a img',
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'category_img_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_responsive_control('category_img_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper:hover .ua-category-box-img a img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'category_img_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper:hover .ua-category-box-img a img',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'category_img_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper:hover .ua-category-box-img a img',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/*----------------------------------
		UA Get Title Style
	------------------------------------*/
	private function ua_get_title_style()
	{
		$this->start_controls_section('category_title_style',
			[
				'label' => __('Title', 'useful-addons-elementor'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control('category_title_color',
			[
				'label'     => __( 'Normal Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content h2 a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control('category_title_hv_color',
			[
				'label'     => __( 'Hover Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#F66B5D',
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content h2 a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'category_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content h2',
			]
		);
		$this->add_responsive_control('category_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '20',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/*----------------------------------
		UA Get Button Style
	------------------------------------*/
	private function ua_get_btn_style()
	{
		$this->start_controls_section('category_btn_style',
			[
				'label'     => __('Button', 'useful-addons-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'category_show_btn'      => 'yes',
				]
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'category_btn_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'category_btn_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('btn_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'btn_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'btn_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn',
			]
		);
		$this->add_responsive_control('btn_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'btn_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn',
			]
		);
		$this->add_responsive_control('btn_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('btn_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control('btn_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control('btn_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'category_btn_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('btn_hv_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#F66B5D',
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'btn_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'btn_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover',
			]
		);
		$this->add_responsive_control('btn_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'btn_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover',
			]
		);
		$this->add_responsive_control('btn_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('btn_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control('btn_hv_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control('btn_hv_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'btn_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn',
			]
		);
		$this->end_controls_section();
	}
	/*----------------------------------
		UA Get Button Icon Style
	------------------------------------*/
	private function ua_get_icon_style()
	{
		$this->start_controls_section('category_icon_style',
			[
				'label'     => __('Icon', 'useful-addons-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'category_show_btn_icon' => 'yes',
					'category_show_btn'      => 'yes',
				]
			]
		);
		$this->add_control('btn_icon_size',
			[
				'label'      => __( 'Font Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control('btn_icon_width',
			[
				'label'      => __( 'Width', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn i' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control('btn_icon_height',
			[
				'label'      => __( 'Height', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn i' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'category_btn_icon_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'category_btn_icon_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('btn_icon_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'btn_icon_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn i',
			]
		);
		$this->add_responsive_control('bnt_icon_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('bnt_icon_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('bnt_icon_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'category_btn_icon_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control('btn_icon_hv_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover i' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'btn_icon_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover i',
			]
		);
		$this->add_responsive_control('bnt_icon_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('bnt_icon_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('bnt_icon_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper .ua-category-box-content .ua-category-box-btn:hover i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->end_controls_section();
	}
	/*----------------------------------
		UA Get Box Style
	------------------------------------*/
	private function ua_get_box_style()
	{
		$this->start_controls_section('category_box_style',
			[
				'label'     => __('Box', 'useful-addons-elementor'),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'category_box_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'category_box_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'box_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper',
			]
		);
		$this->add_responsive_control('box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper',
			]
		);
		$this->add_responsive_control('box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('box_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'category_box_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'box_hv_bg',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper:hover',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'box_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper:hover',
			]
		);
		$this->add_responsive_control('box_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'box_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-category-box-wrapper:hover',
			]
		);
		$this->add_responsive_control('box_hv_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control('box_hv_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-category-box-wrapper:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->end_controls_section();
	}


	protected function _register_controls() {
		$this->ua_get_content();
		$this->ua_get_img_style();
		$this->ua_get_title_style();
		$this->ua_get_btn_style();
		$this->ua_get_icon_style();
		$this->ua_get_box_style();

	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();

		$target   = $settings['category_title_url']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['category_title_url']['nofollow'] ? ' rel="nofollow"' : '';

		$img_target   = $settings['category_img_url']['is_external'] ? ' target="_blank"' : '';
		$img_nofollow = $settings['category_img_url']['nofollow'] ? ' rel="nofollow"' : '';

		$btn_target   = $settings['category_button_url']['is_external'] ? ' target="_blank"' : '';
		$btn_nofollow = $settings['category_button_url']['nofollow'] ? ' rel="nofollow"' : '';


		if($settings['category_img_alignment'] == 0) {
			$img_alignment = 'text-left';
		} elseif($settings['category_img_alignment'] == 1) {
			$img_alignment = 'text-center';
		} elseif($settings['category_img_alignment'] == 2) {
			$img_alignment = 'text-right';
		} else {
			$img_alignment = 'text-left';
		}



		?>
        <div class="ua-category-box-wrapper">
			<?php
			if ( !empty( $settings['category_img']['url'] ) ) {
				?>
                <div class="ua-category-box-img <?php esc_attr_e($img_alignment); ?>">
                    <a href="<?php echo esc_url($settings['category_img_url']['url']); ?>" <?php echo esc_attr($img_target) .' '. esc_attr($img_nofollow); ?>>
                        <img src="<?php echo esc_url($settings['category_img']['url']); ?>" alt="new product">
                    </a>
                </div>
			<?php } ?>
            <div class="ua-category-box-content">
				<?php if ( !empty( $settings['category_title'] ) && 'yes' == $settings['category_title_url_dpnd'] ) { ?>
                    <h2 class="ua-category-box-title">
                        <a href="<?php echo esc_url($settings['category_title_url']['url']); ?>" <?php echo esc_attr($target) . ' ' . esc_attr($nofollow); ?> >
                            <?php echo esc_html($settings['category_title']); ?>
                        </a>
                    </h2>
				<?php } else { ?>
                    <h2 class="ua-category-box-title">
						<?php echo esc_html($settings['category_title']); ?>
                    </h2>
				<?php }

				if ( 'yes' == $settings['category_show_btn'] && !empty( $settings['category_btn_tx'] ) ) {
					?>
                    <a href="<?php echo esc_url($settings['category_button_url']['url']); ?>" class="ua-category-box-btn transition-all-3s" <?php echo esc_attr($btn_target) .' '. esc_attr($btn_nofollow); ?>>
                        <?php echo esc_html($settings['category_btn_tx']);

                        if( $settings['category_show_btn_icon'] == 'yes' ) {
                            if ( !empty($settings['category_btn_icon'] ) ) {
                                Icons_Manager::render_icon( $settings['category_btn_icon'], [ 'aria-hidden' => 'true' ] );
                            }
                        }
                        ?>
                    </a>
				<?php } ?>
            </div>
        </div>
		<?php


	}

	protected function _content_template() { }
}
Plugin::instance()->widgets_manager->register_widget_type( new ua_category_box() );