<?php
namespace Elementor;
// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}


class ua_icon_list extends Widget_Base {
	public function get_name() {
		return 'UA_icon_list';
	}

	public function get_title() {
		return esc_html__( 'Icon List', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-checkbox ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Icon list content */
	private function get_icon_list_content() {
		$this->start_controls_section( 'icon_list',
			[
				'label' => __( 'Icon List', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'icon_list_icon',
			[
				'label'   => __( 'Icon', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'  => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$this->add_control( 'icon_list_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Default title', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_list_desc',
			[
				'label'       => __( 'Description', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => __( 'Default description', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
			]
		);
		$this->end_controls_section();
	}
	/* UA Icon list icon style */
    private function get_icon_list_icon_style() {
	    $this->start_controls_section( 'icon_list_icon_style',
		    [
			    'label' => __( 'Icon', 'useful-addons-elementor' ),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_svg_size',
		    [
			    'label'      => __( 'SVG Font Size', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => [ 'px', '%' ],
			    'range'  => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 500,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'default'  => [
				    'unit' => 'px',
				    'size' => 40,
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon svg' => 'width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_size',
		    [
			    'label'      => __( 'Normal Font Size', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => [ 'px', '%' ],
			    'range'  => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 500,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'default'  => [
				    'unit' => 'px',
				    'size' => 45,
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_width',
		    [
			    'label'      => __( 'Width', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => [ 'px', '%' ],
			    'range'  => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 500,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'default'  => [
				    'unit' => 'px',
				    'size' => 80,
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon' => 'width: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_height',
		    [
			    'label'      => __( 'Height', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => [ 'px', '%' ],
			    'range'  => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 500,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'default'  => [
				    'unit' => 'px',
				    'size' => 80,
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon' => 'height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_lheight',
		    [
			    'label'      => __( 'Line Height', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::SLIDER,
			    'size_units' => [ 'px', '%' ],
			    'range'  => [
				    'px' => [
					    'min'  => 0,
					    'max'  => 500,
					    'step' => 1,
				    ],
				    '%' => [
					    'min' => 0,
					    'max' => 100,
				    ],
			    ],
			    'default'  => [
				    'unit' => 'px',
				    'size' => 80,
			    ],
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon, .ua-icon-list-box .ua-icon-list-icon i' => 'line-height: {{SIZE}}{{UNIT}};',
			    ],
		    ]
	    );
	    /* start tab */
	    $this->start_controls_tabs( 'icon_list_icon_tabs',
		    [
			    'separator' => 'before',
		    ]
	    );
	    // normal tab
	    $this->start_controls_tab( 'icon_list_icon_nrml_tab',
		    [
			    'label' => __( 'Normal', 'useful-addons-elementor' ),
		    ]
	    );
	    $this->add_control('icon_list_icon_svg_clr',
		    [
			    'label'     => __( 'SVG Color', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#3CAAF7',
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon svg' => 'fill: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_control('icon_list_icon_clr',
		    [
			    'label'     => __( 'Icon Color', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#3CAAF7',
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon i' => 'color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_control('icon_list_icon_bg',
		    [
			    'label'     => __( 'Background', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => 'rgba(60, 170, 247, 0.1)',
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon' => 'background: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_group_control( Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'icon_list_icon_shadow',
			    'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
			    'selector' => '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon',
		    ]
	    );
	    $this->add_group_control( Group_Control_Border::get_type(),
		    [
			    'name'     => 'icon_list_icon_border',
			    'label'    => __( 'Border', 'useful-addons-elementor' ),
			    'selector' => '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon',
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_radius',
		    [
			    'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'default'    => [
                    'top'   => '50',
                    'right' => '50',
                    'bottom'    => '50',
                    'left'  => '50',
                    'unit'  =>'%',
                    'isLinked'  => true
                ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_pd',
		    [
			    'label'      => __( 'Padding', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_mg',
		    [
			    'label'      => __( 'Margin', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->end_controls_tab();
	    // hover tab
	    $this->start_controls_tab( 'icon_list_icon_hv_tab',
		    [
			    'label' => __( 'Hover', 'useful-addons-elementor' ),
		    ]
	    );
	    $this->add_control('icon_list_icon_hv_svg_clr',
		    [
			    'label'     => __( 'SVG Color', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#ffffff',
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box:hover .ua-icon-list-icon svg' => 'fill: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_control('icon_list_icon_hv_clr',
		    [
			    'label'     => __( 'Icon Color', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#ffffff',
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box:hover .ua-icon-list-icon i' => 'color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_control('icon_list_icon_hv_bg',
		    [
			    'label'     => __( 'Background', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::COLOR,
			    'default'   => '#3CAAF7',
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box:hover .ua-icon-list-icon' => 'background: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_group_control( Group_Control_Box_Shadow::get_type(),
		    [
			    'name'     => 'icon_list_icon_hv_shadow',
			    'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
			    'selector' => '{{WRAPPER}} .ua-icon-list-box:hover .ua-icon-list-icon',
		    ]
	    );
	    $this->add_group_control( Group_Control_Border::get_type(),
		    [
			    'name'     => 'icon_list_icon_hv_border',
			    'label'    => __( 'Border', 'useful-addons-elementor' ),
			    'selector' => '{{WRAPPER}} .ua-icon-list-box:hover .ua-icon-list-icon',
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_hv_radius',
		    [
			    'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-icon-list-box:hover .ua-icon-list-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_hv_pd',
		    [
			    'label'      => __( 'Padding', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-icon-list-box:hover .ua-icon-list-icon' => 'Padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_icon_hv_mg',
		    [
			    'label'      => __( 'Margin', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-icon-list-box:hover .ua-icon-list-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->end_controls_tab();
	    $this->end_controls_tabs();
	    /* end tab */
	    $this->end_controls_section();
    }
    /* UA Icon list title style */
    private  function get_icon_list_title_style() {
	    $this->start_controls_section( 'icon_list_title_style',
		    [
			    'label' => __( 'Title', 'useful-addons-elementor' ),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );
	    $this->add_control( 'icon_list_title_clr',
		    [
			    'label'     => __( 'Color', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::COLOR,
			    'default'     => '#0A1B4F',
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-title' => 'color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_group_control( Group_Control_Border::get_type(),
		    [
			    'name'     => 'icon_list_title_border',
			    'label'    => __( 'Border', 'useful-addons-elementor' ),
			    'selector' => '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-title',
		    ]
	    );
	    $this->add_group_control( Group_Control_Typography::get_type(),
		    [
			    'name'     => 'icon_list_title_typography',
			    'label'    => __( 'Typography', 'useful-addons-elementor' ),
			    'selector' => '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-title',
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_title_pd',
		    [
			    'label'      => __( 'Padding', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'default'    => [
                    'top'       => '0',
                    'right'     =>'0',
                    'bottom'    =>'8',
                    'left'      =>'0',
                    'unit'      => 'px',
                    'isLinked'  => false
                ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_title_mg',
		    [
			    'label'      => __( 'Margin', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->end_controls_section();
    }
    /* UA Icon list description style */
    private  function get_icon_list_desc_style() {
	    $this->start_controls_section( 'icon_list_desc_style',
		    [
			    'label' => __( 'Description', 'useful-addons-elementor' ),
			    'tab'   => Controls_Manager::TAB_STYLE,
		    ]
	    );
	    $this->add_control( 'icon_list_desc_clr',
		    [
			    'label'     => __( 'Color', 'useful-addons-elementor' ),
			    'type'      => Controls_Manager::COLOR,
			    'default'     => '#7f8897',
			    'selectors' => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-desc' => 'color: {{VALUE}}',
			    ],
		    ]
	    );
	    $this->add_group_control( Group_Control_Border::get_type(),
		    [
			    'name'     => 'icon_list_desc_border',
			    'label'    => __( 'Border', 'useful-addons-elementor' ),
			    'selector' => '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-desc',
		    ]
	    );
	    $this->add_group_control( Group_Control_Typography::get_type(),
		    [
			    'name'     => 'icon_list_desc_typography',
			    'label'    => __( 'Typography', 'useful-addons-elementor' ),
			    'selector' => '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-desc',
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_desc_pd',
		    [
			    'label'      => __( 'Padding', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->add_responsive_control( 'icon_list_desc_mg',
		    [
			    'label'      => __( 'Margin', 'useful-addons-elementor' ),
			    'type'       => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors'  => [
				    '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );
	    $this->end_controls_section();
    }
	/* UA Icon list description style */
	private  function get_icon_list_box_style() {
		$this->start_controls_section( 'icon_list_box_style',
			[
				'label' => __( 'Box', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		/* start tab */
		$this->start_controls_tabs( 'icon_list_box_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'icon_list_box_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_list_box_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-icon-list-box' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_list_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-list-box',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name' => 'icon_list_box_border',
				'label' => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-list-box',
			]
		);
		$this->add_responsive_control( 'icon_list_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-list-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_list_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-list-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_list_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-list-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'icon_list_box_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'icon_list_box_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-icon-list-box:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'icon_list_box_hv_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-list-box:hover',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name' => 'icon_list_box_hv_border',
				'label' => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-list-box:hover',
			]
		);
		$this->add_responsive_control( 'icon_list_box_hv_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-list-box:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_list_box_hv_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-list-box:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_list_box_hv_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-list-box:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* end tab */

		$this->add_control( 'icon_box_inner_box_title',
			[
				'label'     => __( 'Content Inner Box', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'icon_box_inner_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-icon-list-box .ua-icon-list-content',
			]
		);
		$this->add_responsive_control( 'icon_box_inner_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '0',
                    'left'     => '16',
                    'unit'     => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-list-box .ua-icon-list-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'icon_box_inner_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-icon-list-box .ua-icon-list-content' => 'Margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}


	protected function _register_controls() {
		$this->get_icon_list_content();
		$this->get_icon_list_icon_style();
		$this->get_icon_list_title_style();
		$this->get_icon_list_desc_style();
		$this->get_icon_list_box_style();
	}


	protected function render( ) {
		$settings = $this->get_settings_for_display();
		?>
            <div class="ua-icon-list-box d-flex align-items-center">
                <?php
                    if(!empty($settings['icon_list_icon'])) {
                ?>
                <div class="ua-icon-list-icon transition-all-3s flex-shrink-0">
	                <?php Icons_Manager::render_icon( $settings['icon_list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                </div>
                <?php } ?>
                <div class="ua-icon-list-content">
                    <?php
                        if(!empty($settings['icon_list_title'])) {
                    ?>
                    <h3 class="ua-icon-list-title">
                        <?php echo esc_html($settings['icon_list_title']); ?>
                    </h3>
                    <?php }
		            if(!empty($settings['icon_list_desc'])) { ?>
                        <p class="ua-icon-list-desc">
	                        <?php echo $settings['icon_list_desc']; ?>
                        </p>
                    <?php } ?>
                </div>
            </div>
		<?php
	}

	protected function _content_template() {}
}

Plugin::instance()->widgets_manager->register_widget_type( new ua_icon_list() );