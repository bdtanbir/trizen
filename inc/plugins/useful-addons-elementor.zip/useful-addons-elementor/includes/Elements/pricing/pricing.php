<?php
namespace Elementor;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
	exit;
}

class UA_pricing_table extends Widget_Base {
	public function get_name() {
		return 'UA_pricing_table';
	}

	public function get_title() {
		return esc_html__( 'Pricing Table', 'useful-addons-elementor' );
	}

	public function get_icon() {
		return 'eicon-price-table ua-addons-icon';
	}

	public function get_categories() {
		return [ 'useful-addons-elementor-category' ];
	}

	/* UA Pricing Content Controls */
	private function get_content_pricing( ){
		$this->start_controls_section( 'UA_pricing_box_setting',
			[
				'label' => __( 'Pricing Table', 'useful-addons-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control( 'pricing_box_layout',
			[
				'label'   => __( 'Layout', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'layout_1',
				'options' => [
					'layout_1'  => __( 'Layout 1', 'useful-addons-elementor' ),
					'layout_2'  => __( 'Layout 2', 'useful-addons-elementor' ),
					'layout_3'  => __( 'Layout 3', 'useful-addons-elementor' ),
				],
			]
		);
		/* pricing layout 1 start */
		$this->add_control( 'pricing_plan_tabs_button',
			[
				'label'        => __( 'Show Yearly Button', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
                'condition'    => [
                    'pricing_box_layout' => 'layout_1'
                ]
			]
		);
		$this->add_control( 'pricing_plan_tabs_monthly_btn_txt',
			[
				'label'       => __( 'Monthly Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Monthly', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type monthly text here', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_plan_tabs_button' => 'yes',
					'pricing_box_layout'       => 'layout_1'
				],
			]
		);
		$this->add_control( 'pricing_plan_tabs_yearly_btn_txt',
			[
				'label'       => __( 'Yearly Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Yearly', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type yearly text here', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_plan_tabs_button' => 'yes',
					'pricing_box_layout'       => 'layout_1'
				],
			]
		);
		$this->add_control( 'pricing_plan_active_yearly_btn',
			[
				'label'        => __( 'Active Yearly button', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'    => [
					'pricing_plan_tabs_button' => 'yes',
					'pricing_box_layout'       => 'layout_1'
				],
			]
		);

		$repeater = new Repeater();
		$repeater->add_control('pricing_plan_box_active',
			[
				'label'        => __( 'Active', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Yes', 'useful-addons-elementor' ),
				'label_off'    => __( 'No', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			]
		);
		$repeater->add_control('pricing_plan_title',
			[
				'label'       => __( 'Plan Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Basic', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type pricing plan title here', 'useful-addons-elementor' ),
			]
		);
		$repeater->add_control('pricing_plan_per_month_price',
			[
				'label'       => __( 'Per Monthly Price', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '19', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type per monthly price', 'useful-addons-elementor' ),
				'description' => __('This price for Per monthly', 'useful-addons-elementor'),
			]
		);
		$repeater->add_control('pricing_plan_per_yearly_price',
			[
				'label'       => __( 'Per Yearly Price', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '38', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type per yearly price', 'useful-addons-elementor' ),
				'description' => __('This price for Per yearly', 'useful-addons-elementor'),
			]
		);
		$repeater->add_control('pricing_price_currency',
			[
				'label'       => __( 'Price Currency', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '$', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type price currency', 'useful-addons-elementor' ),
			]
		);
		$repeater->add_control('pricing_price_currency_position',
			[
				'label'   => __( 'Currency Position', 'useful-addons-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'left',
				'options' => [
					'left'  => __( 'Left', 'useful-addons-elementor' ),
					'right' => __( 'Right', 'useful-addons-elementor' ),
				],
			]
		);
		$repeater->add_control('pricing_price_period_per_monthly',
			[
				'label'       => __( 'Price Period (per) Monthly', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '/Monthly', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type price period per monthly title', 'useful-addons-elementor' ),
				'description' => __('you can enter the period title for per monthly', 'useful-addons-elementor'),
			]
		);
		$repeater->add_control('pricing_price_period_per_yearly',
			[
				'label'       => __( 'Price Period (per) Yearly', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '/Year (Save 20%)', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type price period per yearly title', 'useful-addons-elementor' ),
				'description' => __('you can enter the period title for per yearly', 'useful-addons-elementor'),
			]
		);
		$repeater->add_control('pricing_price_list_content',
			[
				'label'       => __( 'Description', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 10,
				'default'     => __( "Description 1\nDescription 2\nDescription 3", "useful-addons-elementor" ),
				'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
				'description' => __('Insert tag &lt;strong&gt; when you want highlight text. Example: &lt;strong&gt;<strong>24/7</strong>&lt;/strong&gt; Support', 'useful-addons-elementor'),
			]
		);
		$repeater->add_control('pricing_price_show_button',
			[
				'label'        => __( 'Show Button', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);
		$repeater->add_control('pricing_price_btn_text',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Purchase', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type button text here', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_price_show_button' => 'yes',
				],
			]
		);
		$repeater->add_control('pricing_price_btn_url',
			[
				'label'         => __( 'Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);
		$repeater->add_control('pricing_price_show_btn_icon',
			[
				'label'        => __( 'Show Button Icon', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => [
					'pricing_price_show_button' => 'yes',
				],
			]
		);
		$repeater->add_control('pricing_price_btn_icon',
			[
				'label'            => __( 'Button Icon', 'useful-addons-elementor' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fa fa-shopping-cart',
					'library' => 'solid',
				],
				'recommended' => [
					'fa-solid' => [
						'cart-arrow-down',
						'cart-plus',
						'luggage-cart',
						'shopping-cart',
						'opencart',
						'shopping-bag',
						'shopping-basket',
						'shopping-cart',
					],
				],
				'condition' => [
					'pricing_price_show_btn_icon' => 'yes',
					'pricing_price_show_button' => 'yes',
				],
			]
		);
		$this->add_control( 'pricing_box_list',
			[
				'label'  => __( 'Pricing Plans', 'useful-addons-elementor' ),
				'type'   => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'condition' => [
					'pricing_box_layout' => 'layout_1'
                ],
				'default' => [
					[
						'pricing_plan_title'               => __( 'Basic', 'useful-addons-elementor' ),
						'pricing_plan_per_month_price'     => __( '19', 'useful-addons-elementor' ),
						'pricing_plan_per_yearly_price'    => __( '200', 'useful-addons-elementor' ),
						'pricing_plan_box_active'          => __( 'no', 'useful-addons-elementor' ),
						'pricing_price_currency'           => __( '$', 'useful-addons-elementor' ),
						'pricing_price_currency_position'  => __( 'left', 'useful-addons-elementor' ),
						'pricing_price_period_per_monthly' => __( '/Monthly', 'useful-addons-elementor' ),
						'pricing_price_period_per_yearly'  => __( '/Year (Save 20%)', 'useful-addons-elementor' ),
						'pricing_price_show_button'        => __( 'yes', 'useful-addons-elementor' ),
					],
					[
						'pricing_plan_title'               => __( 'Popular', 'useful-addons-elementor' ),
						'pricing_plan_per_month_price'     => __( '39', 'useful-addons-elementor' ),
						'pricing_plan_per_yearly_price'    => __( '460', 'useful-addons-elementor' ),
						'pricing_plan_box_active'          => __( 'yes', 'useful-addons-elementor' ),
						'pricing_price_currency'           => __( '$', 'useful-addons-elementor' ),
						'pricing_price_currency_position'  => __( 'left', 'useful-addons-elementor' ),
						'pricing_price_period_per_monthly' => __( '/Monthly', 'useful-addons-elementor' ),
						'pricing_price_period_per_yearly'  => __( '/Year (Save 20%)', 'useful-addons-elementor' ),
						'pricing_price_show_button'        => __( 'yes', 'useful-addons-elementor' ),
					],
					[
						'pricing_plan_title'               => __( 'Premium', 'useful-addons-elementor' ),
						'pricing_plan_per_month_price'     => __( '78', 'useful-addons-elementor' ),
						'pricing_plan_per_yearly_price'    => __( '930', 'useful-addons-elementor' ),
						'pricing_plan_box_active'          => __( 'no', 'useful-addons-elementor' ),
						'pricing_price_currency'           => __( '$', 'useful-addons-elementor' ),
						'pricing_price_currency_position'  => __( 'left', 'useful-addons-elementor' ),
						'pricing_price_period_per_monthly' => __( '/Monthly', 'useful-addons-elementor' ),
						'pricing_price_period_per_yearly'  => __( '/Year (Save 20%)', 'useful-addons-elementor' ),
						'pricing_price_show_button'        => __( 'yes', 'useful-addons-elementor' ),
					],
				],
				'title_field' => '{{{ pricing_plan_title }}}',
			]
		);
		/* pricing layout 1 end */

		/* pricing layout 2 start */
		$this->add_control( 'ua_pricing2_title_shape_show',
			[
				'label'        => __( 'Show Title', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		$this->add_control( 'ua_pricing2_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'PSD TO HTML', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your title here', 'useful-addons-elementor' ),
                'condition'   => [
                    'pricing_box_layout' => 'layout_2'
                ]
			]
		);
		$this->add_control( 'ua_pricing2_price',
			[
				'label'       => __( 'Price', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '80.99', 'useful-addons-elementor' ),
                'condition'   => [
                    'pricing_box_layout' => 'layout_2'
                ]
			]
		);
		$this->add_control( 'ua_pricing2_currency',
			[
				'label'       => __( 'Currency', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '$', 'useful-addons-elementor' ),
                'condition'   => [
                    'pricing_box_layout' => 'layout_2'
                ]
			]
		);
		$this->add_control( 'ua_pricing2_time',
			[
				'label'       => __( 'Time', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Delivery in 7 Days', 'useful-addons-elementor' ),
                'condition'   => [
                    'pricing_box_layout' => 'layout_2'
                ]
			]
		);
		$this->add_control( 'ua_pricing2_content',
			[
				'label'       => __( 'Content', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => __( 'This price is given for 10 regular pages PSD to HTML. The pricing may vary based on the design, the number of pages, and the number of requirements.', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your description here', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		$this->add_control( 'ua_pricing2_btn_tx',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Get Started', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		$this->add_control( 'ua_pricing2_btn_url',
			[
				'label'         => __( 'Button Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		$this->add_control( 'ua_pricing2_charge',
			[
				'label'       => __( 'Charge', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'no hidden charges!', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		/* pricing layout 2 end */

		/* pricing layout 3 start */
		$this->add_control( 'pricing_st3_show_badge',
			[
				'label'        => __( 'Show Badge', 'useful-addons-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => __( 'Show', 'useful-addons-elementor' ),
				'label_off'    => __( 'Hide', 'useful-addons-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
				'condition'   => [
					'pricing_box_layout' => 'layout_3'
				]
			]
		);
		$this->add_control( 'pricing_st3_badge',
			[
				'label'       => __( 'Badge', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => __( 'Recommended', 'useful-addons-elementor' ),
				'placeholder' => __( 'Type your badge title here', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_box_layout'     => 'layout_3',
                    'pricing_st3_show_badge' => 'yes'
				]
			]
		);
		$this->add_control( 'pricing_st3_currency',
			[
				'label'       => __( 'Currency', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '$', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_box_layout'     => 'layout_3',
				]
			]
		);
		$this->add_control( 'pricing_st3_price',
			[
				'label'       => __( 'Price', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( '100', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_box_layout'     => 'layout_3',
				]
			]
		);
		$this->add_control( 'pricing_st3_title',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Business Plan', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_box_layout'     => 'layout_3',
				]
			]
		);
		$this->add_control( 'pricing_st3_feature_lists',
			[
				'label'     => __( 'Feature Lists', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::REPEATER,
				'condition' => [
					'pricing_box_layout'     => 'layout_3',
				],
				'fields'  => [
					[
                        'name'    => 'pricing_st3_feature_icon',
						'label'   => __( 'Icon', 'useful-addons-elementor' ),
						'type'    => Controls_Manager::ICONS,
						'default' => [
							'value'   => 'la la-check',
							'library' => 'solid',
						],
					],
					[
                        'name'      => 'pricing_st3_feature_icon_clr',
						'label'     => __( 'Icon Color', 'useful-addons-elementor' ),
						'type'      => Controls_Manager::COLOR,
						'default'   => '#51be78',
					],
					[
                        'name'        => 'pricing_st3_feature_title',
						'label'       => __( 'Title', 'useful-addons-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'default'     => __( 'Limited User Support' , 'useful-addons-elementor' ),
						'label_block' => true,
					],
                ],
				'default' => [
					[
						'pricing_st3_feature_title' => __( '3 Full Courses', 'useful-addons-elementor' ),
                        'pricing_st3_feature_icon'  => __('la la-check', 'useful-addons-elementor')
					],
					[
						'pricing_st3_feature_title' => __( 'Limited Features', 'useful-addons-elementor' ),
                        'pricing_st3_feature_icon'  => __('la la-check', 'useful-addons-elementor')
					],
					[
						'pricing_st3_feature_title' => __( 'Limited User Support', 'useful-addons-elementor' ),
                        'pricing_st3_feature_icon'  => __('la la-check', 'useful-addons-elementor')
					],
					[
						'pricing_st3_feature_title' => __( 'Discount Available', 'useful-addons-elementor' ),
                        'pricing_st3_feature_icon'  => __('la la-check', 'useful-addons-elementor')
					],
					[
						'pricing_st3_feature_title' => __( 'Lifetime free access', 'useful-addons-elementor' ),
                        'pricing_st3_feature_icon'  => __('la la-check', 'useful-addons-elementor')
					],
					[
						'pricing_st3_feature_title' => __( 'Limited Period Offer', 'useful-addons-elementor' ),
                        'pricing_st3_feature_icon'  => __('la la-close', 'useful-addons-elementor')
					],
				],
				'title_field' => '{{{ pricing_st3_feature_title }}}',
			]
		);
		$this->add_control( 'pricing_st3_btn_txt',
			[
				'label'       => __( 'Button Text', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Choose Plan', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_box_layout'     => 'layout_3',
				]
			]
		);
		$this->add_control( 'pricing_st3_btn_url',
			[
				'label'         => __( 'Button Link', 'useful-addons-elementor' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'useful-addons-elementor' ),
				'show_external' => true,
				'default' => [
					'url'         => '',
					'is_external' => true,
					'nofollow'    => true,
				],
				'condition'   => [
					'pricing_box_layout'     => 'layout_3',
				]
			]
		);
		$this->add_control( 'pricing_st3_meta',
			[
				'label'       => __( 'Meta', 'useful-addons-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'No Hidden Charges!', 'useful-addons-elementor' ),
				'condition'   => [
					'pricing_box_layout'     => 'layout_3',
				]
			]
		);
		/* pricing layout 3 end */
		$this->end_controls_section();
	}
	/* UA Pricing Monthly Yearly Button Style */
	private function get_style_pricing_monthly_yearly_btn( ){
		$this->start_controls_section( 'UA_pricing_monthly_yearly_style',
			[
				'label'      => __( 'Monthly/Yearly Button', 'useful-addons-elementor' ),
				'tab'        => Controls_Manager::TAB_STYLE,
				'condition'  => [
					'pricing_plan_tabs_button' => 'yes',
					'pricing_box_layout'       => 'layout_1'
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'pricing_box_monthly_yearly_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'pricing_box_monthly_yearly_normal_tabs',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'pricing_box_monthly_yearly_normal_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing_box_monthly_yearly_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'            => 'pricing_box_monthly_yearly_normal_border',
				'label'           => __( 'Border', 'useful-addons-elementor' ),
				'selector'        => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#233d63',
					],
				],
			]
		);
		$this->add_responsive_control( 'pricing_box_monthly_yearly_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '30',
					'right'    => '30',
					'bottom'   => '30',
					'left'     => '30',
					'unit'     => 'px',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing_box_monthly_yearly_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a',
			]
		);
		$this->add_responsive_control( 'pricing_box_monthly_yearly_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '12',
					'right'    => '30',
					'bottom'   => '12',
					'left'     => '30',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing_box_monthly_yearly_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '5',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'pricing_box_monthly_yearly_hover_tabs',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'pricing_box_monthly_yearly_hv_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing_box_monthly_yearly_hv_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pricing_box_monthly_yearly_hv_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a:hover',
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#F66B5D',
					],
				],
			]
		);
		$this->add_responsive_control( 'pricing_box_monthly_yearly_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a:hover, {{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li.active a, {{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a.active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing_box_monthly_yearly_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a:hover, {{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li.active a, {{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a.active',
			]
		);
		$this->add_responsive_control( 'pricing_box_monthly_yearly_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a:hover, {{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li.active a, {{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a.active' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing_box_monthly_yearly_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a:hover, {{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li.active a, {{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a.active' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'pricing_box_end_monthly_yearly_tabs',
			[
				'label'     => __( 'Active Button', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'pricing_box_monthly_yearly_active_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li.active a, {{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a.active' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing_box_monthly_yearly_active_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li.active a, {{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a.active' => 'background: {{VALUE}};border-color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing_box_monthly_yearly_btn_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .nav-tabs li a',
			]
		);
		$this->end_controls_section();
	}
	/* UA Pricing Title Style Controls */
	private function get_style_pricing_title( ){
		$this->start_controls_section( 'UA_pricing_plan_title_style',
			[
				'label'     => __( 'Plan Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
	                'pricing_box_layout' => 'layout_1'
                ]
			]
		);
		$this->add_control( 'pricing_plan_title_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .package__title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing_plan_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .package__title',
			]
		);
		$this->add_responsive_control( 'pricing_plan_title_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '5',
					'right'    => '0',
					'bottom'   => '10',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .package__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

	}
	/* UA Pricing Price And Currency Style Controls */
	private function get_style_pricing_price_and_currency( ){
		$this->start_controls_section( 'UA_pricing_price_style',
			[
				'label'     => __( 'Price', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
	                'pricing_box_layout' => 'layout_1'
                ]
			]
		);
		$this->add_control( 'pricing_price_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .price__box .price__price-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing_price_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .price__box .price__price-title',
			]
		);
		$this->add_responsive_control( 'pricing_price_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '28',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .price__box .price__price-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// currency
		$this->add_control( 'pricing_price_currency_hd',
			[
				'label'     => __( 'Currency', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'pricing_price_currency_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .price__box .price__price-title sup' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing_price_currency_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .price__box .price__price-title sup',
			]
		);
		$this->add_responsive_control( 'pricing_price_currency_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '3',
					'right'    => '0',
					'bottom'   => '0',
					'left'     =>'0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .price__box .price__price-title sup' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// period
		$this->add_control( 'pricing_period_hd',
			[
				'label'     => __( 'Pricing Period', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'pricing_period_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#677286',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .price__box .price__text-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing_period_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .price__box .price__text-text',
			]
		);
		$this->add_responsive_control( 'pricing_period_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .price__box .price__text-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Pricing Feature List Style Controls */
	private function get_style_pricing_feature_list( ){
		$this->start_controls_section( 'UA_pricing_feature_list_style',
			[
				'label'     => __( 'Feature List', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
	                'pricing_box_layout' => 'layout_1'
                ]
			]
		);
		$this->add_control( 'pricing_feature_box_hd',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pricing_feature_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .package__list',
			]
		);
		$this->add_responsive_control( 'pricing_feature_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '30',
					'right'    => '0',
					'bottom'   => '0',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .package__list' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing_feature_box_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '31',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .package__list' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing_feature_list_hd',
			[
				'label'     => __( 'List', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'pricing_feature_list_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#677286',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .package__list li' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing_feature_list_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .package__list li',
			]
		);
		$this->add_responsive_control( 'pricing_feature_list_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top'      => '0',
					'right'    => '0',
					'bottom'   => '10',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .package__list li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing_feature_list_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .package__list li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	/* UA Pricing Button Style Controls */
	private function get_style_pricing_button( ){
		$this->start_controls_section( 'UA_pricing_button_styles',
			[
				'label'     => __( 'Button', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
	                'pricing_box_layout' => 'layout_1'
                ]
			]
		);
		// start tab
		$this->start_controls_tabs( 'pricing_button_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'pricing_button_normal_tabs',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'pricing_button_normal_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing_button_normal_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing_button_normal_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pricing_button_normal_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button',
			]
		);
		$this->add_responsive_control( 'pricing_button_normal_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '4',
					'right'    => '4',
					'bottom'   => '4',
					'left'     => '4',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing_button_normal_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'      => '13',
					'right'    => '40',
					'bottom'   => '13',
					'left'     => '25',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'pricing_button_hover_tabs',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'pricing_button_hover_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button:hover, {{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-active .theme-button' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing_button_hover_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button:hover, {{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-active .theme-button' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing_button_hover_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button:hover, {{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-active .theme-button',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pricing_button_hover_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button:hover, {{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-active .theme-button',
			]
		);
		$this->add_responsive_control( 'pricing_button_hover_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button:hover, {{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-active .theme-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing_button_hover_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button:hover, {{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-active .theme-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->add_control( 'end_pricing_button_tab',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing_button_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button',
			]
		);
		// icon
		$this->add_control( 'pricing_button_icon_hd',
			[
				'label'     => __( 'Icon', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control( 'pricing_button_icon_size',
			[
				'label'      => __( 'Font size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 50,
						'step' => 2,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'  => [
					'unit' => 'px',
					'size' => 14,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button .fa__arrow' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		// start tab
		$this->start_controls_tabs( 'pricing_button_icon_tabs',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'pricing_button_normal_icon_tabs',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'pricing_button_icon_normal_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button .fa__arrow' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'pricing_button_icon_normal_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'pricing_button_hover_icon_tabs',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'pricing_button_icon_hover_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button:hover .fa__arrow, {{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-active .theme-button .fa__arrow' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'pricing_button_icon_hover_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content .theme-button:hover .fa__arrow, {{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-active .theme-button .fa__arrow' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		// end tab
		$this->end_controls_section();
	}
	/* UA Pricing Box Style Controls */
	private function get_style_pricing_box( ){
		$this->start_controls_section( 'UA_pricing_box_styles',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
	                'pricing_box_layout' => 'layout_1'
                ]
			]
		);
		$this->add_control( 'pricing_box_background',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'.ua-package-area .ua-package-tab-content .tab-content .package-content' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'pricing_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top'     => '4',
					'right'   => '4',
					'bottom'  => '4',
					'left'    => '4',
					'unit'    => 'px',
					'isLinked' => true,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pricing_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content',
			]
		);
		$this->add_responsive_control( 'pricing_box_padding',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'       => '45',
					'right'     => '0',
					'bottom'    => '45',
					'left'     => '0',
					'unit'     => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing_box_margin',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		// active box
		$this->add_control( 'pricing_box_active_hd',
			[
				'label'     => __( 'Price Box Active', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control( 'pricing_box_active_background',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'.ua-package-area .ua-package-tab-content .tab-content .package-content.package-active' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing_box_active_border_clr',
			[
				'label'     => __( 'Border Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#f66b5d',
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content.package-active, {{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-active .package__list' => 'border-color: {{VALUE}}',
				],
			]
		);
		$this->add_responsive_control( 'pricing_box_active_border_size',
			[
				'label'      => __( 'Border Size', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'  => [
					'px' => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content.package-active' => 'border-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing_box_active_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content.package-active' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing_box_active_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package-area .ua-package-tab-content .tab-content .package-content.package-active',
			]
		);
		$this->end_controls_section();
	}


	/* Pricing2 Style Controls */
	private function get_style_pricing2_title( ){
		$this->start_controls_section( 'pricing2_title_style',
			[
				'label'       => __( 'Title', 'useful-addons-elementor' ),
				'tab'         => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		$this->add_control( 'pricing2_title_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-title-box .ua-package2-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing2_title_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#00c99c',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-title-box' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing2_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .ua-package2-title-box',
			]
		);
		$this->add_control( 'pricing2_title_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '8',
					'right'  => '8',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-title-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing2_title_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .ua-package2-title-box',
			]
		);
		$this->add_control( 'pricing2_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '20',
					'right'  => '20',
					'bottom' => '20',
					'left'   => '20',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-title-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-title-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing2_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .ua-package2-title-box .ua-package2-title',
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing2_price( ){
		$this->start_controls_section( 'pricing2_price_style',
			[
				'label'       => __( 'Price', 'useful-addons-elementor' ),
				'tab'         => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		$this->add_control( 'pricing2_price_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#00c99c',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box h3' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing2_price_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .ua-package2-content-box h3',
			]
		);
		$this->add_control( 'pricing2_price_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box h3' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_price_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_price_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing2_price_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .ua-package2-content-box h3',
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing2_time( ){
		$this->start_controls_section( 'pricing2_time_style',
			[
				'label'       => __( 'Time', 'useful-addons-elementor' ),
				'tab'         => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		$this->add_control( 'pricing2_time_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#748494',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box h5' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing2_time_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .ua-package2-content-box h5',
			]
		);
		$this->add_control( 'pricing2_time_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box h5' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_time_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box h5' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_time_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing2_time_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .ua-package2-content-box h5',
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing2_content( ){
		$this->start_controls_section( 'pricing2_content_style',
			[
				'label'       => __( 'Content', 'useful-addons-elementor' ),
				'tab'         => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		$this->add_control( 'pricing2_content_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#748494',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing2_content_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .ua-package2-content-box p',
			]
		);
		$this->add_control( 'pricing2_content_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box p' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_content_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '24',
                    'right'  => '0',
                    'bottom' => '0',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_content_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing2_content_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .ua-package2-content-box p',
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing2_btn( ){
		$this->start_controls_section( 'pricing2_btn_style',
			[
				'label'       => __( 'Button', 'useful-addons-elementor' ),
				'tab'         => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		/* Start Tab */
		$this->start_controls_tabs( 'pricing2_btn_tabs',
			[
				'separator' => 'before'
			]
		);
		// normal tab
		$this->start_controls_tab( 'pricing2_btn_nrml_tab',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'pricing2_btn_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#00c99c',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing2_btn_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'  => 'pricing2_btn_border',
				'label' => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#00c99c',
					],
				],
				'selector' => '{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn',
			]
		);
		$this->add_control( 'pricing2_btn_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
                    'top'    => '.25',
                    'right'  => '.25',
                    'bottom' => '.25',
                    'left'   => '.25',
                    'unit'   => 'rem',
                    'isLinked' => true,
                ],
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing2_btn_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn',
			]
		);
		$this->add_control( 'pricing2_btn_pd',
			[
				'label' => __( 'Padding', 'useful-addons-elementor' ),
				'type'  => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'default'    => [
					'top'    => '14',
					'right'  => '18',
					'bottom' => '12',
					'left'   => '18',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_btn_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();

		// hover tab
		$this->start_controls_tab( 'pricing2_btn_hv_tab',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'pricing2_btn_color_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing2_btn_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#00c99c',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name'     => 'pricing2_btn_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn:hover',
			]
		);
		$this->add_control( 'pricing2_btn_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing2_btn_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn:hover',
			]
		);
		$this->add_control( 'pricing2_btn_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_btn_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* End Tab */
		$this->add_control( 'pricing2_btn_hr',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing2_btn_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .btn-box .ua-package2-btn',
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing2_charges( ){
		$this->start_controls_section( 'pricing2_charges_style',
			[
				'label'       => __( 'Charges', 'useful-addons-elementor' ),
				'tab'         => Controls_Manager::TAB_STYLE,
				'condition'   => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		$this->add_control( 'pricing2_charges_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#748494',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card .btn-box p' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing2_charges_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .btn-box p',
			]
		);
		$this->add_control( 'pricing2_charges_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .btn-box p' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_charges_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '8',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .btn-box p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_charges_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .btn-box p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing2_charges_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .btn-box p',
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing2_box( ){
		$this->start_controls_section( 'pricing2_box_style',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'pricing_box_layout' => 'layout_2'
				]
			]
		);
		$this->add_control( 'pricing2_box_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package2-card' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing2_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card',
			]
		);
		$this->add_control( 'pricing2_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '8',
					'right'  => '8',
					'bottom' => '8',
					'left'   => '8',
					'unit'   => 'px',
					'isLinked' => true,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing2_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card',
				'fields_options' => [
					'box_shadow_type' => [
						'default' =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(82, 85, 90, 0.1)'
						]
					]
				],
			]
		);
		$this->add_control( 'pricing2_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		/* content inner box */
		$this->add_control( 'pricing2_box_content_inner_box',
			[
				'label'     => __( 'Content Inner Box', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing2_box_content_inner_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .ua-package2-content-box',
			]
		);
		$this->add_control( 'pricing2_box_content_inner_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '40',
					'right'  => '40',
					'bottom' => '35',
					'left'   => '40',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_box_content_inner_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .ua-package2-content-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		/* Button inner box */
		$this->add_control( 'pricing2_box_btn_inner_box',
			[
				'label'     => __( 'Button Inner Box', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing2_box_btn_inner_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package2-card .btn-box',
			]
		);
		$this->add_control( 'pricing2_box_btn_inner_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '0',
					'right'  => '40',
					'bottom' => '30',
					'left'   => '40',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .btn-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control( 'pricing2_box_btn_inner_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package2-card .btn-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}

	/* Pricing 3 Style Controls */
	private function get_style_pricing3_badge( ) {
		$this->start_controls_section( 'pricing3_badge_style',
			[
				'label'     => __( 'Badge', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'pricing_st3_show_badge' => 'yes',
					'pricing_box_layout'     => 'layout_3'
				],
			]
		);
		$this->add_control( 'pricing3_badge_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-badge' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing3_badge_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-badge' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing3_badge_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-badge',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing3_badge_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-badge',
			]
		);
		$this->add_control( 'pricing3_badge_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '4',
                    'right'  => '4',
                    'bottom' => '0',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing3_badge_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-badge',
			]
		);
		$this->add_responsive_control( 'pricing3_badge_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '15',
					'right'  => '0',
					'bottom' => '15',
					'left'   => '0',
					'unit'   => 'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_badge_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-badge' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing3_price( ) {
		$this->start_controls_section( 'pricing3_price_style',
			[
				'label'     => __( 'Price', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'pricing_box_layout'     => 'layout_3'
				],
			]
		);
		$this->add_control( 'pricing3_price_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-price' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing3_price_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-price',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing3_price_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-price',
			]
		);
		$this->add_control( 'pricing3_price_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-price' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_price_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_price_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '0',
                    'bottom' => '10',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-price' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing3_title( ) {
		$this->start_controls_section( 'pricing3_title_style',
			[
				'label'     => __( 'Title', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'pricing_box_layout' => 'layout_3'
				],
			]
		);
		$this->add_control( 'pricing3_title_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#233d63',
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing3_title_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-title',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing3_title_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-title',
			]
		);
		$this->add_control( 'pricing3_title_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_title_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_title_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '0',
                    'right'    => '0',
                    'bottom'   => '6',
                    'left'     => '0',
                    'unit'     => 'px',
                    'isLinked' => false
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing3_feature_list( ) {
		$this->start_controls_section( 'pricing3_featurelist_style',
			[
				'label'     => __( 'Feature List', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'pricing_box_layout' => 'layout_3'
				],
			]
		);
		$this->add_control( 'pricing3_featurelist_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-feature-lists li' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing3_featurelist_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-feature-lists li',
			]
		);
		$this->add_responsive_control( 'pricing3_featurelist_spc_between',
			[
				'label'      => __( 'Space Between', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px'     => [
						'min'  => 0,
						'max'  => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 8,
				],
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-feature-lists li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing3_featurelist_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '0',
							'bottom'   => '0',
							'left'     => '0',
							'isLinked' => false,
						],
					],
					'color' => [
						'default' => 'rgba(127, 136, 151, 0.1)',
					],
				],
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-feature-lists',
			]
		);
		$this->add_responsive_control( 'pricing3_featurelist_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
					'top'    => '33',
					'right'  => '0',
					'bottom' => '0',
					'left'   => '0',
					'unit'   =>  'px',
					'isLinked' => false,
				],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-feature-lists' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_featurelist_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '35',
                    'right'  => '0',
                    'bottom' => '35',
                    'left'   => '0',
                    'unit'   =>  'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-feature-lists' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing3_btn( ) {
		$this->start_controls_section( 'pricing3_btn_style',
			[
				'label'     => __( 'Button', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'pricing_box_layout' => 'layout_3'
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing3_btn_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-btn',
			]
		);
		/* ------------------------
		    Start Tab
		----------------------------*/
		$this->start_controls_tabs( 'pricing3_btn_tab',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'pricing3_btn_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'pricing3_btn_clr',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-btn' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing3_btn_bg',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-btn' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing3_btn_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'fields_options'  => [
					'border'      => [
						'default' => 'solid',
					],
					'width'       => [
						'default' => [
							'top'      => '1',
							'right'    => '1',
							'bottom'   => '1',
							'left'     => '1',
							'isLinked' => true,
						],
					],
					'color' => [
						'default' => '#51be78',
					],
				],
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-btn',
			]
		);
		$this->add_control( 'pricing3_btn_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '5',
                    'right'  => '5',
                    'bottom' => '5',
                    'left'   => '5',
                    'unit'   => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing3_btn_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-btn',
			]
		);
		$this->add_responsive_control( 'pricing3_btn_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '0',
                    'right'  => '30',
                    'bottom' => '0',
                    'left'   => '30',
                    'unit'   => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_btn_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'pricing3_btn_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_control( 'pricing3_btn_clr_hv',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-btn:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control( 'pricing3_btn_bg_hv',
			[
				'label'     => __( 'Background', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#51be78',
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-btn:hover' => 'background: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing3_btn_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-btn:hover',
			]
		);
		$this->add_control( 'pricing3_btn_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-btn:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing3_btn_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-btn:hover',
			]
		);
		$this->add_responsive_control( 'pricing3_btn_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-btn:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_btn_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-btn:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* ------------------------
		    End Tab
		----------------------------*/
		$this->end_controls_section();
	}
	private function get_style_pricing3_meta( ) {
		$this->start_controls_section( 'pricing3_meta_style',
			[
				'label'     => __( 'Meta', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'pricing_box_layout' => 'layout_3'
				],
			]
		);
		$this->add_control( 'pricing3_meta_color',
			[
				'label'     => __( 'Color', 'useful-addons-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#7f8897',
				'selectors' => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-meta' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control( Group_Control_Typography::get_type(),
			[
				'name'     => 'pricing3_meta_typography',
				'label'    => __( 'Typography', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-meta',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing3_meta_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item .ua-package3-meta',
			]
		);
		$this->add_control( 'pricing3_meta_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-meta' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_meta_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-meta' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_meta_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '23',
                    'right'  => '0',
                    'bottom' => '0',
                    'left'   => '0',
                    'unit'   => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item .ua-package3-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
	}
	private function get_style_pricing3_box( ) {
		$this->start_controls_section( 'pricing3_box_style',
			[
				'label'     => __( 'Box', 'useful-addons-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'pricing_box_layout' => 'layout_3'
				],
			]
		);
		/* ------------------------
		    Start Tab
		----------------------------*/
		$this->start_controls_tabs( 'pricing3_box_tab',
			[
				'separator' => 'before',
			]
		);
		// normal tab
		$this->start_controls_tab( 'pricing3_box_nrml',
			[
				'label' => __( 'Normal', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'pricing3_box_background',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .ua-package3-item',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing3_box_border',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item',
			]
		);
		$this->add_control( 'pricing3_box_radius',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'    => '4',
                    'right'  => '4',
                    'bottom' => '4',
                    'left'   => '4',
                    'unit'   => 'px',
                    'isLinked' => true,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing3_box_shadow',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'fields_options' => [
					'box_shadow_type' => [
						'default'     =>'yes'
					],
					'box_shadow'  => [
						'default' => [
							'horizontal' => 0,
							'vertical'   => 0,
							'blur'       => 40,
							'spread'     => 0,
							'color'      => 'rgba(14, 16, 48, 0.05)'
						]
					]
				],
				'selector' => '{{WRAPPER}} .ua-package3-item',
			]
		);
		$this->add_responsive_control( 'pricing3_box_pd',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'    => [
                    'top'      => '42',
                    'right'    => '40',
                    'bottom'   => '45',
                    'left'     => '40',
                    'unit'     => 'px',
                    'isLinked' => false,
                ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_box_mg',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		// hover tab
		$this->start_controls_tab( 'pricing3_box_hv',
			[
				'label' => __( 'Hover', 'useful-addons-elementor' ),
			]
		);
		$this->add_group_control( Group_Control_Background::get_type(),
			[
				'name'     => 'pricing3_box_background_hv',
				'label'    => __( 'Background', 'useful-addons-elementor' ),
				'types'    => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .ua-package3-item:hover',
			]
		);
		$this->add_group_control( Group_Control_Border::get_type(),
			[
				'name'     => 'pricing3_box_border_hv',
				'label'    => __( 'Border', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item:hover',
			]
		);
		$this->add_control( 'pricing3_box_radius_hv',
			[
				'label'      => __( 'Border Radius', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control( Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'pricing3_box_shadow_hv',
				'label'    => __( 'Box Shadow', 'useful-addons-elementor' ),
				'selector' => '{{WRAPPER}} .ua-package3-item:hover',
			]
		);
		$this->add_responsive_control( 'pricing3_box_pd_hv',
			[
				'label'      => __( 'Padding', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control( 'pricing3_box_mg_hv',
			[
				'label'      => __( 'Margin', 'useful-addons-elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .ua-package3-item:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		/* ------------------------
		    End Tab
		----------------------------*/
		$this->end_controls_section();
	}

	protected function _register_controls() {
		$this->get_content_pricing();
		$this->get_style_pricing_monthly_yearly_btn();
		$this->get_style_pricing_title();
		$this->get_style_pricing_price_and_currency();
		$this->get_style_pricing_feature_list();
		$this->get_style_pricing_button();
		$this->get_style_pricing_box();


		/* Pricing2 Style Controls */
		$this->get_style_pricing2_title();
		$this->get_style_pricing2_price();
		$this->get_style_pricing2_time();
		$this->get_style_pricing2_content();
		$this->get_style_pricing2_btn();
		$this->get_style_pricing2_charges();
		$this->get_style_pricing2_box();


		/* Pricing 3 Style Controls */
        $this->get_style_pricing3_badge();
        $this->get_style_pricing3_price();
        $this->get_style_pricing3_title();
        $this->get_style_pricing3_feature_list();
        $this->get_style_pricing3_btn();
        $this->get_style_pricing3_meta();
        $this->get_style_pricing3_box();

	}
	protected function render( ) {
		$settings              = $this->get_settings_for_display();
		$pricing_box_repeaters = $this->get_settings_for_display( 'pricing_box_list' );


		$target   = $settings['ua_pricing2_btn_url']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['ua_pricing2_btn_url']['nofollow'] ? ' rel="nofollow"' : '';

		$target2   = $settings['pricing_st3_btn_url']['is_external'] ? ' target="_blank"' : '';
		$nofollow2 = $settings['pricing_st3_btn_url']['nofollow'] ? ' rel="nofollow"' : '';


		if($settings['pricing_box_layout'] === 'layout_1') {
		?>
        <section class="ua-package-area ua-package-area2 text-center">
            <div class="ua-package-tab-content">
                <!-- Nav tabs -->
				<?php
                $pricing_plan_tabapne_remove_class = '';
                $pricing_plan_tabapne_class = '';
                if($settings['pricing_plan_tabs_button'] == 'yes') {
					if($settings['pricing_plan_active_yearly_btn'] == 'yes') {
						$pricing_plan_active_yearly_class  = 'active';
						$pricing_plan_remove_active_class  = ' ';
						$pricing_plan_tabapne_class        = ' in active';
						$pricing_plan_tabapne_remove_class = ' ';
					} else {
						$pricing_plan_active_yearly_class  = ' ';
						$pricing_plan_remove_active_class  = ' active';
						$pricing_plan_tabapne_class        = ' ';
						$pricing_plan_tabapne_remove_class = ' in active';
					}
					if( !empty( $settings['pricing_plan_tabs_monthly_btn_txt'] ) || !empty( $settings['pricing_plan_tabs_yearly_btn_txt'] ) ) {
						?>
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation">
                                <a href="#tab4" class="<?php echo esc_attr($pricing_plan_remove_active_class); ?>" role="tab" data-toggle="tab">
									<?php echo esc_html($settings['pricing_plan_tabs_monthly_btn_txt']); ?>
                                </a>
                            </li>
                            <li role="presentation">
                                <a class="<?php echo esc_attr($pricing_plan_active_yearly_class); ?>" href="#tab5" role="tab" data-toggle="tab">
									<?php echo esc_html($settings['pricing_plan_tabs_yearly_btn_txt']); ?>
                                </a>
                            </li>
                        </ul>
					<?php }
					$pricing_plan_default_active_setting = ' ';
				} else {
					$pricing_plan_default_active_setting = ' in active';
				} ?>
                <!-- Tab panes -->
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane fade <?php echo esc_attr($pricing_plan_tabapne_remove_class); echo '  '. esc_attr($pricing_plan_default_active_setting); ?>" id="tab4">
                        <div class="row">
							<?php
							foreach ( $pricing_box_repeaters as $index => $item ) {
								if($item['pricing_plan_box_active'] == 'yes') {
									$pricing_box_active = ' package-active';
								} else {
									$pricing_box_active = ' ';
								}
								$pricing_plan_title_key = $this->get_repeater_setting_key( 'pricing_plan_title', 'pricing_box_list', $index );
								$this->add_render_attribute( $pricing_plan_title_key, [
									'class' => 'package__title',
								] );

								$pricing_content_list = $item['pricing_price_list_content'];
								$pricing_content_list_counts = explode("\n", $pricing_content_list);

								$target = $item['pricing_price_btn_url']['is_external'] ? ' target="_blank"' : '';
								$nofollow = $item['pricing_price_btn_url']['nofollow'] ? ' rel="nofollow"' : '';
								?>
                                <div class="col-md-4 col-sm-12">
                                    <div class="package-content <?php echo esc_attr($pricing_box_active); ?>">
										<?php if(!empty( $item['pricing_plan_title'] )) { ?>
                                            <h4 <?php $this->print_render_attribute_string( $pricing_plan_title_key); ?>>
												<?php echo esc_html($item['pricing_plan_title']); ?>
                                            </h4>
										<?php } if( !empty( $item['pricing_plan_per_month_price']) || !empty( $item['pricing_price_period_per_monthly'])) { ?>
                                            <div class="price__box">
												<?php if(!empty( $item['pricing_plan_per_month_price'])) {
													if($item['pricing_price_currency_position'] == 'left'){
														?>
                                                        <span class="price__price-title">
                                                            <sup><?php echo esc_html($item['pricing_price_currency']); ?></sup><?php echo esc_html($item['pricing_plan_per_month_price']); ?>
                                                        </span>
													<?php } else { ?>
                                                        <span class="price__price-title">
                                                            <?php echo esc_html($item['pricing_plan_per_month_price']); ?><sup><?php echo esc_html($item['pricing_price_currency']); ?></sup>
                                                        </span>
													<?php }
												} if(!empty( $item['pricing_price_period_per_monthly'])) { ?>
                                                    <span class="price__text-text">
                                                        <?php echo esc_html($item['pricing_price_period_per_monthly']); ?>
                                                    </span>
												<?php } ?>
                                            </div>
										<?php } if(!empty( $pricing_content_list)) { ?>
                                            <ul class="package__list">
												<?php
												foreach ( $pricing_content_list_counts as $pricing_content_list_count ) {
													echo '<li> '.$pricing_content_list_count.'</li>';
												}
												?>
                                            </ul>
										<?php } if($item['pricing_price_show_button'] == 'yes' && !empty( $item['pricing_price_btn_text'])) { ?>
                                            <a href="<?php echo esc_url($item['pricing_price_btn_url']['url']); ?>" <?php echo esc_attr($target) . ' ' . esc_attr($nofollow) ?> class="theme-button">
												<?php
												if( $item['pricing_price_show_btn_icon'] == 'yes' ) {
													if ( !empty( $item['pricing_price_btn_icon'] ) ) {
														Icons_Manager::render_icon( $item['pricing_price_btn_icon'], ['class' => 'fa__arrow ', 'aria-hidden' => 'true' ] );
													}
												} ?>
												<?php echo esc_html($item['pricing_price_btn_text']); ?>
                                            </a>
										<?php } ?>
                                    </div><!-- end package-content -->
                                </div><!-- end col-md-4 -->
							<?php } ?>
                        </div><!-- end row -->
                    </div><!-- end tab-pane -->

                    <div role="tabpanel" class="tab-pane fade <?php echo esc_attr($pricing_plan_tabapne_class); ?>" id="tab5">
                        <div class="row">
							<?php
							foreach ( $pricing_box_repeaters as $index => $item ) {
								if($item['pricing_plan_box_active'] == 'yes') {
									$pricing_box_active = ' package-active';
								} else {
									$pricing_box_active = ' ';
								}
								$pricing_plan_title_key = $this->get_repeater_setting_key( 'pricing_plan_title', 'pricing_box_list', $index );
								$this->add_render_attribute( $pricing_plan_title_key, [
									'class' => 'package__title',
								] );

								$pricing_content_list        = $item['pricing_price_list_content'];
								$pricing_content_list_counts = explode("\n", $pricing_content_list);

								?>
                                <div class="col-md-4 col-sm-12">
                                    <div class="package-content <?php echo esc_attr($pricing_box_active); ?>">
										<?php if(!empty( $item['pricing_plan_title'])) { ?>
                                            <h4 <?php $this->print_render_attribute_string( $pricing_plan_title_key); ?>>
												<?php echo esc_html($item['pricing_plan_title']); ?>
                                            </h4>
										<?php }
										if(!empty( $item['pricing_plan_per_yearly_price']) || !empty( $item['pricing_plan_per_yearly_price'])) { ?>
                                            <div class="price__box">
												<?php if(!empty( $item['pricing_plan_per_yearly_price'])) {
													if($item['pricing_price_currency_position'] == 'left'){
														?>
                                                        <span class="price__price-title">
                                                            <sup><?php echo esc_html($item['pricing_price_currency']); ?></sup><?php echo esc_html($item['pricing_plan_per_yearly_price']); ?>
                                                        </span>
													<?php } else { ?>
                                                        <span class="price__price-title">
                                                            <?php echo esc_html($item['pricing_plan_per_yearly_price']); ?><sup><?php echo esc_html($item['pricing_price_currency']); ?></sup>
                                                        </span>
													<?php }
												} if(!empty( $item['pricing_price_period_per_yearly'])) { ?>
                                                    <span class="price__text-text">
                                                        <?php echo esc_html($item['pricing_price_period_per_yearly']); ?>
                                                    </span>
												<?php } ?>
                                            </div>
										<?php } if(!empty( $pricing_content_list)) { ?>
                                            <ul class="package__list">
												<?php
												foreach ( $pricing_content_list_counts as $pricing_content_list_count ) {
													echo '<li> '.$pricing_content_list_count.'</li>';
												}
												?>
                                            </ul>
										<?php } if($item['pricing_price_show_button'] == 'yes' && !empty( $item['pricing_price_btn_text'])) { ?>
                                            <a href="<?php echo esc_url($item['pricing_price_btn_url']['url']); ?>" <?php echo esc_attr($target) . ' ' . esc_attr($nofollow) ?> class="theme-button">
												<?php
												if($item['pricing_price_show_btn_icon'] == 'yes') {
													if ( !empty( $item['pricing_price_btn_icon'] ) ) {
														Icons_Manager::render_icon( $item['pricing_price_btn_icon'], ['class' => 'fa__arrow ', 'aria-hidden' => 'true' ] );
													}
												}

												?>
												<?php echo esc_html($item['pricing_price_btn_text']); ?>
                                            </a>
										<?php } ?>
                                    </div><!-- end package-content -->
                                </div><!-- end col-md-4 -->
							<?php } ?>
                        </div>
                    </div><!-- end tab-pane -->
                </div><!-- end tab-content -->
            </div><!-- end ua-package-tab-content -->
        </section>
	<?php
        } elseif($settings['pricing_box_layout'] === 'layout_2') { ?>

            <div class="ua-package2-card text-center">
                <?php if(!empty($settings['ua_pricing2_title'])) { ?>
                    <div class="ua-package2-title-box">
                        <?php if($settings['ua_pricing2_title_shape_show'] === 'yes') { ?>
                            <span class="dot-bg dot-bg-one"></span>
                            <span class="dot-bg dot-bg-two"></span>
                            <span class="dot-bg dot-bg-three"></span>
                            <span class="dot-bg dot-bg-four"></span>
                            <span class="dot-bg dot-bg-five"></span>
                            <span class="dot-bg dot-bg-six"></span>
                        <?php } ?>
                        <h2 class="ua-package2-title"><?php echo esc_html($settings['ua_pricing2_title']); ?></h2>
                    </div>
                <?php } ?>
                <div class="ua-package2-content-box">
                    <?php if(!empty($settings['ua_pricing2_price'])) { ?>
                        <h3 class="ua-package2-price">
                            <?php if(!empty($settings['ua_pricing2_currency'])) { ?>
                            <span><?php echo esc_html($settings['ua_pricing2_currency']); ?></span><?php } echo esc_html($settings['ua_pricing2_price']); ?></h3>
                    <?php } if(!empty($settings['ua_pricing2_time'])) { ?>
                        <h5 class="ua-package2-time">
                            <?php echo esc_html($settings['ua_pricing2_time']); ?>
                        </h5>
                    <?php } if(!empty($settings['ua_pricing2_content'])) { ?>
                        <p class="ua-package2-content">
                            <?php echo esc_html($settings['ua_pricing2_content']) ?>
                        </p>
                    <?php } ?>
                </div>
                <?php if(!empty($settings['ua_pricing2_btn_tx']) || !empty($settings['ua_pricing2_charge'])) { ?>
                    <div class="btn-box">
                        <?php if(!empty($settings['ua_pricing2_btn_tx'])) {
                            echo '<a href="'.esc_url($settings['ua_pricing2_btn_url']['url']).'" '.esc_attr($target).' '. esc_attr($nofollow).'  class="btn ua-package2-btn">';
                                echo esc_html($settings['ua_pricing2_btn_tx']);
                            echo '</a>';
                        } if(!empty($settings['ua_pricing2_charge'])) { ?>
                            <p class="ua-package2-charge">
                                <?php echo esc_html($settings['ua_pricing2_charge']); ?>
                            </p>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>

        <?php } else { ?>
            <div class="ua-package3-item transition-all-3s">
                <?php if($settings['pricing_st3_show_badge'] == 'yes' && !empty($settings['pricing_st3_badge'])) { ?>
                    <span class="ua-package3-badge text-center">
                        <?php echo esc_html($settings['pricing_st3_badge']); ?>
                    </span>
                <?php } ?>
                <div class="ua-package3-title-price">
                    <?php if(!empty($settings['pricing_st3_price'])) { ?>
                        <h3 class="ua-package3-price">
                            <span><?php echo esc_html($settings['pricing_st3_currency']); ?></span><?php echo esc_html($settings['pricing_st3_price']); ?>
                        </h3>
                    <?php } if(!empty($settings['pricing_st3_title'])) { ?>
                        <h3 class="ua-package3-title">
                            <?php echo esc_html($settings['pricing_st3_title']); ?>
                        </h3>
                    <?php } ?>
                </div>
                <?php if(!empty($settings['pricing_st3_feature_lists'])) { ?>
                    <ul class="ua-package3-feature-lists">
                        <?php foreach ( $settings['pricing_st3_feature_lists'] as $item ) { ?>
                            <li>
                                <span style="<?php if(!empty($item['pricing_st3_feature_icon_clr'])) {echo esc_attr__('color: ', 'useful-addons-elementor').esc_attr($item['pricing_st3_feature_icon_clr']); } ?>">
                                    <?php Icons_Manager::render_icon( $item['pricing_st3_feature_icon'], [ 'aria-hidden' => 'true' ] ); echo '</span> '. esc_html($item['pricing_st3_feature_title']); ?>
                            </li>
                        <?php } ?>
                    </ul>
                <?php } ?>
                <div class="ua-package3-btn-box">
                    <?php if(!empty($settings['pricing_st3_btn_txt'])) { ?>
                        <a href="<?php echo esc_url($settings['pricing_st3_btn_url']['url']); ?>" <?php echo esc_attr($target2) . esc_attr($nofollow2); ?> class="ua-package3-btn transition-all-3s">
                            <?php echo esc_html($settings['pricing_st3_btn_txt']); ?>
                        </a>
                    <?php } if(!empty($settings['pricing_st3_meta'])) { ?>
                        <p class="ua-package3-meta">
                            <?php echo esc_html($settings['pricing_st3_meta']); ?>
                        </p>
                    <?php } ?>
                </div>
            </div>
        <?php }
    }

	protected function _content_template() { }
}

Plugin::instance()->widgets_manager->register_widget_type( new UA_pricing_table() );