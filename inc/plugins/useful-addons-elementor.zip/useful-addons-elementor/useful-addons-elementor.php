<?php
/**
 * Plugin Name: Useful Addons for Elementor
 * Description: The ultimate elements library for Elementor page builder plugin for WordPress.
 * Plugin URI: https://usefuladdons.com/
 * Author: Techydevs
 * Version: 1.0
 * Author URI: https://techydevs.com/about
 * Text Domain: useful-addons-elementor
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Defining plugin constants.
 * @since 1.0.0
 */
define( 'UA_ELEMENTOR_URL', plugin_dir_url( __FILE__));
define( 'UA_ELEMENTOR_PATH', plugin_dir_path( __FILE__ ) );
define( 'UA_ELEMENTOR_ROOT', __FILE__ );
define( 'UA_ELEMENTOR_VERSION', '1.0' );
define( 'UA_ELEMENTOR_BASENAME', plugin_basename( __FILE__ ) );
define( 'UA_ELEMENTOR_ASSETS', trailingslashit( UA_ELEMENTOR_URL . 'assets' ) );


/**
 * Including composer autoloader globally.
 * @since 3.0.0
 */
require_once UA_ELEMENTOR_PATH . 'autoloader.php';
// setting dashboard
require_once UA_ELEMENTOR_PATH.'includes/settings/admin.php';
require_once UA_ELEMENTOR_PATH.'includes/Elements/breadcrumbs/class-one-breadcrumbs.php';
require_once UA_ELEMENTOR_PATH.'includes/Elements/breadcrumbs/class-one-woocommerce-helper.php';


add_image_size( 'ua-download-gallery-img', 610, 400, true );
add_image_size( 'ua-blog-grid-img', 370, 247, true );




/**
 * This function will return true for all activated modules
 * @since   v1.0.0
 */
function UA_elementor_activated_modules() {
	$UA_elementor_default_keys = [
		'hero-banner',
		'corona-live-map',
		'advice',
		'icon-list',
		'icon-box',
		'button',
		'counter',
		'progressbar',
		'tabs',
		'post-grid',
		'testimonial',
		'divider',
		'search-form',
		'search-hotel',
		'hotel-slider',
		'course-grid',
		'course-filter',
		'login_register',
		'social-media',
		'team',
		'pricing',
		'portfolio',
		'pie-chart',
		'page-list',
		'hero-slider',
		'breadcrumbs',
		'course-category',
		'category-box',
		'flip-card',
		'edd-slider',
		'edd-gallery-slider',
		'edd-product-filter'
	];

	$UA_elementor_default_settings  = array_fill_keys( $UA_elementor_default_keys, true );
	$UA_elementor_get_settings      = get_option( 'UA_elementor_save_settings', $UA_elementor_default_settings );
	$UA_elementor_new_settings      = array_diff_key( $UA_elementor_default_settings, $UA_elementor_get_settings );

	if( ! empty( $UA_elementor_new_settings ) ) {
		$UA_elementor_updated_settings = array_merge( $UA_elementor_get_settings, $UA_elementor_new_settings );
		update_option( 'UA_elementor_save_settings', $UA_elementor_updated_settings );
	}
	return $UA_elementor_get_settings = get_option( 'UA_elementor_save_settings', $UA_elementor_default_settings );
}

/**
 * Activate or Deactivate Modules
 * @since v1.0.0
 */
require_once UA_ELEMENTOR_PATH.'includes/widgets-register.php';

/* Category Register */
function add_UA_widget_categories( $elements_manager ) {
	$elements_manager->add_category( 'useful-addons-elementor-category',
		[
			'title' => __( 'Useful Addons', 'useful-addons-elementor' ),
			'icon'  => 'la la-user',
		]
	);
}
add_action( 'elementor/elements/categories_registered', 'add_UA_widget_categories' );

/**
 * Check if a plugin is installed
 *
 * @param $basename
 *
 * @return bool
 * @since v1.0.0
 */
function is_plugin_installed($basename) {
	if (!function_exists('get_plugins')) {
		include_once ABSPATH . '/wp-admin/includes/plugin.php';
	}

	$installed_plugins = get_plugins();

	return isset($installed_plugins[$basename]);
}

/**
 * Admin notice.
 * Warning when the site doesn't have Elementor installed or activated.
 * @since 1.0.0
 * @access public
 */
function admin_notice_missing_elementor() {
	$elementor = 'elementor/elementor.php';
	if (!current_user_can('activate_plugins') || is_plugin_active( $elementor)) {
		return;
	}

	if (is_plugin_installed( $elementor)) {
		$activation_url = wp_nonce_url('plugins.php?action=activate&amp;plugin=' . $elementor . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $elementor);
		$message = sprintf( __('%1$s Useful Addons for Elementor %2$s requires %1$s Elementor %2$s to be installed and activated.', 'useful-addons-elementor'), '<strong>', '</strong>' );
		$button_text = __('Activate Elementor', 'useful-addons-elementor');
	} else {
		$activation_url = wp_nonce_url(self_admin_url('update.php?action=install-plugin&plugin=elementor'), 'install-plugin_elementor');
		$message = sprintf(__('%1$s Useful Addons for Elementor %2$s requires %1$s Elementor %2$s to be installed and activated.', 'useful-addons-elementor'), '<strong>', '</strong>');
		$button_text = __('Install Elementor', 'useful-addons-elementor');
	}

	$button = '<p><a href="' . $activation_url . '" class="button-primary">' . $button_text . '</a></p>';

	printf('<div class="error UA-missing-elementor"><p>%1$s</p>%2$s</div>', $message, $button);
}

add_action( 'admin_notices', 'admin_notice_missing_elementor' );


// Team Widget
$is_component_active = UA_elementor_activated_modules();
if( $is_component_active['team'] ) {
    require_once UA_ELEMENTOR_PATH.'includes/sidebars/team-sidebar.php';
}

/**
 * UA Function - Check if added to cart.
 *
 * Check if an item exists or is added to cart already.
 */
if( ! function_exists( 'ua_check_if_added_to_cart' ) ){
	function ua_check_if_added_to_cart( $itemID ) {

		$cartItems = edd_get_cart_contents();
		$cartIDs   = ua_get_cart_IDs($cartItems);
		if(in_array($itemID, $cartIDs)){
			return true;
		}
		return false;
	}
}

/**
 * UA Function - Get cart item ids.
 * Getting the cart item ids.
 */
if( ! function_exists( 'ua_get_cart_IDs' ) ){
	function ua_get_cart_IDs( $cartItems ) {

		$cartIDs=array();
		if(is_array($cartItems)){
			foreach ($cartItems as $cartItemkey => $cartItemvalue) {
				$cartIDs[]=$cartItemvalue['id'];
			}
		}
		return $cartIDs;
	}
}


// ua enqueue assets
require_once UA_ELEMENTOR_PATH.'includes/enqueue.php';

// ua custom post types
require_once UA_ELEMENTOR_PATH.'custom-posttypes/custom-posttype.php';

// ua meta box register
require_once UA_ELEMENTOR_PATH.'custom-meta/ua-meta-box.php';

/* UA Icons*/
require_once UA_ELEMENTOR_PATH.'includes/ua-icons-manager.php';




/**
 * Initializing the authorisation.
 */

if( ! function_exists( 'ua_authorisation_init' ) ){
	function ua_authorisation_init(){
		$loginRedirect = home_url();
		wp_enqueue_script('ua-login-register', UA_ELEMENTOR_URL.'/assets/js/ua-login-register.js', array('jquery'));
		wp_localize_script( 'ua-login-register', 'ajax_auth_object', array(
			'ajaxurl'         => admin_url( 'admin-ajax.php' ),
			'redirecturl'     => isset($loginRedirect) ? $loginRedirect : home_url(),
			'loadingmessage'  => esc_html__('Sending user info, please wait...','useful-addons-elementor')
		));
		add_action( 'wp_ajax_ua_ajaxlogin', 'ua_ajaxlogin' );
		add_action( 'wp_ajax_nopriv_ua_ajaxlogin', 'ua_ajaxlogin' );
		add_action( 'wp_ajax_nopriv_ua_ajaxregister','ua_ajax_register' );
		add_action( 'wp_ajax_ua_ajaxregister', 'ua_ajax_register' );
	}
}
add_action('init', 'ua_authorisation_init');



/**
 * Ajax popup login actions.
 */
if( ! function_exists( 'ua_ajaxlogin' ) ){
	function ua_ajaxlogin(){

		// First check the nonce, if it fails the function will break
		check_ajax_referer( 'ajax-login-nonce', 'security' );

		// Nonce is checked, get the POST data and sign user on
		// Call auth_user_login
		ua_auth_user_login($_POST['username'], $_POST['password'], 'Login');

		die();
	}
}


/**
 * Ajax popup register actions.
 */

if( ! function_exists( 'ua_ajax_register' ) ){
	function ua_ajax_register(){

		global $options; $options = get_option('ua_register_login');

		// First check the nonce, if it fails the function will break
		check_ajax_referer( 'ajax-register-nonce', 'security' );

		// Nonce is checked, get the POST data and sign user on
		$info = array();
		$info['user_nicename'] = $info['nickname'] = $info['display_name'] = $info['first_name'] = $info['user_login'] = sanitize_user($_POST['username']) ;
		$info['user_pass']     = sanitize_text_field($_POST['password']);
		$info['user_email']    = sanitize_email( $_POST['email']);

		// Register the user

		if(!is_email($info['user_email']) ){
			echo json_encode(array('loggedin'=>false, 'message'=>esc_html__("Please enter a valid email address","useful-addons-elementor")));
			die();
		}
		if(sanitize_text_field($_POST['password2'])!=$info['user_pass']){
			echo json_encode(array('loggedin'=>false, 'message'=>esc_html__("Please enter same password in both fields","useful-addons-elementor")));
			die();
		}
		if(!isset($info['user_pass'])|| !(strlen($info['user_pass']) >0 ) ){
			echo json_encode(array('loggedin'=>false, 'message'=>esc_html__("Password fields cannot be blank","useful-addons-elementor")));
			die();
		}

		$user_register = wp_insert_user( $info );
		if ( is_wp_error($user_register) ){
			$error  = $user_register->get_error_codes() ;

			if(in_array('empty_user_login', $error))
				echo json_encode(array('loggedin'=>false, 'message'=>$user_register->get_error_message('empty_user_login')));
			elseif(in_array('existing_user_login',$error))
				echo json_encode(array('loggedin'=>false, 'message'=>esc_html__('This username is already registered.','useful-addons-elementor')));
			elseif(in_array('existing_user_email',$error))
				echo json_encode(array('loggedin'=>false, 'message'=>esc_html__('This email address is already registered.','useful-addons-elementor')));
		} else {

			ua_auth_user_login($info['nickname'], $info['user_pass'], 'Registration');
		}

		die();
	}
}


/**
 * Authenticating the popup login user.
 */

if( ! function_exists( 'ua_auth_user_login' ) ){
	function ua_auth_user_login($user_login, $password, $login)
	{
		$info                  = array();
		$info['user_login']    = $user_login;
		$info['user_password'] = $password;
		$info['remember']      = true;

		add_action( 'set_logged_in_cookie', 'ua_loggedin_cookie' );
		function ua_loggedin_cookie( $logged_in_cookie ){
			$_COOKIE[LOGGED_IN_COOKIE] = $logged_in_cookie;
		}

		$user_signon = wp_signon( $info, is_ssl() ? true : false);
		if ( is_wp_error($user_signon) ){
			echo json_encode(array('loggedin'=>false, 'message'=>esc_html__('Wrong username or password.','useful-addons-elementor')));
		} else {
			global $current_user;
			wp_set_current_user($user_signon->ID);
			if($login=="Login"){
				echo json_encode(array('loggedin'=>true, 'message'=>esc_html__('Login successful, redirecting...','useful-addons-elementor')));
			}
			else{
				echo json_encode(array('loggedin'=>true, 'message'=>esc_html__('Registration successful, redirecting...','useful-addons-elementor')));
			}

		}

		die();
	}
}

/**
 * Displays the currently logged in user name.
 */

if( ! function_exists( 'ua_print_current_user_name' ) ){
	function ua_print_current_user_name(){
		$current_user = wp_get_current_user();
		echo esc_html($current_user->user_login);
	}
}
add_action( 'wp_ajax_ua_main_ajax',  'ua_main_ajax' );
add_action( 'wp_ajax_nopriv_ua_main_ajax','ua_main_ajax');


