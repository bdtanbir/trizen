

if ( jQuery(".skillbar").length ) {
    jQuery(window).scroll(function () {
        // skillbar
        jQuery('.skillbar').each(function () {
            jQuery(this).find('.skillbar-bar').animate( {
                width: jQuery(this).attr('data-percent')
            }, 6000);
        });
    });
}

jQuery(window).load(function($){


    if( jQuery(".ua-portfolio-filter").length ) {
        jQuery('.portfolioFilter a').click(function () {
            jQuery('.portfolioFilter .current').removeClass('current');
            jQuery(this).addClass('current');

            var selector = jQuery(this).attr('data-filter');
            $container.isotope({
                filter: selector,
                animationOptions: {
                    duration: 750,
                    easing: 'linear',
                    queue: false
                }
            });
            return false;
        });
        var $container2 = jQuery('.portfolio-list');
        $container2.isotope({
            filter: '*',
            animationOptions: {
                duration: 750,
                easing: 'linear',
                queue: false
            }
        });

        jQuery('.ua-portfolio-filter li').click(function () {
            jQuery('.ua-portfolio-filter li').removeClass('active');
            jQuery(this).addClass('active');

            var selector = jQuery(this).attr('data-filter');
            $container2.isotope({
                filter: selector,
                animationOptions: {
                    duration: 750,
                    easing: 'linear',
                    queue: false
                }
            });
            return false;
        });
    }


    if ( jQuery(".ua-counter").length ) {
        jQuery('.ua-counter').counterUp({
            delay: 20,
            time: 2000
        });
    }

    /*==== Card preview tooltipster =====*/
    if(jQuery(".ua-card-preview").length) {
        jQuery('.ua-card-preview').tooltipster({
            contentCloning: true,
            interactive: true,
            side: 'right',
            delay: 100,
            animation: 'swing',
            //trigger: 'click'
        });
    }



    
});


jQuery(function($){

    /*Destination selection*/
    if($(".field-detination").length) {
        $('.field-detination').each(function () {
            var parent = $(this);
            var dropdown_menu = $('.dropdown-menu', parent);
            $('li', dropdown_menu).on('click', function () {
                var target = $(this).closest('ul.dropdown-menu').attr('aria-labelledby');
                var focus = parent.find('#' + target);
                $('.destination', focus).text($(this).find('span').text());
                $('input[name="location_name"]', focus).val($(this).find('span').text());
                $('input.location_name', focus).val($(this).find('span').text());
                $('input[name="location_id"]', focus).val($(this).data('value'));
                $('input.location_id', focus).val($(this).data('value'));
                if (window.matchMedia('(max-width: 767px)').matches) {
                    $('label', focus).hide();
                    $('.render', focus).show();
                }
                // dropdown_menu.slideUp(50);
            });
        });
    }




    /* Price range */
    function format_money($money) {
        // if (!$money) {
        //     return ts_params.free_text;
        // }

        $money = ts_number_format($money, ts_params.booking_currency_precision, ts_params.decimal_separator, ts_params.thousand_separator);
        var $symbol = ts_params.currency_symbol;
        var $money_string = '';

        switch (ts_params.currency_position) {
            case "right":
                $money_string = $money + $symbol;
                break;
            case "left_space":
                $money_string = $symbol + " " + $money;
                break;

            case "right_space":
                $money_string = $money + " " + $symbol;
                break;
            case "left":
            default:
                $money_string = $symbol + $money;
                break;
        }

        return $money_string;
    }
    function ts_number_format(number, decimals, dec_point, thousands_sep) {
        number = (number + '')
            .replace(/[^0-9+\-Ee.]/g, '');
        var n = !isFinite(+number) ? 0 : +number,
            prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
            sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
            dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
            s = '',
            toFixedFix = function (n, prec) {
                var k = Math.pow(10, prec);
                return '' + (Math.round(n * k) / k)
                    .toFixed(prec);
            };
        // Fix for IE parseFloat(0.55).toFixed(0) = 0;
        s = (prec ? toFixedFix(n, prec) : '' + Math.round(n))
            .split('.');
        if (s[0].length > 3) {
            s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
        }
        if ((s[1] || '')
            .length < prec) {
            s[1] = s[1] || '';
            s[1] += new Array(prec - s[1].length + 1)
                .join('0');
        }
        return s.join(dec);
    }
    if($(".price_range").length) {
        $(".price_range").each(function () {
            var t = $(this);
            var min = $(this).data('min');
            var max = $(this).data('max');
            var step = $(this).data('step');
            var value = $(this).val();
            var from = value.split(';');
            var prefix_symbol = $(this).data('symbol');
            var to = from[1];
            from = from[0];
            console.log(max)
            $(this).ionRangeSlider({
                min: min,
                max: max,
                type: 'double',
                prefix: prefix_symbol,
                prettify: false,
                step: step,
                onFinish: function (data) {
                    t.trigger('ts_ranger_price_change');
                    set_price_range_val(data, $('input[name="price_range"]'));
                    format_price_price_ranger(data);
                },
                from: from,
                to: to,
                force_edges: true,
            });
        });
    }
    var rangeContainer = $('.sidebar-item.range-slider');
    function format_price_price_ranger(data) {


        var min = rangeContainer.find('.price_range').data('min');
        var max = rangeContainer.find('.price_range').data('max');
        var convert_price_min = data.from;
        var convert_price_max = data.to;
        rangeContainer.find('.irs-from').text(convert_price_min);
        rangeContainer.find('.irs-to').text(convert_price_max);

    }

    function set_price_range_val(data, element) {
        var exchange = 1;
        var from = Math.round(parseInt(data.from) / exchange);
        var to = Math.round(parseInt(data.to) / exchange);
        var text = from + ";" + to;
        element.val(text);
    }




    /* Taxonomy advance search */
    var advFacilities = [];
    $('.taxonomy-advance-search .ts-icheck-item input[type="checkbox"]').each(function () {
        var t = $(this);
        if (t.is(':checked')) {
            advFacilities.push(t.val());
        }
    });
    $('.taxonomy-advance-search .ts-icheck-item input[type="checkbox"]').change(function () {
        var t = $(this);
        if (t.is(':checked')) {
            advFacilities.push(t.val());
        } else {
            var index = advFacilities.indexOf(t.val());
            if (index > -1) {
                advFacilities.splice(index, 1);
            }
        }
        t.closest('.taxonomy-advance-search').find('.data_taxonomy').val(advFacilities.join(','));
    });


    // var body = $('body');
    // if($(".form-date-search").length) {
    //     $('.form-date-search', body).each(function () {
    //         var parent = $(this),
    //             date_wrapper = $('.date-wrapper', parent),
    //             check_in_input = $('.check-in-input', parent),
    //             check_out_input = $('.check-out-input', parent),
    //             check_in_out = $('.check-in-out', parent),
    //             check_in_render = $('.check-in-render', parent),
    //             check_out_render = $('.check-out-render', parent);
    //         var timepicker = parent.data('timepicker');
    //         if (typeof timepicker == 'undefined' || timepicker == '') {
    //             timepicker = false;
    //         } else {
    //             timepicker = true;
    //         }
    //         var options = {
    //             singleDatePicker: false,
    //             sameDate: false,
    //             autoApply: true,
    //             disabledPast: true,
    //             dateFormat: 'DD/MM/YYYY',
    //             customClass: '',
    //             widthSingle: 500,
    //             minDate: new Date,
    //             onlyShowCurrentMonth: true,
    //             timePicker: timepicker,
    //             timePicker24Hour: (ts_params.time_format == '12h') ? false : true,
    //         };
    //         if (typeof locale_daterangepicker == 'object') {
    //             options.locale = locale_daterangepicker;
    //         }

    //         check_in_out.daterangepicker(options,
    //             function (start, end, label) {
    //                 check_in_input.val(start.format(parent.data('format'))).trigger('change');
    //                 $('#tp_hotel .form-date-search .check-in-input').val(start.format('YYYY-MM-DD')).trigger('change');
    //                 check_in_render.html(start.format(parent.data('format'))).trigger('change');
    //                 check_out_input.val(end.format(parent.data('format'))).trigger('change');
    //                 $('#tp_hotel .form-date-search .check-out-input').val(end.format('YYYY-MM-DD')).trigger('change');
    //                 check_out_render.html(end.format(parent.data('format'))).trigger('change');
    //                 if (timepicker) {
    //                     check_in_input.val(start.format(parent.data('date-format'))).trigger('change');
    //                     $('.check-in-input-time', parent).val(start.format(parent.data('time-format'))).trigger('change');
    //                     check_out_input.val(end.format(parent.data('date-format'))).trigger('change');
    //                     $('.check-out-input-time', parent).val(end.format(parent.data('time-format'))).trigger('change');
    //                     $('.check-out-input-time', parent).val(end.format(parent.data('time-format'))).trigger('change');
    //                 }
    //                 check_in_out.trigger('daterangepicker_change', [start, end]);
    //                 if (window.matchMedia('(max-width: 767px)').matches) {
    //                     $('label', parent).hide();
    //                     $('.render', parent).show();
    //                     $('.check-in-wrapper span', parent).show();
    //                 }
    //             });
    //         date_wrapper.click(function (e) {
    //             check_in_out.trigger('click');
    //         });
    //     });
    // }
})


