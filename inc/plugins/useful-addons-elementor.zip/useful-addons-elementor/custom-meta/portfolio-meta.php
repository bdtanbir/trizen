
<div class="ua-portfolio-meta-box">
    <p class="meta-options ua-portfolio-meta-field">
        <label for="UA_portfolio_meta_client">
            <?php echo esc_html__('Client:', 'useful-addons-elementor'); ?>
        </label>
        
        <input id="UA_portfolio_meta_client"
            class="widefat title"
            type="text"
            name="UA_portfolio_meta_client"
            placeholder="TechyDevs LTD."
            value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'UA_portfolio_meta_client', true ) ); ?>">
    </p>
    <p class="meta-options ua-portfolio-meta-field">
        <label for="UA_portfolio_meta_website_txt">
            <?php echo esc_html__('Website Title:', 'useful-addons-elementor'); ?>
        </label>
        
        <input id="UA_portfolio_meta_website_txt"
            class="widefat title"
            type="text"
            name="UA_portfolio_meta_website_txt"
            placeholder="www.example.com"
            value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'UA_portfolio_meta_website_txt', true ) ); ?>">
    </p>
    <p class="meta-options ua-portfolio-meta-field">
        <label for="UA_portfolio_meta_website_url">
            <?php echo esc_html__('Website URL:', 'useful-addons-elementor'); ?>
        </label>
        
        <input id="UA_portfolio_meta_website_url"
            class="widefat title"
            type="text"
            name="UA_portfolio_meta_website_url"
            placeholder="https://"
            value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'UA_portfolio_meta_website_url', true ) ); ?>">
    </p>
</div>
