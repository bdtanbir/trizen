


<?php
    $tm_cnt_designation = get_post_meta( get_the_ID(), 'tm_cnt_designation', true );
    $tm_cnt_address 	= get_post_meta( get_the_ID(), 'tm_cnt_address', true );
    $tm_cnt_num 		= get_post_meta( get_the_ID(), 'tm_cnt_num', true );
    $tm_cnt_gmail 	    = get_post_meta( get_the_ID(), 'tm_cnt_gmail', true );
    $tm_cnt_website	    = get_post_meta( get_the_ID(), 'tm_cnt_website', true );
    $tm_cnt_website_url = get_post_meta( get_the_ID(), 'tm_cnt_website_url', true );
?>
<p>
  <label for="tm_cnt_designation">
    <?php _e('Designation', 'useful-addons-elementor'); ?>
    <input 
      id="tm_cnt_designation"
      type="text" 
      name="tm_cnt_designation"
      value="<?php echo wp_kses_post( $tm_cnt_designation ); ?>"
      />
  </label>
</p>
<p>
  <label for="tm_cnt_address">
    <?php _e('Address', 'useful-addons-elementor'); ?>
    <input 
      id="tm_cnt_address"
      type="text" 
      name="tm_cnt_address"
      value="<?php echo wp_kses_post($tm_cnt_address); ?>"
      />
  </label>
</p>
<p>
  <label for="tm_cnt_num">
    <?php _e('Number', 'useful-addons-elementor'); ?>
    <input 
      id="tm_cnt_num"
      type="tel" 
      name="tm_cnt_num"
      value="<?php echo wp_kses_post($tm_cnt_num); ?>"
      />
  </label>
</p>
<p>
  <label for="tm_cnt_gmail">
    <?php _e('Gmail', 'useful-addons-elementor'); ?>
    <input 
      id="tm_cnt_gmail"
      type="email" 
      name="tm_cnt_gmail"
      value="<?php echo wp_kses_post($tm_cnt_gmail); ?>"
      />
  </label>
</p>
<p>
  <label for="tm_cnt_website">
    <?php _e('Website', 'useful-addons-elementor'); ?>
    <input 
      id="tm_cnt_website"
      type="text" 
      name="tm_cnt_website"
      value="<?php echo wp_kses_post($tm_cnt_website); ?>"
      />
  </label>
</p>
<p>
  <label for="tm_cnt_website_url">
    <?php _e('Website URL', 'useful-addons-elementor'); ?>
    <input 
      id="tm_cnt_website_url"
      type="url" 
      name="tm_cnt_website_url"
      value="<?php echo wp_kses_post($tm_cnt_website_url); ?>"
      />
  </label>
</p>