
<script type="text/html" id="tmpl-repeater2">
    <div class="field-group">
        <input type="text" name="team_education_item[]" value="" />
        <button type="button" class="button button-secondary edc-field-data-remove">
            <?php _e('X', 'useful-addons-elementor'); ?>
        </button>
    </div>
</script>

<?php
$education_data = get_post_meta( get_the_ID(), 'team_education_item', true );
?>

<div id="education_data">
    <?php
    if( !empty( $education_data ) ) {
        foreach( $education_data as $field ) { ?>
            <div class="field-group">
                <input type="text" name="team_education_item[]" value="<?php echo wp_kses_post($field); ?>" />
                <button type="button" class="button button-secondary edc-field-data-remove">
                    <?php _e('X', 'useful-addons-elementor'); ?>
                </button>
            </div>
        <?php }
    } ?>
</div>
<button type="button" id="edc-field_data_add" class="button button-primary">
    <?php _e('Add', 'useful-addons-elementor'); ?>
</button>
