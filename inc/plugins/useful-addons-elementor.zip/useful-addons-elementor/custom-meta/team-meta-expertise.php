
<script type="text/html" id="tmpl-repeater">
  <div class="field-group">
      <input type="text" name="team_expertise_item[]" value="" />
      <button type="button" class="button button-secondary field-data-remove">
          <?php _e('X', 'useful-addons-elementor'); ?>
      </button>
  </div>
</script>

<?php
    $expertise_data = get_post_meta( get_the_ID(), 'team_expertise_item', true );
?>

<div id="expertise_data">
  <?php 
    if(!empty($expertise_data)) {
        foreach( $expertise_data as $field ) { ?>
            <div class="field-group">
                <input type="text" name="team_expertise_item[]" value="<?php echo wp_kses_post( $field ); ?>" />
                <button type="button" class="button button-secondary field-data-remove">
                    <?php _e('X', 'useful-addons-elementor'); ?>
                </button>
            </div>
        <?php } 
    } ?>
</div>
<button type="button" id="field_data_add" class="button button-primary">
    <?php _e('Add', 'useful-addons-elementor'); ?>
</button>
