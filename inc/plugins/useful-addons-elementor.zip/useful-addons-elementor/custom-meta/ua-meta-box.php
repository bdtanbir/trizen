<?php


/**
 * Register meta boxes.
 */
if(function_exists('UA_elementor_custom_posttypes')) {
    function UA_register_meta_boxes() {
        add_meta_box( 'UA_metabox-1', __( 'Portfolio Personal Info', 'useful-addons-elementor' ), 'ua_portfolio_display_callback', 'portfolio', 'side', 'low' );
        add_meta_box( 'ua-metabox-team-contact-info', __( 'Team Contact Info', 'useful-addons-elementor' ), 'UA_team_meta_display_callback', 'team', 'side', 'low' );
        add_meta_box( 'ua-metabox-team-expt', __( 'Team Expertise', 'useful-addons-elementor' ), 'UA_team_expt_display_callback', 'team', 'side', 'low' );
        add_meta_box( 'ua-metabox-team-edc', __( 'Team Education', 'useful-addons-elementor' ), 'UA_team_edc_display_callback', 'team', 'side', 'low' );
        add_meta_box( 'ua-metabox-team-social', __( 'Team Social', 'useful-addons-elementor' ), 'UA_team_social_display_callback', 'team', 'side', 'low' );
    }
    add_action( 'add_meta_boxes', 'UA_register_meta_boxes' );


    /**
     * Save meta box content.
     * @param WP_Post $post
     */
    function UA_save_meta_box( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

        $expertise_items = !empty($_POST['team_expertise_item']) && is_array($_POST['team_expertise_item'])
            ? array_map('sanitize_text_field', $_POST['team_expertise_item'])
            : '' ;
        update_post_meta($post_id, 'team_expertise_item', $expertise_items);

        $expertise_items = !empty($_POST['team_education_item']) && is_array($_POST['team_education_item'])
            ? array_map('sanitize_text_field', $_POST['team_education_item'])
            : '' ;
        update_post_meta($post_id, 'team_education_item', $expertise_items);

        $fields = [
            'UA_portfolio_meta_client',
            'UA_portfolio_meta_website_txt',
            'UA_portfolio_meta_website_url',
            'tm_cnt_designation',
            'tm_cnt_address',
            'tm_cnt_num',
            'tm_cnt_gmail',
            'tm_cnt_website',
            'tm_cnt_website_url',
            'ua_team_social_fb',
            'ua_team_social_tw',
            'ua_team_social_ln',
            'ua_team_social_yt',
            'ua_team_social_gg',
            'ua_team_social_pt',
            'ua_team_social_gt',
            'ua_team_social_dd',
        ];
        foreach ( $fields as $field ) {
            if ( array_key_exists( $field, $_POST ) ) {
                update_post_meta( $post_id, $field, sanitize_text_field( $_POST[$field] ) );
            }
        }

    }

    add_action( 'save_post_portfolio', 'UA_save_meta_box', 10, 2 );
    add_action( 'save_post_team', 'UA_save_meta_box', 10, 2 );



    /**
     * Meta box display callback.
     * @param WP_Post $post Current post object.
     */
    function ua_portfolio_display_callback( $post ) {
        include UA_ELEMENTOR_PATH . 'custom-meta/portfolio-meta.php';
    }

    /**
     * Meta box display callback.
     * @param WP_Post $post Current post object.
     */
    function UA_team_meta_display_callback( $post ) {
        include UA_ELEMENTOR_PATH . 'custom-meta/team-meta-contact.php';
    }

    /**
     * Meta box display callback.
     * @param WP_Post $post Current post object.
     */
    function UA_team_expt_display_callback( $post ) {
        include UA_ELEMENTOR_PATH . 'custom-meta/team-meta-expertise.php';
    }

    /**
     * Meta box display callback.
     * @param WP_Post $post Current post object.
     */
    function UA_team_edc_display_callback( $post ) {
        include UA_ELEMENTOR_PATH . 'custom-meta/team-meta-education.php';
    }

    /**
     * Meta box display callback.
     * @param WP_Post $post Current post object.
     */
    function UA_team_social_display_callback( $post ) {
        include UA_ELEMENTOR_PATH . 'custom-meta/team-meta-social.php';
    }

}
