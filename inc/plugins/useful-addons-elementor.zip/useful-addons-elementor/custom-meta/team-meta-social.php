
<?php
    $social_fb = get_post_meta( get_the_ID(), 'ua_team_social_fb', true );
    $social_tw = get_post_meta( get_the_ID(), 'ua_team_social_tw', true );
    $social_ln = get_post_meta( get_the_ID(), 'ua_team_social_ln', true );
    $social_yt = get_post_meta( get_the_ID(), 'ua_team_social_yt', true );
    $social_gg = get_post_meta( get_the_ID(), 'ua_team_social_gg', true );
    $social_pt = get_post_meta( get_the_ID(), 'ua_team_social_pt', true );
    $social_gt = get_post_meta( get_the_ID(), 'ua_team_social_gt', true );
    $social_dd = get_post_meta( get_the_ID(), 'ua_team_social_dd', true );
?>


<div class="ua_team_social">
    <label for="ua_team_social_fb">
    <?php _e('Facebook: ', 'useful-addons-elementor'); ?>
    <input id="ua_team_social_fb"
            class="widefat"
           type="text"
           name="ua_team_social_fb"
           placeholder="<?php _e('https://facebook.com', 'useful-addons-elementor') ?>"
           value="<?php echo wp_kses_post( $social_fb ); ?>">
    </label>
</div>
<div class="ua_team_social">
    <label for="ua_team_social_tw">
    <?php _e('Twitter: ', 'useful-addons-elementor'); ?>
    <input id="ua_team_social_tw"
            class="widefat"
           type="text"
           name="ua_team_social_tw"
           placeholder="<?php _e('https://twitter.com', 'useful-addons-elementor'); ?>"
           value="<?php echo wp_kses_post( $social_tw ); ?>">
    </label>
</div>
<div class="ua_team_social">
    <label for="ua_team_social_ln">
    <?php _e('Linkedin: ', 'useful-addons-elementor'); ?>
    <input id="ua_team_social_ln"
            class="widefat"
           type="text"
           name="ua_team_social_ln"
           placeholder="<?php _e('https://linkedin.com', 'useful-addons-elementor') ?>"
           value="<?php echo wp_kses_post( $social_ln ); ?>">
    </label>
</div>
<div class="ua_team_social">
    <label for="ua_team_social_yt">
    <?php _e('YouTube: ', 'useful-addons-elementor'); ?>
    <input id="ua_team_social_yt"
            class="widefat"
           type="text"
           name="ua_team_social_yt"
           placeholder="<?php _e('https://youtube.com', 'useful-addons-elementor'); ?>"
           value="<?php echo wp_kses_post( $social_yt ); ?>">
    </label>
</div>
<div class="ua_team_social">
    <label for="ua_team_social_gg">
    <?php _e('Google+: ', 'useful-addons-elementor'); ?>
    <input id="ua_team_social_gg"
            class="widefat"
           type="text"
           name="ua_team_social_gg"
           placeholder="<?php _e('https://plus.google.com', 'useful-addons-elementor'); ?>"
           value="<?php echo wp_kses_post( $social_gg ); ?>">
    </label>
</div>
<div class="ua_team_social">
    <label for="ua_team_social_pt">
    <?php _e('Pinterest: ', 'useful-addons-elementor'); ?>
    <input id="ua_team_social_pt"
            class="widefat"
           type="text"
           name="ua_team_social_pt"
           placeholder="<?php _e('https://pinterest.com', 'useful-addons-elementor'); ?>"
           value="<?php echo wp_kses_post( $social_pt ); ?>">
    </label>
</div>
<div class="ua_team_social">
    <label for="ua_team_social_gt">
    <?php _e('Github: ', 'useful-addons-elementor'); ?>
    <input id="ua_team_social_gt"
            class="widefat"
           type="text"
           name="ua_team_social_gt"
           placeholder="<?php _e('https://github.com', 'useful-addons-elementor') ?>"
           value="<?php echo wp_kses_post( $social_gt ); ?>">
    </label>
</div>
<div class="ua_team_social">
    <label for="ua_team_social_dd">
    <?php _e('Dribbble: ', 'useful-addons-elementor'); ?>
    <input id="ua_team_social_dd"
            class="widefat"
           type="text"
           name="ua_team_social_dd"
           placeholder="<?php _e('https://dribbble.com', 'useful-addons-elementor'); ?>"
           value="<?php echo wp_kses_post( $social_dd ); ?>">
    </label>
</div>